<?php
/**
 * Página do jogador (15/11/2026): /jogador/<nome>/
 * Junta tudo o que a base do TSP tem sobre o jogador: figurinha, clube atual, idade, números e clubes de 2026,
 * selos, movimentos do mercado e a carreira (quando já levantada). Dados: api/mercado.json e api/elencos.json.
 * Dois jogadores com o mesmo nome em clubes diferentes: o endereço ganha o clube (/jogador/gabriel-oliveira-marilia/).
 * Não conflita com /jogador/<time>/<nome>/ (página de temporada do plugin TSP Jogos).
 */

if (!defined('ABSPATH')) {
    exit;
}

// 22/11/2026 (SEO): endereço de pessoa que não existe responde 404 de verdade (antes abria "Arquivos" com status 200,
// criando milhares de páginas vazias para o Google)
if (!function_exists('tsp_404_real')) {
    function tsp_404_real()
    {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        nocache_headers();
        $tpl = get_query_template('404');
        if ($tpl) {
            include $tpl;
        } else {
            get_header();
            echo '<main class="tsp-container"><h1>Página não encontrada</h1></main>';
            get_footer();
        }
        exit;
    }
}

// Índice de jogadores: chave = nome + clube atual; mercado e elenco do mesmo clube viram uma pessoa só
function tsp_mc_jogadores()
{
    static $idx = null;
    if ($idx !== null) {
        return $idx;
    }
    $pessoas = array();
    $add = function ($nome, $clube, $dados) use (&$pessoas) {
        $k = sanitize_title(remove_accents($nome)) . '|' . $clube;
        if (!isset($pessoas[$k])) {
            $pessoas[$k] = array('nome' => $nome, 'clube' => $clube, 'movimentos' => array());
        }
        foreach ($dados as $c => $v) {
            if ($c === 'movimento') {
                $pessoas[$k]['movimentos'][] = $v;
            } elseif ($v !== '' && $v !== array() && $v !== null && empty($pessoas[$k][$c])) {
                $pessoas[$k][$c] = $v;
            }
        }
    };
    foreach (tsp_mc_itens() as $m) {
        $sai = in_array($m['tipo'] ?? '', array('saida', 'venda'), true);
        $dono = $sai ? ($m['de']['slug'] ?? '') : ($m['para']['slug'] ?? '');
        $add($m['jogador'] ?? '', $dono, array(
            'movimento' => $m, 'foto' => $m['foto'] ?? array(), 'posicao' => $m['posicao'] ?? '', 'nascimento' => $m['nascimento'] ?? '',
            'numeros' => $m['numeros'] ?? array(), 'selos' => $m['selos'] ?? array(), 'carreira' => $m['carreira'] ?? array(),
            'saiu' => $sai, 'ficha' => $m['ficha'] ?? array(),
        ));
    }
    $d = tsp_mc_arquivo('elencos.json');
    foreach ((array) ($d['clubes'] ?? array()) as $slug => $el) {
        foreach ((array) ($el['jogadores'] ?? array()) as $x) {
            $add($x['nome'] ?? '', $slug, array(
                'foto' => $x['foto'] ?? array(), 'posicao' => $x['posicao'] ?? '', 'nascimento' => $x['nascimento'] ?? '',
                'numeros' => $x['numeros'] ?? array(), 'selos' => $x['selos'] ?? array(), 'numero' => $x['numero'] ?? '',
                'nacionalidade' => $x['nacionalidade'] ?? '', 'no_elenco' => true, 'ficha' => $x['ficha'] ?? array(),
            ));
        }
    }
    // Endereço: só o nome; nome repetido em clubes diferentes leva o clube junto
    $por_nome = array();
    foreach ($pessoas as $k => $p) {
        $por_nome[strtok($k, '|')][] = $k;
    }
    $idx = array();
    foreach ($por_nome as $n => $ks) {
        foreach ($ks as $k) {
            $p = $pessoas[$k];
            $u = count($ks) > 1 && $p['clube'] ? $n . '-' . $p['clube'] : $n;
            $p['url_slug'] = $u;
            $idx[$u] = $p;
        }
    }
    return $idx;
}

function tsp_mc_jog_url($nome, $clube = '')
{
    $n = sanitize_title(remove_accents((string) $nome));
    $idx = tsp_mc_jogadores();
    $u = isset($idx[$n . '-' . $clube]) ? $n . '-' . $clube : $n;
    // Comissão técnica tem endereço próprio: /treinador/<clube>/<nome>/ (21/11/2026)
    if (isset($idx[$u]) && function_exists('tsp_tec_e_comissao') && tsp_tec_e_comissao($idx[$u])) {
        return tsp_tec_url($idx[$u]);
    }
    return home_url('/jogador/' . $u . '/');
}

add_action('init', function () {
    add_rewrite_rule('^jogador/([a-z0-9-]+)/?$', 'index.php?tsp_jog=$matches[1]', 'top');
    if (get_option('tsp_jog_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_jog_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_jog';
    return $v;
});

add_action('template_redirect', function () {
    $u = get_query_var('tsp_jog');
    if (!$u) {
        return;
    }
    $idx = tsp_mc_jogadores();
    if (!isset($idx[$u])) {
        tsp_404_real();
    }
    $p = $idx[$u];
    if (function_exists('tsp_tec_e_comissao') && tsp_tec_e_comissao($p)) {
        wp_safe_redirect(tsp_tec_url($p), 301);
        exit;
    }
    $t = $p['clube'] ? get_term_by('slug', $p['clube'], 'times') : null;
    $clube_nome = $t ? $t->name : '';
    $idade = tsp_mc_idade($p['nascimento'] ?? '') ?: (int) ($p['ficha']['idade'] ?? 0);
    $n = (array) ($p['numeros'] ?? array());
    $com = function_exists('tsp_mc_e_comissao_pos') && tsp_mc_e_comissao_pos($p['posicao'] ?? '');
    $titulo = $p['nome'] . ($clube_nome ? ' (' . $clube_nome . ')' : '') . ': carreira, números e clubes';
    $resumo = $p['nome'] . (!empty($p['posicao']) ? ', ' . mb_strtolower($p['posicao']) : '') . ($idade ? ', ' . $idade . ' anos' : '')
        . ($clube_nome ? (!empty($p['saiu']) ? ', deixou o ' . $clube_nome : ($com ? ', trabalha no ' : ', joga no ') . $clube_nome . ' em 2027') : '') . '.'
        . (!empty($n['jogos']) ? ' Em 2026: ' . (int) $n['jogos'] . ' jogos' . (isset($n['gols']) ? ', ' . (int) $n['gols'] . ((int) $n['gols'] === 1 ? ' gol' : ' gols') : '') . (isset($n['assistencias']) ? ', ' . (int) $n['assistencias'] . ((int) $n['assistencias'] === 1 ? ' assistência' : ' assistências') : '') . (!empty($n['clubes']) ? ' (' . implode(', ', (array) $n['clubes']) . ')' : '') . '.' : '');
    foreach (array('pre_get_document_title', 'wpseo_title') as $f) {
        add_filter($f, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($resumo) {
        return mb_substr($resumo, 0, 155);
    }, 99);
    $canon = home_url('/jogador/' . $u . '/');
    add_filter('wpseo_canonical', function () use ($canon) {
        return $canon;
    }, 99);
    add_filter('wpseo_opengraph_url', function () use ($canon) {
        return $canon;
    }, 99);
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    $foto = (array) ($p['foto'] ?? array());
    echo '<main class="tsp-container tsp-jog">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › '
        . ($t ? '<a href="' . esc_url(get_term_link($t)) . '">' . esc_html($clube_nome) . '</a> › ' : '<a href="' . esc_url(home_url('/mercado-da-bola/')) . '">Mercado da Bola</a> › ')
        . '<span>' . esc_html($p['nome']) . '</span></nav>';
    echo '<header class="tsp-jog__cab">';
    echo '<div class="tsp-jog__foto">' . tsp_mc_foto($p['nome'], $foto, 220, false) . '</div>';
    echo '<div class="tsp-jog__id"><h1>' . esc_html($p['nome']) . '</h1>';
    if ($t) {
        echo '<a class="tsp-jog__clube" href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 28) . '<span>' . esc_html($clube_nome) . (!empty($p['saiu']) ? ' (saiu)' : ' · 2027') . '</span></a>';
    }
    $fatos = array_filter(array(
        $p['posicao'] ?? '',
        $idade ? $idade . ' anos' . (!empty($p['nascimento']) ? ' (nasceu em ' . wp_date('d/m/Y', strtotime($p['nascimento'] . ' 12:00')) . ')' : '') : '',
        !empty($p['nacionalidade']) && $p['nacionalidade'] !== 'Brasil' ? $p['nacionalidade'] : '',
        !empty($p['numero']) ? 'camisa ' . (int) $p['numero'] : '',
    ));
    echo $fatos ? '<p class="tsp-jog__fatos">' . esc_html(implode(' · ', $fatos)) . '</p>' : '';
    echo '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resumo) . '</p></div>';
    echo tsp_mc_selos_html((array) ($p['selos'] ?? array()));
    echo tsp_mc_ficha_html($p, false, true);
    echo '</div></header>';

    // Números de 2026
    if ($n) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__num"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Números em 2026</h2></div></div><div class="tsp-jog__nums">';
        foreach (array('jogos' => 'jogos', 'minutos' => 'minutos', 'gols' => 'gols', 'assistencias' => 'assistências') as $c => $r) {
            if (isset($n[$c]) && $n[$c] !== '') {
                echo '<div><b>' . esc_html(number_format_i18n((int) $n[$c])) . '</b><span>' . esc_html($r) . '</span></div>';
            }
        }
        echo '</div>';
        if (!empty($n['clubes'])) {
            $esc = (array) ($n['escudos'] ?? array());
            echo '<p class="tsp-jog__clubes">Clubes em 2026: ' . implode(' ', array_map(function ($c) use ($esc) {
                $logo = tsp_mc_escudo(array('nome' => $c, 'escudo' => $esc[$c] ?? ''), 20);
                return '<span class="tsp-fig__clube">' . (strpos($logo, '<img') !== false ? $logo : '') . esc_html($c) . '</span>';
            }, (array) $n['clubes'])) . '</p>';
        }
        echo '</section>';
    } else {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__num"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Números em 2026</h2></div></div>' . '<p class="tsp-atualiza">Em atualização</p>' . '</section>';
    }

    // Carreira (temporada a temporada), quando já levantada
    if (!empty($p['carreira'])) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__carreira"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Carreira</h2></div></div>';
        echo '<div class="tsp-tabela-rolagem"><table class="tsp-tabela"><thead><tr><th>Temporada</th><th>Clube</th><th>Jogos</th><th>Gols</th><th>Assist.</th></tr></thead><tbody>';
        foreach ((array) $p['carreira'] as $c) {
            $logo = tsp_mc_escudo(array('nome' => $c['clube'] ?? '', 'escudo' => $c['escudo'] ?? ''), 18);
            echo '<tr><td>' . esc_html($c['temporada'] ?? '') . '</td><td><span class="tsp-fig__clube">' . (strpos($logo, '<img') !== false ? $logo : '') . esc_html($c['clube'] ?? '') . (!empty($c['emprestimo']) ? ' <small>(empréstimo)</small>' : '') . '</span></td>'
                . '<td>' . esc_html($c['jogos'] ?? '-') . '</td><td>' . esc_html($c['gols'] ?? '-') . '</td><td>' . esc_html($c['assistencias'] ?? '-') . '</td></tr>';
        }
        echo '</tbody></table></div></section>';
    } else {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__carreira"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Carreira</h2></div></div>' . '<p class="tsp-atualiza">Em atualização</p>' . '</section>';
    }

    // Mercado da bola
    if (!empty($p['movimentos'])) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__mercado"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Mercado da Bola</h2></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/')) . '">Mercado completo →</a></span></div><ul class="tsp-jog__movs">';
        foreach ($p['movimentos'] as $m) {
            $rota = trim(($m['de']['nome'] ?? '') . (!empty($m['para']['nome']) ? ' → ' . $m['para']['nome'] : ''), ' →');
            echo '<li><time datetime="' . esc_attr($m['data']) . '">' . esc_html(wp_date('d/m/Y', strtotime($m['data'] . ' 12:00'))) . '</time> <b>' . esc_html($m['tipo_nome'] ?? '') . '</b> ' . esc_html($rota)
                . (!empty($m['obs']) ? ' <small>' . esc_html($m['obs']) . '</small>' : '') . '</li>';
        }
        echo '</ul></section>';
    }

    // Jogos de 2026 na base do TSP (página de temporada do plugin), quando existir
    if ($p['clube'] && function_exists('tsp_tf_jog_url') && function_exists('tsp_jogos_api_do_slug') && function_exists('tsp_jogos_base_times')) {
        $tid = tsp_jogos_api_do_slug($p['clube']);
        $bt = $tid ? tsp_jogos_base_times() : array();
        if (!empty($bt[$tid]['chave']) && !empty($p['no_elenco']) && empty($p['movimentos'])) {
            echo '<p><a class="tsp-vertudo" href="' . esc_url(tsp_tf_jog_url($bt[$tid]['chave'], $p['nome'])) . '">Jogos de ' . esc_html($p['nome']) . ' na temporada →</a></p>';
        }
    }

    $notas = array('Dados conferidos pelo TSP: movimentos com anúncio oficial e imprensa; números de 2026 e carreira conferidos em matérias e fontes do futebol.');
    if (!empty($foto['ia'])) {
        $notas[] = 'Figurinha: montagem com IA, ilustrativa, feita a partir da foto oficial de anúncio do jogador.';
    }
    echo '<p class="tsp-nota">' . esc_html(implode(' ', $notas)) . '</p>';
    // Dados estruturados (Person)
    $ld = array('@context' => 'https://schema.org', '@type' => 'Person', 'name' => $p['nome'], 'url' => $canon, 'jobTitle' => 'Jogador de futebol');
    if (!empty($p['nascimento'])) {
        $ld['birthDate'] = $p['nascimento'];
    }
    if ($clube_nome && empty($p['saiu'])) {
        $ld['memberOf'] = array('@type' => 'SportsTeam', 'name' => $clube_nome);
    }
    echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    echo '</main>';
    get_footer();
    exit;
});
