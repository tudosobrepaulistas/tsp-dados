<?php
/**
 * Vitrine de ofertas (Mercado Livre e Shopee, links de afiliado do TSP por clube).
 * Os produtos chegam pelo plugin TSP Jogos (opção tsp_ofertas, lida da Base TSP).
 * Aparece: na página do clube (depois do painel de jogos), no meio da matéria (depois do 3º parágrafo,
 * em matérias com 6 parágrafos ou mais) e no fim da matéria. Só para clubes que têm lista.
 * Todo clique vai para a lista de afiliado do TSP (rel="sponsored"), com aviso de transparência.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_ofertas_do_clube($slug)
{
    $of = get_option('tsp_ofertas', array());
    $clubes = (array) ($of['clubes'] ?? array());
    $chave = function_exists('tsp_clube_slug_pai') ? tsp_clube_slug_pai($slug) : $slug;
    $c = $clubes[$chave] ?? ($clubes[$slug] ?? null);
    // Produtos da Shopee (plugin TSP Ofertas Shopee), só do mesmo clube
    $sh = function_exists('tsp_shopee_produtos') ? tsp_shopee_produtos($chave) : array();
    if (!$sh && $chave !== $slug && function_exists('tsp_shopee_produtos')) {
        $sh = tsp_shopee_produtos($slug);
    }
    if (!$c && !$sh) {
        return null;
    }
    $c = is_array($c) ? $c : array('lista' => '', 'produtos' => array());
    foreach ((array) $c['produtos'] as $i => $p) {
        $c['produtos'][$i]['loja'] = 'Mercado Livre';
        $c['produtos'][$i]['antigo'] = $p['antigo'] ?? ($p['preco_antigo'] ?? '');
    }
    $c['produtos'] = array_merge((array) $c['produtos'], $sh);
    $c['lojas'] = array_values(array_unique(wp_list_pluck($c['produtos'], 'loja')));
    return $c['produtos'] ? $c : null;
}

// Clube da matéria que tem vitrine: SÓ o clube principal da matéria (o do selo no topo).
// Matéria do Bragantino nunca mostra produtos do Santos, mesmo que o Santos seja citado.
function tsp_ofertas_clube_do_post($post_id)
{
    $t = function_exists('tsp_time_do_post') ? tsp_time_do_post($post_id) : null;
    return ($t && tsp_ofertas_do_clube($t->slug)) ? $t : null;
}

// Vitrine geral (eletrônicos e futebol para todo torcedor), da Shopee
function tsp_ofertas_geral()
{
    $p = function_exists('tsp_shopee_produtos') ? tsp_shopee_produtos('_geral') : array();
    return $p ? array('lista' => '', 'produtos' => $p, 'lojas' => array('Shopee')) : null;
}

// $termo = clube; sem clube (null) = vitrine geral
function tsp_ofertas_html($termo, $onde = 'clube', $qtd = 10)
{
    $c = $termo ? tsp_ofertas_do_clube($termo->slug) : tsp_ofertas_geral();
    if (!$c || empty($c['produtos'])) {
        return '';
    }
    $prods = $c['produtos'];
    // Gira a ordem por dia e por lugar, para o leitor ver produtos diferentes no meio e no fim
    $semente = crc32(wp_date('Y-m-d') . $onde . get_the_ID());
    usort($prods, function ($a, $b) use ($semente) {
        return crc32($a['img'] . $semente) <=> crc32($b['img'] . $semente);
    });
    $prods = array_slice($prods, 0, $qtd);
    $lista = $c['lista'];
    $lojas = array_intersect($c['lojas'] ?? array('Mercado Livre'), wp_list_pluck($prods, 'loja')) ?: ($c['lojas'] ?? array('Mercado Livre'));
    $onde_loja = implode(' e ', array_map(function ($l) {
        return ($l === 'Shopee' ? 'na ' : 'no ') . $l;
    }, $lojas));
    $nome = $termo ? preg_replace('~ (Feminino|Sub-\d+)$~i', '', $termo->name) : 'para torcedores';
    $cores = ($termo && function_exists('tsp_clube_cores')) ? tsp_clube_cores($termo) : array('#E8862A', '#111111');
    $rel = 'sponsored nofollow noopener';
    $h = '<aside class="tsp-ofertas tsp-ofertas--' . esc_attr($onde) . '" style="--of-cor:' . esc_attr($cores[0]) . ';--of-txt:' . esc_attr($cores[1]) . '" aria-label="Ofertas ' . esc_attr($nome) . ' ' . esc_attr($onde_loja) . '">';
    $h .= '<div class="tsp-ofertas__cab"><p class="tsp-ofertas__tit">' . esc_html($termo ? 'Produtos ' . (function_exists('tsp_de') ? tsp_de($termo) : 'do ' . $nome) : 'Ofertas para quem ama futebol') . ' <span>' . esc_html($onde_loja) . '</span></p>';
    // Hook + corpo curto (08/11/2026): convite para o torcedor, sem prometer o que a loja não garante
    $de = $termo ? (function_exists('tsp_de') ? tsp_de($termo) : 'do ' . $nome) : '';
    $hooks = $termo ? array('Leve o ' . $nome . ' com você', 'Torcedor ' . $de . ' se veste assim', 'Mostre de que lado você está', 'Para usar no próximo jogo ' . $de) : array('Para quem vive futebol');
    $hk = $hooks[crc32(wp_date('Y-m-d') . $onde) % count($hooks)];
    $h .= '<p class="tsp-ofertas__hook"><strong>' . esc_html($hk) . '.</strong> ' . esc_html('Camisas, agasalhos e acessórios para torcedores ' . ($termo ? $de : '') . ' selecionados ' . $onde_loja . '. Você compra direto na loja.') . '</p>';
    $h .= '<div class="tsp-ofertas__nav"><button type="button" data-of="-1" aria-label="Ofertas anteriores">‹</button><button type="button" data-of="1" aria-label="Mais ofertas">›</button></div></div>';
    $h .= '<ul class="tsp-ofertas__trilho">';
    foreach ($prods as $p) {
        $h .= '<li><a href="' . esc_url(!empty($p['link']) ? $p['link'] : $lista) . '" target="_blank" rel="' . $rel . '">';
        $h .= '<span class="tsp-ofertas__img"><img src="' . esc_url($p['img']) . '" alt="" width="160" height="160" loading="lazy" decoding="async" referrerpolicy="no-referrer"></span>';
        $h .= '<span class="tsp-ofertas__nome">' . esc_html($p['titulo']) . '</span>';
        if (($p['antigo'] ?? '') !== '') {
            $h .= '<s class="tsp-ofertas__antigo">R$ ' . esc_html($p['antigo']) . '</s>';
        }
        if (($p['preco'] ?? '') !== '') {
            $h .= '<strong class="tsp-ofertas__preco">R$ ' . esc_html($p['preco']) . '</strong>';
        }
        $h .= '</a></li>';
    }
    $h .= '</ul><div class="tsp-ofertas__rod">' . ($lista ? '<a class="tsp-ofertas__todas" href="' . esc_url($lista) . '" target="_blank" rel="' . $rel . '">' . esc_html($termo ? 'Ver todos os produtos ' . $de . ' →' : 'Ver todas as ofertas →') . '</a>' : '');
    $h .= '<small>Os produtos são anunciados, vendidos e entregues pelos marketplaces (' . esc_html(implode(', ', $lojas)) . ') e seus vendedores. O Tudo Sobre Paulista só indica as ofertas: não vende, não entrega e não responde pela qualidade, garantia, troca ou entrega dos produtos. Dúvidas e trocas são com a loja. Links de afiliado: o TSP pode receber comissão, sem custo extra para você. Preços e estoque podem mudar.</small></div></aside>';
    return $h;
}

// Meio e fim da matéria (tipos Matéria e Post; jogos e páginas ficam de fora)
// Onde a vitrine entra no meio do texto: depois de ~40% do texto, num fim de parágrafo
// (conta tanto <p> quanto quebras duplas <br><br>, que muitos redatores usam)
function tsp_ofertas_inserir_meio($html, $vitrine)
{
    if ($vitrine === '') {
        return $html;
    }
    $total = mb_strlen(wp_strip_all_tags($html));
    if ($total < 900) {
        return $html;
    }
    if (!preg_match_all('~</p>|(?:<br\s*/?>\s*){2,}~i', $html, $m, PREG_OFFSET_CAPTURE)) {
        return $html;
    }
    $passou = 0;
    foreach ($m[0] as $x) {
        $fim = $x[1] + strlen($x[0]);
        $antes = substr($html, 0, $fim);
        $passou++;
        $dentro = substr_count(strtolower($antes), '<blockquote') > substr_count(strtolower($antes), '</blockquote')
            || preg_match_all('~<li[\s>]~i', $antes) > substr_count(strtolower($antes), '</li>')
            || substr_count(strtolower($antes), '<table') > substr_count(strtolower($antes), '</table');
        if ($dentro || $passou < 2 || mb_strlen(wp_strip_all_tags($antes)) < $total * 0.35) {
            continue;
        }
        if (stripos($x[0], '</p>') === 0) {
            return $antes . $vitrine . substr($html, $fim);
        }
        // quebra dupla dentro de um parágrafo: fecha o parágrafo, põe a vitrine e reabre
        return substr($html, 0, $x[1]) . '</p>' . $vitrine . '<p>' . substr($html, $fim);
    }
    return $html;
}

add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $html;
    }
    $t = tsp_ofertas_clube_do_post(get_the_ID());
    // Com produtos do clube: no meio, os do clube; no fim, a vitrine geral (alterna clube e eletrônicos/futebol).
    // Sem produtos do clube: só a vitrine geral, no meio.
    if ($t) {
        $html = tsp_ofertas_inserir_meio($html, tsp_ofertas_html($t, 'meio', 8));
        return $html . tsp_ofertas_html(null, 'fim', 10);
    }
    return tsp_ofertas_inserir_meio($html, tsp_ofertas_html(null, 'meio', 8));
}, 30);
