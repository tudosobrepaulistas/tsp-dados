<?php
/**
 * Links internos automáticos (08/11/2026): em toda matéria, a 1ª vez que aparecem no texto,
 *  - o nome de um clube vira link para a página do clube (página pilar do clube);
 *  - o nome de um campeonato vira link para a página do campeonato (página pilar do campeonato);
 *  - o nome de um jogador/técnico marcado nas tags da matéria vira link para a página dele (tag com 3+ matérias).
 * Não mexe em títulos, links que já existem, legendas, citações nem no nome do clube da própria página.
 * No máximo 8 links por matéria. Sem custo: tudo sai do próprio WordPress.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_links_dicionario()
{
    $d = get_transient('tsp_links_dic_v1');
    if (is_array($d)) {
        return $d;
    }
    $d = array();
    // Clubes (os 150 mais citados)
    $times = get_terms(array('taxonomy' => 'times', 'hide_empty' => true, 'number' => 150, 'orderby' => 'count', 'order' => 'DESC'));
    foreach ((is_array($times) ? $times : array()) as $t) {
        $l = get_term_link($t);
        if (!is_wp_error($l) && mb_strlen($t->name) >= 4) {
            $d[$t->name] = $l;
        }
    }
    // Campeonatos, com os nomes que a redação usa no texto
    $camp = array(
        'brasileiro-serie-a' => array('Brasileirão Série A', 'Série A do Brasileirão', 'Série A do Campeonato Brasileiro'),
        'brasileiro-serie-b' => array('Série B do Brasileirão', 'Brasileirão Série B', 'Série B do Campeonato Brasileiro', 'Série B'),
        'brasileiro-serie-c' => array('Série C'),
        'brasileiro-serie-d' => array('Série D'),
        'copadobrasil' => array('Copa do Brasil'),
        'libertadores' => array('Libertadores'),
        'sulamericana' => array('Copa Sul-Americana', 'Sul-Americana'),
        'paulistao-a1' => array('Paulistão A1', 'Paulistão'),
        'paulistao-a2' => array('Paulistão A2', 'Série A2', 'A2 do Paulista'),
        'paulistao-a3' => array('Paulistão A3', 'Série A3', 'A3 do Paulista'),
        'paulistao-a4' => array('Paulistão A4', 'Série A4', 'A4 do Paulista'),
        'paulistao-b1' => array('Segunda Divisão Paulista', 'Bezinha'),
        'copapaulista' => array('Copa Paulista'),
        'copinha' => array('Copinha', 'Copa São Paulo de Futebol Júnior'),
        'paulistao-feminino' => array('Paulistão Feminino', 'Paulista Feminino'),
        'brasileirao-feminino' => array('Brasileirão Feminino', 'Brasileiro Feminino'),
        'copadobrasil-feminina' => array('Copa do Brasil Feminina'),
    );
    foreach ($camp as $slug => $nomes) {
        $t = get_term_by('slug', $slug, 'campeonato');
        if (!$t) {
            continue;
        }
        $l = get_term_link($t);
        if (is_wp_error($l)) {
            continue;
        }
        foreach ($nomes as $n) {
            $d[$n] = $l;
        }
    }
    set_transient('tsp_links_dic_v1', $d, 12 * HOUR_IN_SECONDS);
    return $d;
}
add_action('created_times', function () {
    delete_transient('tsp_links_dic_v1');
});

function tsp_links_aplicar($html, $post_id)
{
    $dic = tsp_links_dicionario();
    // Jogadores/técnicos: tags da matéria que são nome próprio (não clube nem campeonato) e têm 3+ matérias
    $tags = get_the_tags($post_id);
    $nomes_dic = array_map('mb_strtolower', array_keys($dic));
    foreach ((is_array($tags) ? $tags : array()) as $t) {
        if ($t->count < 3 || mb_strlen($t->name) < 4 || in_array(mb_strtolower($t->name), $nomes_dic, true) || preg_match('~not[íi]cias|mercado|futebol|s[ée]rie|brasileir|copa|paulist|campeonato|jogo|onde assistir|escala|ingresso|tabela|classifica|resultado|feminino|sub-?\d~iu', $t->name)) {
            continue;
        }
        $dic['#tag#' . $t->name] = get_tag_link($t);
    }
    // Não linkar a própria página do clube principal da matéria duas vezes nem para o mesmo destino repetido
    uksort($dic, function ($a, $b) {
        return mb_strlen(str_replace('#tag#', '', $b)) - mb_strlen(str_replace('#tag#', '', $a));
    });
    $partes = preg_split('~(<[^>]+>)~', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    $bloqueio = 0;
    $usados = array();
    $destinos = array();
    $total = 0;
    $ph = array();
    foreach ($partes as $i => $p) {
        if ($p === '' || $total >= 8) {
            continue;
        }
        if ($p[0] === '<') {
            if (preg_match('~^<(a|h[1-6]|figcaption|blockquote|script|style|button|strong class="tsp|code)\b~i', $p)) {
                $bloqueio++;
            } elseif (preg_match('~^</(a|h[1-6]|figcaption|blockquote|script|style|button|code)>~i', $p)) {
                $bloqueio = max(0, $bloqueio - 1);
            }
            continue;
        }
        if ($bloqueio) {
            continue;
        }
        foreach ($dic as $nome => $url) {
            if ($total >= 8) {
                break;
            }
            $tag = strpos($nome, '#tag#') === 0;
            $txt = $tag ? substr($nome, 5) : $nome;
            if (isset($usados[mb_strtolower($txt)]) || isset($destinos[$url])) {
                continue;
            }
            // Tag de jogador: só se aparece com inicial maiúscula (nome próprio). "São Paulo" cidade (em/de São Paulo) não vira link de clube.
            $re = '~(?<![\p{L}\p{N}>/-])(' . preg_quote($txt, '~') . ')(?![\p{L}\p{N}])~u' . ($tag ? '' : 'i');
            if ($txt === 'São Paulo') {
                $re = '~(?<![\p{L}])(?<!em )(?<!de )(?<!do )(?<!estado de )(São Paulo)(?![\p{L}])(?! \(SP\))(?!-SP)~u';
            }
            if (!preg_match($re, $p, $m, PREG_OFFSET_CAPTURE)) {
                continue;
            }
            if (!$tag && $m[1][0] !== $txt && mb_strtolower($m[1][0]) === mb_strtolower($txt) && preg_match('~^\p{Ll}~u', $m[1][0])) {
                continue; // "santos" minúsculo (ex.: plural comum) não vira link
            }
            $ph[] = '<a href="' . esc_url($url) . '" class="tsp-link-interno">' . $m[1][0] . '</a>';
            $p = substr($p, 0, $m[1][1]) . "\x01" . (count($ph) - 1) . "\x02" . substr($p, $m[1][1] + strlen($m[1][0]));
            $usados[mb_strtolower($txt)] = 1;
            $destinos[$url] = 1;
            $total++;
        }
        $partes[$i] = $p;
    }
    return preg_replace_callback('~\x01(\d+)\x02~', function ($m) use ($ph) {
        return $ph[(int) $m[1]];
    }, implode('', $partes));
}

add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $html;
    }
    return tsp_links_aplicar($html, get_the_ID());
}, 30);
