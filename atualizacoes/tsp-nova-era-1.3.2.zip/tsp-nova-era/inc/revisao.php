<?php
/**
 * Revisor automático das matérias (rede de segurança para quando a redação esquece algo).
 * Ao publicar ou atualizar:
 *  - preenche sozinho o que dá para preencher sem inventar: texto alternativo da foto (título da matéria)
 *    e meta descrição do Yoast (1º parágrafo, até 155 caracteres);
 *  - aponta o que só a redação pode resolver: foto sem crédito, matéria sem time marcado, sem foto, título longo.
 * Lista em Ferramentas → TSP · Revisão. Fotos novas: no máximo 1920 px e qualidade 82 (leves e nítidas).
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('big_image_size_threshold', function () {
    return 1920;
});
add_filter('jpeg_quality', function () {
    return 82;
});
add_filter('wp_editor_set_quality', function () {
    return 82;
});

function tsp_revisar_materia($post_id)
{
    $p = get_post($post_id);
    if (!$p || $p->post_status !== 'publish' || !in_array($p->post_type, tsp_tipos(), true)) {
        return array();
    }
    $falta = array();
    $foto = get_post_thumbnail_id($post_id);
    if (!$foto) {
        $falta[] = 'Sem foto de destaque';
    } else {
        if (tsp_credito_foto($post_id) === '') {
            $falta[] = 'Foto sem crédito (preencha "Crédito da imagem": Foto: Nome / Clube)';
        }
        if (trim((string) get_post_meta($foto, '_wp_attachment_image_alt', true)) === '') {
            update_post_meta($foto, '_wp_attachment_image_alt', wp_strip_all_tags($p->post_title));
        }
    }
    $times = taxonomy_exists('times') ? wp_get_post_terms($post_id, 'times', array('fields' => 'ids')) : array();
    if (!$times || is_wp_error($times)) {
        $falta[] = 'Sem time marcado (a matéria não aparece no bloco nem na página do clube)';
    }
    if (mb_strlen($p->post_title) > 75) {
        $falta[] = 'Título com mais de 75 caracteres (o Google corta)';
    }
    if (defined('WPSEO_VERSION') && trim((string) get_post_meta($post_id, '_yoast_wpseo_metadesc', true)) === '') {
        $txt = $p->post_excerpt ? $p->post_excerpt : $p->post_content;
        $txt = trim(preg_replace('~\s+~', ' ', wp_strip_all_tags(strip_shortcodes($txt))));
        if ($txt) {
            $d = mb_substr($txt, 0, 155);
            if (mb_strlen($txt) > 155) {
                $d = preg_replace('~\s+\S*$~u', '', mb_substr($txt, 0, 152)) . '...';
            }
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $d);
            update_post_meta($post_id, 'tsp_metadesc_auto', $d);
        }
    }
    update_post_meta($post_id, 'tsp_revisao', $falta);
    return $falta;
}

add_action('save_post', function ($post_id, $post) {
    if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) {
        return;
    }
    tsp_revisar_materia($post_id);
}, 30, 2);

add_action('admin_menu', function () {
    add_management_page('TSP · Revisão', 'TSP · Revisão', 'edit_others_posts', 'tsp-revisao', function () {
        $q = new WP_Query(array('post_type' => tsp_tipos(), 'post_status' => 'publish', 'posts_per_page' => 60, 'no_found_rows' => true));
        echo '<div class="wrap"><h1>TSP · Revisão das matérias</h1><p>Últimas 60 matérias publicadas. O texto alternativo da foto e a meta descrição já são preenchidos sozinhos; os itens abaixo só a redação pode resolver.</p><table class="widefat striped"><thead><tr><th>Matéria</th><th>O que falta</th></tr></thead><tbody>';
        $ok = 0;
        foreach ($q->posts as $p) {
            $f = tsp_revisar_materia($p->ID);
            if (!$f) {
                $ok++;
                continue;
            }
            echo '<tr><td><a href="' . esc_url(get_edit_post_link($p->ID)) . '">' . esc_html($p->post_title) . '</a><br><small>' . esc_html(get_the_date('d/m H\hi', $p)) . '</small></td><td>' . esc_html(implode(' · ', $f)) . '</td></tr>';
        }
        echo '</tbody></table><p>' . (int) $ok . ' matéria(s) sem pendência.</p></div>';
    });
});

// Aviso no editor (editor clássico) quando a matéria publicada tem pendência
add_action('admin_notices', function () {
    $s = get_current_screen();
    if (!$s || $s->base !== 'post' || empty($_GET['post'])) {
        return;
    }
    $f = get_post_meta((int) $_GET['post'], 'tsp_revisao', true);
    if ($f && is_array($f)) {
        echo '<div class="notice notice-warning"><p><strong>Revisão TSP:</strong> ' . esc_html(implode(' · ', $f)) . '</p></div>';
    }
});

// Toda matéria precisa estar ligada a um clube OU a um campeonato (08/11/2026). Sem isso o editor não publica e avisa.
function tsp_rev_exigir_vinculo($prep, $request)
{
    $st = $request['status'] ?? '';
    $id = (int) ($request['id'] ?? 0);
    if ($st === '' && $id) {
        $st = get_post_status($id);
    }
    if (!in_array($st, array('publish', 'future'), true)) {
        return $prep;
    }
    $tem = function ($tax) use ($request, $id) {
        if (isset($request[$tax])) {
            return !empty(array_filter((array) $request[$tax]));
        }
        if ($id && taxonomy_exists($tax)) {
            $t = wp_get_post_terms($id, $tax, array('fields' => 'ids'));
            return $t && !is_wp_error($t);
        }
        return false;
    };
    if (!$tem('times') && !$tem('campeonato')) {
        return new WP_Error('tsp_sem_vinculo', 'Antes de publicar, marque o clube (Times) ou o campeonato da matéria. Notícia da CBF ou da FPF: marque o campeonato (ex.: Paulistão A2, Brasileiro Série B, Paulistão Feminino).', array('status' => 400));
    }
    return $prep;
}
foreach (array('materia', 'post') as $tsp_tp) {
    add_filter('rest_pre_insert_' . $tsp_tp, 'tsp_rev_exigir_vinculo', 10, 2);
}
// Editor clássico (sem REST): volta para rascunho e avisa
add_filter('wp_insert_post_data', function ($data, $postarr) {
    if (defined('REST_REQUEST') || !is_admin() || !in_array($data['post_type'], tsp_tipos(), true) || !in_array($data['post_status'], array('publish', 'future'), true) || !isset($postarr['tax_input'])) {
        return $data;
    }
    $ti = (array) $postarr['tax_input'];
    $tem = !empty(array_filter((array) ($ti['times'] ?? array()))) || !empty(array_filter((array) ($ti['campeonato'] ?? array())));
    if (!$tem) {
        $data['post_status'] = 'draft';
        set_transient('tsp_rev_vinculo_' . get_current_user_id(), 1, 120);
    }
    return $data;
}, 20, 2);
add_action('admin_notices', function () {
    if (get_transient('tsp_rev_vinculo_' . get_current_user_id())) {
        delete_transient('tsp_rev_vinculo_' . get_current_user_id());
        echo '<div class="notice notice-error"><p><strong>A matéria voltou para rascunho:</strong> marque o clube (Times) ou o campeonato antes de publicar.</p></div>';
    }
});
