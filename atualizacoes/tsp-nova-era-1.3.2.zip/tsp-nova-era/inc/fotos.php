<?php
/**
 * Textos das fotos para o Google (08/11/2026, pedido do Thiago).
 * Toda foto de matéria ganha sozinha, sem inventar nada:
 *  - Texto alternativo: o que a foto mostra (quando a Máquina informa) ou "Clube: título da matéria";
 *  - Título: o título da matéria (no lugar de nomes de arquivo como "Tani-fsta-campeao-R...");
 *  - Legenda: o crédito ("Foto: Nome/Clube");
 *  - Descrição: frase com matéria, clube, campeonato e crédito.
 * Só preenche campo vazio (ou nome de arquivo). O que a redação escreveu à mão fica.
 * Fotos antigas: um robô do próprio site passa por todas as matérias, aos poucos (150 a cada 5 minutos).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_foto_nome_arquivo($t)
{
    $t = trim((string) $t);
    return $t === '' || (strpos($t, ' ') === false && preg_match('~[-_]|\d{3,}|^(img|dsc|whatsapp|foto|image)~i', $t)) || preg_match('~\.(jpe?g|png|webp|gif)$~i', $t);
}

function tsp_foto_preencher($aid, $post_id)
{
    $aid = (int) $aid;
    $p = get_post($post_id);
    $a = get_post($aid);
    if (!$p || !$a || $a->post_type !== 'attachment' || !in_array($p->post_type, tsp_tipos(), true)) {
        return false;
    }
    $titulo = trim(wp_strip_all_tags(html_entity_decode($p->post_title, ENT_QUOTES, 'UTF-8')));
    if ($titulo === '') {
        return false;
    }
    $clubes = taxonomy_exists('times') ? wp_get_post_terms($post_id, 'times', array('fields' => 'names')) : array();
    $clubes = is_wp_error($clubes) ? array() : array_slice($clubes, 0, 3);
    $camps = taxonomy_exists('campeonato') ? wp_get_post_terms($post_id, 'campeonato', array('fields' => 'names')) : array();
    $camp = (!is_wp_error($camps) && $camps) ? $camps[0] : '';
    $cred = function_exists('tsp_credito_foto') ? tsp_credito_foto($post_id) : '';
    if ($cred === '') {
        $cred = trim((string) get_post_meta($aid, 'tsp_credito', true));
    }
    if ($cred !== '' && !preg_match('/^(foto|imagem|reprodu)/iu', $cred)) {
        $cred = 'Foto: ' . $cred;
    }
    $mostra = trim((string) get_post_meta($aid, 'tsp_foto_mostra', true));

    $mudou = false;
    $alt = trim((string) get_post_meta($aid, '_wp_attachment_image_alt', true));
    if ($alt === '' || $alt === $titulo || tsp_foto_nome_arquivo($alt)) {
        $novo = $mostra !== '' ? $mostra : (($clubes && mb_stripos($titulo, $clubes[0]) === false) ? $clubes[0] . ': ' . $titulo : $titulo);
        $novo = mb_substr($novo, 0, 150);
        if ($novo !== $alt) {
            update_post_meta($aid, '_wp_attachment_image_alt', $novo);
            $mudou = true;
        }
    }
    $upd = array();
    if (tsp_foto_nome_arquivo($a->post_title)) {
        $upd['post_title'] = mb_substr($titulo, 0, 180);
    }
    if (trim($a->post_excerpt) === '' && $cred !== '') {
        $upd['post_excerpt'] = $cred;
    }
    if (trim($a->post_content) === '' || strpos($a->post_content, 'Foto da matéria "') === 0) {
        $d = 'Foto da matéria "' . $titulo . '"';
        if ($clubes) {
            $d .= ', sobre ' . implode(', ', $clubes);
        }
        if ($camp !== '') {
            $d .= ' (' . $camp . ')';
        }
        $d .= '.';
        if ($mostra !== '') {
            $d .= ' ' . rtrim($mostra, '.') . '.';
        }
        if ($cred !== '') {
            $d .= ' ' . rtrim($cred, '.') . '.';
        }
        $d .= ' Tudo Sobre Paulista.';
        if ($d !== $a->post_content) {
            $upd['post_content'] = $d;
        }
    }
    if ($upd) {
        $upd['ID'] = $aid;
        wp_update_post(wp_slash($upd));
        $mudou = true;
    }
    if ($cred !== '' && get_post_meta($aid, 'tsp_credito', true) === '') {
        update_post_meta($aid, 'tsp_credito', $cred);
    }
    return $mudou;
}

// Ao salvar a matéria: foto de destaque e fotos enviadas dentro dela
add_action('save_post', function ($post_id, $post) {
    if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !in_array($post->post_type, tsp_tipos(), true)) {
        return;
    }
    $t = get_post_thumbnail_id($post_id);
    if ($t) {
        tsp_foto_preencher($t, $post_id);
    }
    foreach (get_attached_media('image', $post_id) as $img) {
        if ((int) $img->ID !== (int) $t) {
            tsp_foto_preencher($img->ID, $post_id);
        }
    }
}, 40, 2);

// Ao definir a foto de destaque (inclusive pela Máquina)
$tsp_foto_thumb = function ($meta_id, $post_id, $chave, $valor) {
    if ($chave === '_thumbnail_id' && $valor) {
        tsp_foto_preencher((int) $valor, $post_id);
    }
};
add_action('added_post_meta', $tsp_foto_thumb, 10, 4);
add_action('updated_post_meta', $tsp_foto_thumb, 10, 4);

// Ao enviar a foto de dentro da matéria: os campos já aparecem preenchidos na janela da biblioteca
add_action('add_attachment', function ($aid) {
    $a = get_post($aid);
    if ($a && $a->post_parent && wp_attachment_is_image($aid)) {
        tsp_foto_preencher($aid, $a->post_parent);
    }
});

// Fotos no meio do texto sem texto alternativo: usa a legenda ou o título da matéria
add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || strpos($html, '<img') === false) {
        return $html;
    }
    $titulo = esc_attr(wp_strip_all_tags(get_the_title()));
    return preg_replace_callback('~<img\b[^>]*>~i', function ($m) use ($titulo) {
        $tag = $m[0];
        if (preg_match('~\balt\s*=\s*(["\'])\s*\1~i', $tag)) {
            return preg_replace('~\balt\s*=\s*(["\'])\s*\1~i', 'alt="' . $titulo . '"', $tag);
        }
        if (!preg_match('~\balt\s*=~i', $tag)) {
            return preg_replace('~<img\b~i', '<img alt="' . $titulo . '"', $tag, 1);
        }
        return $tag;
    }, $html);
}, 20);

// Robô das fotos antigas: 150 matérias a cada 5 minutos, da mais nova para a mais antiga, até acabar
add_filter('cron_schedules', function ($s) {
    $s['tsp_5min'] = array('interval' => 300, 'display' => 'A cada 5 minutos (TSP)');
    return $s;
});
add_action('init', function () {
    if (get_option('tsp_fotos_retro_fim') || wp_next_scheduled('tsp_fotos_retro')) {
        return;
    }
    wp_schedule_event(time() + 120, 'tsp_5min', 'tsp_fotos_retro');
});
add_action('tsp_fotos_retro', function () {
    $pag = (int) get_option('tsp_fotos_retro_pag', 1);
    $q = new WP_Query(array('post_type' => tsp_tipos(), 'post_status' => 'publish', 'posts_per_page' => 150, 'paged' => $pag, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC', 'meta_key' => '_thumbnail_id', 'no_found_rows' => true));
    if (!$q->posts) {
        update_option('tsp_fotos_retro_fim', current_time('mysql'), false);
        wp_clear_scheduled_hook('tsp_fotos_retro');
        return;
    }
    $n = (int) get_option('tsp_fotos_retro_n', 0);
    foreach ($q->posts as $pid) {
        if (tsp_foto_preencher(get_post_thumbnail_id($pid), $pid)) {
            $n++;
        }
    }
    update_option('tsp_fotos_retro_n', $n, false);
    update_option('tsp_fotos_retro_pag', $pag + 1, false);
});
