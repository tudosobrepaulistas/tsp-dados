<?php
/**
 * Página do clube: tarja (TSP à esquerda, nome no centro, escudo à direita) →
 * 4 destaques → jogos, classificação e elenco → 4 últimos vídeos (só se houver) →
 * 8 últimas notícias → "Mais notícias" (paginação) → Sobre o clube.
 * A partir da página 2: só a lista de notícias.
 */
get_header();
$tsp_t = get_queried_object();
$tsp_ids = wp_list_pluck($GLOBALS['wp_query']->posts, 'ID');
tsp_clube_tarja($tsp_t);
?>
<main class="tsp-container tsp-clube">
	<?php tsp_breadcrumbs(); ?>
	<?php if (!$tsp_ids) : ?>
		<p class="tsp-vazio">Ainda não há notícias <?php echo esc_html(tsp_de($tsp_t)); ?>.</p>
	<?php elseif (is_paged()) : ?>
		<h2 class="tsp-clube__tit">Mais notícias <?php echo esc_html(tsp_de($tsp_t)); ?></h2>
		<div class="tsp-grade tsp-grade--4"><?php foreach ($tsp_ids as $tsp_i) { tsp_card($tsp_i, 'grade'); } ?></div>
	<?php else : ?>
		<section class="tsp-secao" aria-label="Destaques">
			<div class="tsp-topo">
				<?php tsp_card($tsp_ids[0], 'grande', true); ?>
				<div class="tsp-topo__lado tsp-topo__lado--lista">
					<?php foreach (array_slice($tsp_ids, 1, 3) as $tsp_i) { tsp_card($tsp_i, 'lista'); } ?>
				</div>
			</div>
		</section>

		<?php tsp_clube_painel($tsp_t); ?>
		<?php // Números da temporada (base do TSP): campanha, artilheiros, mais utilizados e campinho
		if (function_exists('tsp_tn_html') && function_exists('tsp_jogos_api_do_slug')) {
			$tsp_tid = tsp_jogos_api_do_slug($tsp_t->slug);
			$tsp_tn = $tsp_tid ? tsp_tn_html($tsp_tid, $tsp_t->name, false) : '';
			if ($tsp_tn) {
				echo '<section class="tsp-secao" aria-labelledby="tsp-tn-tit"><h2 id="tsp-tn-tit" class="tsp-sr">Números do ' . esc_html($tsp_t->name) . '</h2>' . $tsp_tn . '</section>'; // phpcs:ignore
			}
		} ?>

		<?php echo tsp_ofertas_html($tsp_t, 'clube', 12) ?: tsp_ofertas_html(null, 'clube', 12); // phpcs:ignore -- HTML já escapado ?>

		<?php $tsp_v = tsp_clube_videos($tsp_t, 4); if ($tsp_v) : ?>
			<section class="tsp-secao tsp-secao--escura" aria-labelledby="tsp-v-tit">
				<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="tsp-v-tit">Vídeos <?php echo esc_html(tsp_de($tsp_t)); ?></h2></div></div>
				<div class="tsp-grade tsp-grade--4 tsp-grade--videos"><?php foreach ($tsp_v as $tsp_x) { echo tsp_clube_video_html($tsp_x); } ?></div>
			</section>
		<?php endif; ?>

		<?php if (count($tsp_ids) > 4) : ?>
			<section class="tsp-secao" aria-labelledby="tsp-n-tit">
				<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="tsp-n-tit">Últimas notícias <?php echo esc_html(tsp_de($tsp_t)); ?></h2></div></div>
				<div class="tsp-grade tsp-grade--4"><?php foreach (array_slice($tsp_ids, 4, 8) as $tsp_i) { tsp_card($tsp_i, 'grade'); } ?></div>
			</section>
		<?php endif; ?>
	<?php endif; ?>

	<?php tsp_banner('tsp-banner-clube'); ?>

	<?php
	the_posts_pagination(array(
		'mid_size'           => 1,
		'prev_text'          => '← Anteriores',
		'next_text'          => 'Saiba mais: notícias anteriores →',
		'screen_reader_text' => 'Mais notícias ' . tsp_de($tsp_t),
	));
	?>

	<section class="tsp-wpp">
		<div><h2>Notícias <?php echo esc_html(tsp_de($tsp_t)); ?> no WhatsApp</h2><p>Resultados, bastidores e coletivas direto no celular.</p></div>
		<a class="tsp-botao tsp-botao--wpp" href="<?php echo esc_url(tsp_clube_whatsapp($tsp_t)); ?>" target="_blank" rel="noopener">Entrar no grupo</a>
	</section>

	<?php if (!is_paged()) { tsp_guia_html($tsp_t); } ?>
</main>
<?php
get_footer();
