<?php
get_header();
while (have_posts()) :
	the_post();
	?>
<?php $tsp_pilar = function_exists('tsp_pagina_pilar') && tsp_pagina_pilar(get_the_ID()); // perfil especial: o título já vem na página ?>
<main class="tsp-container tsp-pagina<?php echo $tsp_pilar ? ' tsp-pagina--pilar' : ''; ?>">
	<article>
		<?php tsp_breadcrumbs(); ?>
		<?php if (!$tsp_pilar) : ?><h1 class="tsp-materia__titulo"><?php the_title(); ?></h1><?php endif; ?>
		<div class="tsp-corpo"><?php the_content(); ?></div>
	</article>
</main>
	<?php
endwhile;
get_footer();
