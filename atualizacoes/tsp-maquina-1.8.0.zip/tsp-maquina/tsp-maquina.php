<?php
/*
Plugin Name: TSP Máquina de Notícias
Description: Recebe as matérias que a Máquina de Notícias do TSP escreve (Paulistão A4, futebol feminino e clubes sem divisão / Segunda Divisão), agenda no horário certo (de 1h30 em 1h30, das 8h às 23h) com foto e crédito, e deixa como rascunho para um redator quando não há foto segura.
Version: 1.8.0
Author: TSP
Requires at least: 6.3
Requires PHP: 7.4
Text Domain: tsp-maquina
*/

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_MAQ_VERSAO', '1.7.0');
const TSP_MAQ_RAW = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/';

function tsp_maq_tipo()
{
    return post_type_exists('materia') ? 'materia' : 'post';
}

function tsp_maq_get($caminho)
{
    if (!empty($GLOBALS['tsp_maq_forcar'])) {
        // Leitura na hora: API do GitHub (sem o atraso de até 5 min do endereço "raw")
        $r = wp_remote_get('https://api.github.com/repos/tudosobrepaulistas/tsp-dados/contents/' . $caminho . '?ref=main', array('timeout' => 20, 'headers' => array('Accept' => 'application/vnd.github.raw', 'User-Agent' => 'TSP-Maquina')));
        if (!is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) === 200) {
            return json_decode(wp_remote_retrieve_body($r), true);
        }
    }
    $v = !empty($GLOBALS['tsp_maq_forcar']) ? time() . wp_rand(100, 999) : floor(time() / 300);
    $r = wp_remote_get(add_query_arg('v', $v, TSP_MAQ_RAW . $caminho), array('timeout' => 20, 'headers' => array('Cache-Control' => 'no-cache')));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return null;
    }
    return json_decode(wp_remote_retrieve_body($r), true);
}

/* ---------- Agenda: confere a fila a cada 15 minutos ---------- */

add_filter('cron_schedules', function ($s) {
    $s['tsp_maq_15'] = array('interval' => 900, 'display' => 'A cada 15 minutos (TSP Máquina)');
    return $s;
});
add_action('init', function () {
    if (!wp_next_scheduled('tsp_maq_buscar')) {
        wp_schedule_event(time() + 60, 'tsp_maq_15', 'tsp_maq_buscar');
    }
});
add_action('tsp_maq_buscar', 'tsp_maq_importar');
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tsp_maq_buscar');
});

function tsp_maq_ja_existe($mid)
{
    return (bool) get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => 'tsp_maq_id', 'meta_value' => $mid, 'no_found_rows' => true));
}

function tsp_maq_importar()
{
    $log = array('quando' => current_time('mysql'), 'novas' => 0, 'erros' => array());
    $av = tsp_maq_get('api/maquina-avisos.json');
    if (is_array($av)) {
        update_option('tsp_maq_avisos', $av, false);
    }
    $ind = tsp_maq_get('maquina/fila/indice.json');
    if (!is_array($ind)) {
        $log['erros'][] = 'Não consegui ler a fila no GitHub.';
        update_option('tsp_maq_log', $log, false);
        return 0;
    }
    $feitos = (array) get_option('tsp_maq_feitos', array());
    foreach ((array) ($ind['arquivos'] ?? array()) as $nome) {
        $nome = basename((string) $nome);
        if (!preg_match('~^[\w.-]+\.json$~', $nome) || isset($feitos[$nome])) {
            continue;
        }
        $env = tsp_maq_get('maquina/fila/' . $nome);
        if (!is_array($env) || empty($env['z'])) {
            continue;
        }
        $json = function_exists('gzdecode') ? @gzdecode(base64_decode($env['z'])) : false;
        $it = $json ? json_decode($json, true) : null;
        if (!is_array($it) || empty($it['id'])) {
            $log['erros'][] = $nome . ': arquivo ilegível';
            $feitos[$nome] = 'erro';
            continue;
        }
        if (tsp_maq_ja_existe($it['id'])) {
            $feitos[$nome] = 'ok';
            continue;
        }
        $r = tsp_maq_criar($it);
        if (is_wp_error($r)) {
            $log['erros'][] = $nome . ': ' . $r->get_error_message();
        } else {
            $log['novas']++;
        }
        $feitos[$nome] = is_wp_error($r) ? 'erro' : (int) $r;
    }
    update_option('tsp_maq_feitos', array_slice($feitos, -300, null, true), false);
    update_option('tsp_maq_log', $log, false);
    return $log['novas'];
}

function tsp_maq_acf($post_id, $rotulos, $valor)
{
    if (function_exists('tsp_audio_acf')) {
        return tsp_audio_acf($post_id, $rotulos, $valor);
    }
    if (!function_exists('acf_get_field_groups') || !function_exists('update_field')) {
        return false;
    }
    $alvo = array_map(function ($r) {
        return sanitize_title(remove_accents($r));
    }, $rotulos);
    foreach (acf_get_field_groups() as $g) {
        foreach ((array) acf_get_fields($g) as $f) {
            if (in_array(sanitize_title(remove_accents($f['label'])), $alvo, true)) {
                update_field($f['key'], $valor, $post_id);
                return true;
            }
        }
    }
    return false;
}

// Autor do pós-jogo: a conta da redação (login "tsp", "Redação Tudo Sobre Paulista"), não a pessoa da Máquina
function tsp_maq_autor_posjogo()
{
    $id = (int) get_option('tsp_maq_autor_posjogo', 0);
    if ($id && get_userdata($id)) {
        return $id;
    }
    $u = get_user_by('login', 'tsp');
    return $u ? (int) $u->ID : tsp_maq_autor();
}

function tsp_maq_autor()
{
    $id = (int) get_option('tsp_maq_autor', 0);
    if ($id && get_userdata($id)) {
        return $id;
    }
    $adm = get_users(array('role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'fields' => 'ID'));
    return $adm ? (int) $adm[0] : 1;
}

function tsp_maq_criar($it)
{
    $txt = function ($s, $max = 400) {
        return mb_substr(trim(wp_strip_all_tags((string) $s)), 0, $max);
    };
    $titulo = $txt($it['titulo'] ?? '', 120);
    $blocos = '';
    foreach ((array) ($it['corpo'] ?? array()) as $b) {
        if (!empty($b['h2'])) {
            $blocos .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html($txt($b['h2'], 140)) . "</h2>\n<!-- /wp:heading -->\n\n";
        } elseif (!empty($b['citacao'])) {
            $blocos .= "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>" . esc_html($txt($b['citacao'], 900)) . "</p></blockquote>\n<!-- /wp:quote -->\n\n";
        } elseif (!empty($b['p'])) {
            $blocos .= "<!-- wp:paragraph -->\n<p>" . esc_html($txt($b['p'], 2000)) . "</p>\n<!-- /wp:paragraph -->\n\n";
        }
    }
    if ($titulo === '' || substr_count($blocos, '<p>') < 4) {
        return new WP_Error('incompleto', 'texto incompleto');
    }
    // Horário de Brasília (publish_at = "AAAA-MM-DD HH:MM")
    $quando = date_create_immutable((string) ($it['publish_at'] ?? ''), new DateTimeZone('America/Sao_Paulo'));
    $ts = $quando ? $quando->getTimestamp() : time();
    $ja = in_array($it['tipo'] ?? '', array('posjogo', 'versao'), true); // pós-jogo e versão por clube saem na hora
    if ($ja) {
        $ts = time();
    } elseif ($ts < time() + 60) {
        $ts = time() + 60;
    }
    $foto = (array) ($it['foto'] ?? array());
    $sub = $txt($it['subtitulo'] ?? '', 220);
    $id = wp_insert_post(array(
        'post_type'     => tsp_maq_tipo(),
        'post_title'    => $titulo,
        'post_name'     => sanitize_title($it['slug'] ?? $titulo),
        'post_content'  => $blocos,
        'post_excerpt'  => $sub,
        'post_status'   => 'draft',
        'post_author'   => in_array($it['tipo'] ?? '', array('posjogo', 'versao'), true) ? tsp_maq_autor_posjogo() : tsp_maq_autor(),
    ), true);
    if (is_wp_error($id)) {
        return $id;
    }
    update_post_meta($id, 'tsp_maq_id', sanitize_key($it['id']));
    update_post_meta($id, 'tsp_maq_clube', sanitize_title($it['clube'] ?? ''));
    update_post_meta($id, 'tsp_maq_tipo', sanitize_key($it['tipo'] ?? ''));
    if (!empty($it['jogo'])) {
        update_post_meta($id, 'tsp_maq_jogo', (int) $it['jogo']);
    }
    // Versão por clube: a mesma notícia do redator contada pelo lado de outro clube marcado (só na página do clube)
    if (($it['tipo'] ?? '') === 'versao' && !empty($it['versao_de'])) {
        update_post_meta($id, 'tsp_versao_de', (int) $it['versao_de']);
        update_post_meta($id, 'tsp_versao_clube', sanitize_title($it['clube'] ?? ''));
    }
    update_post_meta($id, 'tsp_maq_horario', gmdate('Y-m-d H:i:s', $ts));
    if ((!empty($it['clube']) || !empty($it['clubes'])) && taxonomy_exists('times')) {
        wp_set_object_terms($id, array_values(array_unique(array_map('sanitize_title', array_merge(array($it['clube']), (array) ($it['clubes'] ?? array()))))), 'times', false);
    }
    if (!empty($it['categoria'])) {
        $cat = get_category_by_slug(sanitize_title($it['categoria']));
        if ($cat) {
            wp_set_post_categories($id, array($cat->term_id), false);
        }
    }
    if ($sub !== '') {
        tsp_maq_acf($id, array('Subtítulo', 'Subtitulo', 'Linha fina'), $sub);
    }
    if (!empty($it['resumo'])) {
        update_post_meta($id, 'tsp_resumo', implode("\n", array_map(function ($s) use ($txt) {
            return $txt($s, 220);
        }, array_slice((array) $it['resumo'], 0, 5))));
    }
    $faq = array();
    foreach (array_slice((array) ($it['faq'] ?? array()), 0, 5) as $f) {
        if (is_array($f) && !empty($f[0]) && !empty($f[1])) {
            $faq[] = array($txt($f[0], 200), $txt($f[1], 500));
        }
    }
    if ($faq) {
        update_post_meta($id, 'tsp_faq', wp_json_encode($faq, JSON_UNESCAPED_UNICODE));
    }
    foreach (array('meta_title' => array('_yoast_wpseo_title', 70), 'meta_desc' => array('_yoast_wpseo_metadesc', 160), 'foco' => array('_yoast_wpseo_focuskw', 80)) as $k => $m) {
        if (!empty($it[$k])) {
            update_post_meta($id, $m[0], $txt($it[$k], $m[1]));
        }
    }
    if (!empty($it['tags'])) {
        wp_set_post_tags($id, array_map(function ($t) use ($txt) {
            return $txt($t, 60);
        }, array_slice((array) $it['tags'], 0, 6)), false);
    }
    $fontes = array();
    foreach ((array) ($it['fontes'] ?? array()) as $f) {
        if (!empty($f['url'])) {
            $fontes[] = $txt($f['nome'] ?? parse_url($f['url'], PHP_URL_HOST), 120) . ' | ' . esc_url_raw($f['url']);
        }
    }
    update_post_meta($id, 'tsp_fontes', implode("\n", $fontes));
    update_post_meta($id, 'tsp_ia', '1');
    update_post_meta($id, 'tsp_ia_origem', 'maquina');
    update_post_meta($id, 'tsp_h2_aplicado', 1);

    $anexo = 0;
    if (!empty($foto['url']) && !empty($foto['credito'])) {
        $anexo = tsp_maq_foto($id, $foto, $titulo);
    }
    // Pós-jogo: sem foto própria, usa a foto do estádio (já com crédito) da página do jogo
    if (!$anexo && !empty($it['jogo']) && function_exists('tsp_jogos_post_do_jogo')) {
        $jp = tsp_jogos_post_do_jogo((int) $it['jogo']);
        $aid = $jp ? (int) get_post_thumbnail_id($jp) : 0;
        $cred = $aid ? trim((string) wp_get_attachment_caption($aid)) : '';
        if ($aid && $cred !== '') {
            set_post_thumbnail($id, $aid);
            tsp_maq_acf($id, array('Crédito da imagem', 'Credito da imagem', 'Crédito da foto', 'Credito da foto'), $cred);
            $anexo = $aid;
        }
    }
    // Versão por clube: usa a mesma foto (e o mesmo crédito) da matéria original
    if (!$anexo && !empty($it['versao_de'])) {
        $orig = (int) $it['versao_de'];
        $aid = (int) get_post_thumbnail_id($orig);
        $cred = function_exists('tsp_credito_foto') ? (string) tsp_credito_foto($orig) : trim((string) wp_get_attachment_caption($aid));
        if ($aid && $cred !== '') {
            set_post_thumbnail($id, $aid);
            tsp_maq_acf($id, array('Crédito da imagem', 'Credito da imagem', 'Crédito da foto', 'Credito da foto'), $cred);
            $anexo = $aid;
        }
    }
    if ($anexo) {
        update_post_meta($id, 'tsp_maq_status', $ja ? 'publicada' : 'agendada');
        $data = wp_date('Y-m-d H:i:s', $ts);
        wp_update_post(array(
            'ID'            => $id,
            'post_status'   => $ts > time() ? 'future' : 'publish',
            'post_date'     => $data,
            'post_date_gmt' => gmdate('Y-m-d H:i:s', $ts),
            'edit_date'     => true,
        ));
    } else {
        update_post_meta($id, 'tsp_maq_status', 'sem_foto');
        update_post_meta($id, 'tsp_maq_obs', !empty($foto['url']) ? 'A foto sugerida não pôde ser baixada.' : 'Não achamos foto com direito de uso garantido.');
    }
    return $id;
}

// Baixa a foto para a biblioteca com legenda/crédito. Devolve o ID do anexo ou 0.
function tsp_maq_foto($post_id, $foto, $titulo)
{
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $url = esc_url_raw($foto['url']);
    if (!wp_http_validate_url($url)) {
        return 0;
    }
    $tmp = download_url($url, 30);
    if (is_wp_error($tmp)) {
        return 0;
    }
    $info = @getimagesize($tmp);
    if (!$info || $info[0] < 600) {
        @unlink($tmp);
        return 0;
    }
    $ext = array(IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp')[$info[2]] ?? '';
    if (!$ext) {
        @unlink($tmp);
        return 0;
    }
    $credito = mb_substr(wp_strip_all_tags($foto['credito']), 0, 160);
    $aid = media_handle_sideload(array('name' => sanitize_title($titulo) . '.' . $ext, 'tmp_name' => $tmp), $post_id, $titulo, array('post_excerpt' => $credito));
    if (is_wp_error($aid)) {
        @unlink($tmp);
        return 0;
    }
    update_post_meta($aid, '_wp_attachment_image_alt', mb_substr(wp_strip_all_tags($foto['alt'] ?? $titulo), 0, 150));
    update_post_meta($aid, 'tsp_credito', $credito);
    if (!empty($foto['fonte'])) {
        update_post_meta($aid, 'tsp_foto_fonte', esc_url_raw($foto['fonte']));
    }
    set_post_thumbnail($post_id, $aid);
    tsp_maq_acf($post_id, array('Crédito da imagem', 'Credito da imagem', 'Crédito da foto', 'Credito da foto'), $credito);
    return (int) $aid;
}

// Redator que coloca a foto e publica um rascunho da Máquina vira o autor (conta no relatório dele)
add_action('transition_post_status', function ($novo, $antigo, $post) {
    if (!in_array($novo, array('publish', 'future'), true) || $antigo !== 'draft' || get_post_meta($post->ID, 'tsp_maq_status', true) !== 'sem_foto') {
        return;
    }
    update_post_meta($post->ID, 'tsp_maq_status', 'finalizada');
    $u = get_current_user_id();
    if ($u && !user_can($u, 'manage_options')) {
        update_post_meta($post->ID, 'tsp_maq_finalizou', $u);
        global $wpdb;
        $wpdb->update($wpdb->posts, array('post_author' => $u), array('ID' => $post->ID));
        clean_post_cache($post->ID);
    }
}, 10, 3);

/* ---------- Painel ---------- */

function tsp_maq_rascunhos()
{
    return get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'draft', 'numberposts' => 20, 'meta_key' => 'tsp_maq_status', 'meta_value' => 'sem_foto', 'orderby' => 'date', 'order' => 'ASC'));
}

// Recado para redatores: matérias prontas esperando foto
add_action('admin_notices', function () {
    $tela = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$tela || $tela->id !== 'dashboard' || !current_user_can('edit_posts')) {
        return;
    }
    $r = tsp_maq_rascunhos();
    if (!$r) {
        return;
    }
    $p = $r[0];
    $link = current_user_can('edit_post', $p->ID) ? get_edit_post_link($p->ID) : '';
    echo '<div class="notice notice-warning" style="border-left-color:#E8862A;font-size:14px"><p>📸 A Máquina de Notícias deixou <strong>' . count($r) . ' matéria' . (count($r) > 1 ? 's' : '') . ' pronta' . (count($r) > 1 ? 's' : '') . '</strong> esperando só uma foto com crédito. Quer finalizar? Coloque a foto, confira o texto e publique: a matéria passa a contar para você! '
        . ($link ? '<a href="' . esc_url($link) . '">Começar por “' . esc_html(wp_trim_words($p->post_title, 10)) . '”</a>' : '') . '</p></div>';
});

add_action('wp_dashboard_setup', function () {
    if (current_user_can('edit_posts')) {
        wp_add_dashboard_widget('tsp_maq', '🤖 Máquina de Notícias', 'tsp_maq_widget');
    }
});

function tsp_maq_widget()
{
    $prox = get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'future', 'numberposts' => 4, 'meta_key' => 'tsp_maq_status', 'meta_value' => 'agendada', 'orderby' => 'date', 'order' => 'ASC'));
    echo '<p style="margin-top:0">Uma matéria a cada 1h30, das 8h às 23h, sobre o Paulistão A4, o futebol feminino e os clubes sem divisão / Segunda Divisão. <em>Responsável: Thiago Barbalho. A redação cobre o Paulistão A1, A2 e A3.</em></p>';
    if ($prox) {
        echo '<p><strong>Próximas:</strong></p><ul style="margin-left:0">';
        foreach ($prox as $p) {
            echo '<li>' . esc_html(get_the_date('d/m H\hi', $p)) . ' · ' . esc_html($p->post_title) . '</li>';
        }
        echo '</ul>';
    }
    $r = tsp_maq_rascunhos();
    if ($r) {
        echo '<p><strong>Esperando foto (' . count($r) . '):</strong></p><ul style="margin-left:0">';
        foreach (array_slice($r, 0, 5) as $p) {
            $l = current_user_can('edit_post', $p->ID) ? get_edit_post_link($p->ID) : '';
            echo '<li>' . ($l ? '<a href="' . esc_url($l) . '">' : '') . esc_html($p->post_title) . ($l ? '</a>' : '') . '</li>';
        }
        echo '</ul>';
    }
    $av = (array) get_option('tsp_maq_avisos', array());
    $lista = current_user_can('manage_options') ? array_slice(array_reverse((array) ($av['avisos'] ?? array())), 0, 8) : array();
    if ($lista) {
        echo '<p><strong>📝 Pautas pedidas pela Máquina</strong> (não achou notícia nova confirmada; vale apurar com o clube):</p><ul style="margin-left:0">';
        foreach ($lista as $a) {
            echo '<li><strong>' . esc_html($a['nome'] ?? '') . '</strong>' . (!empty($a['sugestao']) ? ': ' . esc_html($a['sugestao']) : (!empty($a['motivo']) ? ': ' . esc_html($a['motivo']) : '')) . '</li>';
        }
        echo '</ul>';
    }
}

/* ---------- Tela de configuração (Ferramentas → Máquina de Notícias) ---------- */

add_action('admin_menu', function () {
    add_management_page('Máquina de Notícias', 'Máquina de Notícias', 'manage_options', 'tsp-maquina', 'tsp_maq_tela');
});

function tsp_maq_tela()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    if (isset($_POST['tsp_maq_salvar']) && check_admin_referer('tsp_maq')) {
        update_option('tsp_maq_autor', (int) ($_POST['autor'] ?? 0), false);
        update_option('tsp_maq_autor_posjogo', (int) ($_POST['autor_posjogo'] ?? 0), false);
        echo '<div class="notice notice-success"><p>Salvo.</p></div>';
    }
    if (isset($_POST['tsp_maq_agora']) && check_admin_referer('tsp_maq')) {
        $GLOBALS['tsp_maq_forcar'] = true;
        $n = tsp_maq_importar();
        echo '<div class="notice notice-success"><p>Fila lida agora: ' . (int) $n . ' matéria(s) nova(s).</p></div>';
    }
    // Forçar publicação fora do horário: uma matéria agendada, ou todas
    if ((isset($_POST['tsp_maq_pub']) || isset($_POST['tsp_maq_pub_todas'])) && check_admin_referer('tsp_maq')) {
        $ids = isset($_POST['tsp_maq_pub_todas']) ? wp_list_pluck(tsp_maq_agendadas(50), 'ID') : array((int) $_POST['tsp_maq_pub']);
        $n = 0;
        foreach ($ids as $pid) {
            if (tsp_maq_publicar_agora((int) $pid)) {
                $n++;
            }
        }
        do_action('litespeed_purge_all');
        echo '<div class="notice notice-success"><p>' . $n . ' matéria(s) publicada(s) agora.</p></div>';
    }
    $log = (array) get_option('tsp_maq_log', array());
    echo '<div class="wrap"><h1>🤖 Máquina de Notícias do TSP</h1>';
    echo '<p>A Máquina escreve uma matéria a cada 1h30 (8h às 23h) sobre o Paulistão A4, o futebol feminino e os clubes sem divisão / Segunda Divisão, sempre com fontes. O site busca as matérias a cada 15 minutos e agenda cada uma no horário dela. Sem foto segura, a matéria fica como rascunho para um redator.</p>';
    echo '<p><strong>Última leitura:</strong> ' . esc_html($log['quando'] ?? 'ainda não') . ' · novas: ' . (int) ($log['novas'] ?? 0) . (!empty($log['erros']) ? ' · <span style="color:#b32d2e">' . esc_html(implode(' / ', array_slice($log['erros'], 0, 3))) . '</span>' : '') . '</p>';
    echo '<form method="post">';
    wp_nonce_field('tsp_maq');
    echo '<p><label><strong>Autor das matérias da Máquina:</strong> ';
    wp_dropdown_users(array('name' => 'autor', 'selected' => tsp_maq_autor(), 'role__in' => array('administrator', 'editor')));
    echo '</label><br><span class="description">Matérias do Paulistão A4, futebol feminino e clubes sem divisão.</span></p>';
    echo '<p><label><strong>Autor dos pós-jogos:</strong> ';
    wp_dropdown_users(array('name' => 'autor_posjogo', 'selected' => tsp_maq_autor_posjogo(), 'role__in' => array('administrator', 'editor')));
    echo '</label><br><span class="description">Resultados de todos os jogos da base (inclusive Palmeiras, Corinthians etc.): use a conta da redação ("Redação Tudo Sobre Paulista"). Administradores não entram no pagamento.</span></p>';
    echo '<p><button class="button button-primary" name="tsp_maq_salvar" value="1">Salvar</button> <button class="button" name="tsp_maq_agora" value="1">Ler a fila agora</button></p>';
    $ag = tsp_maq_agendadas(30);
    echo '<h2>Agendadas pela Máquina (' . count($ag) . ')</h2>';
    if ($ag) {
        echo '<p class="description">Como administrador, você pode publicar fora do horário: a matéria sai na hora.</p><table class="widefat striped"><thead><tr><th>Horário</th><th>Matéria e fontes para conferir</th><th></th></tr></thead><tbody>';
        foreach ($ag as $p) {
            echo '<tr><td>' . esc_html(get_the_date('d/m H\\hi', $p)) . '</td><td><a href="' . esc_url(get_edit_post_link($p->ID)) . '">' . esc_html($p->post_title) . '</a>' . tsp_maq_fontes_html($p->ID) . '</td><td><button class="button" name="tsp_maq_pub" value="' . (int) $p->ID . '">Publicar agora</button></td></tr>';
        }
        echo '</tbody></table><p><button class="button" name="tsp_maq_pub_todas" value="1" onclick="return confirm(\'Publicar todas as agendadas agora?\')">Publicar todas agora</button></p>';
    } else {
        echo '<p>Nenhuma agendada no momento. Clique em “Ler a fila agora” para buscar as que a Máquina acabou de escrever.</p>';
    }
    $rs = tsp_maq_rascunhos();
    echo '<h2>Esperando foto (' . count($rs) . ')</h2>';
    if ($rs) {
        echo '<p class="description">A Máquina escreveu, mas não achou foto com direito de uso garantido. Coloque a foto com crédito e publique (ou agende).</p><ul>';
        foreach ($rs as $p) {
            echo '<li><a href="' . esc_url(get_edit_post_link($p->ID)) . '">' . esc_html($p->post_title) . '</a>' . tsp_maq_fontes_html($p->ID) . '</li>';
        }
        echo '</ul>';
    } else {
        echo '<p>Nenhuma.</p>';
    }
    echo '</form></div>';
}

function tsp_maq_agendadas($n = 30)
{
    return get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'future', 'numberposts' => $n, 'meta_key' => 'tsp_maq_status', 'meta_value' => 'agendada', 'orderby' => 'date', 'order' => 'ASC'));
}

function tsp_maq_publicar_agora($pid)
{
    $p = get_post($pid);
    if (!$p || $p->post_status !== 'future' || !get_post_meta($pid, 'tsp_maq_id', true) || !current_user_can('manage_options')) {
        return false;
    }
    $r = wp_update_post(array('ID' => $pid, 'post_status' => 'publish', 'post_date' => current_time('mysql'), 'post_date_gmt' => current_time('mysql', true), 'edit_date' => true), true);
    if (is_wp_error($r)) {
        return false;
    }
    update_post_meta($pid, 'tsp_maq_status', 'publicada_adm');
    return true;
}

// Atalho "Publicar agora" também na lista de matérias
add_filter('post_row_actions', function ($acoes, $p) {
    if ($p->post_status === 'future' && current_user_can('manage_options') && get_post_meta($p->ID, 'tsp_maq_status', true) === 'agendada') {
        $acoes['tsp_maq_pub'] = '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=tsp_maq_pub&id=' . $p->ID), 'tsp_maq_pub_' . $p->ID)) . '">Publicar agora</a>';
    }
    return $acoes;
}, 10, 2);
add_action('admin_post_tsp_maq_pub', function () {
    $id = (int) ($_GET['id'] ?? 0);
    check_admin_referer('tsp_maq_pub_' . $id);
    if (tsp_maq_publicar_agora($id)) {
        do_action('litespeed_purge_all');
    }
    wp_safe_redirect(wp_get_referer() ?: admin_url('edit.php?post_type=' . tsp_maq_tipo()));
    exit;
});


/* ---------- Fontes para conferir (tela da Máquina e editor da matéria) ---------- */

function tsp_maq_fontes_html($pid)
{
    $linhas = array_filter(array_map('trim', explode("\n", (string) get_post_meta($pid, 'tsp_fontes', true))));
    $h = '<div style="font-size:12px;margin-top:4px">';
    foreach ($linhas as $l) {
        $x = array_map('trim', explode('|', $l, 2));
        $h .= '🔗 ' . (!empty($x[1]) ? '<a href="' . esc_url($x[1]) . '" target="_blank" rel="noopener">' . esc_html($x[0]) . '</a>' : esc_html($x[0])) . '<br>';
    }
    $aid = get_post_thumbnail_id($pid);
    $fonte_foto = $aid ? get_post_meta($aid, 'tsp_foto_fonte', true) : '';
    if ($aid) {
        $h .= '📷 ' . esc_html(wp_get_attachment_caption($aid)) . ($fonte_foto ? ' · <a href="' . esc_url($fonte_foto) . '" target="_blank" rel="noopener">de onde veio a foto</a>' : '') . '<br>';
    }
    $tipo = get_post_meta($pid, 'tsp_maq_tipo', true);
    if ($tipo) {
        $h .= '<em>Tipo: ' . esc_html(array('noticia' => 'notícia (2 fontes cruzadas)', 'coletiva' => 'coletiva/pronunciamento oficial', 'historia' => 'história / atemporal', 'posjogo' => 'pós-jogo (placar conferido em 2 fontes)')[$tipo] ?? $tipo) . '</em>';
    }
    return $h . '</div>';
}

add_action('add_meta_boxes', function () {
    global $post;
    if ($post && get_post_meta($post->ID, 'tsp_maq_id', true)) {
        add_meta_box('tsp_maq_fontes', '🤖 Máquina: fontes para conferir', function ($p) {
            echo tsp_maq_fontes_html($p->ID) ?: '<p>Sem fontes registradas.</p>'; // phpcs:ignore
            $obs = get_post_meta($p->ID, 'tsp_maq_obs', true);
            if ($obs) {
                echo '<p><strong>Obs.:</strong> ' . esc_html($obs) . '</p>';
            }
        }, null, 'side', 'high');
    }
});


/* ---------- Aviso da Máquina: "acabei de mandar um pós-jogo, leia a fila agora" ---------- */

add_action('rest_api_init', function () {
    register_rest_route('tsp/v1', '/maquina-ler', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            if (get_transient('tsp_maq_ler_trava')) {
                return rest_ensure_response(array('ok' => true, 'msg' => 'lido há menos de 1 minuto'));
            }
            set_transient('tsp_maq_ler_trava', 1, 60);
            $GLOBALS['tsp_maq_forcar'] = true;
            $n = tsp_maq_importar();
            if ($n) {
                do_action('litespeed_purge_all');
            }
            $r = rest_ensure_response(array('ok' => true, 'novas' => (int) $n));
            $r->header('X-Robots-Tag', 'noindex');
            $r->header('Cache-Control', 'no-store');
            return $r;
        },
    ));
});

/* ---------- Página do jogo: link para a matéria pós-jogo ---------- */

add_filter('the_content', function ($c) {
    if (!is_singular('jogo') || !in_the_loop()) {
        return $c;
    }
    $fid = (int) get_post_meta(get_the_ID(), 'tsp_fixture_id', true);
    if (!$fid) {
        return $c;
    }
    $m = get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'publish', 'numberposts' => 1, 'meta_key' => 'tsp_maq_jogo', 'meta_value' => $fid, 'no_found_rows' => true));
    if (!$m) {
        return $c;
    }
    return '<p class="tsp-posjogo-link" style="background:#FFF4E8;border-left:4px solid #E8862A;padding:12px 16px;border-radius:6px;font-weight:600">📰 Como foi o jogo: <a href="' . esc_url(get_permalink($m[0])) . '">' . esc_html(get_the_title($m[0])) . '</a></p>' . $c;
}, 5);


// Atualização automática pelo GitHub do TSP (Painel → Atualizações)
require_once __DIR__ . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('plugin', 'tsp-maquina', plugin_basename(__FILE__), get_file_data(__FILE__, array('v' => 'Version'))['v']);


/* ---------- 1.7.0: sem arte inventada; pós-jogo assinado pela redação ---------- */
add_action('init', function () {
    if (get_option('tsp_maq_migra') === '170') {
        return;
    }
    update_option('tsp_maq_migra', '170', false);
    global $wpdb;
    // 1) Matérias que receberam arte automática: voltam a rascunho esperando foto de verdade; a arte é apagada
    foreach (get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => array('publish', 'future', 'draft'), 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => 'tsp_maq_arte', 'meta_value' => '1')) as $pid) {
        $aid = (int) get_post_thumbnail_id($pid);
        if ($aid && get_post_meta($aid, 'tsp_credito', true) === 'Arte: Tudo Sobre Paulista') {
            delete_post_thumbnail($pid);
            wp_delete_attachment($aid, true);
        }
        delete_post_meta($pid, 'tsp_maq_arte');
        tsp_maq_acf($pid, array('Crédito da imagem', 'Credito da imagem', 'Crédito da foto', 'Credito da foto'), '');
        update_post_meta($pid, 'tsp_maq_status', 'sem_foto');
        $wpdb->update($wpdb->posts, array('post_status' => 'draft'), array('ID' => $pid));
        clean_post_cache($pid);
    }
    // 2) Pós-jogos já publicados passam para a conta da redação
    $autor = tsp_maq_autor_posjogo();
    foreach (get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => 'tsp_maq_tipo', 'meta_value' => 'posjogo')) as $pid) {
        $wpdb->update($wpdb->posts, array('post_author' => $autor), array('ID' => $pid));
        clean_post_cache($pid);
    }
    do_action('litespeed_purge_all');
}, 40);
