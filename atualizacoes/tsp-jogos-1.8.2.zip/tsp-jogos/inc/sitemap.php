<?php
/**
 * Mapa do site das páginas automáticas (09/11/2026): /time/, /jogador/ e /confronto/ não são posts do WordPress,
 * então o Yoast não as lista. Este arquivo cria /tsp-sitemap-dados.xml e o coloca no índice do Yoast e no robots.txt,
 * para o Google achar e indexar essas páginas.
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', function () {
    add_rewrite_rule('^tsp-sitemap-dados\.xml$', 'index.php?tsp_sitemap_dados=1', 'top');
    if (get_option('tsp_sm_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_sm_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_sitemap_dados';
    return $v;
});

function tsp_sm_urls()
{
    $urls = array();
    // Times (não paulistas; os paulistas já estão no Yoast como páginas de clube)
    foreach (tsp_jogos_base_times() as $id => $t) {
        if (!tsp_jogos_slug_do_time($id) && !empty($t['chave'])) {
            $f = function_exists('tsp_tf') ? tsp_tf($id) : null;
            $urls[] = array(home_url('/time/' . sanitize_title($t['chave']) . '/'), $f['gerado'] ?? '', '0.7');
            foreach ((array) ($f['jogadores'] ?? array()) as $s) {
                if (($s['jogos'] ?? 0) >= 3) {
                    $urls[] = array(tsp_tf_jog_url($t['chave'], $s['nome']), $f['gerado'] ?? '', '0.5');
                }
            }
        } elseif (tsp_jogos_slug_do_time($id)) {
            $f = function_exists('tsp_tf') ? tsp_tf($id) : null;
            foreach ((array) ($f['jogadores'] ?? array()) as $s) {
                if (($s['jogos'] ?? 0) >= 3) {
                    $urls[] = array(tsp_tf_jog_url($t['chave'], $s['nome']), $f['gerado'] ?? '', '0.6');
                }
            }
        }
    }
    // Confrontos com clube paulista
    global $wpdb;
    $t = tsp_jogos_tabela();
    $pares = $wpdb->get_results("SELECT casa_id, casa, fora_id, fora, MAX(inicio) ult FROM $t WHERE sp = 1 GROUP BY casa_id, fora_id");
    $vistos = array();
    foreach ($pares as $p) {
        $k = min($p->casa_id, $p->fora_id) . '-' . max($p->casa_id, $p->fora_id);
        if (isset($vistos[$k]) || !function_exists('tsp_conf_url')) {
            continue;
        }
        $vistos[$k] = 1;
        $urls[] = array(tsp_conf_url($p->casa_id, $p->casa, $p->fora_id, $p->fora), wp_date('c', (int) $p->ult), '0.6');
    }
    return $urls;
}

add_action('template_redirect', function () {
    if (!get_query_var('tsp_sitemap_dados')) {
        return;
    }
    status_header(200);
    header('Content-Type: application/xml; charset=UTF-8');
    header('X-Robots-Tag: noindex, follow');
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach (tsp_sm_urls() as $u) {
        echo '<url><loc>' . esc_url($u[0]) . '</loc>' . ($u[1] ? '<lastmod>' . esc_html(gmdate('c', strtotime($u[1]))) . '</lastmod>' : '') . '<priority>' . esc_html($u[2]) . '</priority></url>' . "\n";
    }
    echo '</urlset>';
    exit;
});

// No índice do Yoast
add_filter('wpseo_sitemap_index', function ($xml) {
    return $xml . '<sitemap><loc>' . esc_url(home_url('/tsp-sitemap-dados.xml')) . '</loc><lastmod>' . esc_html(gmdate('c')) . '</lastmod></sitemap>' . "\n";
});
// No robots.txt
add_filter('robots_txt', function ($txt) {
    return rtrim($txt) . "\nSitemap: " . home_url('/tsp-sitemap-dados.xml') . "\n";
}, 99);
