<?php
/**
 * Números do time (08/11/2026): página /time/<chave>/ de qualquer time que enfrenta clubes paulistas
 * e seção "Números da temporada" na página dos clubes paulistas.
 * Tudo sai da base própria do TSP (resultados conferidos em 2 fontes, gols confirmados, escalações das fichas técnicas
 * e elenco do site oficial). Nada é copiado de bancos de estatística.
 *  - Resposta rápida, forma (últimos 5), números por competição (geral, casa e fora), recordes;
 *  - artilheiros do time; jogadores mais utilizados (titular, entrou, gols) e campinho do time-base;
 *  - elenco por posição; últimos e próximos jogos; confrontos com clubes paulistas;
 *  - perguntas frequentes e dados estruturados (SportsTeam + FAQPage).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_tn_elenco($id)
{
    $e = get_option('tsp_jogos_elencos', array());
    return is_array($e) && !empty($e[(int) $id]['jogadores']) ? $e[(int) $id] : null;
}

function tsp_tn_norm($n)
{
    return sanitize_title(remove_accents((string) $n));
}

// Calcula tudo de uma vez (cache curto; a base muda no máximo a cada 15 minutos)
function tsp_tn_dados($id)
{
    $id = (int) $id;
    $ck = 'tsp_tn_' . $id . '_' . (int) get_option('tsp_jogos_base_ver', 0);
    $c = wp_cache_get($ck, 'tsp');
    if ($c !== false) {
        return $c;
    }
    $todos = tsp_jogos_buscar('(casa_id = %d OR fora_id = %d)', array($id, $id), 'inicio ASC', 300);
    $r = array('comp' => array(), 'geral' => array(), 'casa' => array(), 'fora' => array(), 'forma' => array(), 'ult' => array(), 'prx' => array(),
        'artilheiros' => array(), 'uso' => array(), 'ultima_esc' => null, 'maior_v' => null, 'maior_d' => null, 'sem_sofrer' => 0, 'adversarios' => array());
    $zero = array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'gp' => 0, 'gc' => 0);
    $r['geral'] = $r['casa'] = $r['fora'] = $zero;
    foreach ($todos as $j) {
        if (strpos((string) $j->liga, 'fem_') === 0) {
            continue; // a base usa o mesmo time para o masculino e o feminino: a página do time é do masculino
        }
        $em_casa = (int) $j->casa_id === $id;
        $adv = $em_casa ? (int) $j->fora_id : (int) $j->casa_id;
        $r['adversarios'][$adv] = $em_casa ? $j->fora : $j->casa;
        if (in_array($j->status, array('FT', 'AET', 'PEN'), true) && $j->gols_casa !== null) {
            $gp = (int) ($em_casa ? $j->gols_casa : $j->gols_fora);
            $gc = (int) ($em_casa ? $j->gols_fora : $j->gols_casa);
            $res = $gp > $gc ? 'v' : ($gp < $gc ? 'd' : 'e');
            $liga = tsp_jogos_nome_liga($j->liga);
            $r['comp'][$liga] = $r['comp'][$liga] ?? $zero;
            foreach (array(&$r['comp'][$liga], &$r['geral'], &$r[$em_casa ? 'casa' : 'fora']) as &$x) {
                $x['j']++;
                $x[$res]++;
                $x['gp'] += $gp;
                $x['gc'] += $gc;
            }
            unset($x);
            $r['forma'][] = array($res, $j);
            $r['ult'][] = $j;
            if ($gc === 0) {
                $r['sem_sofrer']++;
            }
            if ($res === 'v' && (!$r['maior_v'] || $gp - $gc > $r['maior_v'][0])) {
                $r['maior_v'] = array($gp - $gc, $j);
            }
            if ($res === 'd' && (!$r['maior_d'] || $gc - $gp > $r['maior_d'][0])) {
                $r['maior_d'] = array($gc - $gp, $j);
            }
            $d = tsp_jogos_detalhes($j->id);
            // Gols do time
            foreach ((array) ($d['eventos'] ?? array()) as $ev) {
                if (($ev['type'] ?? '') !== 'Goal' || (int) ($ev['team']['id'] ?? 0) !== $id || ($ev['detail'] ?? '') === 'Own Goal') {
                    continue;
                }
                $n = (string) ($ev['player']['name'] ?? '');
                if ($n === '') {
                    continue;
                }
                $k = tsp_tn_norm($n);
                $r['artilheiros'][$k] = $r['artilheiros'][$k] ?? array('nome' => $n, 'gols' => 0, 'pen' => 0);
                $r['artilheiros'][$k]['gols']++;
                if (($ev['detail'] ?? '') === 'Penalty') {
                    $r['artilheiros'][$k]['pen']++;
                }
            }
            // Escalações confirmadas
            $esc = (array) ($d['esc_tsp'][$em_casa ? 'casa' : 'fora'] ?? array());
            if (!empty($esc['time'])) {
                $linhas = array();
                foreach (explode(';', $esc['time']) as $l) {
                    $nomes = array_values(array_filter(array_map('trim', explode(',', $l))));
                    if ($nomes) {
                        $linhas[] = $nomes;
                    }
                }
                $r['ultima_esc'] = array('linhas' => $linhas, 'tecnico' => $esc['tecnico'] ?? '', 'jogo' => $j);
                foreach ($linhas as $li => $nomes) {
                    foreach ($nomes as $n) {
                        $k = tsp_tn_norm($n);
                        $r['uso'][$k] = $r['uso'][$k] ?? array('nome' => $n, 'tit' => 0, 'ent' => 0, 'linha' => array());
                        $r['uso'][$k]['tit']++;
                        $r['uso'][$k]['linha'][$li] = ($r['uso'][$k]['linha'][$li] ?? 0) + 1;
                    }
                }
                foreach ((array) ($esc['entraram'] ?? array()) as $s) {
                    $k = tsp_tn_norm($s['jogador'] ?? '');
                    if ($k) {
                        $r['uso'][$k] = $r['uso'][$k] ?? array('nome' => $s['jogador'], 'tit' => 0, 'ent' => 0, 'linha' => array());
                        $r['uso'][$k]['ent']++;
                    }
                }
            }
        } elseif ((int) $j->inicio > time() - 3 * HOUR_IN_SECONDS && !in_array($j->status, array('CANC'), true)) {
            $r['prx'][] = $j;
        }
    }
    uasort($r['artilheiros'], function ($a, $b) {
        return $b['gols'] - $a['gols'];
    });
    foreach ($r['uso'] as $k => &$u) {
        $u['gols'] = $r['artilheiros'][$k]['gols'] ?? 0;
        $u['jogos'] = $u['tit'] + $u['ent'];
    }
    unset($u);
    uasort($r['uso'], function ($a, $b) {
        return ($b['tit'] * 10 + $b['ent']) - ($a['tit'] * 10 + $a['ent']);
    });
    $r['forma'] = array_slice($r['forma'], -5);
    $r['ult'] = array_reverse($r['ult']);
    wp_cache_set($ck, $r, 'tsp', 600);
    return $r;
}

function tsp_tn_pct($x)
{
    return $x['j'] ? round(($x['v'] * 3 + $x['e']) / ($x['j'] * 3) * 100) : 0;
}

function tsp_tn_placar($j, $id)
{
    $c = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $f = tsp_jogos_nome_time($j->fora_id, $j->fora);
    return $c . ' ' . (int) $j->gols_casa . ' x ' . (int) $j->gols_fora . ' ' . $f;
}

// Campinho: time-base (mais escalados, nas linhas em que mais jogaram) ou o último time confirmado
function tsp_tn_campinho($r)
{
    if (!$r['ultima_esc']) {
        return '';
    }
    $linhas_ult = $r['ultima_esc']['linhas'];
    $formacao = array_map('count', $linhas_ult);
    $base = array();
    $usados = array();
    if (count($r['ult']) >= 3 && count(array_filter($r['uso'], function ($u) {
        return $u['tit'] > 0;
    })) >= 11) {
        // preenche cada linha com quem mais jogou nela
        foreach ($formacao as $li => $qtd) {
            $cand = array();
            foreach ($r['uso'] as $k => $u) {
                if (!isset($usados[$k]) && !empty($u['linha'][$li])) {
                    $cand[$k] = $u['linha'][$li];
                }
            }
            arsort($cand);
            $base[$li] = array();
            foreach (array_slice(array_keys($cand), 0, $qtd) as $k) {
                $base[$li][] = $r['uso'][$k];
                $usados[$k] = 1;
            }
        }
        $tit = 'Time-base: os mais escalados em cada setor (' . implode('-', array_slice($formacao, 1)) . ')';
    } else {
        foreach ($linhas_ult as $li => $nomes) {
            foreach ($nomes as $n) {
                $base[$li][] = $r['uso'][tsp_tn_norm($n)] ?? array('nome' => $n, 'tit' => 1, 'ent' => 0, 'gols' => 0);
            }
        }
        $j = $r['ultima_esc']['jogo'];
        $tit = 'Último time titular confirmado (' . implode('-', array_slice($formacao, 1)) . ') · ' . wp_date('d/m', $j->inicio);
    }
    $h = '<figure class="tsp-campo"><figcaption>' . esc_html($tit) . '</figcaption><div class="tsp-campo__gramado">';
    foreach (array_reverse($base) as $linha) { // ataque em cima, goleiro embaixo
        $h .= '<div class="tsp-campo__linha">';
        foreach ($linha as $u) {
            $h .= '<div class="tsp-campo__jog"><span class="tsp-campo__bola">' . (int) ($u['tit'] ?? 0) . '</span><span class="tsp-campo__nome">' . esc_html($u['nome']) . '</span>' . (!empty($u['gols']) ? '<span class="tsp-campo__gols">⚽ ' . (int) $u['gols'] . '</span>' : '') . '</div>';
        }
        $h .= '</div>';
    }
    $h .= '</div><p class="tsp-nota">O número na bola é quantas vezes o jogador começou jogando nos jogos com escalação confirmada.' . ($r['ultima_esc']['tecnico'] ? ' Técnico: ' . esc_html($r['ultima_esc']['tecnico']) . '.' : '') . '</p></figure>';
    return $h;
}

function tsp_tn_html($id, $nome, $completo = true)
{
    $r = tsp_tn_dados($id);
    if (!$r['geral']['j'] && !$r['prx']) {
        return '';
    }
    $g = $r['geral'];
    $h = '';
    // Forma
    if ($r['forma']) {
        $h .= '<div class="tsp-forma" aria-label="Últimos 5 jogos">';
        foreach ($r['forma'] as $f) {
            $h .= '<span class="tsp-forma__' . $f[0] . '" title="' . esc_attr(tsp_tn_placar($f[1], $id) . ' · ' . wp_date('d/m', $f[1]->inicio)) . '">' . strtoupper($f[0]) . '</span>';
        }
        $h .= '</div>';
    }
    // Números por competição
    if ($g['j']) {
        $h .= '<section class="tsp-tn__bloco"><h2>Números da temporada</h2><div class="tsp-tabela-rolagem"><table class="tsp-stats tsp-tn__tab"><thead><tr><th>Competição</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>%</th></tr></thead><tbody>';
        $linha = function ($rot, $x, $forte = false) {
            return '<tr' . ($forte ? ' class="tsp-tn__total"' : '') . '><td>' . esc_html($rot) . '</td><td>' . $x['j'] . '</td><td>' . $x['v'] . '</td><td>' . $x['e'] . '</td><td>' . $x['d'] . '</td><td>' . $x['gp'] . '</td><td>' . $x['gc'] . '</td><td>' . ($x['gp'] - $x['gc']) . '</td><td>' . tsp_tn_pct($x) . '%</td></tr>';
        };
        foreach ($r['comp'] as $c => $x) {
            $h .= $linha($c, $x);
        }
        if (count($r['comp']) > 1) {
            $h .= $linha('Total', $g, true);
        }
        $h .= $linha('Em casa', $r['casa']) . $linha('Fora de casa', $r['fora']);
        $h .= '</tbody></table></div>';
        $h .= '<dl class="tsp-camp__ficha"><div><dt>Média de gols marcados</dt><dd>' . number_format_i18n($g['gp'] / $g['j'], 1) . '</dd></div><div><dt>Média de gols sofridos</dt><dd>' . number_format_i18n($g['gc'] / $g['j'], 1) . '</dd></div><div><dt>Jogos sem sofrer gol</dt><dd>' . (int) $r['sem_sofrer'] . '</dd></div>';
        if ($r['maior_v']) {
            $h .= '<div><dt>Maior vitória</dt><dd><small>' . esc_html(tsp_tn_placar($r['maior_v'][1], $id)) . '</small></dd></div>';
        }
        if ($r['maior_d']) {
            $h .= '<div><dt>Maior derrota</dt><dd><small>' . esc_html(tsp_tn_placar($r['maior_d'][1], $id)) . '</small></dd></div>';
        }
        $h .= '</dl></section>';
    }
    // Artilheiros e mais utilizados
    $art = array_slice($r['artilheiros'], 0, 10);
    $uso = array_slice(array_filter($r['uso'], function ($u) {
        return $u['jogos'] > 0;
    }), 0, 15);
    if ($art || $uso) {
        $h .= '<section class="tsp-tn__bloco"><div class="tsp-jogo__duas">';
        if ($art) {
            $h .= '<div><h2>Artilheiros do ' . esc_html($nome) . '</h2><table class="tsp-stats"><thead><tr><th>Jogador</th><th>Gols</th><th>Pênaltis</th></tr></thead><tbody>';
            foreach ($art as $a) {
                $h .= '<tr><td>' . esc_html($a['nome']) . '</td><td><strong>' . (int) $a['gols'] . '</strong></td><td>' . (int) $a['pen'] . '</td></tr>';
            }
            $h .= '</tbody></table></div>';
        }
        if ($uso) {
            $h .= '<div><h2>Jogadores mais utilizados</h2><table class="tsp-stats"><thead><tr><th>Jogador</th><th>Jogos</th><th>Titular</th><th>Entrou</th><th>Gols</th></tr></thead><tbody>';
            foreach ($uso as $u) {
                $h .= '<tr><td>' . esc_html($u['nome']) . '</td><td><strong>' . (int) $u['jogos'] . '</strong></td><td>' . (int) $u['tit'] . '</td><td>' . (int) $u['ent'] . '</td><td>' . (int) $u['gols'] . '</td></tr>';
            }
            $h .= '</tbody></table></div>';
        }
        $h .= '</div>' . tsp_tn_campinho($r) . '</section>';
    }
    if (!$completo) {
        return '<div class="tsp-tn">' . $h . '<p class="tsp-nota">Números dos jogos registrados na base do TSP (resultados conferidos em 2 fontes).</p></div>';
    }
    // Elenco
    $el = tsp_tn_elenco($id);
    if ($el) {
        $h .= '<section class="tsp-tn__bloco"><h2>Elenco do ' . esc_html($nome) . '</h2><div class="tsp-tn__elenco">';
        foreach (array('Goleiro' => 'Goleiros', 'Zagueiro' => 'Zagueiros', 'Lateral' => 'Laterais', 'Volante' => 'Volantes', 'Meia' => 'Meias', 'Atacante' => 'Atacantes') as $pos => $rot) {
            $js = array_filter($el['jogadores'], function ($x) use ($pos) {
                return ($x['posicao'] ?? '') === $pos;
            });
            if (!$js) {
                continue;
            }
            $h .= '<div><h3>' . esc_html($rot) . '</h3><ul>';
            foreach ($js as $x) {
                $u = $r['uso'][tsp_tn_norm($x['nome'])] ?? null;
                $h .= '<li>' . (!empty($x['numero']) ? '<span class="tsp-tn__num">' . (int) $x['numero'] . '</span>' : '') . esc_html($x['nome']) . ($u && $u['jogos'] ? ' <small>' . (int) $u['jogos'] . ' jogos' . ($u['gols'] ? ', ' . (int) $u['gols'] . ' gols' : '') . '</small>' : '') . '</li>';
            }
            $h .= '</ul></div>';
        }
        $h .= '</div><p class="tsp-nota">Elenco conforme o site oficial do clube, conferido em ' . esc_html(wp_date('d/m/Y', strtotime($el['atualizado']))) . '. <a href="' . esc_url($el['fonte']) . '" rel="nofollow noopener" target="_blank">Fonte</a>.</p></section>';
    }
    return '<div class="tsp-tn">' . $h . '</div>';
}

function tsp_tn_faq($id, $nome)
{
    $r = tsp_tn_dados($id);
    $faq = array();
    if ($r['prx']) {
        $j = $r['prx'][0];
        $faq[] = array('Quando é o próximo jogo do ' . $nome . '?', tsp_jogos_nome_time($j->casa_id, $j->casa) . ' x ' . tsp_jogos_nome_time($j->fora_id, $j->fora) . ', ' . wp_date('l, d/m/Y \à\s H\hi', $j->inicio) . ' (horário de Brasília)' . ($j->estadio ? ', no ' . $j->estadio : '') . ' (' . tsp_jogos_nome_liga($j->liga) . ').');
    }
    if ($r['ult']) {
        $j = $r['ult'][0];
        $faq[] = array('Qual foi o último resultado do ' . $nome . '?', tsp_tn_placar($j, $id) . ', em ' . wp_date('d/m/Y', $j->inicio) . ' (' . tsp_jogos_nome_liga($j->liga) . ').');
    }
    if ($r['artilheiros']) {
        $a = reset($r['artilheiros']);
        $faq[] = array('Quem é o artilheiro do ' . $nome . '?', $a['nome'] . ', com ' . (int) $a['gols'] . ' gol' . ($a['gols'] > 1 ? 's' : '') . ' nos jogos registrados pelo TSP nesta temporada.');
    }
    if ($r['geral']['j']) {
        $g = $r['geral'];
        $faq[] = array('Qual a campanha do ' . $nome . ' na temporada?', $g['j'] . ' jogos, ' . $g['v'] . ' vitórias, ' . $g['e'] . ' empates e ' . $g['d'] . ' derrotas, com ' . $g['gp'] . ' gols marcados e ' . $g['gc'] . ' sofridos (' . tsp_tn_pct($g) . '% de aproveitamento).');
    }
    return $faq;
}

function tsp_tn_pagina($id, $t)
{
    $nome = $t['nome'];
    $r = tsp_tn_dados($id);
    $h = '<main class="tsp-container tsp-camp tsp-time"><header class="tsp-camp__cab">';
    if (function_exists('tsp_breadcrumbs')) {
        ob_start();
        tsp_breadcrumbs();
        $h .= ob_get_clean();
    }
    $h .= '<div class="tsp-tn__cab">' . (function_exists('tsp_jogos_escudo_html') ? tsp_jogos_escudo_html($id, $nome) : '') . '<h1>' . esc_html($nome) . ': jogos, elenco, artilheiros e estatísticas</h1></div>';
    // Resposta rápida
    $pos = array();
    foreach (tsp_jogos_ligas() as $liga => $l) {
        foreach ((array) (tsp_jogos_classificacao($liga)['grupos'] ?? array()) as $gr) {
            foreach ($gr as $x) {
                if ((int) $x[1] === (int) $id) {
                    $pos[] = array(tsp_jogos_nome_liga($liga), $x);
                }
            }
        }
    }
    $faq = tsp_tn_faq($id, $nome);
    $resp = $pos ? $nome . ' está em ' . (int) $pos[0][1][0] . 'º lugar no ' . $pos[0][0] . ', com ' . (int) $pos[0][1][3] . ' pontos em ' . (int) $pos[0][1][4] . ' jogos.' : '';
    foreach ($faq as $f) {
        if (strpos($f[0], 'próximo jogo') !== false || strpos($f[0], 'último resultado') !== false) {
            $resp .= ' ' . $f[1];
        }
    }
    if (trim($resp)) {
        $h .= '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html(trim($resp)) . '</p></div>';
    }
    $h .= '</header>';
    $tem_ficha = function_exists('tsp_tf') && tsp_tf($id);
    $h .= tsp_tn_html($id, $nome, !$tem_ficha || empty(tsp_tf($id)['elenco']));
    $h .= $tem_ficha ? '<div class="tsp-tn">' . tsp_tf_html($id, $nome) . '</div>' : '';
    // Jogos
    $li = function ($j) {
        $placar = ($j->gols_casa !== null && $j->status !== 'NS') ? (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : 'x';
        $link = function_exists('tsp_jogos_link_jogo') ? tsp_jogos_link_jogo($j->id) : '';
        return '<li class="tsp-jogos__item"><span class="tsp-jogos__dia">' . esc_html(tsp_jogos_dia_curto($j->inicio)) . '</span><span class="tsp-jogos__casa">' . esc_html(tsp_jogos_nome_time($j->casa_id, $j->casa)) . '</span><span class="tsp-jogos__placar">' . esc_html($placar) . '</span><span class="tsp-jogos__fora">' . esc_html(tsp_jogos_nome_time($j->fora_id, $j->fora)) . '</span><span class="tsp-jogos__extra"><span class="tsp-jogos__comp">' . esc_html(tsp_jogos_nome_liga($j->liga)) . '</span>' . ($link ? '<a class="tsp-jogos__link" href="' . esc_url($link) . '">Ficha do jogo →</a>' : '') . '</span></li>';
    };
    if ($r['ult'] || $r['prx']) {
        $h .= '<section class="tsp-secao"><div class="tsp-painel__linha tsp-painel__linha--2">';
        if ($r['prx']) {
            $h .= '<div class="tsp-jogos tsp-jogos--escuro"><h2 class="tsp-caixa__tit">Próximos jogos</h2><ul>' . implode('', array_map($li, array_slice($r['prx'], 0, 5))) . '</ul></div>';
        }
        if ($r['ult'] && empty($tem_ficha)) {
            $h .= '<div class="tsp-jogos"><h2 class="tsp-caixa__tit">Jogos da temporada</h2><ul>' . implode('', array_map($li, array_slice($r['ult'], 0, 20))) . '</ul></div>';
        }
        $h .= '</div></section>';
    }
    // Confrontos com clubes paulistas
    $links = array();
    foreach ($r['adversarios'] as $adv => $an) {
        if (tsp_jogos_slug_do_time($adv) && function_exists('tsp_conf_url')) {
            $links[] = '<a href="' . esc_url(tsp_conf_url($id, $nome, $adv, $an)) . '">' . esc_html($nome . ' x ' . tsp_jogos_nome_time($adv, $an)) . '</a>';
        }
    }
    if ($links) {
        $h .= '<section class="tsp-tn__bloco"><h2>Confrontos com clubes paulistas</h2><p>' . implode(' · ', $links) . '</p></section>';
    }
    if ($faq) {
        $h .= '<section class="tsp-tn__bloco"><h2>Perguntas frequentes</h2>';
        foreach ($faq as $f) {
            $h .= '<h3>' . esc_html($f[0]) . '</h3><p>' . esc_html($f[1]) . '</p>';
        }
        $h .= '</section>';
    }
    $h .= '<p class="tsp-nota">Números dos jogos registrados na base própria do TSP nesta temporada: resultados conferidos em 2 fontes, gols e escalações das fichas técnicas de veículos jornalísticos e sites oficiais. Atualizado sozinho depois de cada jogo.</p>';
    return $h . '</main>';
}

// Dados estruturados da página do time
add_action('wp_head', function () {
    $t = $GLOBALS['tsp_time_atual'] ?? null;
    if (!$t) {
        return;
    }
    $nome = $t[1]['nome'];
    $ld = array(array('@context' => 'https://schema.org', '@type' => 'SportsTeam', 'name' => $nome, 'sport' => 'Futebol', 'url' => home_url('/time/' . sanitize_title($t[1]['chave']) . '/')));
    if (!empty($t[1]['wiki'])) {
        $ld[0]['sameAs'] = 'https://pt.wikipedia.org/wiki/' . rawurlencode(str_replace(' ', '_', $t[1]['wiki']));
    }
    $el = tsp_tn_elenco($t[0]);
    if ($el) {
        $ld[0]['athlete'] = array_map(function ($x) {
            return array('@type' => 'Person', 'name' => $x['nome']);
        }, array_slice($el['jogadores'], 0, 40));
    }
    $faq = tsp_tn_faq($t[0], $nome);
    if ($faq) {
        $ld[] = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($x) {
            return array('@type' => 'Question', 'name' => $x[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $x[1]));
        }, $faq));
    }
    foreach ($ld as $x) {
        echo '<script type="application/ld+json">' . wp_json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
    }
}, 5);

// Estilos
add_action('wp_head', function () {
    if (empty($GLOBALS['tsp_time_atual']) && !is_tax('times')) {
        return;
    }
    echo '<style>.tsp-tn .tsp-stats{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;font-size:15px}.tsp-tn .tsp-stats th{background:#111;color:#fff;padding:8px 6px;font-weight:700;text-align:center}.tsp-tn .tsp-stats td{padding:7px 6px;border-bottom:1px solid #eee;text-align:center}.tsp-tn .tsp-stats td:first-child,.tsp-tn .tsp-stats th:first-child{text-align:left}.tsp-tn .tsp-stats tr:nth-child(even) td{background:#faf7f2}'
        . '.tsp-tn .tsp-jogo__duas{display:grid;grid-template-columns:1fr 1fr;gap:20px}@media(max-width:760px){.tsp-tn .tsp-jogo__duas{grid-template-columns:1fr}}.tsp-tn .tsp-camp__ficha{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-top:12px}.tsp-tn .tsp-camp__ficha div{display:block;background:#fff;border-radius:8px;padding:10px;border:1px solid #eee;min-width:0}.tsp-tn .tsp-camp__ficha dt{font-size:12px;text-transform:uppercase;color:#666}.tsp-tn .tsp-camp__ficha dd{margin:4px 0 0;font-size:22px;font-weight:800;text-align:left;overflow-wrap:anywhere}.tsp-tn .tsp-camp__ficha dd small{font-size:13px;font-weight:600}'
        . '.tsp-tn__cab{display:flex;align-items:center;gap:14px}.tsp-tn__cab img{width:56px;height:56px;object-fit:contain}.tsp-tn__bloco{margin:26px 0}.tsp-tn__bloco h2{font-size:24px;margin-bottom:10px}.tsp-tn__tab td:first-child{text-align:left}.tsp-tn__total td{font-weight:800}.tsp-tabela-rolagem{overflow-x:auto}'
        . '.tsp-forma{display:flex;gap:6px;margin:12px 0}.tsp-forma span{width:28px;height:28px;border-radius:6px;display:grid;place-items:center;font-weight:800;color:#fff;font-size:13px}.tsp-forma__v{background:#1e9e4a}.tsp-forma__e{background:#8a8f98}.tsp-forma__d{background:#d33a2c}'
        . '.tsp-campo{margin:18px 0}.tsp-campo figcaption{font-weight:700;margin-bottom:8px}.tsp-campo__gramado{background:repeating-linear-gradient(0deg,#2f8a3c 0 40px,#34963f 40px 80px);border-radius:12px;padding:18px 8px;display:flex;flex-direction:column;gap:18px;max-width:560px;border:3px solid #fff;outline:2px solid #2f8a3c}'
        . '.tsp-campo__linha{display:flex;justify-content:space-around;gap:4px}.tsp-campo__jog{display:flex;flex-direction:column;align-items:center;min-width:0;flex:1;color:#fff;text-align:center}.tsp-campo__bola{width:30px;height:30px;border-radius:50%;background:#fff;color:#111;font-weight:800;display:grid;place-items:center;font-size:13px;box-shadow:0 2px 4px rgba(0,0,0,.3)}'
        . '.tsp-campo__nome{font-size:12px;font-weight:700;margin-top:4px;line-height:1.1;text-shadow:0 1px 2px rgba(0,0,0,.6);overflow-wrap:anywhere}.tsp-campo__gols{font-size:11px}'
        . '.tsp-tn__elenco{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}.tsp-tn__elenco h3{font-size:16px;text-transform:uppercase;margin:0 0 6px}.tsp-tn__elenco ul{list-style:none;margin:0;padding:0}.tsp-tn__elenco li{padding:4px 0;border-bottom:1px solid #eee}.tsp-tn__num{display:inline-block;min-width:26px;font-weight:800;color:#A8520C}</style>';
});
