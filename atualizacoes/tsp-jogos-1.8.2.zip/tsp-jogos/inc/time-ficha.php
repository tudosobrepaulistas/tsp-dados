<?php
/**
 * Ficha completa do time e do jogador (09/11/2026), a partir dos arquivos api/times/<time>.json da base do TSP
 * (calculados pelo motor de estatísticas: todos os jogos oficiais da temporada, jogadores que entraram em campo,
 * minutos, gols, cartões, aproveitamento com e sem o jogador, elenco com foto).
 *  - Página do time /time/<chave>/: jogos por competição, jogadores, "com ele em campo", elenco com fotos.
 *  - Página do jogador /jogador/<time>/<jogador>/: perfil, números, aproveitamento com/sem ele, jogos.
 *  - Página do jogo: prognóstico estatístico do TSP (modelo de Poisson).
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------- Importação dos arquivos dos times (a cada 15 min, só o que mudou) ---------- */
function tsp_tf_url($arq)
{
    return preg_replace('~tsp\.json(\?.*)?$~', 'times/' . $arq, tsp_jogos_base_url());
}

function tsp_tf_importar()
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 300), tsp_tf_url('indice.json')), array('timeout' => 20));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return 0;
    }
    $ind = json_decode(wp_remote_retrieve_body($r), true);
    $hashes = (array) get_option('tsp_tf_hashes', array());
    $n = 0;
    foreach ((array) ($ind['times'] ?? array()) as $chave => $t) {
        $chave = sanitize_title($chave);
        if (($hashes[$chave] ?? '') === ($t['hash'] ?? '') || $n >= 25) {
            continue;
        }
        $x = wp_remote_get(add_query_arg('h', $t['hash'] ?? '', tsp_tf_url($chave . '.json')), array('timeout' => 20));
        if (is_wp_error($x) || (int) wp_remote_retrieve_response_code($x) !== 200) {
            continue;
        }
        $d = json_decode(wp_remote_retrieve_body($x), true);
        if (!is_array($d) || empty($d['id'])) {
            continue;
        }
        update_option('tsp_tf_' . (int) $d['id'], tsp_jogos_limpar_lista($d), false);
        $hashes[$chave] = $t['hash'] ?? '';
        $n++;
    }
    update_option('tsp_tf_hashes', $hashes, false);
    return $n;
}
add_action('init', function () {
    if (!wp_next_scheduled('tsp_tf_importar')) {
        wp_schedule_event(time() + 60, 'tsp_15min', 'tsp_tf_importar');
    }
});
add_filter('cron_schedules', function ($s) {
    $s['tsp_15min'] = $s['tsp_15min'] ?? array('interval' => 900, 'display' => 'A cada 15 minutos (TSP)');
    return $s;
});
add_action('tsp_tf_importar', 'tsp_tf_importar');

function tsp_tf($id)
{
    $d = get_option('tsp_tf_' . (int) $id, null);
    return is_array($d) ? $d : null;
}

function tsp_tf_jog_url($chave_time, $nome)
{
    return home_url('/jogador/' . sanitize_title($chave_time) . '/' . sanitize_title(remove_accents($nome)) . '/');
}

function tsp_tf_res_badge($x)
{
    if (empty($x['res'])) {
        return '<span class="tsp-tf__res tsp-tf__res--x">·</span>';
    }
    return '<span class="tsp-tf__res tsp-tf__res--' . esc_attr($x['res']) . '">' . strtoupper(esc_html($x['res'])) . '</span>';
}

/* ---------- Seções da página do time ---------- */
function tsp_tf_html($id, $nome)
{
    $f = tsp_tf($id);
    if (!$f) {
        return '';
    }
    $h = '';
    // Jogos por competição
    $por = array();
    foreach ((array) $f['jogos'] as $x) {
        $por[$x['nome_comp']][] = $x;
    }
    if ($por) {
        $h .= '<section class="tsp-tn__bloco"><h2>Todos os jogos oficiais da temporada</h2>';
        foreach ($por as $comp => $js) {
            $enc = array_filter($js, function ($x) {
                return isset($x['res']);
            });
            $h .= '<details class="tsp-tf__comp"' . (count($por) === 1 ? ' open' : '') . '><summary><strong>' . esc_html($comp) . '</strong> <small>' . count($js) . ' jogos' . ($enc ? ' · ' . count(array_filter($enc, function ($x) {
                return $x['res'] === 'v';
            })) . 'V ' . count(array_filter($enc, function ($x) {
                return $x['res'] === 'e';
            })) . 'E ' . count(array_filter($enc, function ($x) {
                return $x['res'] === 'd';
            })) . 'D' : '') . '</small></summary><table class="tsp-stats"><thead><tr><th>Data</th><th>Fase</th><th></th><th>Adversário</th><th>Placar</th><th></th></tr></thead><tbody>';
            foreach ($js as $x) {
                $link = function_exists('tsp_jogos_link_jogo') ? tsp_jogos_link_jogo($x['id']) : '';
                $pl = isset($x['gp']) && $x['gp'] !== null ? ($x['mando'] === 'casa' ? $x['gp'] . ' x ' . $x['gc'] : $x['gc'] . ' x ' . $x['gp']) : 'x';
                $h .= '<tr><td>' . esc_html(wp_date('d/m', strtotime($x['data']))) . '</td><td>' . esc_html(trim(($x['fase'] ?? '') . ' ' . (!empty($x['rodada']) ? 'R' . $x['rodada'] : ''))) . '</td><td>' . ($x['mando'] === 'casa' ? 'Casa' : 'Fora') . '</td><td>' . esc_html($x['adv_nome']) . '</td><td>' . ($link ? '<a href="' . esc_url($link) . '">' . esc_html($pl) . '</a>' : esc_html($pl)) . (!empty($x['pen']) ? ' <small>(pên. ' . esc_html($x['pen']) . ')</small>' : '') . '</td><td>' . tsp_tf_res_badge($x) . '</td></tr>';
            }
            $h .= '</tbody></table></details>';
        }
        $h .= '</section>';
    }
    // Jogadores que entraram em campo
    $jog = array_values(array_filter((array) $f['jogadores'], function ($s) {
        return $s['jogos'] > 0 || $s['gols'] > 0;
    }));
    if ($jog) {
        $h .= '<section class="tsp-tn__bloco"><h2>Jogadores que entraram em campo pelo ' . esc_html($nome) . '</h2><p class="tsp-nota">' . (int) $f['jogos_com_escalacao'] . ' jogos com escalação confirmada. Clique no título da coluna para ordenar.</p><div class="tsp-tabela-rolagem"><table class="tsp-stats tsp-tf__ord"><thead><tr><th>Nº</th><th>Jogador</th><th>Pos.</th><th>J</th><th>Tit.</th><th>Ent.</th><th>Min.</th><th>Gols</th><th>🟨</th><th>🟥</th><th>Aprov. com ele</th><th>Sem ele</th></tr></thead><tbody>';
        foreach ($jog as $s) {
            $h .= '<tr><td>' . (!empty($s['numero']) ? (int) $s['numero'] : '') . '</td><td style="text-align:left"><a href="' . esc_url(tsp_tf_jog_url($f['time'], $s['nome'])) . '">' . esc_html($s['nome']) . '</a></td><td>' . esc_html(mb_substr($s['posicao'] ?? '', 0, 3)) . '</td><td>' . (int) $s['jogos'] . '</td><td>' . (int) $s['tit'] . '</td><td>' . (int) $s['ent'] . '</td><td>' . (int) $s['min'] . (!empty($s['min_est']) ? '*' : '') . '</td><td>' . (int) $s['gols'] . '</td><td>' . (int) $s['am'] . '</td><td>' . (int) $s['vm'] . '</td><td>' . ($s['aprov'] !== null ? (int) $s['aprov'] . '%' : '—') . '</td><td>' . (isset($s['sem']['aprov']) && $s['sem']['aprov'] !== null ? (int) $s['sem']['aprov'] . '% <small>(' . (int) $s['sem']['j'] . ')</small>' : '—') . '</td></tr>';
        }
        $h .= '</tbody></table></div><p class="tsp-nota">Aproveitamento = pontos ganhos ÷ pontos disputados. "Sem ele" = jogos com escalação confirmada em que o jogador não entrou. * minutos estimados (substituição sem minuto na ficha).</p>';
        // Quem faz diferença (mínimo 4 jogos com e 3 sem)
        $dif = array();
        foreach ($jog as $s) {
            if ($s['jogos'] >= 4 && isset($s['sem']['j']) && $s['sem']['j'] >= 3 && $s['aprov'] !== null && $s['sem']['aprov'] !== null && $s['aprov'] > $s['sem']['aprov']) {
                $dif[] = array($s['aprov'] - $s['sem']['aprov'], $s);
            }
        }
        usort($dif, function ($a, $b) {
            return $b[0] - $a[0];
        });
        if ($dif) {
            $h .= '<h3>Quem faz diferença</h3><ul class="tsp-tf__dif">';
            foreach (array_slice($dif, 0, 3) as $x) {
                $s = $x[1];
                $h .= '<li>Com <strong>' . esc_html($s['nome']) . '</strong> em campo, o ' . esc_html($nome) . ' tem <strong>' . (int) $s['aprov'] . '%</strong> de aproveitamento (' . (int) $s['v'] . 'V ' . (int) $s['e'] . 'E ' . (int) $s['d'] . 'D); sem ele, ' . (int) $s['sem']['aprov'] . '% (' . (int) $s['sem']['j'] . ' jogos).</li>';
            }
            $h .= '</ul>';
        }
        $h .= '</section>';
    }
    // Elenco com fotos
    $el = $f['elenco']['jogadores'] ?? array();
    if ($el) {
        $idx = array();
        foreach ($jog as $s) {
            $idx[sanitize_title(remove_accents($s['nome']))] = $s;
        }
        $h .= '<section class="tsp-tn__bloco"><h2>Elenco do ' . esc_html($nome) . '</h2>';
        foreach (array('Goleiro' => 'Goleiros', 'Zagueiro' => 'Zagueiros', 'Lateral' => 'Laterais', 'Volante' => 'Volantes', 'Meia' => 'Meias', 'Atacante' => 'Atacantes') as $pos => $rot) {
            $js = array_filter($el, function ($x) use ($pos) {
                return ($x['posicao'] ?? '') === $pos;
            });
            if (!$js) {
                continue;
            }
            $h .= '<h3 class="tsp-sub-bloco">' . esc_html($rot) . '</h3><div class="tsp-tf__elenco">';
            foreach ($js as $x) {
                $s = $idx[sanitize_title(remove_accents($x['nome']))] ?? null;
                $idade = !empty($x['nascimento']) ? (int) floor((time() - strtotime($x['nascimento'])) / (365.25 * DAY_IN_SECONDS)) : 0;
                $h .= '<a class="tsp-tf__jog" href="' . esc_url(tsp_tf_jog_url($f['time'], $x['nome'])) . '">';
                $h .= !empty($x['foto']['url']) ? '<img src="' . esc_url($x['foto']['url']) . '" alt="' . esc_attr($x['nome'] . ', ' . strtolower($pos) . ' do ' . $nome) . '" loading="lazy" referrerpolicy="no-referrer" width="120" height="120">' : '<span class="tsp-tf__sem-foto" aria-hidden="true">' . esc_html(mb_substr($x['nome'], 0, 1)) . '</span>';
                $h .= '<span class="tsp-tf__nome">' . (!empty($x['numero']) ? '<b>' . (int) $x['numero'] . '</b> ' : '') . esc_html($x['nome']) . '</span>';
                $h .= '<small>' . esc_html(trim(($idade ? $idade . ' anos' : '') . (!empty($x['nacionalidade']) && $x['nacionalidade'] !== 'Brasil' ? ' · ' . $x['nacionalidade'] : ''))) . '</small>';
                $h .= $s && $s['jogos'] ? '<small>' . (int) $s['jogos'] . ' jogos · ' . (int) $s['gols'] . ' gols</small>' : '';
                $h .= '</a>';
            }
            $h .= '</div>';
        }
        $h .= '<p class="tsp-nota">Elenco e fotos: site oficial do clube (créditos na página de cada jogador), conferido em ' . esc_html(wp_date('d/m/Y', strtotime($f['elenco']['atualizado'] ?? 'now'))) . '.</p></section>';
    }
    return $h;
}

/* ---------- Página do jogador ---------- */
add_action('init', function () {
    add_rewrite_rule('^jogador/([a-z0-9-]+)/([a-z0-9-]+)/?$', 'index.php?tsp_jogador=$matches[1]|$matches[2]', 'top');
    if (get_option('tsp_tf_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_tf_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_jogador';
    return $v;
});

add_action('template_redirect', function () {
    $q = get_query_var('tsp_jogador');
    if (!$q) {
        return;
    }
    list($ct, $cj) = array_pad(explode('|', $q), 2, '');
    $t = function_exists('tsp_jogos_time_da_chave') ? tsp_jogos_time_da_chave($ct) : null;
    $f = $t ? tsp_tf($t[0]) : null;
    if (!$f) {
        return;
    }
    $s = null;
    foreach ((array) $f['jogadores'] as $x) {
        if (sanitize_title(remove_accents($x['nome'])) === $cj) {
            $s = $x;
        }
    }
    $e = null;
    foreach ((array) ($f['elenco']['jogadores'] ?? array()) as $x) {
        if (sanitize_title(remove_accents($x['nome'])) === $cj) {
            $e = $x;
        }
    }
    if (!$s && !$e) {
        return;
    }
    $nome = $s['nome'] ?? $e['nome'];
    $time = $f['nome'];
    $pos = $e['posicao'] ?? ($s['posicao'] ?? '');
    $titulo = $nome . ' (' . $time . '): estatísticas, jogos e gols na temporada';
    $resp = $nome . ($pos ? ', ' . strtolower($pos) . ' do ' . $time : ', do ' . $time) . ($s && $s['jogos'] ? ', entrou em campo em ' . (int) $s['jogos'] . ' jogos na temporada (' . (int) $s['tit'] . ' como titular), com ' . (int) $s['gols'] . ' gol' . ((int) $s['gols'] === 1 ? '' : 's') . ' e ' . (int) $s['min'] . ' minutos jogados.' : '.');
    if ($s && $s['aprov'] !== null) {
        $resp .= ' Com ele em campo, o ' . $time . ' tem ' . (int) $s['aprov'] . '% de aproveitamento' . (isset($s['sem']['aprov']) && $s['sem']['aprov'] !== null ? '; sem ele, ' . (int) $s['sem']['aprov'] . '%' : '') . '.';
    }
    add_filter('pre_get_document_title', function () use ($titulo) {
        return $titulo . ' | Tudo Sobre Paulista';
    }, 99);
    add_filter('wpseo_title', function () use ($titulo) {
        return $titulo . ' | Tudo Sobre Paulista';
    }, 99);
    add_filter('wpseo_metadesc', function () use ($resp) {
        return mb_substr($resp, 0, 155);
    }, 99);
    add_action('wp_head', function () use ($nome, $time, $e, $resp) {
        $ld = array('@context' => 'https://schema.org', '@type' => 'Person', 'name' => $nome, 'jobTitle' => 'Jogador de futebol', 'affiliation' => array('@type' => 'SportsTeam', 'name' => $time), 'description' => $resp);
        if (!empty($e['nascimento'])) {
            $ld['birthDate'] = $e['nascimento'];
        }
        if (!empty($e['nacionalidade'])) {
            $ld['nationality'] = $e['nacionalidade'];
        }
        if (!empty($e['foto']['url'])) {
            $ld['image'] = $e['foto']['url'];
        }
        echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
    });
    $GLOBALS['tsp_time_atual'] = $t; // reaproveita os estilos da página do time
    status_header(200);
    get_header();
    echo '<main class="tsp-container tsp-camp tsp-time tsp-tn"><header class="tsp-camp__cab">';
    echo '<p><a href="' . esc_url(tsp_jogos_time_link($t[0])) . '">← ' . esc_html($time) . '</a></p>';
    echo '<div class="tsp-tf__perfil">' . (!empty($e['foto']['url']) ? '<figure><img src="' . esc_url($e['foto']['url']) . '" alt="' . esc_attr($nome . ', jogador do ' . $time) . '" width="220" height="220" referrerpolicy="no-referrer"><figcaption>' . esc_html($e['foto']['credito'] ?? '') . '</figcaption></figure>' : '');
    echo '<div><h1>' . esc_html($nome) . '</h1><dl class="tsp-camp__ficha">';
    $dados = array('Clube' => $time, 'Posição' => $pos, 'Número' => $e['numero'] ?? '', 'Nome completo' => $e['nome_completo'] ?? '', 'Nascimento' => !empty($e['nascimento']) ? wp_date('d/m/Y', strtotime($e['nascimento'])) . ' (' . (int) floor((time() - strtotime($e['nascimento'])) / (365.25 * DAY_IN_SECONDS)) . ' anos)' : '', 'Nacionalidade' => $e['nacionalidade'] ?? '', 'Altura' => $e['altura'] ?? '', 'Pé' => $e['pe'] ?? '');
    foreach ($dados as $k => $v) {
        if ((string) $v !== '') {
            echo '<div><dt>' . esc_html($k) . '</dt><dd><small>' . esc_html($v) . '</small></dd></div>';
        }
    }
    echo '</dl></div></div>';
    echo '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div></header>';
    if ($s) {
        echo '<section class="tsp-tn__bloco"><h2>Números na temporada</h2><dl class="tsp-camp__ficha">';
        $n = array('Jogos' => $s['jogos'], 'Titular' => $s['tit'], 'Entrou' => $s['ent'], 'Substituído' => $s['subst'], 'Minutos' => $s['min'], 'Gols' => $s['gols'], 'Pênaltis' => $s['pen'], 'Minutos por gol' => $s['min_por_gol'] ?: '—', 'Cartões amarelos' => $s['am'], 'Cartões vermelhos' => $s['vm']);
        foreach ($n as $k => $v) {
            echo '<div><dt>' . esc_html($k) . '</dt><dd>' . esc_html($v) . '</dd></div>';
        }
        echo '</dl></section>';
        echo '<section class="tsp-tn__bloco"><h2>O ' . esc_html($time) . ' com e sem ' . esc_html($nome) . '</h2><table class="tsp-stats"><thead><tr><th></th><th>J</th><th>V</th><th>E</th><th>D</th><th>Aproveitamento</th></tr></thead><tbody>';
        echo '<tr><td>Com ele em campo</td><td>' . (int) $s['jogos'] . '</td><td>' . (int) $s['v'] . '</td><td>' . (int) $s['e'] . '</td><td>' . (int) $s['d'] . '</td><td><strong>' . ($s['aprov'] !== null ? (int) $s['aprov'] . '%' : '—') . '</strong></td></tr>';
        $sem = (array) ($s['sem'] ?? array());
        echo '<tr><td>Sem ele</td><td>' . (int) ($sem['j'] ?? 0) . '</td><td>' . (int) ($sem['v'] ?? 0) . '</td><td>' . (int) ($sem['e'] ?? 0) . '</td><td>' . (int) ($sem['d'] ?? 0) . '</td><td><strong>' . (isset($sem['aprov']) && $sem['aprov'] !== null ? (int) $sem['aprov'] . '%' : '—') . '</strong></td></tr>';
        echo '</tbody></table><p class="tsp-nota">Com ele em campo, o time marcou ' . (int) $s['gp_campo'] . ' e sofreu ' . (int) $s['gc_campo'] . ' gols (pelos minutos dos gols e das substituições das fichas técnicas).</p></section>';
        // Jogos dele
        $ids = array_flip((array) ($s['jogos_ids'] ?? array()));
        $meus = array_filter((array) $f['jogos'], function ($x) use ($ids) {
            return isset($ids[$x['id']]);
        });
        if ($meus) {
            echo '<section class="tsp-tn__bloco"><h2>Jogos de ' . esc_html($nome) . ' na temporada</h2><table class="tsp-stats"><thead><tr><th>Data</th><th>Competição</th><th>Adversário</th><th>Placar</th><th></th></tr></thead><tbody>';
            foreach (array_reverse($meus) as $x) {
                $pl = $x['mando'] === 'casa' ? $x['gp'] . ' x ' . $x['gc'] : $x['gc'] . ' x ' . $x['gp'];
                $link = function_exists('tsp_jogos_link_jogo') ? tsp_jogos_link_jogo($x['id']) : '';
                echo '<tr><td>' . esc_html(wp_date('d/m', strtotime($x['data']))) . '</td><td>' . esc_html($x['nome_comp']) . '</td><td>' . esc_html(($x['mando'] === 'casa' ? '' : '@ ') . $x['adv_nome']) . '</td><td>' . ($link ? '<a href="' . esc_url($link) . '">' . esc_html($pl) . '</a>' : esc_html($pl)) . '</td><td>' . tsp_tf_res_badge($x) . '</td></tr>';
            }
            echo '</tbody></table></section>';
        }
    }
    // Notícias com o nome do jogador
    $q2 = new WP_Query(array('post_type' => array('materia', 'post'), 's' => $nome, 'posts_per_page' => 6, 'no_found_rows' => true, 'ignore_sticky_posts' => true));
    if ($q2->posts) {
        echo '<section class="tsp-tn__bloco"><h2>Notícias de ' . esc_html($nome) . '</h2><ul class="tsp-jogo__noticias">';
        foreach ($q2->posts as $p) {
            echo '<li><a href="' . esc_url(get_permalink($p)) . '">' . esc_html(get_the_title($p)) . '</a></li>';
        }
        echo '</ul></section>';
    }
    echo '<p class="tsp-nota">Números da base própria do TSP: jogos oficiais da temporada com resultado conferido em 2 fontes e escalações das fichas técnicas. Foto e dados pessoais: site oficial do clube.' . (!empty($e['foto']['fonte']) ? ' <a href="' . esc_url($e['foto']['fonte']) . '" rel="nofollow noopener" target="_blank">Fonte</a>.' : '') . '</p>';
    echo '</main>';
    get_footer();
    exit;
});

/* ---------- Prognóstico estatístico na página do jogo ---------- */
add_filter('the_content', function ($c) {
    if (!is_singular('jogo') || !in_the_loop()) {
        return $c;
    }
    $j = tsp_jogos_do_post(get_the_ID());
    if (!$j || $j->status !== 'NS') {
        return $c;
    }
    $p = tsp_tf_previsao($j->id);
    if (!$p) {
        return $c;
    }
    $casa = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $fora = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $h = '<section class="tsp-jogo__bloco tsp-tf__prev"><h2>Prognóstico estatístico do TSP</h2><div class="tsp-tf__barra"><span style="width:' . (int) $p['casa'] . '%" class="c">' . esc_html($casa) . ' ' . (int) $p['casa'] . '%</span><span style="width:' . (int) $p['empate'] . '%" class="e">Empate ' . (int) $p['empate'] . '%</span><span style="width:' . (int) $p['fora'] . '%" class="f">' . esc_html($fora) . ' ' . (int) $p['fora'] . '%</span></div>';
    $h .= '<p>Placar mais provável pelo modelo: <strong>' . esc_html($casa . ' ' . str_replace('x', ' x ', $p['placar']) . ' ' . $fora) . '</strong>. Gols esperados: ' . esc_html(number_format_i18n($p['gols_esperados'][0], 1) . ' a ' . number_format_i18n($p['gols_esperados'][1], 1)) . '.</p>';
    $h .= '<p class="tsp-nota">Cálculo do TSP com o ataque e a defesa dos dois times nos jogos oficiais da temporada (' . (int) $p['base'][0] . ' e ' . (int) $p['base'][1] . ' jogos) e o fator casa. É estatística, não palpite: futebol tem surpresa.</p></section>';
    return $c . $h;
}, 22);

function tsp_tf_previsao($id)
{
    $d = tsp_jogos_detalhes($id);
    return !empty($d['previsao']['placar']) ? $d['previsao'] : null;
}

add_action('wp_head', function () {
    if (empty($GLOBALS['tsp_time_atual']) && !is_singular('jogo')) {
        return;
    }
    echo '<style>.tsp-tf__comp{background:#fff;border:1px solid #eee;border-radius:8px;margin:8px 0;padding:8px 12px}.tsp-tf__comp summary{cursor:pointer;padding:4px 0}.tsp-tf__res{display:inline-grid;place-items:center;width:24px;height:24px;border-radius:5px;color:#fff;font-weight:800;font-size:12px}.tsp-tf__res--v{background:#1e9e4a}.tsp-tf__res--e{background:#8a8f98}.tsp-tf__res--d{background:#d33a2c}.tsp-tf__res--x{background:#ddd;color:#555}'
        . '.tsp-tf__ord th{cursor:pointer;white-space:nowrap}.tsp-tf__dif li{margin:6px 0}.tsp-tf__elenco{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px}.tsp-tf__jog{display:flex;flex-direction:column;align-items:center;text-align:center;background:#fff;border:1px solid #eee;border-radius:10px;padding:10px;text-decoration:none;color:inherit}.tsp-tf__jog img,.tsp-tf__sem-foto{width:96px;height:96px;border-radius:50%;object-fit:cover;object-position:50% 15%;background:#f1ede6}.tsp-tf__sem-foto{display:grid;place-items:center;font-size:36px;font-weight:800;color:#A8520C}.tsp-tf__nome{font-weight:700;margin-top:6px}.tsp-tf__jog small{color:#666}'
        . '.tsp-tf__perfil{display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap}.tsp-tf__perfil figure{margin:0;max-width:220px}.tsp-tf__perfil img{width:220px;height:220px;object-fit:cover;object-position:50% 15%;border-radius:12px}.tsp-tf__perfil figcaption{font-size:12px;color:#666}'
        . '.tsp-tf__barra{display:flex;border-radius:8px;overflow:hidden;font-size:13px;font-weight:700;color:#fff;min-height:34px}.tsp-tf__barra span{display:flex;align-items:center;justify-content:center;padding:0 6px;white-space:nowrap;overflow:hidden;min-width:fit-content}.tsp-tf__barra .c{background:#111}.tsp-tf__barra .e{background:#8a8f98}.tsp-tf__barra .f{background:#E18330;color:#111}</style>';
    echo "<script>document.addEventListener('click',function(e){var th=e.target.closest('.tsp-tf__ord th');if(!th)return;var t=th.closest('table'),i=[].indexOf.call(th.parentNode.children,th),b=t.tBodies[0],r=[].slice.call(b.rows),asc=th.dataset.o!=='a';th.dataset.o=asc?'a':'d';r.sort(function(x,y){var a=x.cells[i].innerText.replace('%','').replace('*',''),c=y.cells[i].innerText.replace('%','').replace('*','');var na=parseFloat(a),nc=parseFloat(c);if(!isNaN(na)&&!isNaN(nc))return asc?nc-na:na-nc;return asc?a.localeCompare(c):c.localeCompare(a)});r.forEach(function(x){b.appendChild(x)})});</script>";
});
