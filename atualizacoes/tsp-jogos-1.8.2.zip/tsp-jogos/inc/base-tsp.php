<?php
/**
 * Base de jogos do TSP: lê o arquivo público api/tsp.json do repositório tudosobrepaulistas/tsp-dados
 * (montado pela Máquina de Resultados, que confere cada jogo em 2 fontes de imprensa) e grava no site.
 * Só leitura, sem senha. Roda a cada 15 minutos; se o arquivo não mudou, não faz nada.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_JOGOS_BASE_PADRAO = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/tsp.json';

function tsp_jogos_base_url()
{
    $u = (string) get_option('tsp_jogos_base_url', TSP_JOGOS_BASE_PADRAO);
    return $u !== '' ? $u : TSP_JOGOS_BASE_PADRAO;
}

// A base do TSP é a única fonte de dados
function tsp_jogos_base_ativa()
{
    return true;
}

add_filter('cron_schedules', function ($s) {
    $s['tsp_15min'] = array('interval' => 900, 'display' => 'A cada 15 minutos (TSP Jogos)');
    return $s;
});

add_action('init', function () {
    if (tsp_jogos_base_ativa() && !wp_next_scheduled('tsp_jogos_base')) {
        wp_schedule_event(time() + 60, 'tsp_15min', 'tsp_jogos_base');
    }
    if (!tsp_jogos_base_ativa() && wp_next_scheduled('tsp_jogos_base')) {
        wp_clear_scheduled_hook('tsp_jogos_base');
    }
});
add_action('tsp_jogos_base', function () {
    tsp_jogos_base_importar(false);
});

function tsp_jogos_base_importar($forcar = false)
{
    $cab = array('User-Agent' => 'TSP-Jogos/' . TSP_JOGOS_VERSAO);
    $etag = get_option('tsp_jogos_base_etag', '');
    if ($etag && !$forcar) {
        $cab['If-None-Match'] = $etag;
    }
    $r = wp_remote_get(add_query_arg('v', floor(time() / 300), tsp_jogos_base_url()), array('timeout' => 20, 'headers' => $cab));
    if (is_wp_error($r)) {
        tsp_jogos_log('Base TSP: erro ao ler (' . $r->get_error_message() . ').');
        return false;
    }
    $cod = (int) wp_remote_retrieve_response_code($r);
    if ($cod === 304) {
        return true;
    }
    $corpo = wp_remote_retrieve_body($r);
    $dados = json_decode($corpo, true);
    if ($cod !== 200 || !is_array($dados) || empty($dados['competicoes']) || !isset($dados['jogos'])) {
        tsp_jogos_log('Base TSP: arquivo inválido (código ' . $cod . ').');
        return false;
    }
    $hash = md5($corpo);
    if (!$forcar && get_option('tsp_jogos_base_hash') === $hash) {
        return true;
    }

    // 1) Competições (nomes e se têm tabela)
    $ligas = array();
    foreach ($dados['competicoes'] as $c) {
        $k = sanitize_key($c['chave'] ?? '');
        if (!$k || in_array($c['status'] ?? '', array('encerrada', 'aguardando'), true) && empty(array_filter($dados['jogos'], function ($f) use ($k) {
            return ($f['liga'] ?? '') === $k;
        }))) {
            continue;
        }
        $ligas[$k] = array('id' => 0, 'nome_api' => sanitize_text_field($c['nome'] ?? $k), 'temporada' => (int) ($c['temporada'] ?? 0), 'inicio' => '', 'fim' => '',
            'jogos' => true, 'escalacoes' => false, 'estatisticas' => false, 'tabela' => ($c['formato'] ?? '') !== 'mata', 'desfalques' => false, 'fonte' => 'base');
    }
    update_option('tsp_jogos_ligas', $ligas, false);

    // 2) Times: o próprio arquivo diz qual clube do site é cada time (slug_tsp)
    $v = array_filter(tsp_jogos_vinculos(), function ($id) {
        return (int) $id < 900000; // mantém só vínculos antigos da API; os da base vêm do arquivo
    }, ARRAY_FILTER_USE_KEY);
    foreach ((array) ($dados['times'] ?? array()) as $id => $t) {
        $s = sanitize_title($t['slug_tsp'] ?? '');
        if ($s && term_exists($s, 'times')) {
            $v[(int) $id] = $s;
        }
    }
    update_option('tsp_jogos_times', $v, false);
    $bt = array();
    foreach ((array) ($dados['times'] ?? array()) as $id => $t) {
        $bt[(int) $id] = array('chave' => sanitize_title($t['chave'] ?? ''), 'nome' => sanitize_text_field($t['nome'] ?? ''), 'wiki' => sanitize_text_field($t['wiki'] ?? ''));
    }
    update_option('tsp_jogos_base_times', $bt, false);
    // Elencos (site oficial dos clubes), por id do time
    $el = array();
    foreach ((array) ($dados['elencos'] ?? array()) as $tid => $e) {
        if (!empty($e['jogadores']) && is_array($e['jogadores'])) {
            $el[(int) $tid] = tsp_jogos_limpar_lista(array('atualizado' => $e['atualizado'] ?? '', 'fonte' => $e['fonte'] ?? '', 'jogadores' => array_slice($e['jogadores'], 0, 60)));
        }
    }
    update_option('tsp_jogos_elencos', $el, false);

    // 3) Jogos
    global $wpdb;
    $vistos = array();
    $mudaram = array();
    foreach ($dados['jogos'] as $f) {
        $liga = sanitize_key($f['liga'] ?? '');
        $id = (int) ($f['fixture']['id'] ?? 0);
        if (!$liga || $id < 91000000) {
            continue;
        }
        $antes = $wpdb->get_row($wpdb->prepare('SELECT status, gols_casa, gols_fora, inicio FROM ' . tsp_jogos_tabela() . ' WHERE id = %d', $id));
        tsp_jogos_gravar($liga, (int) ($f['temporada'] ?? 0), $f, true);
        $d = tsp_jogos_detalhes($id);
        $d['obs'] = sanitize_text_field($f['obs'] ?? '');
        $d['penaltis'] = sanitize_text_field($f['penaltis'] ?? '');
        $d['fontes'] = array_map('esc_url_raw', array_slice((array) ($f['fontes'] ?? array()), 0, 6));
        $d['prejogo'] = is_array($f['prejogo'] ?? null) ? tsp_jogos_limpar_lista($f['prejogo']) : array();
        $d['esc_tsp'] = is_array($f['escalacoes'] ?? null) ? tsp_jogos_limpar_lista($f['escalacoes']) : array();
        $d['previsao'] = is_array($f['previsao'] ?? null) ? tsp_jogos_limpar_lista($f['previsao']) : array();
        $wpdb->update(tsp_jogos_tabela(), array('detalhes' => wp_json_encode(tsp_jogos_limpar_lista($d))), array('id' => $id));
        $vistos[] = $id;
        $depois = $f['fixture']['status']['short'] ?? '';
        if (!$antes || $antes->status !== $depois || (string) $antes->gols_casa !== (string) ($f['goals']['home'] ?? '') || (int) $antes->inicio !== (int) ($f['fixture']['timestamp'] ?? 0)) {
            $mudaram[] = (object) array('id' => $id, 'casa_id' => (int) $f['teams']['home']['id'], 'fora_id' => (int) $f['teams']['away']['id'], 'liga' => $liga);
        }
    }
    // Jogos que saíram da base (cadastro errado apagado pela Máquina)
    $ids = $vistos ? implode(',', array_map('intval', $vistos)) : '0';
    $wpdb->query('DELETE FROM ' . tsp_jogos_tabela() . " WHERE id BETWEEN 91000000 AND 91999999 AND id NOT IN ($ids)");

    // 4) Classificação e artilharia
    foreach ((array) ($dados['classificacao'] ?? array()) as $liga => $c) {
        $grupos = array();
        foreach ((array) ($c['grupos'] ?? array()) as $g) {
            $linhas = array();
            foreach ((array) $g as $x) {
                $linhas[] = array((int) $x[0], (int) $x[1], sanitize_text_field($x[2]), (int) $x[3], (int) $x[4], (int) $x[5], (int) $x[6], (int) $x[7], (int) $x[8], sanitize_text_field($x[9] ?? ''), (int) ($x[10] ?? 0), (int) ($x[11] ?? 0));
            }
            $grupos[] = $linhas;
        }
        // Posição anterior de cada time (para a setinha de subiu/caiu): guarda a tabela antiga quando a nova muda
        $velha = get_option('tsp_jogos_class_' . sanitize_key($liga), array());
        $pos_velha = array();
        foreach ((array) ($velha['grupos'][0] ?? array()) as $x) {
            $pos_velha[(int) $x[1]] = (int) $x[0];
        }
        $pos_nova = array();
        foreach ((array) ($grupos[0] ?? array()) as $x) {
            $pos_nova[(int) $x[1]] = (int) $x[0];
        }
        if ($pos_velha && $pos_velha !== $pos_nova) {
            update_option('tsp_jogos_class_ant_' . sanitize_key($liga), $pos_velha, false);
        }
        update_option('tsp_jogos_class_' . sanitize_key($liga), array('quando' => strtotime($dados['gerado'] ?? 'now'), 'grupos' => $grupos), false);
    }
    update_option('tsp_simulador', (array) ($dados['simulador'] ?? array()), false);
    update_option('tsp_jogos_chaves', tsp_jogos_limpar_lista((array) ($dados['chaves'] ?? array())), false);
    update_option('tsp_jogos_painel_fem', tsp_jogos_limpar_lista((array) ($dados['painel_feminino'] ?? array())), false);
    update_option('tsp_jogos_artilharia', tsp_jogos_limpar_lista((array) ($dados['artilharia'] ?? array())), false);

    tsp_jogos_criar_paginas();
    tsp_jogos_montar_resumo();
    if ($mudaram && function_exists('tsp_jogos_limpar_cache')) {
        tsp_jogos_limpar_cache($mudaram);
    }
    // Placar ou tabela mudou: limpa o cache das páginas (LiteSpeed) para a home e os clubes mostrarem o novo resultado
    do_action($mudaram ? 'litespeed_purge_all' : 'litespeed_purge_url', $mudaram ? null : home_url('/'));
    update_option('tsp_jogos_base_hash', $hash, false);
    update_option('tsp_jogos_base_etag', (string) wp_remote_retrieve_header($r, 'etag'), false);
    update_option('tsp_jogos_base_quando', time(), false);
    tsp_jogos_log('Base TSP: ' . count($vistos) . ' jogos lidos, ' . count($mudaram) . ' com novidade.');
    return true;
}
