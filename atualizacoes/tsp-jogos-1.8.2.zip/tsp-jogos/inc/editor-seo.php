<?php
/**
 * Editor SEO do TSP: aplica nas matérias o que o editor-robô preparou no repositório tsp-dados (api/materias.json):
 * resumo em tópicos, perguntas frequentes, título e descrição do Google (Yoast), palavra-chave, tags e intertítulos (H2).
 * Regras: nunca apaga nem reescreve o que a redação preencheu; só completa o que está vazio.
 * Intertítulos só entram em matéria sem nenhum H2/H3, antes do parágrafo indicado, e uma única vez.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_EDITOR_SEO_URL = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/materias.json';

add_action('tsp_jogos_base', 'tsp_editor_seo_aplicar'); // mesma rotina de 15 em 15 minutos da Base TSP

function tsp_editor_seo_aplicar()
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 300), TSP_EDITOR_SEO_URL), array('timeout' => 20));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return;
    }
    $corpo = wp_remote_retrieve_body($r);
    if (get_option('tsp_editor_seo_hash') === md5($corpo)) {
        return;
    }
    $d = json_decode($corpo, true);
    $n = 0;
    foreach ((array) ($d['itens'] ?? array()) as $it) {
        $id = (int) ($it['id'] ?? 0);
        $p = $id ? get_post($id) : null;
        if (!$p || $p->post_status !== 'publish') {
            continue;
        }
        $versao = md5(wp_json_encode($it));
        if (get_post_meta($id, 'tsp_editor_seo', true) === $versao) {
            continue;
        }
        $txt = function ($s, $max = 400) {
            return mb_substr(sanitize_text_field((string) $s), 0, $max);
        };
        if (!empty($it['resumo']) && trim((string) get_post_meta($id, 'tsp_resumo', true)) === '') {
            update_post_meta($id, 'tsp_resumo', implode("\n", array_map($txt, array_slice((array) $it['resumo'], 0, 5))));
        }
        if (!empty($it['faq']) && trim((string) get_post_meta($id, 'tsp_faq', true)) === '') {
            $faq = array();
            foreach (array_slice((array) $it['faq'], 0, 6) as $f) {
                if (is_array($f) && count($f) >= 2) {
                    $faq[] = array($txt($f[0], 200), $txt($f[1], 600));
                }
            }
            update_post_meta($id, 'tsp_faq', wp_json_encode($faq, JSON_UNESCAPED_UNICODE));
        }
        foreach (array('meta_title' => '_yoast_wpseo_title', 'meta_desc' => '_yoast_wpseo_metadesc', 'foco' => '_yoast_wpseo_focuskw') as $k => $meta) {
            if (!empty($it[$k])) {
                $atual = trim((string) get_post_meta($id, $meta, true));
                // a meta descrição automática (1º parágrafo) pode ser trocada pela do editor
                $auto = get_post_meta($id, 'tsp_metadesc_auto', true);
                if ($atual === '' || ($meta === '_yoast_wpseo_metadesc' && $auto && $atual === $auto)) {
                    update_post_meta($id, $meta, $txt($it[$k], $k === 'meta_desc' ? 160 : 80));
                }
            }
        }
        $boas = array_filter(wp_get_post_tags($id, array('fields' => 'names')), function ($t) {
            return !preg_match('~^(futebol( paulista)?|not[íi]cias?|esporte|[\p{L} ]+ not[íi]cias|mercado da bola|brasileir[ãa]o|s[ée]rie [abcd])$~iu', $t);
        });
        if (!empty($it['tags']) && count($boas) < 3) {
            wp_set_post_tags($id, array_map(function ($t) use ($txt) {
                return $txt($t, 40);
            }, array_slice((array) $it['tags'], 0, 6)), true);
        }
        if (!empty($it['intertitulos']) && !preg_match('~<h[23][\s>]~i', $p->post_content) && !get_post_meta($id, 'tsp_h2_aplicado', true)) {
            $novo = tsp_editor_seo_intertitulos($p->post_content, (array) $it['intertitulos']);
            if ($novo !== $p->post_content) {
                wp_update_post(array('ID' => $id, 'post_content' => $novo));
                update_post_meta($id, 'tsp_h2_aplicado', 1);
            }
        }
        // Dicas de SEO para o redator (08/11/2026): só orientação, não trava nada
        if (!empty($it['dicas']) && !get_post_meta($id, 'tsp_seo_dicas', true)) {
            $dicas = array_map(function ($x) use ($txt) {
                return $txt($x, 300);
            }, array_slice((array) $it['dicas'], 0, 5));
            update_post_meta($id, 'tsp_seo_dicas', $dicas);
            if (function_exists('tsp_corr_avisar') && function_exists('tsp_corr_autor_redator') && tsp_corr_autor_redator($p->post_author)) {
                $u = get_userdata($p->post_author);
                $l = array('Oi, ' . ($u ? $u->display_name : '') . '! O editor de SEO deixou dicas para a matéria "' . html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8') . '":', '');
                foreach ($dicas as $d) {
                    $l[] = '• ' . $d;
                }
                $l[] = '';
                $l[] = 'Não é correção obrigatória: aplique nesta matéria se quiser e use nas próximas. Matéria com bom título, palavra-chave e tags aparece mais no Google. — Redação TSP';
                tsp_corr_avisar($p->post_author, '💡 Dicas de SEO: ' . html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'), $l, admin_url('post.php?post=' . $id . '&action=edit'));
            }
        }
        update_post_meta($id, 'tsp_editor_seo', $versao);
        clean_post_cache($id);
        $n++;
    }
    update_option('tsp_editor_seo_hash', md5($corpo), false);
    if ($n && function_exists('tsp_jogos_log')) {
        tsp_jogos_log('Editor SEO: ' . $n . ' matéria(s) completadas.');
    }
}

// Insere <h2> antes do parágrafo N (contando só os parágrafos de texto, a partir de 1)
function tsp_editor_seo_intertitulos($html, $inter)
{
    $mapa = array();
    foreach ($inter as $x) {
        $n = (int) ($x['p'] ?? 0);
        $t = sanitize_text_field((string) ($x['h2'] ?? ''));
        if ($n > 1 && $t !== '') {
            $mapa[$n] = $t;
        }
    }
    if (!$mapa) {
        return $html;
    }
    $gutenberg = strpos($html, '<!-- wp:') !== false;
    $padrao = $gutenberg ? '~(?=<!-- wp:paragraph)~' : '~(\r?\n\s*\r?\n)|(?=<p[\s>])~i';
    $blocos = preg_split($padrao, $html, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
    $saida = '';
    $i = 0;
    foreach ($blocos as $b) {
        $limpo = trim(wp_strip_all_tags($b));
        if ($limpo !== '' && mb_strlen($limpo) > 40) {
            $i++;
            if (isset($mapa[$i])) {
                $saida .= $gutenberg
                    ? '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html($mapa[$i]) . "</h2><!-- /wp:heading -->\n\n"
                    : "\n\n<h2>" . esc_html($mapa[$i]) . "</h2>\n\n";
            }
        }
        $saida .= $b;
    }
    return $saida;
}

// Dicas de SEO no editor da matéria
add_action('add_meta_boxes', function () {
    foreach (array('materia', 'post') as $tp) {
        add_meta_box('tsp_seo_dicas', '💡 Dicas de SEO', function ($p) {
            $d = (array) get_post_meta($p->ID, 'tsp_seo_dicas', true);
            $d = array_filter($d);
            echo $d ? '<ul style="margin:0;padding-left:18px">' . implode('', array_map(function ($x) {
                return '<li>' . esc_html($x) . '</li>';
            }, $d)) . '</ul>' : '<p>Sem dicas para esta matéria.</p>';
        }, $tp, 'side', 'default');
    }
});
