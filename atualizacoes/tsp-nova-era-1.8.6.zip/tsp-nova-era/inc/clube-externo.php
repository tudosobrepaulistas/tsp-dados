<?php
/**
 * Página de clube de fora (22/11/2026, pedido do Thiago): /clube/<nome>/
 * Todo clube citado numa trajetória vira link. Clube paulista leva à página dele (/times/<slug>/);
 * clube de fora ganha esta página, montada só com o que a base do TSP já tem (custo zero):
 * escudo, ficha (api/guia_clubes.json, quando houver), quem passou pelo clube (técnicos e jogadores da base)
 * e as transferências com clubes paulistas. Sem notícias: o foco do TSP são os clubes paulistas.
 * Página com pouco conteúdo fica fora do Google (noindex) até a base crescer.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_ce_slug($nome)
{
    return sanitize_title(remove_accents(preg_replace('~\s*\([^)]*\)\s*$~', '', (string) $nome)));
}

// Endereço do clube: paulista → página do clube no site; de fora → /clube/<nome>/
function tsp_clube_url($nome, $slug = '')
{
    static $memo = array();
    $k = $slug . '|' . $nome;
    if (isset($memo[$k])) {
        return $memo[$k];
    }
    $t = $slug ? get_term_by('slug', $slug, 'times') : null;
    if (!$t && $nome) {
        $t = get_term_by('name', $nome, 'times');
    }
    if ($t && !is_wp_error($t)) {
        return $memo[$k] = get_term_link($t);
    }
    $s = tsp_ce_slug($nome);
    return $memo[$k] = ($s ? home_url('/clube/' . $s . '/') : '');
}

// Índice dos clubes citados na base (mercado: origem/destino, carreira, clubes de 2026)
function tsp_ce_indice()
{
    static $idx = null;
    if ($idx !== null) {
        return $idx;
    }
    $idx = array();
    $add = function ($nome, $escudo, $pessoa = null, $mov = null) use (&$idx) {
        $s = tsp_ce_slug($nome);
        if (!$s) {
            return;
        }
        if (!isset($idx[$s])) {
            $idx[$s] = array('nome' => preg_replace('~\s*\([^)]*\)\s*$~', '', $nome), 'escudo' => '', 'pessoas' => array(), 'movs' => array());
        }
        if ($escudo && !$idx[$s]['escudo']) {
            $idx[$s]['escudo'] = $escudo;
        }
        if ($pessoa) {
            $idx[$s]['pessoas'][$pessoa['k']] = $pessoa;
        }
        if ($mov) {
            $idx[$s]['movs'][] = $mov;
        }
    };
    foreach (tsp_mc_itens() as $m) {
        $nome = $m['jogador'] ?? '';
        $pos = $m['posicao'] ?? '';
        $pk = sanitize_title(remove_accents($nome));
        foreach (array('de', 'para') as $lado) {
            $c = $m[$lado] ?? array();
            if (!empty($c['nome']) && empty($c['slug'])) {
                $add($c['nome'], $c['escudo'] ?? '', array('k' => $pk, 'nome' => $nome, 'posicao' => $pos, 'quando' => substr((string) ($m['data'] ?? ''), 0, 4)), $m);
            }
        }
        foreach ((array) ($m['carreira'] ?? array()) as $c) {
            if (!empty($c['clube'])) {
                $add($c['clube'], $c['escudo'] ?? '', array('k' => $pk, 'nome' => $nome, 'posicao' => $pos ?: ($c['funcao'] ?? ''), 'quando' => (string) ($c['temporada'] ?? '')));
            }
        }
        foreach ((array) ($m['numeros']['clubes'] ?? array()) as $c) {
            $add($c, $m['numeros']['escudos'][$c] ?? '', array('k' => $pk, 'nome' => $nome, 'posicao' => $pos, 'quando' => '2026'));
        }
    }
    return $idx;
}

add_action('init', function () {
    add_rewrite_rule('^clube/([a-z0-9-]+)/?$', 'index.php?tsp_ce=$matches[1]', 'top');
    if (get_option('tsp_ce_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_ce_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_ce';
    return $v;
});

add_action('template_redirect', function () {
    $s = get_query_var('tsp_ce');
    if (!$s) {
        return;
    }
    // Clube paulista: vai para a página dele
    $t = get_term_by('slug', $s, 'times');
    $idx = tsp_ce_indice();
    $c = $idx[$s] ?? null;
    if (!$t && $c) {
        $t = get_term_by('name', $c['nome'], 'times');
    }
    if ($t && !is_wp_error($t)) {
        wp_safe_redirect(get_term_link($t), 301);
        exit;
    }
    if (!$c) {
        if (function_exists('tsp_404_real')) {
            tsp_404_real();
        }
        return;
    }
    $nome = $c['nome'];
    $guia = array();
    if (function_exists('tsp_mc_arquivo')) {
        $g = tsp_mc_arquivo('guia_clubes.json');
        $guia = (array) ($g['clubes'][$s] ?? array());
    }
    $pessoas = array_values($c['pessoas']);
    $tecs = array_filter($pessoas, function ($p) {
        return in_array($p['posicao'], array('Treinador', 'Técnico'), true);
    });
    $jogs = array_filter($pessoas, function ($p) {
        return !in_array($p['posicao'], array('Treinador', 'Técnico'), true);
    });
    $resumo = $nome . (!empty($guia['cidade']) ? ' é um clube de ' . $guia['cidade'] : ' é um clube de futebol') . '.'
        . ' Na base do Tudo Sobre Paulista, ' . count($pessoas) . ' ' . (count($pessoas) === 1 ? 'profissional ligado' : 'profissionais ligados') . ' ao futebol paulista ' . (count($pessoas) === 1 ? 'passou' : 'passaram') . ' pelo clube'
        . ($tecs ? ' (' . count($tecs) . ' técnico' . (count($tecs) > 1 ? 's' : '') . ')' : '') . '.';
    $titulo = $nome . ': quem passou pelo clube, transferências e ficha';
    $canon = home_url('/clube/' . $s . '/');
    $fraca = count($pessoas) + count($c['movs']) < 4;
    foreach (array('pre_get_document_title', 'wpseo_title') as $fl) {
        add_filter($fl, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($resumo) {
        return mb_substr($resumo, 0, 155);
    }, 99);
    add_filter('wpseo_canonical', function () use ($canon) {
        return $canon;
    }, 99);
    add_filter('wpseo_robots', function ($r) use ($fraca) {
        return $fraca ? 'noindex, follow' : $r;
    }, 99);
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    echo '<main class="tsp-container tsp-jog tsp-ce">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <a href="' . esc_url(home_url('/todos-os-times/')) . '">Clubes</a> › <span>' . esc_html($nome) . '</span></nav>';
    echo '<header class="tsp-jog__cab"><div class="tsp-jog__foto tsp-ce__esc">' . ($c['escudo'] ? '<img src="' . esc_url($c['escudo']) . '" alt="Escudo do ' . esc_attr($nome) . '" width="120" height="120" style="object-fit:contain">' : '<span class="tsp-ce__ini">' . esc_html(mb_substr($nome, 0, 1)) . '</span>') . '</div>';
    echo '<div class="tsp-jog__id"><h1>' . esc_html($nome) . '</h1><div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resumo) . '</p></div></div></header>';

    $ficha = array_filter(array('Cidade' => $guia['cidade'] ?? '', 'Estádio' => $guia['estadio'] ?? '', 'Fundação' => $guia['fundacao'] ?? '', 'Apelidos' => $guia['apelidos'] ?? '', 'Cores' => $guia['cores'] ?? ''));
    if ($ficha) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Ficha do clube</h2></div></div><dl class="tsp-tecp__ficha">';
        foreach ($ficha as $k => $v) {
            echo '<div><dt>' . esc_html($k) . '</dt><dd>' . esc_html($v) . '</dd></div>';
        }
        echo '</dl></section>';
    }
    $lista = function ($arr, $tit) {
        if (!$arr) {
            return;
        }
        usort($arr, function ($a, $b) {
            return strcmp((string) $b['quando'], (string) $a['quando']);
        });
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($tit) . '</h2></div></div><ul class="tsp-tecp__imprensa">';
        foreach ($arr as $p) {
            $u = function_exists('tsp_mc_jog_url') ? tsp_mc_jog_url($p['nome']) : '';
            echo '<li><a href="' . esc_url($u) . '"><b>' . esc_html(trim($p['posicao'] . ($p['quando'] ? ' · ' . $p['quando'] : ''), ' ·')) . '</b><span>' . esc_html($p['nome']) . '</span></a></li>';
        }
        echo '</ul></section>';
    };
    $lista(array_values($tecs), 'Técnicos que passaram pelo ' . $nome);
    $lista(array_values($jogs), 'Jogadores da base do TSP que passaram pelo ' . $nome);
    if ($c['movs']) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__mercado"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Transferências com clubes paulistas</h2></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/')) . '">Mercado da Bola →</a></span></div><ul class="tsp-jog__movs">';
        foreach (array_slice($c['movs'], 0, 30) as $m) {
            $rota = trim(($m['de']['nome'] ?? '') . (!empty($m['para']['nome']) ? ' → ' . $m['para']['nome'] : ''), ' →');
            echo '<li><time datetime="' . esc_attr($m['data'] ?? '') . '">' . esc_html(!empty($m['data']) ? wp_date('d/m/Y', strtotime($m['data'] . ' 12:00')) : '') . '</time> <b>' . esc_html($m['jogador'] ?? '') . '</b> ' . esc_html($rota) . '</li>';
        }
        echo '</ul></section>';
    }
    echo '<p class="tsp-nota">Página montada com a base do TSP (Mercado da Bola, trajetórias e fichas conferidas). O TSP cobre com notícias os clubes paulistas.</p>';
    $ld = array('@context' => 'https://schema.org', '@type' => 'SportsTeam', 'name' => $nome, 'sport' => 'Futebol', 'url' => $canon);
    if ($c['escudo']) {
        $ld['logo'] = $c['escudo'];
    }
    echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    echo '</main>';
    get_footer();
    exit;
});
