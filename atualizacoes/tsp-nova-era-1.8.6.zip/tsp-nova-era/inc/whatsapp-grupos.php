<?php
/**
 * Grupos de WhatsApp do TSP por clube (22/11/2026, pedido do Thiago).
 * Toda matéria do clube (marcada no clube, no feminino/sub-20 dele, ou com o nome no título) ganha 3 pontos de contato:
 *   1) caixa depois do 1º parágrafo;  2) caixa no fim da matéria;  3) barra fixa no rodapé da tela (pode fechar).
 * A página do clube usa o link do grupo no bloco "Notícias do X no WhatsApp" e ganha a barra fixa também.
 * Para incluir um clube: acrescente o slug e o link em tsp_wg_grupos().
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_wg_grupos()
{
    return array(
        'palmeiras'   => array('url' => 'https://chat.whatsapp.com/JUV2B6cKSbsDyFgOt2TWVA', 'nome' => 'Palmeiras', 'de' => 'do', 'apelido' => 'Verdão', 'cor' => '#006437', 'titulo' => array('palmeiras', 'verdão', 'verdao')),
        'santos'      => array('url' => 'https://chat.whatsapp.com/GgL8y6IpsUPJokr9Rhjq62', 'nome' => 'Santos', 'de' => 'do', 'apelido' => 'Peixe', 'cor' => '#111111', 'titulo' => array('santos', 'peixe')),
        'corinthians' => array('url' => 'https://chat.whatsapp.com/B6AZGDML59K2Rp62TbP1OO', 'nome' => 'Corinthians', 'de' => 'do', 'apelido' => 'Timão', 'cor' => '#111111', 'titulo' => array('corinthians', 'timão', 'timao')),
        'saopaulo'    => array('url' => 'https://chat.whatsapp.com/ECVzGioROp7ExxOJ17b6Rl', 'nome' => 'São Paulo', 'de' => 'do', 'apelido' => 'Tricolor', 'cor' => '#C8102E', 'titulo' => array('são paulo', 'sao paulo', 'spfc')),
        'botafogosp'  => array('url' => 'https://chat.whatsapp.com/E7aRdmICe4SLSGEjLa1QOV', 'nome' => 'Botafogo-SP', 'de' => 'do', 'apelido' => 'Pantera', 'cor' => '#C8102E', 'titulo' => array('botafogo-sp', 'botafogo sp', 'pantera')),
    );
}

// Feminino e Sub-20 levam ao grupo do clube principal
function tsp_wg_do_slug($slug)
{
    $g = tsp_wg_grupos();
    $base = preg_replace('/-(feminino|sub-\d+)$/', '', (string) $slug);
    $base = $base === 'sao-paulo' ? 'saopaulo' : $base;
    return isset($g[$base]) ? array_merge($g[$base], array('slug' => $base)) : null;
}

// Grupos da matéria: clubes marcados primeiro; se nenhum, nome do clube no título
function tsp_wg_do_post($post_id)
{
    static $cache = array();
    if (isset($cache[$post_id])) {
        return $cache[$post_id];
    }
    $achou = array();
    $termos = taxonomy_exists('times') ? wp_get_post_terms($post_id, 'times') : array();
    if (!is_wp_error($termos)) {
        foreach ($termos as $t) {
            $g = tsp_wg_do_slug($t->slug);
            if ($g) {
                $achou[$g['slug']] = $g;
            }
        }
    }
    if (!$achou) {
        $tit = mb_strtolower(get_the_title($post_id));
        foreach (tsp_wg_grupos() as $slug => $g) {
            foreach ($g['titulo'] as $w) {
                if (preg_match('/(^|[^\p{L}])' . preg_quote($w, '/') . '([^\p{L}]|$)/u', $tit)) {
                    $achou[$slug] = array_merge($g, array('slug' => $slug));
                    break;
                }
            }
        }
    }
    return $cache[$post_id] = array_values($achou);
}

function tsp_wg_ico($tam = 26)
{
    return '<svg viewBox="0 0 24 24" width="' . (int) $tam . '" height="' . (int) $tam . '" aria-hidden="true"><path fill="currentColor" d="M17.5 14.4c-.3-.1-1.8-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.4-.5c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3zM12 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.7 1 1-3.6-.2-.4c-1-1.6-1.5-3.4-1.5-5.2C2.2 6.6 6.6 2.2 12 2.2c2.6 0 5.1 1 6.9 2.9 1.9 1.9 2.9 4.3 2.9 6.9 0 5.4-4.4 9.8-9.8 9.8zm8.4-18.2C18.2 1.3 15.2 0 12 0 5.5 0 .1 5.3.1 11.9c0 2.1.5 4.1 1.6 5.9L0 24l6.3-1.7c1.7.9 3.7 1.4 5.7 1.4 6.6 0 11.9-5.3 11.9-11.9 0-3.2-1.2-6.2-3.5-8.2z"/></svg>';
}

// Caixa (lugar: topo | fim | clube)
function tsp_wg_caixa($g, $lugar = 'topo')
{
    $quem = $g['de'] . ' ' . $g['nome'];
    if ($lugar === 'fim') {
        $tit = 'Torcedor ' . $quem . ': receba as notícias em primeira mão';
        $sub = 'Entre grátis no grupo do TSP no WhatsApp. Escalação, bastidores, mercado e resultado do ' . $g['apelido'] . ' direto no seu celular.';
    } elseif ($lugar === 'clube') {
        $tit = 'Grupo ' . $quem . ' no WhatsApp: grátis';
        $sub = 'Receba em primeira mão as matérias do ' . $g['apelido'] . ': escalação, bastidores, mercado e coletivas.';
    } else {
        $tit = 'Notícias ' . $quem . ' em primeira mão no WhatsApp';
        $sub = 'Grupo gratuito do Tudo Sobre Paulista. Entre e receba as matérias do seu time do coração.';
    }
    return '<aside class="tsp-wg tsp-wg--' . esc_attr($lugar) . '" aria-label="Grupo ' . esc_attr($quem) . ' no WhatsApp">'
        . '<span class="tsp-wg__ico">' . tsp_wg_ico() . '</span>'
        . '<div class="tsp-wg__txt"><strong>' . esc_html($tit) . '</strong><span>' . esc_html($sub) . '</span></div>'
        . '<a class="tsp-wg__bt" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug'] . '-' . $lugar) . '">Entrar grátis no grupo</a></aside>';
}

// Pontos 1 e 2: depois do 1º parágrafo e no fim da matéria
add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $html;
    }
    $gs = tsp_wg_do_post(get_the_ID());
    if (!$gs) {
        return $html;
    }
    $p = stripos($html, '</p>');
    $topo = tsp_wg_caixa($gs[0], 'topo');
    $html = $p !== false ? substr($html, 0, $p + 4) . $topo . substr($html, $p + 4) : $topo . $html;
    foreach ($gs as $g) {
        $html .= tsp_wg_caixa($g, 'fim');
    }
    return $html;
}, 12);

// Ponto 3: barra fixa (matéria e página do clube)
add_action('wp_footer', function () {
    $g = null;
    if (is_singular(tsp_tipos())) {
        $gs = tsp_wg_do_post(get_queried_object_id());
        $g = $gs ? $gs[0] : null;
    } elseif (is_tax('times')) {
        $g = tsp_wg_do_slug(get_queried_object()->slug);
    }
    if (!$g) {
        return;
    }
    echo '<div class="tsp-wg-barra" id="tsp-wg-barra" hidden><a href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug']) . '-barra">'
        . '<span class="tsp-wg__ico">' . tsp_wg_ico(22) . '</span><span><b>Grupo ' . esc_html($g['de'] . ' ' . $g['nome']) . '</b> no WhatsApp · grátis</span><span class="tsp-wg-barra__bt">Entrar</span></a>'
        . '<button type="button" class="tsp-wg-barra__x" aria-label="Fechar">×</button></div>';
    echo "<script>(function(){var b=document.getElementById('tsp-wg-barra');if(!b)return;var k='tsp_wg_x';try{if(sessionStorage.getItem(k))return}catch(e){}"
        . "var s=function(){if(window.scrollY>400){b.hidden=false;window.removeEventListener('scroll',s)}};window.addEventListener('scroll',s,{passive:true});"
        . "b.querySelector('.tsp-wg-barra__x').addEventListener('click',function(){b.hidden=true;try{sessionStorage.setItem(k,'1')}catch(e){}});"
        . "document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-tsp-wg]');if(a&&window.gtag){gtag('event','whatsapp_grupo',{clube:a.getAttribute('data-tsp-wg')})}});})();</script>";
}, 20);
