<?php
/**
 * Posts do Instagram, X (Twitter) e TikTok dentro das matérias (17/11/2026).
 * Problema: o WordPress apaga o <script> que vem junto do código de incorporação quando quem publica é redator,
 * então o post ficava como um quadro branco. Aqui o site carrega o script certo sozinho, só nas matérias que têm o post.
 * Link puro do Instagram numa linha também vira o post incorporado.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Link do Instagram sozinho no parágrafo → código de incorporação
add_filter('the_content', function ($html) {
    if (strpos($html, 'instagram.com') === false) {
        return $html;
    }
    return preg_replace_callback('~<p>\s*(?:<a[^>]*>)?\s*(https://(?:www\.)?instagram\.com/(?:p|reel|tv)/[\w-]+/?)[^<\s]*\s*(?:</a>)?\s*</p>~i', function ($m) {
        $u = esc_url(trailingslashit($m[1]));
        return '<blockquote class="instagram-media" data-instgrm-captioned data-instgrm-permalink="' . $u . '" data-instgrm-version="14"><a href="' . $u . '" target="_blank" rel="noopener">Ver esse post no Instagram</a></blockquote>';
    }, $html);
}, 9);

add_action('wp_footer', function () {
    if (!is_singular()) {
        return;
    }
    $c = (string) get_post_field('post_content', get_queried_object_id());
    $ig = strpos($c, 'instagram-media') !== false || preg_match('~instagram\.com/(p|reel|tv)/~i', $c);
    if ($ig) {
        echo '<script async src="https://www.instagram.com/embed.js"></script>'
            . '<script>window.addEventListener("load",function(){if(window.instgrm&&instgrm.Embeds){instgrm.Embeds.process();}});</script>' . "\n";
    }
    if (strpos($c, 'twitter-tweet') !== false) {
        echo '<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>' . "\n";
    }
    if (strpos($c, 'tiktok-embed') !== false) {
        echo '<script async src="https://www.tiktok.com/embed.js"></script>' . "\n";
    }
}, 50);

// O post do Instagram ocupa a largura certa e fica centralizado
add_action('wp_head', function () {
    if (is_singular()) {
        echo '<style>.instagram-media,.twitter-tweet,.tiktok-embed{margin:24px auto!important;max-width:540px!important}</style>' . "\n";
    }
});
