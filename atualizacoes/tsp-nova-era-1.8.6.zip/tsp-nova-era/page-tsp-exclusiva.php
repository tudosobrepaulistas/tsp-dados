<?php
/* TSP Exclusiva: catálogo (/tsp-exclusiva/) ou página de um episódio (/tsp-exclusiva/173-nome/). Tudo em inc/exclusiva.php */
get_header();
$tsp_ex = tsp_exclusiva_dados();
$tsp_ep = function_exists('tsp_exclusiva_ep_atual') ? tsp_exclusiva_ep_atual() : null;
?>
<main class="tsp-container tsp-pagina tsp-excl-pag">
	<div class="tsp-excl-pag__in">
		<?php if ($tsp_ep) : ?>
			<?php tsp_exclusiva_pagina_ep($tsp_ep); ?>
		<?php else : ?>
			<?php tsp_breadcrumbs(); ?>
			<header class="tsp-excl-pag__cab">
				<?php echo tsp_exclusiva_selo(); // phpcs:ignore ?>
				<h1 class="tsp-materia__titulo">TSP Exclusiva: todas as entrevistas</h1>
				<p>Jogadores, técnicos e dirigentes do futebol paulista em conversas exclusivas com o TSP. São <?php echo (int) count($tsp_ex['eps']); ?> episódios: filtre por clube, ano ou quem foi entrevistado e abra a página do episódio para assistir aos cortes.</p>
			</header>
			<?php tsp_bloco_exclusiva(); ?>
			<?php tsp_exclusiva_catalogo(); ?>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
