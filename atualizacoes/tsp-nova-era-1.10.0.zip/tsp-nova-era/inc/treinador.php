<?php
/**
 * Página do treinador e da comissão técnica (21/11/2026)
 *   /treinador/<clube>/<nome>/          (treinador)
 *   /comissao-tecnica/<clube>/<nome>/   (auxiliar, preparador físico, treinador de goleiros)
 * O antigo /jogador/<nome>/ de quem é da comissão leva para cá com redirecionamento 301.
 * Dados: api/mercado.json (movimento, ficha, carreira temporada a temporada com J, V, E, D quando a fonte traz).
 * Nada é estimado: aproveitamento só onde há vitórias, empates e derrotas; nos outros anos, % de vitórias.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_tec_e_comissao($p)
{
    return function_exists('tsp_mc_e_comissao_pos') && tsp_mc_e_comissao_pos($p['posicao'] ?? '');
}

function tsp_tec_url($p)
{
    $base = ($p['posicao'] ?? '') === 'Treinador' ? 'treinador' : 'comissao-tecnica';
    $clube = $p['clube'] ?: 'sem-clube';
    return home_url('/' . $base . '/' . $clube . '/' . sanitize_title(remove_accents($p['nome'])) . '/');
}

add_action('init', function () {
    add_rewrite_rule('^(treinador|comissao-tecnica)/([a-z0-9-]+)/([a-z0-9-]+)/?$', 'index.php?tsp_tec_tipo=$matches[1]&tsp_tec_clube=$matches[2]&tsp_tec_nome=$matches[3]', 'top');
    if (get_option('tsp_tec_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_tec_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    return array_merge($v, array('tsp_tec_tipo', 'tsp_tec_clube', 'tsp_tec_nome'));
});

// Conta da carreira como técnico principal
function tsp_tec_totais($carreira)
{
    $t = array('jogos' => 0, 'vitorias' => 0, 'clubes' => array(), 'temporadas' => array(), 'vde' => array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0));
    foreach ((array) $carreira as $c) {
        if (($c['funcao'] ?? 'Treinador') !== 'Treinador') {
            continue;
        }
        $t['jogos'] += (int) ($c['jogos'] ?? 0);
        $t['vitorias'] += (int) ($c['vitorias'] ?? 0);
        $t['clubes'][$c['clube']] = ($t['clubes'][$c['clube']] ?? 0) + (int) ($c['jogos'] ?? 0);
        $t['temporadas'][$c['temporada']] = 1;
        if (isset($c['empates'], $c['derrotas'])) {
            $t['vde']['j'] += (int) $c['jogos'];
            $t['vde']['v'] += (int) $c['vitorias'];
            $t['vde']['e'] += (int) $c['empates'];
            $t['vde']['d'] += (int) $c['derrotas'];
        }
    }
    return $t;
}

function tsp_tec_pct($a, $b)
{
    return $b ? number_format_i18n(100 * $a / $b, 1) . '%' : '–';
}

// Por temporada (só técnico principal), para o resumo de 2026 e o aproveitamento
function tsp_tec_por_ano($carreira)
{
    $a = array();
    foreach ((array) $carreira as $c) {
        if (($c['funcao'] ?? 'Treinador') !== 'Treinador') {
            continue;
        }
        $y = $c['temporada'];
        $a[$y] = $a[$y] ?? array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'vde' => true, 'clubes' => array());
        $a[$y]['j'] += (int) ($c['jogos'] ?? 0);
        $a[$y]['v'] += (int) ($c['vitorias'] ?? 0);
        $a[$y]['clubes'][] = $c['clube'];
        if (isset($c['empates'], $c['derrotas'])) {
            $a[$y]['e'] += (int) $c['empates'];
            $a[$y]['d'] += (int) $c['derrotas'];
        } else {
            $a[$y]['vde'] = false;
        }
    }
    return $a;
}

// Matérias do TSP: primeiro as que citam o nome; completa com as últimas do clube atual
function tsp_tec_materias($nome, $t)
{
    $ids = array();
    $q = get_posts(array('post_type' => 'post', 's' => $nome, 'sentence' => true, 'posts_per_page' => 6, 'no_found_rows' => true));
    $posts = $q;
    foreach ($q as $x) {
        $ids[] = $x->ID;
    }
    if (count($posts) < 6 && $t) {
        $mais = get_posts(array('post_type' => 'post', 'posts_per_page' => 6 - count($posts), 'post__not_in' => $ids, 'no_found_rows' => true,
            'tax_query' => array(array('taxonomy' => 'times', 'field' => 'term_id', 'terms' => $t->term_id))));
        $posts = array_merge($posts, $mais);
    }
    return $posts;
}

add_action('template_redirect', function () {
    $nome_slug = get_query_var('tsp_tec_nome');
    if (!$nome_slug) {
        return;
    }
    $clube_slug = get_query_var('tsp_tec_clube');
    $p = null;
    foreach (tsp_mc_jogadores() as $x) {
        if (tsp_tec_e_comissao($x) && sanitize_title(remove_accents($x['nome'])) === $nome_slug && (($x['clube'] ?: 'sem-clube') === $clube_slug)) {
            $p = $x;
            break;
        }
    }
    if (!$p) {
        if (function_exists('tsp_404_real')) {
            tsp_404_real();
        }
        return;
    }
    $canon = tsp_tec_url($p);
    if (untrailingslashit($canon) !== untrailingslashit(home_url(strtok($_SERVER['REQUEST_URI'] ?? '', '?')))) {
        wp_safe_redirect($canon, 301);
        exit;
    }
    tsp_tec_pagina($p, $canon);
    exit;
});


// 22/11/2026: jogos do técnico na base do TSP (api/tecnicos.json, fichas técnicas com fonte)
function tsp_tec_base($nome)
{
    if (!function_exists('tsp_mc_arquivo')) {
        return null;
    }
    $d = tsp_mc_arquivo('tecnicos.json');
    $k = sanitize_title(remove_accents($nome));
    return $d['tecnicos'][$k] ?? null;
}

function tsp_tec_base_html($b)
{
    if (!$b || empty($b['jogos'])) {
        return '';
    }
    // 25/11/2026: é recorte, não total (regra do Thiago): diz quantos jogos e de quando a quando
    $ds = array();
    foreach ((array) ($b['lista'] ?? array()) as $g) {
        if (!empty($g['data'])) {
            $ds[] = strtotime($g['data'] . ' 12:00');
        }
    }
    $per = $ds ? ', de ' . wp_date('d/m/Y', min($ds)) . ' a ' . wp_date('d/m/Y', max($ds)) : '';
    $h = '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Recorte: últimos ' . (int) $b['jogos'] . ' jogos na base do TSP</h2><span class="tsp-secao__sub">' . esc_html('Só partidas com ficha técnica registrada' . $per . '. Não é o total da carreira nem da temporada.') . '</span></div></div>';
    $h .= '<div class="tsp-jog__nums">';
    foreach (array(array($b['jogos'], 'jogos'), array($b['V'], 'vitórias'), array($b['E'], 'empates'), array($b['D'], 'derrotas'), array(number_format_i18n($b['aproveitamento'], 1) . '%', 'aproveitamento'), array($b['gp'] . ':' . $b['gc'], 'gols pró/contra')) as $c) {
        $h .= '<div><b>' . esc_html($c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
    }
    $h .= '</div>';
    if (!empty($b['competicoes'])) {
        $h .= '<div class="tsp-tabela-rolagem"><table class="tsp-tabela"><thead><tr><th>Competição</th><th>J</th><th>V</th><th>E</th><th>D</th></tr></thead><tbody>';
        foreach ($b['competicoes'] as $c) {
            $h .= '<tr><td>' . esc_html($c['nome']) . '</td><td>' . (int) $c['jogos'] . '</td><td>' . (int) $c['V'] . '</td><td>' . (int) $c['E'] . '</td><td>' . (int) $c['D'] . '</td></tr>';
        }
        $h .= '</tbody></table></div>';
    }
    $ult = array_slice((array) $b['lista'], 0, 10);
    if ($ult) {
        $h .= '<h3>Últimos jogos</h3><div class="tsp-tabela-rolagem"><table class="tsp-tabela"><thead><tr><th>Data</th><th>Jogo</th><th>Placar</th><th>Técnico adversário</th></tr></thead><tbody>';
        foreach ($ult as $g) {
            $adv = $g['adversario_nome'] ?? $g['adversario'];
            $h .= '<tr><td>' . esc_html(wp_date('d/m/Y', strtotime($g['data'] . ' 12:00'))) . '</td><td>' . ($g['mando'] === 'casa' ? 'x ' : '@ ') . esc_html($adv) . '</td><td><b class="tsp-res tsp-res--' . esc_attr(strtolower($g['res'])) . '">' . esc_html($g['placar']) . '</b></td><td>' . esc_html($g['tecnico_adversario'] ?: '–') . '</td></tr>';
        }
        $h .= '</tbody></table></div>';
    }
    $contra = (array) ($b['contra'] ?? array());
    uasort($contra, function ($a, $c) {
        return $c['jogos'] <=> $a['jogos'];
    });
    $contra = array_slice($contra, 0, 8);
    if ($contra) {
        $h .= '<h3>Confrontos contra outros técnicos (no recorte)</h3><ul class="tsp-tecp__contra">';
        foreach ($contra as $c) {
            $h .= '<li><b>' . esc_html($c['nome']) . '</b>: ' . (int) $c['jogos'] . ' jogo' . ($c['jogos'] > 1 ? 's' : '') . ' (' . (int) $c['V'] . 'V ' . (int) $c['E'] . 'E ' . (int) $c['D'] . 'D)</li>';
        }
        $h .= '</ul>';
    }
    $h .= '<p class="tsp-nota">Recorte dos ' . (int) $b['jogos'] . ' jogos com ficha técnica registrada na base do TSP (2026 em diante): a base ainda está recebendo as rodadas anteriores e cresce todo dia.</p></section>';
    return $h;
}

function tsp_tec_pagina($p, $canon)
{
    $t = $p['clube'] ? get_term_by('slug', $p['clube'], 'times') : null;
    $clube_nome = $t ? $t->name : '';
    $f = (array) ($p['ficha'] ?? array());
    $func = $p['posicao'] ?: 'Treinador';
    $principal = $func === 'Treinador';
    $idade = tsp_mc_idade($p['nascimento'] ?? '') ?: (int) ($f['idade'] ?? 0);
    $car = (array) ($p['carreira'] ?? array());
    $tot = tsp_tec_totais($car);
    $ano = tsp_tec_por_ano($car);
    $a26 = $ano['2026'] ?? null;
    // 23/11/2026 (Thiago): número de técnico só sai completo e conferido. Enquanto a carreira inteira não estiver
    // levantada (ficha.carreira_completa), não aparece total, aproveitamento nem número por temporada.
    $completa = !empty($f['carreira_completa']);
    if (!$completa) {
        $tot['jogos'] = 0;
        $tot['vitorias'] = 0;
        $a26 = null;
    }
    $acessos = array_values(array_filter((array) ($f['acessos'] ?? array())));
    $titulos = array_values(array_filter((array) ($f['titulos'] ?? array())));
    $clubes = array_keys($tot['clubes']);
    $antes = array();
    foreach ($car as $c) {
        if (($c['funcao'] ?? 'Treinador') !== 'Treinador') {
            $antes[$c['clube']] = 1;
        }
    }
    $de = mb_strtolower($func);
    $artigo = $t && function_exists('tsp_de') ? tsp_de($t) : ($clube_nome ? 'do ' . $clube_nome : '');

    // Resposta rápida
    $apel = trim(preg_replace('~\s*\([^)]*\)~', '', (string) ($f['conhecido_como'] ?? '')));
    $anos_car = array();
    foreach ($car as $c) {
        if (preg_match_all('~(19|20)\d{2}~', (string) ($c['temporada'] ?? ''), $mm)) {
            $anos_car = array_merge($anos_car, array_map('intval', $mm[0]));
        }
    }
    $desde = $anos_car ? min($anos_car) : 0;
    $resumo = $p['nome'] . ($apel ? ', conhecido como ' . $apel . ',' : '') . ' é ' . $de . ($artigo ? ' ' . $artigo : '') . ' para 2027' . ($idade ? ', tem ' . $idade . ' anos' : '') . '.'
        . (!empty($f['natural']) ? ' Natural de ' . $f['natural'] . '.' : '')
        . (($acessos || $titulos) ? ' Soma ' . ($acessos ? count($acessos) . ' acesso' . (count($acessos) > 1 ? 's' : '') : '') . ($acessos && $titulos ? ' e ' : '') . ($titulos ? count($titulos) . ' título' . (count($titulos) > 1 ? 's' : '') : '') . ' conferidos pelo TSP' . ($desde ? ' em uma carreira iniciada em ' . $desde : '') . '.' : '');
    if ($tot['jogos']) {
        $resumo .= ' Como técnico principal, soma ' . $tot['jogos'] . ' jogos e ' . $tot['vitorias'] . ' vitórias (' . tsp_tec_pct($tot['vitorias'], $tot['jogos']) . ') em ' . count($clubes) . ' clubes, de ' . min(array_keys($tot['temporadas'])) . ' a ' . max(array_keys($tot['temporadas'])) . '.';
    }
    if ($a26 && $a26['vde'] && $a26['j']) {
        $resumo .= ' Em 2026: ' . $a26['j'] . ' jogos, ' . $a26['v'] . 'V ' . $a26['e'] . 'E ' . $a26['d'] . 'D, aproveitamento de ' . tsp_tec_pct($a26['v'] * 3 + $a26['e'], $a26['j'] * 3) . '.';
    }
    $titulo = $p['nome'] . (!empty($f['nome_completo']) && $f['nome_completo'] !== $p['nome'] ? ' (' . $f['nome_completo'] . ')' : '') . ': trajetória, números e carreira' . ($clube_nome ? ' no ' . $clube_nome : '');

    foreach (array('pre_get_document_title', 'wpseo_title') as $fl) {
        add_filter($fl, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($resumo) {
        return mb_substr($resumo, 0, 155);
    }, 99);
    foreach (array('wpseo_canonical', 'wpseo_opengraph_url') as $fl) {
        add_filter($fl, function () use ($canon) {
            return $canon;
        }, 99);
    }
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    $foto = (array) ($p['foto'] ?? array());
    echo '<main class="tsp-container tsp-jog tsp-tecp">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › '
        . ($t ? '<a href="' . esc_url(get_term_link($t)) . '">' . esc_html($clube_nome) . '</a> › ' : '')
        . '<a href="' . esc_url(home_url('/mercado-da-bola/treinadores/')) . '">Treinadores</a> › <span>' . esc_html($p['nome']) . '</span></nav>';

    // Cabeçalho
    echo '<header class="tsp-jog__cab"><div class="tsp-jog__foto">' . tsp_mc_foto($p['nome'], $foto, 220, false) . '</div><div class="tsp-jog__id">';
    echo '<p class="tsp-tecp__func">' . esc_html($func . ($clube_nome ? ' · ' . $clube_nome : '')) . '</p><h1>' . esc_html($titulo) . '</h1>';
    if ($t) {
        echo '<a class="tsp-jog__clube" href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 28) . '<span>' . esc_html($clube_nome) . (!empty($p['saiu']) ? ' (saiu)' : ' · 2027') . '</span></a>';
    }
    echo '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resumo) . '</p></div>';
    echo '</div></header>';

    // Ficha técnica e resumo profissional (modelo pedido pelo Thiago, 21/11/2026)
    $conq = array_merge($titulos, $acessos);
    // 22/11/2026 (Thiago): mostrar todos os campos; o que ainda não foi levantado aparece como "Em atualização"
    $linhas = array(
        'Nome completo' => $f['nome_completo'] ?? '',
        'Apelido' => $f['apelido'] ?? '',
        'Naturalidade' => $f['natural'] ?? '',
        'Nascimento' => !empty($p['nascimento']) ? wp_date('d/m/Y', strtotime($p['nascimento'] . ' 12:00')) . ($idade ? ' (' . $idade . ' anos)' : '') : ($idade ? $idade . ' anos' : ''),
        'Cargo atual' => $func . ($artigo ? ' ' . $artigo : ''),
        'Contrato' => $f['contrato'] ?? '',
        'Posição como jogador' => $f['posicao_jogador'] ?? '',
        'Formação acadêmica' => $f['formacao'] ?? '',
        'Esquema tático preferido' => $f['esquema'] ?? '',
        'Início na comissão técnica' => $f['inicio_comissao'] ?? '',
    );
    if ($apel) {
        $linhas = array_slice($linhas, 0, 1, true) + array('Conhecido como' => $apel) + array_slice($linhas, 1, null, true);
    }
    if (empty($linhas['Apelido'])) {
        unset($linhas['Apelido']);
    }
    unset($linhas[$principal ? 'Início na comissão técnica' : 'Posição como jogador']);
    if (!$principal) {
        unset($linhas['Esquema tático preferido']);
    }
    echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Ficha técnica e resumo profissional</h2></div></div><dl class="tsp-tecp__ficha">';
    foreach ($linhas as $k => $v) {
        echo '<div' . ($v === '' ? ' class="tsp-tecp__vazio"' : '') . '><dt>' . esc_html($k) . '</dt><dd>' . ($v === '' ? 'Em atualização' : esc_html($v)) . '</dd></div>';
    }
    $rh = function_exists('tsp_mc_redes_html') ? tsp_mc_redes_html($f) : '';
    echo '<div' . ($rh === '' ? ' class="tsp-tecp__vazio"' : '') . '><dt>Redes sociais</dt><dd>' . ($rh === '' ? 'Em atualização' : $rh) . '</dd></div>'; // phpcs:ignore
    echo '</dl>';
    // Raio-X em números grandes (só o que está conferido)
    $rx = array_filter(array(
        $acessos ? array(count($acessos), count($acessos) > 1 ? 'acessos' : 'acesso') : null,
        $titulos ? array(count($titulos), count($titulos) > 1 ? 'títulos' : 'título') : null,
        ($nclub = count(array_unique(array_map(function ($c) { return $c['clube'] ?? ''; }, $car)))) ? array($nclub, $nclub > 1 ? 'clubes' : 'clube') : null,
        $desde ? array($desde, 'início da carreira') : null,
    ));
    if (count($rx) >= 2) {
        echo '<div class="tsp-jog__nums tsp-tecp__rx">';
        foreach ($rx as $c) {
            echo '<div><b>' . esc_html($c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
        }
        echo '</div>';
    }
    $hist = array_filter(array($f['inicio'] ?? '', $f['no_clube'] ?? ''));
    foreach ($hist as $h) {
        echo '<p class="tsp-tecp__inicio">' . esc_html(rtrim($h, '.')) . '.</p>';
    }
    echo '</section>';

    // Estilo de jogo (citação com fonte)
    if ($principal && !empty($f['estilo'])) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-tecp__estilo"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Qual é o estilo de jogo de ' . esc_html($p['nome']) . '?</h2></div></div><blockquote>' . esc_html(rtrim($f['estilo'], '.')) . '.</blockquote></section>';
    }

    // Números da carreira
    if ($tot['jogos']) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Números da carreira</h2><span class="tsp-secao__sub">Como técnico principal</span></div></div><div class="tsp-jog__nums">';
        $cx = array(
            array($tot['jogos'], 'jogos'), array($tot['vitorias'], 'vitórias'), array(tsp_tec_pct($tot['vitorias'], $tot['jogos']), 'de vitórias'),
            array(count($clubes), count($clubes) === 1 ? 'clube' : 'clubes'), array(count($tot['temporadas']), 'temporadas'),
            array(count($acessos), count($acessos) === 1 ? 'acesso' : 'acessos'), array(count($titulos), count($titulos) === 1 ? 'título' : 'títulos'),
        );
        foreach ($cx as $c) {
            echo '<div><b>' . esc_html(is_int($c[0]) ? number_format_i18n($c[0]) : $c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
        }
        echo '</div>';
        if ($a26 && $a26['j']) {
            echo '<div class="tsp-tecp__ano"><b>2026</b> ' . esc_html(implode(', ', array_unique($a26['clubes']))) . ': ' . (int) $a26['j'] . ' jogos · '
                . ($a26['vde'] ? (int) $a26['v'] . ' vitória' . ($a26['v'] == 1 ? '' : 's') . ', ' . (int) $a26['e'] . ' empate' . ($a26['e'] == 1 ? '' : 's') . ', ' . (int) $a26['d'] . ' derrota' . ($a26['d'] == 1 ? '' : 's') . ' · <b>aproveitamento ' . esc_html(tsp_tec_pct($a26['v'] * 3 + $a26['e'], $a26['j'] * 3)) . '</b>' : (int) $a26['v'] . ' vitórias') . '</div>';
        }
        echo '</section>';
    }

    // "Jogos na base do TSP" saiu (23/11/2026): é parcial por natureza. Volta só como complemento de carreira completa.
    if ($completa) {
        echo tsp_tec_base_html(tsp_tec_base($p['nome'])); // phpcs:ignore
    } elseif ($principal) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Números da carreira</h2></div></div><p class="tsp-tecp__inicio"><b>Em atualização.</b> O TSP só publica jogos, vitórias e aproveitamento de ' . esc_html($p['nome']) . ' quando todos os trabalhos da carreira estiverem conferidos em fonte. Número parcial não entra.</p></section>';
    }

    // Títulos, acessos e destaques em linha do tempo (ano em destaque, mais recente primeiro)
    $destaques = array_values(array_filter((array) ($f['destaques'] ?? array())));
    $limpa = function ($t) {
        return trim(preg_replace('~\s*\((?=[^)]*(\d{2}/\d{2}|Futebol Interior|Correio|Trivela|Ag[êe]ncia|Lance|Gazeta|ge\b|UOL|Jovem Pan))[^)]*\)~u', '', (string) $t));
    };
    $linha = array();
    foreach ($titulos as $t) {
        $linha[] = array('tipo' => 'titulo', 'txt' => $limpa($t));
    }
    foreach ($acessos as $t) {
        $linha[] = array('tipo' => 'acesso', 'txt' => $limpa($t));
    }
    foreach ($linha as &$l) {
        $l['ano'] = preg_match('~(19|20)\d{2}~', $l['txt'], $m) ? (int) $m[0] : 0;
    }
    unset($l);
    usort($linha, function ($a, $b) {
        return $b['ano'] <=> $a['ano'];
    });
    if ($linha || $destaques) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Títulos e acessos de ' . esc_html($p['nome']) . '</h2>' . ($linha ? '<span class="tsp-secao__sub">' . count($titulos) . ' título' . (count($titulos) == 1 ? '' : 's') . ' · ' . count($acessos) . ' acesso' . (count($acessos) == 1 ? '' : 's') . '</span>' : '') . '</div></div>';
        if ($linha) {
            echo '<ol class="tsp-tl">';
            foreach ($linha as $l) {
                $txt = preg_replace('~^(Campe[aã]o|Acesso)\s~u', '$1 ', $l['txt']);
                echo '<li class="tsp-tl__i tsp-tl__i--' . $l['tipo'] . '"><span class="tsp-tl__ano">' . ($l['ano'] ?: '–') . '</span><span class="tsp-tl__ico" aria-hidden="true">' . ($l['tipo'] === 'titulo' ? '🏆' : '⬆') . '</span><span class="tsp-tl__txt">' . esc_html($txt) . '</span></li>';
            }
            echo '</ol>';
        }
        if ($destaques) {
            echo '<h3>Feitos marcantes</h3><ul class="tsp-tecp__feitos">';
            foreach (array_slice($destaques, 0, 6) as $d) {
                echo '<li>' . esc_html($limpa($d)) . '</li>';
            }
            echo '</ul>';
        }
        echo '</section>';
    }

    // Trajetória: passagens seguidas no mesmo clube viram uma linha; colunas de números só se houver números
    if ($car) {
        $grupos = array();
        foreach ($car as $c) {
            $k = ($c['clube'] ?? '') . '|' . ($c['funcao'] ?? 'Treinador');
            $ult = end($grupos);
            if ($ult && $ult['k'] === $k && empty($c['jogos']) && empty($ult['jogos'])) {
                $grupos[key($grupos)]['anos'][] = $c['temporada'] ?? '';
                continue;
            }
            $grupos[] = array_merge($c, array('k' => $k, 'anos' => array($c['temporada'] ?? '')));
        }
        $com_num = $completa && (bool) array_filter($car, function ($c) {
            return !empty($c['jogos']);
        });
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__carreira"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Por quais clubes ' . esc_html($p['nome']) . ' passou?</h2><span class="tsp-secao__sub">Trajetória temporada a temporada</span></div></div>';
        echo '<div class="tsp-tabela-rolagem"><table class="tsp-tabela tsp-tecp__traj"><thead><tr><th>Ano</th><th>Clube</th><th>Função</th>' . ($com_num ? '<th>J</th><th>V</th><th>E</th><th>D</th><th>Aprov.</th>' : '') . '</tr></thead><tbody>';
        foreach ($grupos as $c) {
            $anos = array();
            foreach ($c['anos'] as $a) {
                if (preg_match_all('~(19|20)\d{2}~', (string) $a, $mm)) {
                    $anos = array_merge($anos, array_map('intval', $mm[0]));
                }
            }
            $per = $anos ? (min($anos) === max($anos) ? min($anos) : min($anos) . '–' . max($anos)) : implode(', ', $c['anos']);
            $term = get_term_by('name', $c['clube'] ?? '', 'times');
            $logo = $term ? tsp_escudo($term, 22) : tsp_mc_escudo(array('nome' => $c['clube'] ?? '', 'escudo' => $c['escudo'] ?? ''), 22);
            if (!empty($c['escudo']) && !$term) {
                $logo = '<span class="tsp-ge__esc"><img src="' . esc_url($c['escudo']) . '" alt="Escudo do ' . esc_attr($c['clube']) . '" width="22" height="22" loading="lazy" style="object-fit:contain"></span>';
            }
            $u_c = function_exists('tsp_clube_url') ? tsp_clube_url($c['clube'] ?? '') : ($term ? get_term_link($term) : '');
            $nome_c = $u_c ? '<a href="' . esc_url($u_c) . '">' . esc_html($c['clube']) . '</a>' : esc_html($c['clube'] ?? '');
            echo '<tr' . (($c['funcao'] ?? 'Treinador') !== 'Treinador' ? ' class="tsp-tecp__outra"' : '') . '><td>' . esc_html($per) . '</td><td><span class="tsp-fig__clube">' . (strpos($logo, '<img') !== false ? $logo : '') . $nome_c . '</span></td><td>' . esc_html($c['funcao'] ?? 'Treinador') . '</td>';
            if ($com_num) {
                $j = $c['jogos'] ?? null;
                $vde = isset($c['vitorias'], $c['empates'], $c['derrotas']) && $j;
                $aprov = $vde ? tsp_tec_pct($c['vitorias'] * 3 + $c['empates'], $j * 3) : ($j && isset($c['vitorias']) ? tsp_tec_pct($c['vitorias'], $j) . '<small> vit.</small>' : '–');
                echo '<td>' . esc_html($j ?? '–') . '</td><td>' . esc_html($c['vitorias'] ?? '–') . '</td><td>' . esc_html($c['empates'] ?? '–') . '</td><td>' . esc_html($c['derrotas'] ?? '–') . '</td><td>' . $aprov . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table></div>' . ($com_num ? '<p class="tsp-nota">Aproveitamento = pontos ganhos ÷ pontos disputados, só nas temporadas em que vitórias, empates e derrotas foram conferidos.</p>' : '') . '</section>';
    } else {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__carreira"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Trajetória temporada a temporada</h2></div></div><p class="tsp-atualiza">Em atualização</p></section>';
    }

    // Clubes
    if (!$car && ($clubes || $antes)) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Clubes em que trabalhou</h2></div></div><div class="tsp-tecp__clubes">';
        arsort($tot['clubes']);
        foreach ($tot['clubes'] as $cl => $j) {
            $logo = tsp_mc_escudo(array('nome' => $cl), 28);
            echo '<a class="tsp-tecp__clube" href="' . esc_url(function_exists('tsp_clube_url') ? tsp_clube_url($cl) : '#') . '">' . (strpos($logo, '<img') !== false ? $logo : '') . '<b>' . esc_html($cl) . '</b><small>' . (($j && $completa) ? (int) $j . ' jogos como técnico' : 'técnico') . '</small></a>';
        }
        foreach (array_keys($antes) as $cl) {
            if (isset($tot['clubes'][$cl])) {
                continue;
            }
            $logo = tsp_mc_escudo(array('nome' => $cl), 28);
            echo '<a class="tsp-tecp__clube" href="' . esc_url(function_exists('tsp_clube_url') ? tsp_clube_url($cl) : '#') . '">' . (strpos($logo, '<img') !== false ? $logo : '') . '<b>' . esc_html($cl) . '</b><small>comissão técnica</small></a>';
        }
        echo '</div></section>';
    }

    // Mercado
    if (!empty($p['movimentos'])) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__mercado"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Mercado da Bola</h2></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/treinadores/')) . '">Todos os treinadores →</a></span></div><ul class="tsp-jog__movs">';
        foreach ($p['movimentos'] as $m) {
            $rota = ($m['tipo'] ?? '') === 'renovacao' ? 'segue no ' . ($m['para']['nome'] ?? '') : trim(($m['de']['nome'] ?? '') . (!empty($m['para']['nome']) ? ' → ' . $m['para']['nome'] : ''), ' →');
            echo '<li><time datetime="' . esc_attr($m['data']) . '">' . esc_html(wp_date('d/m/Y', strtotime($m['data'] . ' 12:00'))) . '</time> <b>' . esc_html($m['tipo_nome'] ?? '') . '</b> ' . esc_html($rota)
                . (!empty($m['obs']) ? ' <small>' . esc_html($m['obs']) . '</small>' : '') . '</li>';
        }
        echo '</ul></section>';
    }

    // Matérias do TSP
    $mats = tsp_tec_materias($p['nome'], $t);
    if ($mats) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Matérias do TSP</h2></div></div><ul class="tsp-tecp__mats">';
        foreach ($mats as $x) {
            echo '<li><a href="' . esc_url(get_permalink($x)) . '">' . esc_html(get_the_title($x)) . '</a> <time datetime="' . esc_attr(get_the_date('c', $x)) . '">' . esc_html(get_the_date('d/m/Y', $x)) . '</time></li>';
        }
        echo '</ul></section>';
    }

    // Na imprensa: matérias de outros portais usadas na apuração (links de saída, só fontes aceitas)
    $links = array();
    foreach (array_merge((array) ($f['fontes'] ?? array()), array($f['fonte'] ?? ''), (array) ($p['movimentos'][0]['fontes'] ?? array())) as $u) {
        if (!is_string($u) || strpos($u, 'http') !== 0 || strpos($u, 'tudosobrepaulista') !== false || preg_match('~instagram|facebook|twitter|x\.com|wikipedia|transfermarkt|sofascore|ogol~i', $u)) {
            continue;
        }
        $links[$u] = 1;
    }
    if ($links) {
        $mapa = array('ge.globo' => 'ge', 'globo.com' => 'ge', 'uol' => 'UOL', 'lance' => 'Lance!', 'gazetaesportiva' => 'Gazeta Esportiva', 'futebolinterior' => 'Futebol Interior', 'correiobraziliense' => 'Correio Braziliense', 'trivela' => 'Trivela', 'agenciabrasil' => 'Agência Brasil', 'jovempan' => 'Jovem Pan', 'opovo' => 'O Povo', 'terra' => 'Terra', 'estadao' => 'Estadão', 'folha' => 'Folha', 'cnnbrasil' => 'CNN Brasil', 'espn' => 'ESPN');
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($p['nome']) . ' na imprensa</h2><span class="tsp-secao__sub">Reportagens usadas na apuração do TSP</span></div></div><ul class="tsp-tecp__imprensa">';
        foreach (array_slice(array_keys($links), 0, 10) as $u) {
            $host = preg_replace('~^www\.~', '', (string) wp_parse_url($u, PHP_URL_HOST));
            $nome_v = $host;
            foreach ($mapa as $k => $v) {
                if (strpos($host, $k) !== false) {
                    $nome_v = $v;
                    break;
                }
            }
            $slug = trim((string) wp_parse_url($u, PHP_URL_PATH), '/');
            $slug = ucfirst(str_replace(array('-', '_'), ' ', preg_replace('~\.(html?|php)$~', '', basename($slug))));
            echo '<li><a href="' . esc_url($u) . '" target="_blank" rel="noopener"><b>' . esc_html($nome_v) . '</b><span>' . esc_html(mb_strimwidth($slug, 0, 90, '…')) . '</span></a></li>';
        }
        echo '</ul></section>';
    }

    // Perguntas frequentes (respondidas com os dados da página)
    $faq = array();
    $faq[] = array('Quem é ' . $p['nome'] . '?', $p['nome'] . (!empty($f['nome_completo']) ? ' (' . $f['nome_completo'] . ')' : '') . ' é ' . $de . ($artigo ? ' ' . $artigo : '') . ($idade ? ', tem ' . $idade . ' anos' : '') . '.' . (!empty($f['inicio']) ? ' ' . $f['inicio'] . '.' : ''));
    if ($clube_nome) {
        $faq[] = array('Qual é o clube de ' . $p['nome'] . ' em 2027?', $p['nome'] . (!empty($p['saiu']) ? ' deixou o ' . $clube_nome . '.' : ' é ' . $de . ' ' . $artigo . ' para a temporada 2027.' . (!empty($f['no_clube']) ? ' ' . $f['no_clube'] . '.' : '')));
    }
    if (!empty($f['natural'])) {
        $faq[] = array('De onde é ' . $p['nome'] . '?', $p['nome'] . ' é natural de ' . $f['natural'] . '.');
    }
    // 22/11/2026: intenções de busca (estilo, esquema, formação, idade, acessos) — só com dado conferido
    if ($idade) {
        $faq[] = array('Quantos anos tem ' . $p['nome'] . '?', $p['nome'] . ' tem ' . $idade . ' anos' . (!empty($p['nascimento']) ? ' (nasceu em ' . wp_date('d/m/Y', strtotime($p['nascimento'] . ' 12:00')) . ')' : '') . '.');
    }
    if (!empty($f['estilo'])) {
        $faq[] = array('Qual é o estilo de jogo de ' . $p['nome'] . '?', rtrim($f['estilo'], '.') . '.');
    }
    if (!empty($f['esquema'])) {
        $faq[] = array('Qual é o esquema tático preferido de ' . $p['nome'] . '?', rtrim($f['esquema'], '.') . '.');
    }
    if (!empty($f['formacao'])) {
        $faq[] = array('Qual é a formação de ' . $p['nome'] . '?', rtrim($f['formacao'], '.') . '.');
    }
    if ($acessos) {
        $faq[] = array('Quantos acessos ' . $p['nome'] . ' tem na carreira?', count($acessos) . ' acesso' . (count($acessos) > 1 ? 's' : '') . ' conferido' . (count($acessos) > 1 ? 's' : '') . ' pelo TSP: ' . implode('; ', $acessos) . '.');
    }
    if (!empty($f['posicao_jogador'])) {
        $faq[] = array('Qual era a posição de ' . $p['nome'] . ' quando jogava futebol?', 'Como jogador, ' . $p['nome'] . ' atuava como ' . mb_strtolower($f['posicao_jogador']) . '.');
    }
    if (!empty($f['inicio_comissao'])) {
        $faq[] = array('Desde quando ' . $p['nome'] . ' trabalha na comissão técnica?', $f['inicio_comissao'] . '.');
    }
    if ($clubes) {
        $faq[] = array(($principal ? 'Quais clubes ' . $p['nome'] . ' já treinou?' : 'Em quais clubes ' . $p['nome'] . ' já trabalhou?'), 'Como técnico principal: ' . implode(', ', $clubes) . '.' . ($antes ? ' Antes, na comissão técnica: ' . implode(', ', array_keys($antes)) . '.' : ''));
    }
    if ($tot['jogos']) {
        $faq[] = array('Quantos jogos ' . $p['nome'] . ' tem como treinador?', $tot['jogos'] . ' jogos como técnico principal, com ' . $tot['vitorias'] . ' vitórias (' . tsp_tec_pct($tot['vitorias'], $tot['jogos']) . ' de vitórias), segundo os registros conferidos pelo TSP.');
    }
    if ($a26 && $a26['vde'] && $a26['j']) {
        $faq[] = array('Qual foi o aproveitamento de ' . $p['nome'] . ' em 2026?', tsp_tec_pct($a26['v'] * 3 + $a26['e'], $a26['j'] * 3) . ': ' . $a26['j'] . ' jogos, ' . $a26['v'] . ' vitórias, ' . $a26['e'] . ' empates e ' . $a26['d'] . ' derrotas por ' . implode(', ', array_unique($a26['clubes'])) . '.');
    }
    if ($titulos || $acessos) {
        if (function_exists('tsp_mc_redes') && ($rs = tsp_mc_redes($f))) {
            $faq[] = array('Qual é o Instagram de ' . $p['nome'] . '?', implode('; ', array_map(function ($x) {
                return $x['nome'] . ': @' . $x['user'];
            }, $rs)) . '.');
        }
        $faq[] = array($p['nome'] . ' tem títulos ou acessos?', trim(($titulos ? 'Títulos: ' . implode('; ', $titulos) . '. ' : '') . ($acessos ? 'Acessos e campanhas: ' . implode('; ', $acessos) . '.' : '') . ($destaques ? ' Destaque: ' . $destaques[0] . '.' : '')));
    }
    echo '<section class="tsp-secao tsp-secao--caixa tsp-faq"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Perguntas frequentes sobre ' . esc_html($p['nome']) . '</h2></div></div>';
    foreach ($faq as $q) {
        echo '<div class="tsp-tecp__faq"><h3>' . esc_html($q[0]) . '</h3><p>' . esc_html($q[1]) . '</p></div>';
    }
    echo '</section>';

    $notas = array('Dados conferidos pelo TSP em anúncios oficiais, matérias e registros de jogos.');
    if (!empty($foto['ia'])) {
        $notas[] = 'Figurinha: montagem com IA, ilustrativa, feita a partir da foto oficial de anúncio.';
    }
    echo '<p class="tsp-nota">' . esc_html(implode(' ', $notas)) . '</p>';

    // Dados estruturados: pessoa, FAQ e migalhas
    $ld = array('@context' => 'https://schema.org', '@type' => 'Person', 'name' => $p['nome'], 'url' => $canon, 'jobTitle' => $func . ' de futebol');
    if (!empty($f['nome_completo'])) {
        $ld['alternateName'] = $f['nome_completo'];
    }
    if (!empty($p['nascimento'])) {
        $ld['birthDate'] = $p['nascimento'];
    }
    if (function_exists('tsp_mc_redes') && ($rs = tsp_mc_redes($f))) {
        $ld['sameAs'] = array_column($rs, 'url');
    }
    if (!empty($foto['url'])) {
        $ld['image'] = $foto['url'];
    }
    if ($clube_nome && empty($p['saiu'])) {
        $ld['worksFor'] = array('@type' => 'SportsTeam', 'name' => $clube_nome, 'url' => $t ? get_term_link($t) : '');
    }
    $ldf = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($q) {
        return array('@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $q[1]));
    }, $faq));
    $mig = array(array('Início', home_url('/')));
    if ($t) {
        $mig[] = array($clube_nome, get_term_link($t));
    }
    $mig[] = array($p['nome'], $canon);
    $ldb = array('@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array_map(function ($x, $i) {
        return array('@type' => 'ListItem', 'position' => $i + 1, 'name' => $x[0], 'item' => $x[1]);
    }, $mig, array_keys($mig)));
    foreach (array($ld, $ldf, $ldb) as $j) {
        echo '<script type="application/ld+json">' . wp_json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    }
    echo '</main>';
    get_footer();
}
