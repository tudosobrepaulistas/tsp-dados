<?php
/**
 * Mercado da Bola 2027 (14/11/2026): quem chega, quem sai e quem renova nos clubes paulistas.
 * Dados: base própria do TSP no GitHub (api/mercado.json e api/elencos.json), conferidos em 2 fontes.
 *  - Home: um carrossel por bloco (Série A, Série B, Feminino, Paulistão A1 a A4). Um movimento não se repete em dois blocos.
 *  - Página /mercado-da-bola/: tudo, com filtro por bloco e por clube.
 *  - Página do clube: "Mercado da bola" (chegadas, saídas e renovações) e "Elenco 2027" com foto.
 * Sem foto oficial com crédito, o card mostra a inicial do jogador (nada de imagem inventada).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_MC_BASE = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/';

/* ---------- Leitura dos arquivos (guardados no site; renovados a cada 30 minutos, sem travar a página) ---------- */

function tsp_mc_baixar($arq)
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 300), TSP_MC_BASE . $arq), array('timeout' => 8));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return null;
    }
    $d = json_decode(wp_remote_retrieve_body($r), true);
    if (!is_array($d)) {
        return null;
    }
    update_option('tsp_mc_' . sanitize_key(str_replace('.json', '', $arq)), array('t' => time(), 'd' => $d), false);
    return $d;
}

function tsp_mc_arquivo($arq)
{
    static $cache = array();
    if (isset($cache[$arq])) {
        return $cache[$arq];
    }
    $o = get_option('tsp_mc_' . sanitize_key(str_replace('.json', '', $arq)));
    if (!is_array($o) || !isset($o['d'])) {
        $d = tsp_mc_baixar($arq); // primeira vez: busca na hora
        return $cache[$arq] = is_array($d) ? $d : array();
    }
    if (time() - (int) $o['t'] > 1800 && !wp_next_scheduled('tsp_mc_atualizar')) {
        wp_schedule_single_event(time() + 5, 'tsp_mc_atualizar');
    }
    return $cache[$arq] = $o['d'];
}

add_action('tsp_mc_atualizar', function () {
    tsp_mc_baixar('mercado.json');
    tsp_mc_baixar('elencos.json');
    tsp_mc_baixar('guia_clubes.json');
    tsp_mc_baixar('tecnicos.json');
});

function tsp_mc_itens()
{
    $d = tsp_mc_arquivo('mercado.json');
    return isset($d['itens']) && is_array($d['itens']) ? $d['itens'] : array();
}

function tsp_mc_elenco($slug)
{
    $d = tsp_mc_arquivo('elencos.json');
    return isset($d['clubes'][$slug]) && is_array($d['clubes'][$slug]) ? $d['clubes'][$slug] : array();
}

/* ---------- Peças ---------- */

function tsp_mc_clube_html($c)
{
    $nome = (string) ($c['nome'] ?? '');
    $t = !empty($c['slug']) ? get_term_by('slug', $c['slug'], 'times') : null;
    if ($t) {
        return '<a class="tsp-mc__clube" href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 26) . '<span>' . esc_html($nome) . '</span></a>';
    }
    return '<span class="tsp-mc__clube">' . tsp_ge_escudo((int) ($c['id'] ?? 0), $nome, 26) . '<span>' . esc_html($nome) . '</span></span>';
}

function tsp_mc_foto($nome, $foto, $tam = 84, $legenda = true)
{
    if (!empty($foto['url'])) {
        // Montagem com IA não leva legenda na foto: o aviso aparece uma vez só, no rodapé da seção
        return '<figure class="tsp-mc__foto"><img src="' . esc_url($foto['url']) . '" alt="' . esc_attr($nome) . '" width="' . (int) $tam . '" height="' . (int) $tam . '" loading="lazy" decoding="async" referrerpolicy="no-referrer">'
            . ($legenda && empty($foto['ia']) && !empty($foto['credito']) ? '<figcaption>Foto: ' . esc_html($foto['credito']) . '</figcaption>' : '') . '</figure>';
    }
    return '<figure class="tsp-mc__foto"><span class="tsp-mc__inicial" aria-hidden="true">' . esc_html(mb_strtoupper(mb_substr($nome, 0, 1))) . '</span></figure>';
}

// Selo da divisão do clube de destino (figurinha): Série A, Série B, A1 a A4 ou Feminino
function tsp_mc_divisao($m)
{
    if (!empty($m['feminino'])) {
        return 'FEM';
    }
    $b = (array) ($m['blocos'] ?? array());
    $slug = ($m['para']['slug'] ?? '') ?: ($m['de']['slug'] ?? '');
    $g = tsp_grupos();
    if (in_array($slug, array_merge(tsp_grupo_slugs('a4'), tsp_grupo_slugs('mb')), true)) {
        return 'SÉRIE A';
    }
    if (in_array($slug, tsp_grupo_slugs('sb'), true)) {
        return 'SÉRIE B';
    }
    foreach (array('d1', 'd2', 'd3', 'd4') as $k) {
        if (isset($g[$k]['divisao'][$slug])) {
            return 'A' . substr($k, 1);
        }
    }
    return $b ? strtoupper($b[0]) : '';
}

function tsp_mc_idade($nasc)
{
    return $nasc ? (int) floor((time() - strtotime($nasc . ' 12:00')) / (365.25 * DAY_IN_SECONDS)) : 0;
}

function tsp_mc_escudo($c, $tam = 30)
{
    $t = !empty($c['slug']) ? get_term_by('slug', $c['slug'], 'times') : null;
    if ($t) {
        return tsp_escudo($t, $tam);
    }
    $h = tsp_ge_escudo((int) ($c['id'] ?? 0), (string) ($c['nome'] ?? ''), $tam);
    if (strpos($h, '<img') === false && !empty($c['escudo'])) {
        // Clube de fora do site: escudo guardado na base (dados/escudos_extra.json)
        return '<span class="tsp-ge__esc"><img src="' . esc_url($c['escudo']) . '" alt="Escudo do ' . esc_attr($c['nome'] ?? '') . '" width="' . (int) $tam . '" height="' . (int) $tam . '" loading="lazy" style="object-fit:contain"></span>';
    }
    return $h;
}

// Números de 2026 (jogos, gols, assistências) e clubes em que jogou; minutos ficam guardados para as estatísticas
function tsp_mc_numeros_html($n, $compacto = false)
{
    $partes = array();
    if (!empty($n['jogos'])) {
        $partes[] = '<b>' . (int) $n['jogos'] . '</b> ' . ((int) $n['jogos'] === 1 ? 'jogo' : 'jogos');
    }
    if (isset($n['gols'])) {
        $partes[] = '<b>' . (int) $n['gols'] . '</b> ' . ((int) $n['gols'] === 1 ? 'gol' : 'gols');
    }
    if (isset($n['assistencias'])) {
        $partes[] = '<b>' . (int) $n['assistencias'] . '</b> assist.';
    }
    $clubes = array_filter((array) ($n['clubes'] ?? array()));
    $h = '<div class="tsp-fig__num"><small>2026</small> ' . ($partes ? implode(' · ', $partes) : 'números em apuração')
        . (!empty($n['obs']) ? '<span class="tsp-fig__obs">' . esc_html($n['obs']) . '</span>' : '') . '</div>';
    if ($clubes && !$compacto) {
        $esc = (array) ($n['escudos'] ?? array());
        $h .= '<div class="tsp-fig__clubes">Em 2026: ' . implode(' ', array_map(function ($c) use ($esc) {
            $logo = tsp_mc_escudo(array('nome' => $c, 'escudo' => $esc[$c] ?? ''), 16);
            return '<span class="tsp-fig__clube">' . (strpos($logo, '<img') !== false ? $logo : '') . esc_html($c) . '</span>';
        }, $clubes)) . '</div>';
    }
    return $h;
}

// Selos de 2026 (campeão estadual/nacional, acessos), só com fonte
function tsp_mc_selos_html($selos)
{
    $selos = array_filter((array) $selos, function ($x) {
        return !empty($x['texto']);
    });
    if (!$selos) {
        return '';
    }
    // Medalhinhas: título (ouro), acesso (verde), prêmio individual (estrela), outras conquistas
    return '<div class="tsp-fig__selos">' . implode('', array_map(function ($x) {
        $t = $x['tipo'] ?? '';
        if (!$t) {
            $tx = mb_strtolower($x['texto']);
            $t = preg_match('/campe[ãa]o|t[íi]tulo/u', $tx) ? 'titulo' : (preg_match('/acesso/u', $tx) ? 'acesso' : (preg_match('/artilheiro|melhor|craque|revela|sele[çc][ãa]o|goleiro menos|gar[çc]om/u', $tx) ? 'premio' : 'conquista'));
        }
        $ic = array('titulo' => '🥇', 'acesso' => '⬆', 'premio' => '⭐', 'conquista' => '🏅');
        return '<span class="tsp-selo tsp-selo--' . esc_attr($t) . '" title="' . esc_attr($x['texto']) . '"><i aria-hidden="true">' . ($ic[$t] ?? '🏅') . '</i>' . esc_html($x['texto']) . '</span>';
    }, $selos)) . '</div>';
}

// Selo de seleção do campeonato de 2026 (ex.: "Seleção do Paulistão A3 2026"), só com fonte
function tsp_mc_selo_selecao($selos)
{
    foreach ((array) $selos as $x) {
        $tx = (string) ($x['texto'] ?? '');
        if ($tx !== '' && (($x['tipo'] ?? '') === 'selecao' || preg_match('/sele[çc][ãa]o/iu', $tx))) {
            return '<div class="tsp-fig__selos"><span class="tsp-selo tsp-selo--selecao" title="' . esc_attr($tx) . '"><i aria-hidden="true">★</i>' . esc_html($tx) . '</span></div>';
        }
    }
    return '';
}

// Card padrão de figurinha (21/11/2026, pedido do Thiago): igual para todos.
// Escudo e divisão no alto, retrato (clicável), nome, posição, de onde veio → para onde foi,
// jogos e gols de 2026, selo de seleção (quando houver) e, no rodapé, o tipo do movimento e a data.
function tsp_mc_card($m)
{
    $tipo = sanitize_html_class($m['tipo'] ?? '');
    $renova = ($m['tipo'] ?? '') === 'renovacao';
    $sai = in_array($m['tipo'] ?? '', array('saida', 'venda'), true);
    $com = tsp_mc_e_treinador($m);
    $clube = $sai ? (array) $m['de'] : (array) $m['para'];
    $slugs = array_filter(array($m['de']['slug'] ?? '', $m['para']['slug'] ?? ''));
    $foto = (array) ($m['foto'] ?? array());
    $dono = $sai ? ($m['de']['slug'] ?? '') : ($m['para']['slug'] ?? '');
    $url = esc_url(tsp_mc_jog_url($m['jogador'] ?? '', $dono));
    $h = '<article class="tsp-mc__card tsp-fig tsp-mc--' . $tipo . '" data-blocos="' . esc_attr(implode(' ', (array) ($m['blocos'] ?? array()))) . '" data-clubes="' . esc_attr(implode(' ', $slugs)) . '" data-de="' . esc_attr($m['de']['slug'] ?? '') . '" data-para="' . esc_attr($m['para']['slug'] ?? '') . '" data-tipo="' . esc_attr($m['tipo'] ?? '') . '">';
    $h .= '<div class="tsp-fig__topo"><span class="tsp-fig__esc">' . tsp_mc_escudo($clube, 30) . '</span><span class="tsp-fig__div">' . esc_html(tsp_mc_divisao($m)) . '</span></div>';
    $h .= '<a class="tsp-fig__retrato" href="' . $url . '" tabindex="-1">' . (!empty($foto['url'])
        ? '<img src="' . esc_url($foto['url']) . '" alt="' . esc_attr(($m['jogador'] ?? '') . (!empty($foto['ia']) ? ' (montagem com IA)' : '')) . '" width="200" height="200" loading="lazy" decoding="async" referrerpolicy="no-referrer">'
        : '<span class="tsp-mc__inicial" aria-hidden="true">' . esc_html(mb_strtoupper(mb_substr($m['jogador'] ?? '', 0, 1))) . '</span>') . '</a>';
    $h .= '<h3 class="tsp-fig__nome"><a href="' . $url . '">' . esc_html($m['jogador'] ?? '') . '</a></h3>';
    $h .= '<div class="tsp-fig__info">' . esc_html(($m['posicao'] ?? '') ?: ($com ? 'Comissão técnica' : 'Jogador')) . '</div>';
    // De onde veio → para onde foi (escudos com setinha)
    $lado = function ($c, $vazio) {
        $c = (array) $c;
        if (empty($c['nome'])) {
            return '<span class="tsp-fig__lado tsp-fig__lado--vazio">' . esc_html($vazio) . '</span>';
        }
        $logo = tsp_mc_escudo($c, 18);
        return '<span class="tsp-fig__lado">' . (strpos($logo, '<img') !== false ? $logo : '') . '<span>' . esc_html($c['nome']) . '</span></span>';
    };
    if ($renova) {
        $h .= '<div class="tsp-fig__rota">' . $lado($m['para'], '') . '<b class="tsp-fig__seta">↻</b><span>renovou</span></div>';
    } else {
        $h .= '<div class="tsp-fig__rota">' . $lado($m['de'], $sai ? '' : 'Origem não informada') . '<b class="tsp-fig__seta" aria-label="para">→</b>' . $lado($m['para'], $sai ? 'A definir' : '') . '</div>';
    }
    // Temporada 2026: jogos e gols (comissão técnica não tem números de jogador)
    $n = (array) ($m['numeros'] ?? array());
    if ($com) {
        $h .= '<div class="tsp-fig__num"><small>2027</small> comissão técnica</div>';
    } else {
        $p = array();
        if (!empty($n['jogos'])) {
            $p[] = '<b>' . (int) $n['jogos'] . '</b> ' . ((int) $n['jogos'] === 1 ? 'jogo' : 'jogos');
            $p[] = '<b>' . (int) ($n['gols'] ?? 0) . '</b> ' . ((int) ($n['gols'] ?? 0) === 1 ? 'gol' : 'gols');
        }
        $h .= '<div class="tsp-fig__num"><small>2026</small> ' . ($p ? implode(' · ', $p) : 'números em apuração') . '</div>';
    }
    $h .= tsp_mc_selo_selecao((array) ($m['selos'] ?? array()));
    $h .= '<div class="tsp-fig__pe"><span class="tsp-mc__selo">' . esc_html($m['tipo_nome'] ?? '') . (($m['situacao'] ?? '') === 'acertado' ? ' · <em>acertado</em>' : '') . '</span>'
        . '<time datetime="' . esc_attr($m['data'] ?? '') . '">' . esc_html(wp_date('d/m', strtotime(($m['data'] ?? '') . ' 12:00'))) . '</time></div>';
    return $h . '</article>';
}

function tsp_mc_trilho($itens, $embaralha = false)
{
    $h = '<div class="tsp-mc__caixa"' . ($embaralha ? ' data-embaralha' : '') . '><button type="button" class="tsp-mc__nav tsp-mc__nav--esq" aria-label="Anteriores" data-mc="-1">‹</button>';
    $h .= '<div class="tsp-mc__trilho" tabindex="0">' . implode('', array_map('tsp_mc_card', $itens)) . '</div>';
    $h .= '<button type="button" class="tsp-mc__nav tsp-mc__nav--dir" aria-label="Próximos" data-mc="1">›</button></div>';
    // Aviso de montagem com IA: uma vez só, discreto, no rodapé do bloco
    $ia = array_filter($itens, function ($m) {
        return !empty($m['foto']['ia']);
    });
    return $h . ($ia ? '<p class="tsp-mc__ia">Figurinhas: montagem com IA, ilustrativa, a partir da foto oficial do jogador.</p>' : '');
}

/* ---------- Bloco da home ---------- */
// $bloco: a, b, fem, d1, d2, d3, d4. $parte = true: dentro de uma seção (Série A, entre os 4 grandes e Mirassol/Bragantino)
/* Só vai ao ar quem já tem figurinha; bloco com menos de TSP_MC_MIN figurinhas fica escondido (pedido do Thiago, 14/11/2026). */
const TSP_MC_MIN = 5;

function tsp_mc_tem_foto($m)
{
    return !empty($m['foto']['url']);
}

// Comissão técnica (20/11/2026): treinador, auxiliar, preparador físico e treinador de goleiros
function tsp_mc_funcoes_comissao()
{
    return array('Treinador', 'Auxiliar técnico', 'Preparador físico', 'Treinador de goleiros');
}

function tsp_mc_e_comissao_pos($p)
{
    return in_array((string) $p, tsp_mc_funcoes_comissao(), true);
}

function tsp_mc_e_treinador($m)
{
    return tsp_mc_e_comissao_pos($m['posicao'] ?? '');
}

// Redes sociais da ficha (22/11/2026): só perfis marcados em post oficial do clube ou confirmados em fonte
function tsp_mc_redes($f)
{
    $r = (array) ($f['redes'] ?? array());
    $base = array('instagram' => 'https://www.instagram.com/%s/', 'x' => 'https://x.com/%s', 'tiktok' => 'https://www.tiktok.com/@%s', 'youtube' => 'https://www.youtube.com/@%s', 'facebook' => 'https://www.facebook.com/%s');
    $nomes = array('instagram' => 'Instagram', 'x' => 'X (Twitter)', 'tiktok' => 'TikTok', 'youtube' => 'YouTube', 'facebook' => 'Facebook');
    $out = array();
    foreach ($r as $rede => $u) {
        $u = trim((string) $u, " @/");
        if ($u === '' || !isset($base[$rede])) {
            continue;
        }
        $out[] = array('rede' => $rede, 'nome' => $nomes[$rede], 'user' => $u, 'url' => sprintf($base[$rede], rawurlencode($u)));
    }
    return $out;
}

function tsp_mc_redes_html($f)
{
    return implode(' ', array_map(function ($x) {
        return '<a class="tsp-redes__link tsp-redes--' . esc_attr($x['rede']) . '" href="' . esc_url($x['url']) . '" target="_blank" rel="nofollow noopener">' . esc_html($x['nome']) . ' <b>@' . esc_html($x['user']) . '</b></a>';
    }, tsp_mc_redes($f)));
}

// Ficha técnica do card (20/11/2026): função, idade, natural, no clube, contrato, passagens e títulos, só com o que a fonte trouxe
function tsp_mc_ficha_html($x, $compacto = false, $sem_idade = false)
{
    $f = (array) ($x['ficha'] ?? array());
    $linhas = array();
    $idade = !empty($x['nascimento']) ? tsp_mc_idade($x['nascimento']) : (int) ($f['idade'] ?? 0);
    if ($idade && !$sem_idade) {
        $linhas['Idade'] = $idade . ' anos';
    }
    if (!empty($f['natural'])) {
        $linhas['Natural de'] = $f['natural'];
    }
    if (!empty($f['no_clube'])) {
        $linhas['Trajetória'] = $f['no_clube'];
    }
    if (!empty($f['contrato'])) {
        $linhas['Contrato'] = $f['contrato'];
    }
    if (!empty($f['clubes_anteriores'])) {
        $cl = array_values((array) $f['clubes_anteriores']);
        $linhas['Passagens'] = implode(', ', $compacto ? array_slice($cl, 0, 3) : $cl) . ($compacto && count($cl) > 3 ? ' e outros' : '');
    }
    if (!empty($f['titulos'])) {
        $linhas['Conquistas'] = implode(', ', (array) $f['titulos']);
    }
    if (!$compacto && tsp_mc_redes($f)) {
        $linhas['Redes sociais'] = '';
    }
    if (!$linhas) {
        return '';
    }
    $h = '<dl class="tsp-ficha' . ($compacto ? ' tsp-ficha--mini' : '') . '">';
    foreach ($linhas as $k => $v) {
        $h .= '<div><dt>' . esc_html($k) . '</dt><dd>' . ($k === 'Redes sociais' ? tsp_mc_redes_html($f) : esc_html($v)) . '</dd></div>';
    }
    return $h . '</dl>';
}

// Carrosséis e página do mercado: só jogadores com figurinha (treinadores têm página própria)
function tsp_mc_com_foto()
{
    return array_values(array_filter(tsp_mc_itens(), function ($m) {
        return tsp_mc_tem_foto($m) && !tsp_mc_e_treinador($m);
    }));
}

function tsp_mc_treinadores()
{
    return array_values(array_filter(tsp_mc_itens(), 'tsp_mc_e_treinador'));
}

const TSP_MC_ALBUM = 30; // figurinhas de jogadores por clube no álbum 2027

// Clube que tem álbum 2027 (os clubes paulistas dos blocos da home)
function tsp_mc_clube_do_album($slug)
{
    static $todos = null;
    if ($todos === null) {
        $todos = array();
        if (function_exists('tsp_grupos') && function_exists('tsp_grupo_slugs')) {
            foreach (array_keys(tsp_grupos()) as $k) {
                $todos = array_merge($todos, tsp_grupo_slugs($k));
            }
        }
    }
    return in_array($slug, $todos, true);
}

function tsp_mc_no_ar()
{
    return count(tsp_mc_com_foto()) >= TSP_MC_MIN;
}

// Ordem da home: figurinha publicada mais recente primeiro (foto.em); sem data, vale a data do movimento
function tsp_mc_por_publicacao($a, $b)
{
    $x = ($a['foto']['em'] ?? '') ?: ($a['data'] ?? '');
    $y = ($b['foto']['em'] ?? '') ?: ($b['data'] ?? '');
    return strcmp((string) $y, (string) $x);
}

// 24/11/2026 (Thiago): os últimos apresentados, mas um clube diferente em cada figurinha
// enquanto houver clubes; só repete clube quando faltam equipes. Ordem sorteada na tela.
function tsp_mc_variado($lista, $n)
{
    $esc = array();
    $resto = array();
    $clubes = array();
    foreach ($lista as $m) {
        $c = ($m['para']['slug'] ?? '') ?: ($m['para']['nome'] ?? '');
        if (count($esc) < $n && !isset($clubes[$c])) {
            $clubes[$c] = 1;
            $esc[] = $m;
        } else {
            $resto[] = $m;
        }
    }
    foreach ($resto as $m) {
        if (count($esc) >= $n) {
            break;
        }
        $esc[] = $m;
    }
    shuffle($esc);
    return $esc;
}

function tsp_bloco_mercado($bloco, $titulo, $ancora, &$vistos, $parte = false, $n = 12)
{
    // 23/11/2026 (Thiago): sempre as figurinhas publicadas por último primeiro (data de publicação da figurinha)
    $lista = array();
    foreach (tsp_mc_com_foto() as $m) {
        if (isset($vistos[$m['id']]) || !in_array($bloco, (array) ($m['blocos'] ?? array()), true) || (!empty($m['feminino']) !== ($bloco === 'fem'))) {
            continue;
        }
        $lista[] = $m;
    }
    usort($lista, 'tsp_mc_por_publicacao');
    $lista = tsp_mc_variado($lista, $n);
    if (count($lista) < TSP_MC_MIN) {
        return;
    }
    foreach ($lista as $m) {
        $vistos[$m['id']] = 1;
    }
    $link = home_url('/mercado-da-bola/') . '#' . $bloco;
    if ($parte) {
        echo '<div class="tsp-secao__parte tsp-mc" id="' . esc_attr($ancora) . '"><div class="tsp-mc__cab"><h3>' . esc_html($titulo) . '</h3><a class="tsp-vertudo" href="' . esc_url($link) . '">Mercado completo →</a></div>';
    } else {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-mc" id="' . esc_attr($ancora) . '" aria-labelledby="h-' . esc_attr($ancora) . '">';
        echo '<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="h-' . esc_attr($ancora) . '">' . esc_html($titulo) . '</h2><span class="tsp-secao__sub">Contratações, saídas e renovações para 2027</span></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url($link) . '">Mercado completo →</a></span></div>';
    }
    // 21/11/2026: em cima os jogadores, embaixo a comissão técnica da divisão; mais recentes primeiro (23/11)
    $tec = array();
    foreach (tsp_mc_treinadores() as $m) {
        if (tsp_mc_tem_foto($m) && !isset($vistos[$m['id']]) && in_array($bloco, (array) ($m['blocos'] ?? array()), true) && (!empty($m['feminino']) === ($bloco === 'fem'))) {
            $tec[] = $m;
        }
    }
    usort($tec, 'tsp_mc_por_publicacao');
    $tec = tsp_mc_variado($tec, 12);
    foreach ($tec as $m) {
        $vistos[$m['id']] = 1;
    }
    echo '<h3 class="tsp-mc__linha">Jogadores</h3>';
    echo tsp_mc_trilho($lista); // phpcs:ignore -- HTML já escapado
    if (count($tec) >= 2) {
        echo '<h3 class="tsp-mc__linha">Treinadores e comissão técnica <a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/treinadores/')) . '">Todos →</a></h3>';
        echo tsp_mc_trilho($tec); // phpcs:ignore
    }
    echo $parte ? '</div>' : '</section>';
}

/* ---------- Página do clube: mercado e Elenco 2027 ---------- */

function tsp_mc_do_clube($slug)
{
    return array_values(array_filter(tsp_mc_itens(), function ($m) use ($slug) {
        return in_array($slug, array($m['de']['slug'] ?? '', $m['para']['slug'] ?? ''), true);
    }));
}

function tsp_mc_clube_secoes($termo)
{
    $slug = $termo->slug;
    $mov = tsp_mc_no_ar() ? array_values(array_filter(tsp_mc_do_clube($slug), 'tsp_mc_tem_foto')) : array();
    $h = '';
    if ($mov) {
        $grupos = array('Chegaram' => array(), 'Saíram' => array(), 'Renovaram' => array());
        foreach ($mov as $m) {
            if (($m['tipo'] ?? '') === 'renovacao') {
                $grupos['Renovaram'][] = $m;
            } elseif (($m['para']['slug'] ?? '') === $slug) {
                $grupos['Chegaram'][] = $m;
            } else {
                $grupos['Saíram'][] = $m;
            }
        }
        $h .= '<section class="tsp-secao tsp-secao--caixa tsp-mc" id="mercado" aria-labelledby="tsp-mc-tit"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="tsp-mc-tit">Mercado da bola ' . esc_html(tsp_de($termo)) . '</h2><span class="tsp-secao__sub">Temporada 2027</span></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/')) . '">Todos os clubes →</a></span></div>';
        foreach ($grupos as $rot => $lista) {
            if ($lista) {
                $h .= '<h3 class="tsp-mc__sub">' . esc_html($rot) . ' <small>(' . count($lista) . ')</small></h3>' . tsp_mc_trilho($lista);
            }
        }
        $h .= '</section>';
    }
    $el = tsp_mc_elenco($slug);
    if (empty($el['jogadores']) && tsp_mc_clube_do_album($slug)) {
        $el = array('jogadores' => array(), 'em_montagem' => true, 'atualizado' => '');
    }
    if (!empty($el['jogadores']) || !empty($el['em_montagem'])) {
        $n_jog = count(array_filter($el['jogadores'], function ($x) {
            return !tsp_mc_e_comissao_pos($x['posicao'] ?? '');
        }));
        $n_fig = count(array_filter($el['jogadores'], function ($x) {
            return !tsp_mc_e_comissao_pos($x['posicao'] ?? '') && !empty($x['foto']['url']);
        }));
        $h .= '<section class="tsp-secao tsp-secao--caixa tsp-el" id="elenco" aria-labelledby="tsp-el-tit"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="tsp-el-tit">Elenco ' . esc_html(tsp_de($termo)) . ' 2027</h2><span class="tsp-secao__sub">Álbum 2027: ' . $n_fig . ' de ' . max(TSP_MC_ALBUM, $n_jog) . ' figurinhas reveladas · ' . $n_jog . ' ' . ($n_jog === 1 ? 'jogador anunciado' : 'jogadores anunciados') . (!empty($el['atualizado']) ? ' · atualizado em ' . esc_html(wp_date('d/m/Y', strtotime($el['atualizado']))) : '') . '</span></div></div>';
        $chave = '';
        if (function_exists('tsp_jogos_api_do_slug') && function_exists('tsp_jogos_base_times')) {
            $tid = tsp_jogos_api_do_slug($slug);
            $bt = $tid ? tsp_jogos_base_times() : array();
            $chave = $bt[$tid]['chave'] ?? '';
        }
        $tem_ia = false;
        $ordem_com = array_flip(tsp_mc_funcoes_comissao());
        foreach (array('*' => 'Comissão técnica', 'Goleiro' => 'Goleiros', 'Zagueiro' => 'Zagueiros', 'Lateral' => 'Laterais', 'Volante' => 'Volantes', 'Meia' => 'Meias', 'Atacante' => 'Atacantes', '' => 'Outros') as $pos => $rot) {
            $js = array_filter($el['jogadores'], function ($x) use ($pos) {
                $p = $x['posicao'] ?? '';
                if ($pos === '*') {
                    return tsp_mc_e_comissao_pos($p);
                }
                return $pos === '' ? !tsp_mc_e_comissao_pos($p) && !in_array($p, array('Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meia', 'Atacante'), true) : $p === $pos;
            });
            if (!$js) {
                continue;
            }
            usort($js, function ($a, $b) use ($ordem_com) {
                $ca = $ordem_com[$a['posicao'] ?? ''] ?? 9;
                $cb = $ordem_com[$b['posicao'] ?? ''] ?? 9;
                return $ca <=> $cb ?: (((int) ($a['numero'] ?? 999)) <=> ((int) ($b['numero'] ?? 999)) ?: strcoll($a['nome'], $b['nome']));
            });
            $h .= '<h3 class="tsp-mc__sub">' . esc_html($rot) . '</h3><div class="tsp-el__grade' . ($pos === '*' ? ' tsp-el__grade--com' : '') . '">';
            foreach ($js as $x) {
                $idade = !empty($x['nascimento']) ? (int) floor((time() - strtotime($x['nascimento'])) / (365.25 * DAY_IN_SECONDS)) : 0;
                $url = tsp_mc_jog_url($x['nome'], $slug);
                $tem_ia = $tem_ia || !empty($x['foto']['ia']);
                $h .= $url ? '<a class="tsp-el__jog" href="' . esc_url($url) . '">' : '<div class="tsp-el__jog">';
                // Sem figurinha ainda: espaço "?" do álbum no lugar da inicial
                $h .= !empty($x['foto']['url']) ? tsp_mc_foto($x['nome'], (array) $x['foto'], 96, false) : '<figure class="tsp-mc__foto"><span class="tsp-el__interroga">?</span></figure>';
                $com = tsp_mc_e_comissao_pos($x['posicao'] ?? '');
                $h .= $com ? '<span class="tsp-el__novo tsp-el__novo--tec">' . esc_html($x['posicao']) . '</span>' : '';
                $h .= $com ? '' : (!empty($x['novo']) ? '<span class="tsp-el__novo">Reforço 2027</span>' : (!empty($x['renovou']) ? '<span class="tsp-el__novo tsp-el__novo--fica">Renovou</span>' : ''));
                $h .= '<strong>' . (!empty($x['numero']) ? '<b>' . (int) $x['numero'] . '</b> ' : '') . esc_html($x['nome']) . '</strong>';
                $ficha = tsp_mc_ficha_html($x, !$com);
                $sub = trim(($idade && !$ficha ? $idade . ' anos' : '') . (!empty($x['de']) ? ($idade && !$ficha ? ' · ' : '') . 'veio do ' . $x['de'] : '') . (!empty($x['nacionalidade']) && $x['nacionalidade'] !== 'Brasil' ? ' · ' . $x['nacionalidade'] : ''));
                $h .= $sub ? '<small>' . esc_html($sub) . '</small>' : '';
                $h .= $ficha;
                $h .= tsp_mc_numeros_html((array) ($x['numeros'] ?? array()), true);
                $h .= tsp_mc_selos_html((array) ($x['selos'] ?? array()));
                $h .= $url ? '</a>' : '</div>';
            }
            $h .= '</div>';
        }
        // Espaços vazios do álbum: as figurinhas que ainda vão ser reveladas (novembro e dezembro)
        $vazios = max(0, TSP_MC_ALBUM - $n_jog);
        if ($vazios) {
            $h .= '<h3 class="tsp-mc__sub">A revelar <small>(' . $vazios . ')</small></h3><div class="tsp-el__grade tsp-el__grade--vazio">'
                . str_repeat('<div class="tsp-el__jog tsp-el__vazio" aria-hidden="true"><span class="tsp-el__interroga">?</span><small>Em breve</small></div>', $vazios) . '</div>';
        }
        $h .= $tem_ia ? '<p class="tsp-nota tsp-el__ia">Figurinhas: montagem com IA, ilustrativa, feita a partir da foto oficial de anúncio do jogador.</p>' : '';
        $h .= !empty($el['em_montagem']) ? '<p class="tsp-nota">Elenco 2027 em montagem: reforços e renovações anunciados oficialmente, conferidos pelo TSP. Números de 2026 só quando publicados em fonte aceita.</p></section>' : '';
        $h .= !empty($el['em_montagem']) ? '' : '<p class="tsp-nota">Elenco: site oficial do clube' . (!empty($el['fonte']) ? ' (<a href="' . esc_url($el['fonte']) . '" rel="nofollow noopener" target="_blank">fonte</a>)' : '') . ', somado às chegadas e saídas oficiais do mercado conferidas pelo TSP. As estatísticas de 2027 entram aqui quando a temporada começar.</p></section>';
    }
    return $h;
}

/* ---------- Página /mercado-da-bola/ ---------- */

add_action('init', function () {
    add_rewrite_rule('^mercado-da-bola/treinadores/?$', 'index.php?tsp_mercado=tec', 'top');
    add_rewrite_rule('^mercado-da-bola/?$', 'index.php?tsp_mercado=1', 'top');
    if (get_option('tsp_mc_regras') !== '2') {
        flush_rewrite_rules(false);
        update_option('tsp_mc_regras', '2', true);
    }
    if (!wp_next_scheduled('tsp_mc_atualizar_hora')) {
        wp_schedule_event(time() + 120, 'hourly', 'tsp_mc_atualizar_hora');
    }
});
add_action('tsp_mc_atualizar_hora', function () {
    tsp_mc_baixar('mercado.json');
    tsp_mc_baixar('elencos.json');
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_mercado';
    return $v;
});

function tsp_mc_rotulos()
{
    return array('a' => 'Série A', 'b' => 'Série B', 'fem' => 'Feminino', 'd1' => 'Paulistão A1', 'd2' => 'Paulistão A2', 'd3' => 'Paulistão A3', 'd4' => 'Paulistão A4');
}

add_action('template_redirect', function () {
    if (!get_query_var('tsp_mercado')) {
        return;
    }
    if (get_query_var('tsp_mercado') === 'tec') {
        tsp_mc_pagina_treinadores();
        exit;
    }
    if (!tsp_mc_no_ar()) {
        wp_safe_redirect(home_url('/'), 302);
        exit;
    }
    $itens = tsp_mc_com_foto();
    $d = tsp_mc_arquivo('mercado.json');
    $ult = $itens ? $itens[0]['data'] : '';
    $titulo = 'Mercado da Bola 2027: contratações, saídas e renovações dos clubes paulistas';
    $chegadas = count(array_filter($itens, function ($m) {
        return in_array($m['tipo'] ?? '', array('contratacao', 'emprestimo', 'retorno', 'promovido'), true);
    }));
    $resp = 'O mercado da bola dos clubes paulistas para 2027 tem ' . count($itens) . ' movimentações confirmadas pelo TSP (' . $chegadas . ' chegadas), de Corinthians, Palmeiras, Santos e São Paulo ao Paulistão A4 e ao futebol feminino. Atualizado todos os dias' . ($ult ? '; última movimentação em ' . wp_date('d/m/Y', strtotime($ult . ' 12:00')) : '') . '.';
    foreach (array('pre_get_document_title', 'wpseo_title') as $f) {
        add_filter($f, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($resp) {
        return mb_substr($resp, 0, 155);
    }, 99);
    add_filter('wpseo_canonical', function () {
        return home_url('/mercado-da-bola/');
    }, 99);
    add_filter('wpseo_opengraph_url', function () {
        return home_url('/mercado-da-bola/');
    }, 99);
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    echo '<main class="tsp-container tsp-mcp">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <span>Mercado da Bola</span></nav>';
    echo '<p class="tsp-mcp__tec"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/treinadores/')) . '">Treinadores e comissões técnicas →</a></p>';
    echo '<header class="tsp-mcp__cab"><h1>' . esc_html($titulo) . '</h1><div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div></header>';
    echo '<div class="tsp-mcp__filtros"><span class="tsp-mcp__divs" role="group" aria-label="Filtrar por divisão"><button type="button" class="ativo" data-f="">Todos</button>';
    foreach (tsp_mc_rotulos() as $k => $r) {
        echo '<button type="button" data-f="' . esc_attr($k) . '">' . esc_html($r) . '</button>';
    }
    // Clubes que aparecem no mercado, para o seletor
    $clubes = array();
    foreach ($itens as $m) {
        foreach (array('de', 'para') as $l) {
            if (!empty($m[$l]['slug'])) {
                $t = get_term_by('slug', $m[$l]['slug'], 'times');
                $clubes[$m[$l]['slug']] = $t ? $t->name : $m[$l]['nome'];
            }
        }
    }
    asort($clubes);
    echo '</span><span class="tsp-mcp__tipos" role="group" aria-label="Filtrar por tipo"><button type="button" class="ativo" data-t="">Tudo</button><button type="button" data-t="entrada">Entradas</button><button type="button" data-t="saida">Saídas</button><button type="button" data-t="renovacao">Renovações</button></span>';
    echo '<select class="tsp-mcp__clube" aria-label="Filtrar por clube"><option value="">Todos os clubes</option>';
    foreach ($clubes as $s => $n) {
        echo '<option value="' . esc_attr($s) . '">' . esc_html($n) . '</option>';
    }
    echo '</select></div>';
    if (!$itens) {
        echo '<p class="tsp-vazio">As primeiras movimentações de 2027 entram aqui assim que forem confirmadas.</p>';
    }
    $por_dia = array();
    foreach ($itens as $m) {
        $por_dia[$m['data']][] = $m;
    }
    foreach ($por_dia as $dia => $lista) {
        $hoje = wp_date('Y-m-d');
        $rot = $dia === $hoje ? 'Hoje' : ($dia === wp_date('Y-m-d', time() - DAY_IN_SECONDS) ? 'Ontem' : wp_date('l, d/m/Y', strtotime($dia . ' 12:00')));
        echo '<section class="tsp-mcp__dia"><h2>' . esc_html(ucfirst($rot)) . '</h2><div class="tsp-mcp__grade">' . implode('', array_map('tsp_mc_card', $lista)) . '</div></section>'; // phpcs:ignore
    }
    echo '<p class="tsp-vazio tsp-mcp__nada" style="display:none">Nenhuma movimentação com esses filtros ainda.</p>';
    echo '<p class="tsp-nota">Como apuramos: cada movimentação é conferida em duas fontes (anúncio oficial do clube e imprensa). "Acertado" = negócio fechado segundo a imprensa, ainda sem anúncio oficial. Sondagens e boatos não entram. Figurinhas com o selo \"Montagem com IA\" são ilustrações feitas a partir da foto oficial do jogador.</p>';
    echo '</main>';
    get_footer();
    exit;
});

/* ---------- Comportamento: setas do carrossel e filtros da página ----------
 * Filtros somam: divisão + tipo (entradas, saídas, renovações) + clube. Com um clube escolhido, "entrada" = ele recebe
 * o jogador e "saída" = ele perde o jogador; sem clube, vale para qualquer clube paulista do site. */
add_action('wp_footer', function () {
    echo "<script>(function(){var q=function(s,c){return [].slice.call((c||document).querySelectorAll(s))};"
        . "q('[data-embaralha] .tsp-mc__trilho').forEach(function(t){var k=[].slice.call(t.children);for(var i=k.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var x=k[i];k[i]=k[j];k[j]=x}k.forEach(function(c){t.appendChild(c)})});"
        . "document.addEventListener('click',function(e){var b=e.target.closest('[data-mc]');if(b){var t=b.parentNode.querySelector('.tsp-mc__trilho');t.scrollBy({left:(+b.dataset.mc)*t.clientWidth*.9,behavior:'smooth'});return}"
        . "var f=e.target.closest('.tsp-mcp__divs [data-f],.tsp-mcp__tipos [data-t]');if(f){q('button',f.parentNode).forEach(function(x){x.classList.toggle('ativo',x===f)});aplicar()}});"
        . "var s=document.querySelector('.tsp-mcp__clube');if(!s)return;s.addEventListener('change',function(){var t=document.querySelector('.tsp-mcp__divs [data-f=\\'\\']');if(s.value&&t){q('.tsp-mcp__divs [data-f]').forEach(function(x){x.classList.toggle('ativo',x===t)})}aplicar()});"
        . "function aplicar(){var f=(document.querySelector('.tsp-mcp__divs .ativo')||{dataset:{f:''}}).dataset.f||'',t=(document.querySelector('.tsp-mcp__tipos .ativo')||{dataset:{t:''}}).dataset.t||'',c=s.value;"
        . "q('.tsp-mcp__dia').forEach(function(d){var n=0;q('.tsp-mc__card',d).forEach(function(k){var x=k.dataset,ren=x.tipo==='renovacao',ok=(!f||(' '+x.blocos+' ').indexOf(' '+f+' ')>-1)&&(!c||(' '+x.clubes+' ').indexOf(' '+c+' ')>-1);"
        . "if(ok&&t==='renovacao')ok=ren;if(ok&&t==='entrada')ok=!ren&&(c?x.para===c:!!x.para);if(ok&&t==='saida')ok=!ren&&(c?x.de===c:!!x.de);k.style.display=ok?'':'none';if(ok)n++});d.style.display=n?'':'none'});"
        . "var v=document.querySelector('.tsp-mcp__nada');if(v)v.style.display=q('.tsp-mcp__dia').some(function(d){return d.style.display!=='none'})?'none':''}"
        . "var h=location.hash.replace('#','');if(h){var b=document.querySelector('.tsp-mcp__divs [data-f=\\''+h+'\\']');if(b)b.click()}})();</script>\n";
}, 30);


/* ---------- Página /mercado-da-bola/treinadores/ (15/11/2026) ---------- */

function tsp_mc_pagina_treinadores()
{
    $itens = tsp_mc_treinadores();
    $titulo = 'Treinadores e comissões técnicas 2027: quem chega e quem sai nos clubes paulistas';
    $resp = $itens
        ? count($itens) . ' mudanças em comissões técnicas confirmadas pelo TSP para 2027 nos clubes paulistas, da Série A ao Paulistão A4. Última: '
            . $itens[0]['jogador'] . ' (' . ($itens[0]['para']['nome'] ?: $itens[0]['de']['nome']) . '), em ' . wp_date('d/m/Y', strtotime($itens[0]['data'] . ' 12:00')) . '.'
        : 'As primeiras mudanças de treinador para 2027 entram aqui assim que forem confirmadas.';
    foreach (array('pre_get_document_title', 'wpseo_title') as $f) {
        add_filter($f, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($resp) {
        return mb_substr($resp, 0, 155);
    }, 99);
    add_filter('wpseo_canonical', function () {
        return home_url('/mercado-da-bola/treinadores/');
    }, 99);
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    echo '<main class="tsp-container tsp-mcp tsp-tec">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <a href="' . esc_url(home_url('/mercado-da-bola/')) . '">Mercado da Bola</a> › <span>Treinadores e comissões</span></nav>';
    echo '<header class="tsp-mcp__cab"><h1>' . esc_html($titulo) . '</h1><div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div></header>';
    $por = array();
    foreach ($itens as $m) {
        $b = (array) ($m['blocos'] ?? array());
        $por[$b ? $b[0] : 'x'][] = $m;
    }
    foreach (array_merge(tsp_mc_rotulos(), array('x' => 'Outros')) as $k => $rot) {
        if (empty($por[$k])) {
            continue;
        }
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($rot) . '</h2></div></div><ul class="tsp-tec__lista">';
        foreach ($por[$k] as $m) {
            $sai = in_array($m['tipo'] ?? '', array('saida', 'venda'), true);
            $clube = $sai ? (array) $m['de'] : (array) $m['para'];
            $t = !empty($clube['slug']) ? get_term_by('slug', $clube['slug'], 'times') : null;
            $rota = ($m['tipo'] ?? '') === 'renovacao' ? 'Renovou' : ($sai ? ('Deixou o ' . ($m['de']['nome'] ?? 'clube') . (!empty($m['para']['nome']) ? ' · vai para o ' . $m['para']['nome'] : '')) : (!empty($m['de']['nome']) ? 'Veio do ' . $m['de']['nome'] : 'Chegou ao clube'));
            echo '<li class="tsp-tec__item">'
                . '<span class="tsp-tec__esc">' . tsp_mc_escudo($clube, 40) . '</span>'
                . '<span class="tsp-tec__txt"><a href="' . esc_url(tsp_mc_jog_url($m['jogador'], $clube['slug'] ?? '')) . '"><strong>' . esc_html($m['jogador']) . '</strong></a>'
                . '<span>' . esc_html(($m['posicao'] ?? 'Treinador') . ' · ' . ($t ? $t->name : ($clube['nome'] ?? '')) . ' · ' . $rota) . '</span>'
                . (!empty($m['obs']) ? '<small>' . esc_html($m['obs']) . '</small>' : '') . tsp_mc_ficha_html($m) . '</span>'
                . '<span class="tsp-tec__pe"><b>' . esc_html($m['tipo_nome'] ?? '') . '</b><time datetime="' . esc_attr($m['data']) . '">' . esc_html(wp_date('d/m/Y', strtotime($m['data'] . ' 12:00'))) . '</time></span>'
                . '</li>';
        }
        echo '</ul></section>';
    }
    echo '<p class="tsp-nota">Como apuramos: só treinador anunciado oficialmente pelo clube ou com acerto confirmado pela imprensa, conferido em fonte aceita. Sondagens não entram.</p>';
    echo '</main>';
    get_footer();
}
