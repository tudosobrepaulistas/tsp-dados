<?php
/**
 * TSP Exclusiva (19/11/2026, pedido do Thiago): entrevistas exclusivas do canal do TSP no YouTube.
 *  - Home: área premium (player no estilo Spotify) depois das coletivas da Série A: episódio mais novo, resumo e cortes clicáveis.
 *  - /tsp-exclusiva/: catálogo com filtros (clube, tipo de entrevistado, ano, busca).
 *  - /tsp-exclusiva/<n>-<nome>/: página de cada episódio, com o mesmo player e os cortes.
 *  - Dados: dados/exclusiva.json no tsp-dados (catálogo e destaque) + RSS do canal (episódios novos entram sozinhos).
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_EXCL_JSON', 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/dados/exclusiva.json');

function tsp_exclusiva_dados()
{
    static $memo = null;
    if ($memo !== null) {
        return $memo;
    }
    $d = get_transient('tsp_excl_dados_' . TSP_VERSAO);
    if (!is_array($d)) {
        $d = get_option('tsp_excl_ultimo', array());
        $r = wp_remote_get(TSP_EXCL_JSON, array('timeout' => 8));
        if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
            $j = json_decode(wp_remote_retrieve_body($r), true);
            if (!empty($j['episodios'])) {
                $d = $j;
                update_option('tsp_excl_ultimo', $d, false);
            }
        }
        set_transient('tsp_excl_dados_' . TSP_VERSAO, $d, HOUR_IN_SECONDS);
    }
    $eps = array();
    foreach ((array) ($d['episodios'] ?? array()) as $e) {
        if (!empty($e['id']) && !empty($e['n'])) {
            $eps[(int) $e['n']] = $e;
        }
    }
    // Episódios novos pelo RSS do canal (título com "Exclusiva" e "#número")
    foreach (tsp_exclusiva_rss($d['canal'] ?? '') as $e) {
        if (!isset($eps[$e['n']])) {
            $eps[$e['n']] = $e;
        }
    }
    krsort($eps);
    $memo = array('eps' => array_values($eps), 'destaque' => $d['destaque'] ?? array(), 'canal_url' => $d['canal_url'] ?? 'https://www.youtube.com/@TudoSobrePaulista');
    return $memo;
}

function tsp_exclusiva_rss($canal)
{
    if (!$canal) {
        return array();
    }
    $c = get_transient('tsp_excl_rss');
    if (is_array($c)) {
        return $c;
    }
    $c = array();
    $r = wp_remote_get('https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode($canal), array('timeout' => 8));
    if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
        $xml = wp_remote_retrieve_body($r);
        if (preg_match_all('#<entry>(.*?)</entry>#s', $xml, $m)) {
            foreach ($m[1] as $ent) {
                if (!preg_match('#<yt:videoId>([\w-]{11})</yt:videoId>#', $ent, $id) || !preg_match('#<title>(.*?)</title>#s', $ent, $ti)) {
                    continue;
                }
                $t = html_entity_decode($ti[1], ENT_QUOTES, 'UTF-8');
                if (stripos($t, 'exclusiva') === false || !preg_match('/#\s*0*(\d+)/', $t, $n)) {
                    continue;
                }
                preg_match('#<published>(\d{4}-\d{2}-\d{2})#', $ent, $p);
                $tl = tsp_exclusiva_limpa($t);
                $c[] = array('n' => (int) $n[1], 'id' => $id[1], 'data' => $p[1] ?? '', 'titulo' => $tl, 'nome' => trim(preg_split('/\s+[–|-]\s+/u', $tl)[0]), 'clube' => '', 'tipo' => tsp_exclusiva_tipo_de($t), 'base' => (bool) preg_match('/\bsub|copinha/iu', $t));
            }
        }
    }
    set_transient('tsp_excl_rss', $c, 3 * HOUR_IN_SECONDS);
    return $c;
}

// "TSP EXCLUSIVA | Episódio #173 – Fulano..." / "#172 - FULANO - TSP EXCLUSIVA #tag" → "Fulano..."
function tsp_exclusiva_limpa($t)
{
    $t = preg_replace('/#[^\s\d][^\s]*/u', '', $t);
    $t = preg_replace('/^\s*TSP EXCLUSIVA\s*\|\s*Epis[oó]dio\s*#?\s*\d+\s*[–-]\s*/iu', '', $t);
    $t = preg_replace('/^\s*#?\s*\d+\s*[-–]?\s*/u', '', $t);
    $t = preg_replace('/[-|–]?\s*(TSP EXCLUSIVA|EXCLUSIVA TSP)\s*$/iu', '', trim($t));
    $t = trim(preg_replace('/\s+/u', ' ', $t), " -|–_");
    if (mb_strtoupper($t) === $t) {
        $t = mb_convert_case(mb_strtolower($t), MB_CASE_TITLE, 'UTF-8');
    }
    return preg_replace('/\s+-\s+/u', ' – ', $t);
}

function tsp_exclusiva_thumb($id, $tam = 'hqdefault')
{
    return 'https://i.ytimg.com/vi/' . rawurlencode($id) . '/' . $tam . '.jpg';
}

function tsp_exclusiva_link($id)
{
    return 'https://www.youtube.com/watch?v=' . rawurlencode($id);
}

function tsp_exclusiva_data($ymd)
{
    $t = strtotime($ymd . ' 12:00');
    return $t ? date_i18n('d/m/Y', $t) : '';
}

function tsp_exclusiva_url()
{
    return home_url('/tsp-exclusiva/');
}

// Selo "TSP Exclusiva"
function tsp_exclusiva_selo()
{
    return '<span class="tsp-excl__selo"><b>TSP</b> Exclusiva</span>';
}

function tsp_exclusiva_tipo_de($t)
{
    $t = remove_accents(mb_strtolower($t));
    if (preg_match('/\b(presidente|diretor|gerente|supervisor|coordenador|assessor|fisioterapeuta|fisiologista|preparador|analista|auxiliar|mentor)\b/', $t)) {
        return 'staff';
    }
    return preg_match('/\b(tecnico|tec|mister|treinador)\b/', $t) ? 'tecnico' : 'jogador';
}

function tsp_exclusiva_tipos()
{
    return array('jogador' => 'Jogadores', 'tecnico' => 'Técnicos', 'staff' => 'Dirigentes e comissão');
}

function tsp_exclusiva_papel($e)
{
    $m = array('jogador' => 'Jogador', 'tecnico' => 'Técnico', 'staff' => 'Dirigente / comissão técnica');
    return $m[$e['tipo'] ?? ''] ?? '';
}

function tsp_exclusiva_seg($mmss)
{
    $s = 0;
    foreach (array_map('intval', explode(':', (string) $mmss)) as $x) {
        $s = $s * 60 + $x;
    }
    return $s;
}

function tsp_exclusiva_data_longa($ymd)
{
    $t = strtotime($ymd . ' 12:00');
    return $t ? date_i18n('j \d\e F \d\e Y', $t) : '';
}

function tsp_exclusiva_ep_url($e)
{
    return home_url('/tsp-exclusiva/' . (int) $e['n'] . '-' . sanitize_title($e['nome'] ?? $e['titulo']) . '/');
}

function tsp_exclusiva_por_n($n)
{
    foreach (tsp_exclusiva_dados()['eps'] as $e) {
        if ((int) $e['n'] === (int) $n) {
            return $e;
        }
    }
    return null;
}

function tsp_exclusiva_termo($e)
{
    return !empty($e['clube']) ? get_term_by('slug', $e['clube'], 'times') : null;
}

/* ---------- Player (home e página do episódio) ---------- */
function tsp_exclusiva_player($e, $novo = false)
{
    $d = tsp_exclusiva_dados();
    $dest = $d['destaque'];
    $eh_dest = !empty($dest['n']) && (int) $dest['n'] === (int) $e['n'];
    $term = tsp_exclusiva_termo($e);
    $papel = $eh_dest && !empty($dest['papel']) ? $dest['papel'] : trim(tsp_exclusiva_papel($e) . ($term ? ' · ' . $term->name : ''));
    $meta = array('Episódio #' . (int) $e['n'], tsp_exclusiva_data_longa($e['data']));
    if (!empty($e['duracao'])) {
        $p = array_map('intval', explode(':', $e['duracao']));
        $meta[] = (count($p) === 3 ? $p[0] * 60 + $p[1] : $p[0]) . ' min';
    }
    $id = esc_attr($e['id']);
    $h = '<div class="tsp-excl__player" data-excl-id="' . $id . '">';
    $h .= '<div class="tsp-excl__capa"><button type="button" class="tsp-excl__capa-btn" data-excl-play="0" aria-label="Assistir ao episódio #' . (int) $e['n'] . '">';
    $h .= '<img src="' . esc_url(tsp_exclusiva_thumb($e['id'], 'maxresdefault')) . '" alt="' . esc_attr('TSP Exclusiva #' . $e['n'] . ': ' . $e['titulo']) . '" width="1280" height="720" loading="lazy" decoding="async" onerror="this.onerror=null;this.src=\'' . esc_url(tsp_exclusiva_thumb($e['id'])) . '\'">';
    $h .= '<span class="tsp-excl__play-grande" aria-hidden="true"></span></button></div>';
    $h .= '<div class="tsp-excl__info">';
    if ($novo) {
        $h .= '<span class="tsp-excl__novo">Novo episódio</span>';
    }
    $h .= '<p class="tsp-excl__meta">' . esc_html(implode(' · ', array_filter($meta))) . '</p>';
    $h .= $novo ? '<h3 class="tsp-excl__tit"><a href="' . esc_url(tsp_exclusiva_ep_url($e)) . '">' . esc_html($e['titulo']) . '</a></h3>' : '<h1 class="tsp-excl__tit">' . esc_html($e['titulo']) . '</h1>';
    if (!empty($e['resumo'])) {
        $h .= '<p class="tsp-excl__resumo">' . esc_html($e['resumo']) . '</p>';
    }
    $h .= '</div><div class="tsp-excl__lado">';
    $h .= '<div class="tsp-excl__conv">';
    if ($term && function_exists('tsp_escudo')) {
        $h .= '<a class="tsp-excl__escudo" href="' . esc_url(get_term_link($term)) . '" title="' . esc_attr($term->name) . '">' . tsp_escudo($term, 48) . '</a>';
    }
    $h .= '<span><b>' . esc_html($e['nome'] ?? '') . '</b>' . ($papel ? '<br>' . esc_html($papel) : '') . (!empty($e['entrevistador']) ? '<br><small>Entrevista: ' . esc_html($e['entrevistador']) . '</small>' : '') . '</span></div>';
    $h .= '<div class="tsp-excl__acoes"><button type="button" class="tsp-excl__play" data-excl-play="0"><span aria-hidden="true"></span>Assistir episódio</button>';
    if ($novo) {
        $h .= '<a class="tsp-excl__ler" href="' . esc_url(tsp_exclusiva_ep_url($e)) . '">Página do episódio</a>';
    }
    if (!empty($e['materia'])) {
        $h .= '<a class="tsp-excl__ler" href="' . esc_url($e['materia']) . '">Ler a matéria</a>';
    }
    $h .= '</div></div>';
    if (!empty($e['topicos'])) {
        $h .= '<div class="tsp-excl__cortes"><div class="tsp-excl__cortes-cab"><h4>Cortes do episódio</h4><p><span class="tsp-excl__dica" aria-hidden="true"></span>Clique em um corte e o vídeo começa direto naquele trecho.</p></div><ol>';
        foreach ($e['topicos'] as $tp) {
            $h .= '<li><button type="button" class="tsp-excl__corte" data-excl-play="' . (int) tsp_exclusiva_seg($tp[0]) . '"><span class="tsp-excl__cplay" aria-hidden="true"></span><span class="tsp-excl__t">' . esc_html($tp[0]) . '</span><span class="tsp-excl__a">' . esc_html($tp[1]) . '</span><span class="tsp-excl__ver">Assistir</span></button></li>';
        }
        $h .= '</ol></div>';
    }
    $h .= '</div>';
    return $h . tsp_exclusiva_js();
}

function tsp_exclusiva_js()
{
    static $feito = false;
    if ($feito) {
        return '';
    }
    $feito = true;
    return '<script>(function(){document.addEventListener("click",function(ev){var b=ev.target.closest("[data-excl-play]");if(!b)return;var pl=b.closest(".tsp-excl__player"),c=pl&&pl.querySelector(".tsp-excl__capa");if(!c)return;ev.preventDefault();var id=pl.getAttribute("data-excl-id"),t=parseInt(b.getAttribute("data-excl-play"),10)||0;c.innerHTML=\'<iframe src="https://www.youtube.com/embed/\'+id+\'?autoplay=1&rel=0&start=\'+t+\'" title="TSP Exclusiva" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>\';pl.querySelectorAll(".tsp-excl__corte.is-ativo").forEach(function(x){x.classList.remove("is-ativo")});if(b.classList.contains("tsp-excl__corte"))b.classList.add("is-ativo");var r=c.getBoundingClientRect();if(r.top<0||r.bottom>innerHeight)c.scrollIntoView({behavior:"smooth",block:"center"});});})();</script>';
}

function tsp_exclusiva_cor($e)
{
    $d = tsp_exclusiva_dados();
    $dest = $d['destaque'];
    if (!empty($dest['n']) && (int) $dest['n'] === (int) $e['n'] && !empty($dest['cor']) && preg_match('/^#[0-9a-f]{6}$/i', $dest['cor'])) {
        return $dest['cor'];
    }
    if (!empty($e['cor']) && preg_match('/^#[0-9a-f]{6}$/i', $e['cor'])) {
        return $e['cor'];
    }
    return '#5a3415';
}

function tsp_exclusiva_mini($a)
{
    return '<li><a href="' . esc_url(tsp_exclusiva_ep_url($a)) . '"><span class="tsp-excl__ln">#' . (int) $a['n'] . '</span><img src="' . esc_url(tsp_exclusiva_thumb($a['id'], 'mqdefault')) . '" alt="" width="160" height="90" loading="lazy" decoding="async"><span class="tsp-excl__lt"><b>' . esc_html($a['titulo']) . '</b><small>' . esc_html(tsp_exclusiva_data($a['data'])) . '</small></span></a></li>';
}

/* ---------- Bloco da home ---------- */
function tsp_bloco_exclusiva()
{
    $eps = tsp_exclusiva_dados()['eps'];
    if (!$eps) {
        return;
    }
    $e = $eps[0];
    echo '<section class="tsp-excl" id="tsp-exclusiva" aria-labelledby="h-excl" style="--excl-cor:' . esc_attr(tsp_exclusiva_cor($e)) . '">';
    echo '<div class="tsp-excl__topo"><div class="tsp-excl__marca"><span class="tsp-excl__ondas" aria-hidden="true"><i></i><i></i><i></i><i></i></span><h2 id="h-excl">TSP Exclusiva</h2><span class="tsp-excl__slogan">Entrevistas exclusivas do futebol paulista</span></div>';
    echo '<a class="tsp-excl__todos" href="' . esc_url(tsp_exclusiva_url()) . '">Todos os ' . count($eps) . ' episódios →</a></div>';
    echo tsp_exclusiva_player($e, true); // phpcs:ignore
    $ant = array_slice($eps, 1, 4);
    if ($ant) {
        echo '<div class="tsp-excl__lista"><h4>Episódios anteriores</h4><ol>';
        foreach ($ant as $a) {
            echo tsp_exclusiva_mini($a); // phpcs:ignore
        }
        echo '</ol></div>';
    }
    echo '</section>';
}

/* ---------- Ficha técnica (estilo catálogo do Spotify: os "gêneros" são os clubes) ---------- */
function tsp_exclusiva_divisao($slug)
{
    if (!$slug || !function_exists('tsp_grupos')) {
        return array('', '');
    }
    foreach (tsp_grupos() as $k => $g) {
        if (!empty($g['divisao'][$slug])) {
            return array($g['titulo'] ?? '', $g['link'] ?? '');
        }
    }
    foreach (array('a4' => array('Brasileirão Série A', '/campeonato/brasileiro-serie-a/'), 'mb' => array('Brasileirão Série A', '/campeonato/brasileiro-serie-a/'), 'fem' => array('Futebol Feminino', '/campeonato/brasileirao-feminino/')) as $k => $r) {
        if (function_exists('tsp_grupo_slugs') && in_array($slug, tsp_grupo_slugs($k), true)) {
            return $r;
        }
    }
    return array('', '');
}

function tsp_exclusiva_ficha($e)
{
    $term = tsp_exclusiva_termo($e);
    list($div, $div_link) = tsp_exclusiva_divisao($e['clube'] ?? '');
    $lin = array(
        'Programa' => 'TSP Exclusiva',
        'Episódio' => '#' . (int) $e['n'],
        'Publicado em' => tsp_exclusiva_data_longa($e['data']),
        'Duração' => !empty($e['duracao']) ? $e['duracao'] : '',
        'Convidado' => $e['nome'] ?? '',
        'Função' => !empty($e['funcao']) ? $e['funcao'] : tsp_exclusiva_papel($e),
        'Clube' => $term ? '<a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a>' : '',
        'Divisão' => $div ? ($div_link ? '<a href="' . esc_url(home_url($div_link)) . '">' . esc_html($div) . '</a>' : esc_html($div)) : '',
        'Entrevista' => $e['entrevistador'] ?? '',
        'Cortes' => !empty($e['topicos']) ? count($e['topicos']) . ' trechos' : '',
        'Assista também em' => '<a href="' . esc_url(tsp_exclusiva_link($e['id'])) . '" target="_blank" rel="noopener">YouTube</a>',
    );
    $h = '<div class="tsp-excl__ficha"><h2>Ficha técnica</h2><dl>';
    foreach ($lin as $k => $v) {
        if ($v === '') {
            continue;
        }
        $html = in_array($k, array('Clube', 'Divisão', 'Assista também em'), true) ? $v : esc_html($v);
        $h .= '<div><dt>' . esc_html($k) . '</dt><dd>' . $html . '</dd></div>';
    }
    $h .= '</dl><div class="tsp-excl__generos"><h3>Gêneros</h3><div class="tsp-excl__chips">';
    $url = tsp_exclusiva_url();
    if ($term) {
        $h .= '<a href="' . esc_url(add_query_arg('clube', $term->slug, $url)) . '">' . (function_exists('tsp_escudo') ? tsp_escudo($term, 24) : '') . esc_html($term->name) . '</a>';
    }
    if ($div) {
        $h .= '<a class="sem-esc" href="' . esc_url(home_url($div_link)) . '">' . esc_html($div) . '</a>';
    }
    $tipos = tsp_exclusiva_tipos();
    if (!empty($tipos[$e['tipo'] ?? ''])) {
        $h .= '<a class="sem-esc" href="' . esc_url(add_query_arg('tipo', $e['tipo'], $url)) . '">' . esc_html($tipos[$e['tipo']]) . '</a>';
    }
    if (!empty($e['base'])) {
        $h .= '<a class="sem-esc" href="' . esc_url(add_query_arg('tipo', 'base', $url)) . '">Base e Copinha</a>';
    }
    $h .= '<a class="sem-esc" href="' . esc_url(add_query_arg('ano', substr($e['data'], 0, 4), $url)) . '">' . esc_html(substr($e['data'], 0, 4)) . '</a>';
    $h .= '</div><p>O TSP Exclusiva é a série de entrevistas do Tudo Sobre Paulista com jogadores, técnicos e dirigentes dos clubes paulistas, da Série A à base. Toque em um gênero para ver outros episódios do mesmo clube, divisão ou tipo de entrevistado.</p>';
    return $h . '</div></div>';
}

/* ---------- Página de cada episódio: /tsp-exclusiva/173-danilo-sacramento/ ---------- */
add_action('init', function () {
    add_rewrite_rule('^tsp-exclusiva/(\d+)(?:-[^/]*)?/?$', 'index.php?pagename=tsp-exclusiva&tsp_ep=$matches[1]', 'top');
    if (get_option('tsp_excl_rw') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_excl_rw', '1', false);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_ep';
    return $v;
});
function tsp_exclusiva_ep_atual()
{
    $n = (int) get_query_var('tsp_ep');
    return $n ? tsp_exclusiva_por_n($n) : null;
}
add_action('template_redirect', function () {
    if (!get_query_var('tsp_ep')) {
        return;
    }
    $e = tsp_exclusiva_ep_atual();
    if (!$e) {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        return;
    }
    // endereço canônico com o nome
    $certo = tsp_exclusiva_ep_url($e);
    $pedido = home_url(add_query_arg(array()));
    if (untrailingslashit(strtok($pedido, '?')) !== untrailingslashit($certo)) {
        wp_safe_redirect($certo, 301);
        exit;
    }
}, 5);
add_filter('redirect_canonical', function ($r) {
    return get_query_var('tsp_ep') ? false : $r;
});
function tsp_exclusiva_titulo_seo($e)
{
    return 'TSP Exclusiva #' . $e['n'] . ': ' . $e['titulo'] . ' | TSP';
}
function tsp_exclusiva_desc_seo($e)
{
    return !empty($e['resumo']) ? $e['resumo'] : 'Entrevista exclusiva do TSP com ' . ($e['nome'] ?? '') . ' (episódio #' . $e['n'] . ', ' . tsp_exclusiva_data($e['data']) . '). Assista no Tudo Sobre Paulista.';
}
add_filter('wpseo_title', function ($t) {
    $e = tsp_exclusiva_ep_atual();
    if ($e) {
        return tsp_exclusiva_titulo_seo($e);
    }
    return is_page('tsp-exclusiva') ? 'TSP Exclusiva: todas as entrevistas do futebol paulista | TSP' : $t;
});
add_filter('pre_get_document_title', function ($t) {
    $e = tsp_exclusiva_ep_atual();
    return $e ? tsp_exclusiva_titulo_seo($e) : $t;
}, 20);
add_filter('wpseo_metadesc', function ($t) {
    $e = tsp_exclusiva_ep_atual();
    if ($e) {
        return tsp_exclusiva_desc_seo($e);
    }
    if (!is_page('tsp-exclusiva')) {
        return $t;
    }
    return 'Todos os ' . count(tsp_exclusiva_dados()['eps']) . ' episódios do TSP Exclusiva: entrevistas com jogadores, técnicos e dirigentes dos clubes paulistas. Filtre por clube, ano e tipo de entrevistado.';
});
add_filter('wpseo_canonical', function ($c) {
    $e = tsp_exclusiva_ep_atual();
    return $e ? tsp_exclusiva_ep_url($e) : $c;
});
add_filter('wpseo_opengraph_url', function ($c) {
    $e = tsp_exclusiva_ep_atual();
    return $e ? tsp_exclusiva_ep_url($e) : $c;
});
add_filter('wpseo_opengraph_title', function ($t) {
    $e = tsp_exclusiva_ep_atual();
    return $e ? tsp_exclusiva_titulo_seo($e) : $t;
});
add_filter('wpseo_opengraph_desc', function ($t) {
    $e = tsp_exclusiva_ep_atual();
    return $e ? tsp_exclusiva_desc_seo($e) : $t;
});
add_filter('wpseo_opengraph_image', function ($i) {
    $e = tsp_exclusiva_ep_atual();
    return $e ? tsp_exclusiva_thumb($e['id'], 'maxresdefault') : $i;
});

function tsp_exclusiva_pagina_ep($e)
{
    $eps = tsp_exclusiva_dados()['eps'];
    echo '<section class="tsp-excl tsp-excl--pagina" style="--excl-cor:' . esc_attr(tsp_exclusiva_cor($e)) . '">';
    echo '<div class="tsp-excl__topo"><div class="tsp-excl__marca"><span class="tsp-excl__ondas" aria-hidden="true"><i></i><i></i><i></i><i></i></span><span class="tsp-excl__marca-t">TSP Exclusiva</span></div><a class="tsp-excl__todos" href="' . esc_url(tsp_exclusiva_url()) . '">← Todos os episódios</a></div>';
    echo tsp_exclusiva_player($e, false); // phpcs:ignore
    // Mais episódios: primeiro do mesmo clube, depois os mais recentes
    $mais = array();
    foreach ($eps as $a) {
        if ((int) $a['n'] !== (int) $e['n'] && !empty($e['clube']) && ($a['clube'] ?? '') === $e['clube']) {
            $mais[] = $a;
        }
    }
    foreach ($eps as $a) {
        if (count($mais) >= 8) {
            break;
        }
        if ((int) $a['n'] !== (int) $e['n'] && !in_array($a, $mais, true)) {
            $mais[] = $a;
        }
    }
    echo tsp_exclusiva_ficha($e); // phpcs:ignore
    if (!empty($e['perguntas'])) {
        echo '<div class="tsp-excl__faq"><h2>Perguntas e respostas</h2>';
        foreach ($e['perguntas'] as $qa) {
            echo '<details><summary>' . esc_html($qa[0]) . '</summary><p>' . esc_html($qa[1]) . '</p></details>';
        }
        echo '</div>';
    }
    echo '<div class="tsp-excl__lista"><h4>Mais episódios</h4><ol>';
    foreach (array_slice($mais, 0, 8) as $a) {
        echo tsp_exclusiva_mini($a); // phpcs:ignore
    }
    echo '</ol></div></section>';
    $dur = '';
    if (!empty($e['duracao'])) {
        $p = array_map('intval', explode(':', $e['duracao']));
        $dur = count($p) === 3 ? sprintf('PT%dH%dM%dS', $p[0], $p[1], $p[2]) : sprintf('PT%dM%dS', $p[0], $p[1] ?? 0);
    }
    $ld = array('@context' => 'https://schema.org', '@type' => 'VideoObject', 'name' => 'TSP Exclusiva #' . $e['n'] . ': ' . $e['titulo'], 'description' => tsp_exclusiva_desc_seo($e), 'thumbnailUrl' => array(tsp_exclusiva_thumb($e['id'], 'maxresdefault'), tsp_exclusiva_thumb($e['id'])), 'uploadDate' => $e['data'] . 'T12:00:00-03:00', 'embedUrl' => 'https://www.youtube.com/embed/' . $e['id'], 'url' => tsp_exclusiva_ep_url($e), 'publisher' => array('@type' => 'Organization', 'name' => 'Tudo Sobre Paulista'));
    if ($dur) {
        $ld['duration'] = $dur;
    }
    if (!empty($e['topicos'])) {
        $ld['hasPart'] = array();
        foreach ($e['topicos'] as $tp) {
            $ld['hasPart'][] = array('@type' => 'Clip', 'name' => $tp[1], 'startOffset' => tsp_exclusiva_seg($tp[0]), 'url' => tsp_exclusiva_link($e['id']) . '&t=' . tsp_exclusiva_seg($tp[0]));
        }
    }
    echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    if (!empty($e['perguntas'])) {
        $faq = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array());
        foreach ($e['perguntas'] as $qa) {
            $faq['mainEntity'][] = array('@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $qa[1]));
        }
        echo '<script type="application/ld+json">' . wp_json_encode($faq, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    }
}

/* ---------- Página do catálogo ---------- */

// Cria a página /tsp-exclusiva/ uma vez (o tema usa page-tsp-exclusiva.php)
add_action('admin_init', function () {
    if (get_option('tsp_excl_pagina')) {
        return;
    }
    $p = get_page_by_path('tsp-exclusiva');
    if (!$p) {
        $id = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'TSP Exclusiva', 'post_name' => 'tsp-exclusiva', 'post_content' => '', 'post_excerpt' => 'Todas as entrevistas exclusivas do TSP com jogadores, técnicos e dirigentes do futebol paulista.'));
        if ($id && !is_wp_error($id)) {
            update_option('tsp_excl_pagina', $id, false);
        }
    } else {
        update_option('tsp_excl_pagina', $p->ID, false);
    }
});

// Menu: "TSP Exclusiva" no menu principal; sem Série B fora de temporada
add_filter('wp_nav_menu_items', function ($itens, $args) {
    if (($args->theme_location ?? '') !== 'principal') {
        return $itens;
    }
    if (function_exists('tsp_serie_b_ativa') && !tsp_serie_b_ativa()) {
        $itens = preg_replace('#<li[^>]*>\s*<a[^>]*>\s*S[ée]rie B\s*</a>.*?</li>#isu', '', $itens);
    }
    if (strpos($itens, 'tsp-exclusiva') === false) {
        $itens .= '<li class="menu-item tsp-nav__excl' . (is_page('tsp-exclusiva') ? ' current-menu-item' : '') . '"><a href="' . esc_url(tsp_exclusiva_url()) . '">TSP Exclusiva</a></li>';
    }
    return $itens;
}, 10, 2);

function tsp_exclusiva_catalogo()
{
    $eps = tsp_exclusiva_dados()['eps'];
    if (!$eps) {
        echo '<p>Os episódios aparecem aqui em instantes.</p>';
        return;
    }
    $clubes = array();
    $anos = array();
    foreach ($eps as $e) {
        if (!empty($e['clube']) && !isset($clubes[$e['clube']])) {
            $t = get_term_by('slug', $e['clube'], 'times');
            $clubes[$e['clube']] = $t ? $t->name : $e['clube'];
        }
        $anos[substr($e['data'], 0, 4)] = true;
    }
    asort($clubes);
    krsort($anos);
    echo '<div class="tsp-excl-cat">';
    echo '<div class="tsp-excl-cat__filtros" role="search">';
    echo '<label class="tsp-excl-cat__campo tsp-excl-cat__campo--busca"><span>Buscar</span><input id="tsp-excl-busca" type="search" placeholder="Nome, clube ou nº do episódio"></label>';
    echo '<label class="tsp-excl-cat__campo"><span>Clube</span><select id="tsp-excl-clube"><option value="">Todos os clubes</option>';
    foreach ($clubes as $s => $n) {
        echo '<option value="' . esc_attr($s) . '">' . esc_html($n) . '</option>';
    }
    echo '</select></label><label class="tsp-excl-cat__campo"><span>Ano</span><select id="tsp-excl-ano"><option value="">Todos</option>';
    foreach (array_keys($anos) as $a) {
        echo '<option value="' . esc_attr($a) . '">' . esc_html($a) . '</option>';
    }
    echo '</select></label></div>';
    echo '<div class="tsp-excl-cat__chips" role="group" aria-label="Quem foi entrevistado"><button type="button" class="is-on" data-tipo="">Todos</button>';
    foreach (tsp_exclusiva_tipos() as $k => $r) {
        echo '<button type="button" data-tipo="' . esc_attr($k) . '">' . esc_html($r) . '</button>';
    }
    echo '<button type="button" data-tipo="base">Base e Copinha</button></div>';
    echo '<p class="tsp-excl-cat__conta" aria-live="polite"><b id="tsp-excl-n">' . count($eps) . '</b> episódios</p>';
    echo '<ol class="tsp-excl-cat__lista">';
    $lista = array();
    $pos = 1;
    foreach ($eps as $e) {
        $t = tsp_exclusiva_termo($e);
        $busca = remove_accents(mb_strtolower('#' . $e['n'] . ' ' . $e['titulo'] . ' ' . ($t ? $t->name : '')));
        echo '<li class="tsp-excl-cat__item" data-b="' . esc_attr($busca) . '" data-clube="' . esc_attr($e['clube'] ?? '') . '" data-ano="' . esc_attr(substr($e['data'], 0, 4)) . '" data-tipo="' . esc_attr($e['tipo'] ?? '') . '" data-base="' . (!empty($e['base']) ? '1' : '') . '"><a href="' . esc_url(tsp_exclusiva_ep_url($e)) . '">';
        echo '<span class="tsp-excl-cat__foto"><img src="' . esc_url(tsp_exclusiva_thumb($e['id'], 'mqdefault')) . '" alt="" width="320" height="180" loading="lazy" decoding="async"></span>';
        echo '<span class="tsp-excl-cat__txt"><span class="tsp-excl-cat__n">' . esc_html(tsp_exclusiva_data($e['data'])) . (tsp_exclusiva_papel($e) ? ' · ' . esc_html(tsp_exclusiva_papel($e)) : '') . '</span>';
        echo '<span class="tsp-excl-cat__t">' . esc_html($e['titulo']) . '</span>';
        if ($t && function_exists('tsp_escudo')) {
            echo '<span class="tsp-excl-cat__clube">' . tsp_escudo($t, 18) . esc_html($t->name) . '</span>'; // phpcs:ignore
        }
        echo '</span></a></li>';
        $lista[] = array('@type' => 'ListItem', 'position' => $pos++, 'url' => tsp_exclusiva_ep_url($e), 'name' => 'TSP Exclusiva #' . $e['n'] . ': ' . $e['titulo']);
    }
    echo '</ol><p class="tsp-excl-cat__nada" hidden>Nenhum episódio com esses filtros.</p></div>';
    echo '<script>(function(){var q=document.getElementById("tsp-excl-busca"),cl=document.getElementById("tsp-excl-clube"),an=document.getElementById("tsp-excl-ano"),ch=document.querySelectorAll(".tsp-excl-cat__chips button"),it=document.querySelectorAll(".tsp-excl-cat__item"),nd=document.querySelector(".tsp-excl-cat__nada"),nn=document.getElementById("tsp-excl-n"),tp="";function f(){var s=q.value.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").trim(),c=cl.value,a=an.value,v=0;it.forEach(function(li){var ok=(!s||li.dataset.b.indexOf(s)>-1)&&(!c||li.dataset.clube===c)&&(!a||li.dataset.ano===a)&&(!tp||(tp==="base"?li.dataset.base==="1":li.dataset.tipo===tp));li.hidden=!ok;if(ok)v++;});nn.textContent=v;nd.hidden=v>0;}q.addEventListener("input",f);cl.addEventListener("change",f);an.addEventListener("change",f);ch.forEach(function(b){b.addEventListener("click",function(){ch.forEach(function(x){x.classList.remove("is-on")});b.classList.add("is-on");tp=b.dataset.tipo;f();});});var u=new URLSearchParams(location.search);if(u.get("clube"))cl.value=u.get("clube");if(u.get("ano"))an.value=u.get("ano");if(u.get("tipo")){tp=u.get("tipo");ch.forEach(function(x){x.classList.toggle("is-on",x.dataset.tipo===tp)});}if(u.get("clube")||u.get("ano")||u.get("tipo")){f();var L=document.querySelector(".tsp-excl-cat");if(L)L.scrollIntoView();}})();</script>';
    echo '<script type="application/ld+json">' . wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'TSP Exclusiva', 'numberOfItems' => count($lista), 'itemListElement' => $lista), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
}
