<?php
/**
 * Arte do TSP para matéria da Máquina sem foto segura: 1200x675, cores do clube, escudo, título e marca do TSP.
 * Crédito: "Arte: Tudo Sobre Paulista". Assim a matéria sai sozinha no horário (sem esperar um redator).
 * Fonte: Poppins Bold (licença SIL Open Font).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_maq_cor($hex, $padrao = array(17, 17, 17))
{
    $h = ltrim((string) $hex, '#');
    if (strlen($h) === 3) {
        $h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
    }
    return strlen($h) === 6 ? array(hexdec(substr($h, 0, 2)), hexdec(substr($h, 2, 2)), hexdec(substr($h, 4, 2))) : $padrao;
}

// Imagem (GD) a partir de um endereço do próprio site ou de fora
function tsp_maq_gd_de_url($url)
{
    if (!$url) {
        return null;
    }
    $up = wp_get_upload_dir();
    $arq = '';
    if (strpos($url, $up['baseurl']) === 0) {
        $arq = $up['basedir'] . substr($url, strlen($up['baseurl']));
    } elseif (strpos($url, content_url()) === 0) {
        $arq = WP_CONTENT_DIR . substr($url, strlen(content_url()));
    }
    $tmp = '';
    if (!$arq || !file_exists($arq)) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $tmp = download_url($url, 20);
        if (is_wp_error($tmp)) {
            return null;
        }
        $arq = $tmp;
    }
    $bin = @file_get_contents($arq);
    if ($tmp) {
        @unlink($tmp);
    }
    $im = $bin ? @imagecreatefromstring($bin) : false;
    return $im ?: null;
}

function tsp_maq_quebrar($texto, $fonte, $tam, $largura)
{
    $linhas = array();
    $atual = '';
    foreach (preg_split('~\s+~u', trim($texto)) as $p) {
        $teste = $atual === '' ? $p : $atual . ' ' . $p;
        $b = imagettfbbox($tam, 0, $fonte, $teste);
        if (($b[2] - $b[0]) > $largura && $atual !== '') {
            $linhas[] = $atual;
            $atual = $p;
        } else {
            $atual = $teste;
        }
    }
    if ($atual !== '') {
        $linhas[] = $atual;
    }
    return $linhas;
}

function tsp_maq_arte($post_id, $titulo, $clube_slug)
{
    if (!function_exists('imagecreatetruecolor') || !function_exists('imagettftext')) {
        return 0;
    }
    $fonte = __DIR__ . '/../assets/Poppins-Bold.ttf';
    $W = 1200;
    $H = 675;
    $im = imagecreatetruecolor($W, $H);
    imagesavealpha($im, true);
    $termo = $clube_slug ? get_term_by('slug', $clube_slug, 'times') : null;
    $cores = ($termo && function_exists('tsp_clube_cores')) ? tsp_clube_cores($termo) : array('#111111', '#FFFFFF');
    $c1 = tsp_maq_cor($cores[0] ?? '#111111');
    // Fundo: cor do clube escurecendo para preto (da esquerda para a direita)
    for ($x = 0; $x < $W; $x++) {
        $f = min(1, $x / $W * 1.35);
        $r = (int) ($c1[0] * (1 - $f) + 14 * $f);
        $g = (int) ($c1[1] * (1 - $f) + 14 * $f);
        $b = (int) ($c1[2] * (1 - $f) + 14 * $f);
        imageline($im, $x, 0, $x, $H, imagecolorallocate($im, $r, $g, $b));
    }
    $laranja = imagecolorallocate($im, 232, 134, 42);
    $branco = imagecolorallocate($im, 255, 255, 255);
    $cinza = imagecolorallocate($im, 210, 210, 210);
    imagefilledrectangle($im, 0, $H - 10, $W, $H, $laranja);
    // Escudo do clube num círculo claro à esquerda
    $cx = 230;
    $cy = 300;
    imagefilledellipse($im, $cx, $cy, 330, 330, imagecolorallocatealpha($im, 255, 255, 255, 20));
    $esc = ($termo && function_exists('tsp_escudo_url')) ? tsp_maq_gd_de_url(tsp_escudo_url($termo)) : null;
    if ($esc) {
        $ew = imagesx($esc);
        $eh = imagesy($esc);
        $esc_tam = 230;
        $k = min($esc_tam / max(1, $ew), $esc_tam / max(1, $eh));
        $nw = (int) ($ew * $k);
        $nh = (int) ($eh * $k);
        imagecopyresampled($im, $esc, (int) ($cx - $nw / 2), (int) ($cy - $nh / 2), 0, 0, $nw, $nh, $ew, $eh);
        imagedestroy($esc);
    } elseif ($termo) {
        $sigla = mb_strtoupper(mb_substr(remove_accents($termo->name), 0, 3));
        $b = imagettfbbox(70, 0, $fonte, $sigla);
        imagettftext($im, 70, 0, (int) ($cx - ($b[2] - $b[0]) / 2), $cy + 25, imagecolorallocate($im, 30, 30, 30), $fonte, $sigla);
    }
    // Chapéu (nome do clube) e título
    $x0 = 450;
    $larg = $W - $x0 - 60;
    if ($termo) {
        imagettftext($im, 22, 0, $x0, 130, $laranja, $fonte, mb_strtoupper($termo->name));
    }
    $tam = 46;
    do {
        $linhas = tsp_maq_quebrar($titulo, $fonte, $tam, $larg);
        $tam -= 3;
    } while (count($linhas) > 5 && $tam > 26);
    $tam += 3;
    $y = 190 + $tam;
    foreach (array_slice($linhas, 0, 5) as $l) {
        imagettftext($im, $tam, 0, $x0, $y, $branco, $fonte, $l);
        $y += (int) ($tam * 1.35);
    }
    // Marca do TSP
    $logo = @imagecreatefrompng(__DIR__ . '/../assets/logo-tsp.png');
    if ($logo) {
        $lw = imagesx($logo);
        $lh = imagesy($logo);
        $nh = 70;
        $nw = (int) ($lw * $nh / $lh);
        imagecopyresampled($im, $logo, 60, $H - 105, 0, 0, $nw, $nh, $lw, $lh);
        imagedestroy($logo);
    }
    imagettftext($im, 18, 0, $x0, $H - 52, $cinza, $fonte, 'tudosobrepaulista.com.br');
    // Grava e manda para a biblioteca de mídia
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $tmp = wp_tempnam('tsp-arte') . '.jpg';
    imagejpeg($im, $tmp, 88);
    imagedestroy($im);
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $credito = 'Arte: Tudo Sobre Paulista';
    $aid = media_handle_sideload(array('name' => sanitize_title(wp_trim_words($titulo, 10, '')) . '-arte-tsp.jpg', 'tmp_name' => $tmp), $post_id, $titulo, array('post_excerpt' => $credito));
    if (is_wp_error($aid)) {
        @unlink($tmp);
        return 0;
    }
    update_post_meta($aid, '_wp_attachment_image_alt', mb_substr('Arte do TSP: ' . $titulo, 0, 150));
    update_post_meta($aid, 'tsp_credito', $credito);
    set_post_thumbnail($post_id, $aid);
    if (function_exists('tsp_maq_acf')) {
        tsp_maq_acf($post_id, array('Crédito da imagem', 'Credito da imagem', 'Crédito da foto', 'Credito da foto'), $credito);
    }
    update_post_meta($post_id, 'tsp_maq_arte', 1);
    return (int) $aid;
}

// Rascunhos "sem foto" da Máquina (últimos 3 dias): ganham a arte e saem no horário deles.
// Os que já passaram do horário saem espaçados (um a cada 30 minutos), para não soltar tudo de uma vez.
function tsp_maq_liberar_rascunhos($max = 10)
{
    $ps = get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => 'draft', 'numberposts' => $max, 'meta_key' => 'tsp_maq_status', 'meta_value' => 'sem_foto',
        'date_query' => array(array('after' => '3 days ago')), 'orderby' => 'date', 'order' => 'ASC'));
    $n = 0;
    $proximo = time() + 60;
    foreach ($ps as $p) {
        if (get_post_thumbnail_id($p->ID)) {
            $aid = get_post_thumbnail_id($p->ID); // redator já pôs foto: só libera
        } else {
            $aid = tsp_maq_arte($p->ID, $p->post_title, (string) get_post_meta($p->ID, 'tsp_maq_clube', true));
        }
        if (!$aid) {
            continue;
        }
        $h = get_post_meta($p->ID, 'tsp_maq_horario', true);
        $ts = $h ? strtotime($h . ' UTC') : time();
        if ($ts <= time() + 60) {
            $ts = $proximo;
            $proximo += 30 * MINUTE_IN_SECONDS;
        }
        $futuro = $ts > time() + 30;
        update_post_meta($p->ID, 'tsp_maq_status', $futuro ? 'agendada' : 'publicada');
        wp_update_post(array(
            'ID'            => $p->ID,
            'post_status'   => $futuro ? 'future' : 'publish',
            'post_date'     => $futuro ? wp_date('Y-m-d H:i:s', $ts) : current_time('mysql'),
            'post_date_gmt' => $futuro ? gmdate('Y-m-d H:i:s', $ts) : current_time('mysql', true),
            'edit_date'     => true,
        ));
        $n++;
    }
    if ($n) {
        do_action('litespeed_purge_all');
    }
    return $n;
}
