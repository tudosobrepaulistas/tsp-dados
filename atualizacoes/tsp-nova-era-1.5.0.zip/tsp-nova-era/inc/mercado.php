<?php
/**
 * Mercado da Bola 2027 (14/11/2026): quem chega, quem sai e quem renova nos clubes paulistas.
 * Dados: base própria do TSP no GitHub (api/mercado.json e api/elencos.json), conferidos em 2 fontes.
 *  - Home: um carrossel por bloco (Série A, Série B, Feminino, Paulistão A1 a A4). Um movimento não se repete em dois blocos.
 *  - Página /mercado-da-bola/: tudo, com filtro por bloco e por clube.
 *  - Página do clube: "Mercado da bola" (chegadas, saídas e renovações) e "Elenco 2027" com foto.
 * Sem foto oficial com crédito, o card mostra a inicial do jogador (nada de imagem inventada).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_MC_BASE = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/';

/* ---------- Leitura dos arquivos (guardados no site; renovados a cada 30 minutos, sem travar a página) ---------- */

function tsp_mc_baixar($arq)
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 300), TSP_MC_BASE . $arq), array('timeout' => 8));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return null;
    }
    $d = json_decode(wp_remote_retrieve_body($r), true);
    if (!is_array($d)) {
        return null;
    }
    update_option('tsp_mc_' . sanitize_key(str_replace('.json', '', $arq)), array('t' => time(), 'd' => $d), false);
    return $d;
}

function tsp_mc_arquivo($arq)
{
    static $cache = array();
    if (isset($cache[$arq])) {
        return $cache[$arq];
    }
    $o = get_option('tsp_mc_' . sanitize_key(str_replace('.json', '', $arq)));
    if (!is_array($o) || !isset($o['d'])) {
        $d = tsp_mc_baixar($arq); // primeira vez: busca na hora
        return $cache[$arq] = is_array($d) ? $d : array();
    }
    if (time() - (int) $o['t'] > 1800 && !wp_next_scheduled('tsp_mc_atualizar')) {
        wp_schedule_single_event(time() + 5, 'tsp_mc_atualizar');
    }
    return $cache[$arq] = $o['d'];
}

add_action('tsp_mc_atualizar', function () {
    tsp_mc_baixar('mercado.json');
    tsp_mc_baixar('elencos.json');
});

function tsp_mc_itens()
{
    $d = tsp_mc_arquivo('mercado.json');
    return isset($d['itens']) && is_array($d['itens']) ? $d['itens'] : array();
}

function tsp_mc_elenco($slug)
{
    $d = tsp_mc_arquivo('elencos.json');
    return isset($d['clubes'][$slug]) && is_array($d['clubes'][$slug]) ? $d['clubes'][$slug] : array();
}

/* ---------- Peças ---------- */

function tsp_mc_clube_html($c)
{
    $nome = (string) ($c['nome'] ?? '');
    $t = !empty($c['slug']) ? get_term_by('slug', $c['slug'], 'times') : null;
    if ($t) {
        return '<a class="tsp-mc__clube" href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 26) . '<span>' . esc_html($nome) . '</span></a>';
    }
    return '<span class="tsp-mc__clube">' . tsp_ge_escudo((int) ($c['id'] ?? 0), $nome, 26) . '<span>' . esc_html($nome) . '</span></span>';
}

function tsp_mc_foto($nome, $foto, $tam = 84)
{
    if (!empty($foto['url'])) {
        return '<figure class="tsp-mc__foto"><img src="' . esc_url($foto['url']) . '" alt="' . esc_attr($nome) . '" width="' . (int) $tam . '" height="' . (int) $tam . '" loading="lazy" decoding="async" referrerpolicy="no-referrer">'
            . (!empty($foto['credito']) ? '<figcaption>Foto: ' . esc_html($foto['credito']) . '</figcaption>' : '') . '</figure>';
    }
    return '<figure class="tsp-mc__foto"><span class="tsp-mc__inicial" aria-hidden="true">' . esc_html(mb_strtoupper(mb_substr($nome, 0, 1))) . '</span></figure>';
}

function tsp_mc_card($m)
{
    $tipo = sanitize_html_class($m['tipo'] ?? '');
    $renova = ($m['tipo'] ?? '') === 'renovacao';
    $slugs = array_filter(array($m['de']['slug'] ?? '', $m['para']['slug'] ?? ''));
    $h = '<article class="tsp-mc__card tsp-mc--' . $tipo . '" data-blocos="' . esc_attr(implode(' ', (array) ($m['blocos'] ?? array()))) . '" data-clubes="' . esc_attr(implode(' ', $slugs)) . '">';
    $h .= tsp_mc_foto($m['jogador'] ?? '', (array) ($m['foto'] ?? array()));
    $h .= '<span class="tsp-mc__selo">' . esc_html($m['tipo_nome'] ?? '') . (($m['situacao'] ?? '') === 'acertado' ? ' · <em>acertado</em>' : '') . '</span>';
    $h .= '<h3 class="tsp-mc__nome">' . esc_html($m['jogador'] ?? '') . '</h3>';
    if (!empty($m['posicao'])) {
        $h .= '<span class="tsp-mc__pos">' . esc_html($m['posicao']) . '</span>';
    }
    if ($renova || empty($m['de']['nome'])) {
        $h .= '<div class="tsp-mc__rota tsp-mc__rota--fica">' . tsp_mc_clube_html((array) $m['para']) . '</div>';
    } else {
        $h .= '<div class="tsp-mc__rota">' . tsp_mc_clube_html((array) $m['de']) . '<span class="tsp-mc__seta" aria-label="para">→</span>' . tsp_mc_clube_html((array) $m['para']) . '</div>';
    }
    if (!empty($m['obs'])) {
        $h .= '<p class="tsp-mc__obs">' . esc_html($m['obs']) . '</p>';
    }
    $h .= '<time class="tsp-mc__data" datetime="' . esc_attr($m['data'] ?? '') . '">' . esc_html(wp_date('d/m', strtotime(($m['data'] ?? '') . ' 12:00'))) . '</time>';
    return $h . '</article>';
}

function tsp_mc_trilho($itens)
{
    $h = '<div class="tsp-mc__caixa"><button type="button" class="tsp-mc__nav tsp-mc__nav--esq" aria-label="Anteriores" data-mc="-1">‹</button>';
    $h .= '<div class="tsp-mc__trilho" tabindex="0">' . implode('', array_map('tsp_mc_card', $itens)) . '</div>';
    return $h . '<button type="button" class="tsp-mc__nav tsp-mc__nav--dir" aria-label="Próximos" data-mc="1">›</button></div>';
}

/* ---------- Bloco da home ---------- */
// $bloco: a, b, fem, d1, d2, d3, d4. $parte = true: dentro de uma seção (Série A, entre os 4 grandes e Mirassol/Bragantino)
function tsp_bloco_mercado($bloco, $titulo, $ancora, &$vistos, $parte = false, $n = 12)
{
    // Alterna os clubes (o mais recente de cada um primeiro) para um clube só não tomar o carrossel inteiro
    $fila = array();
    foreach (tsp_mc_itens() as $m) {
        if (isset($vistos[$m['id']]) || !in_array($bloco, (array) ($m['blocos'] ?? array()), true) || (!empty($m['feminino']) !== ($bloco === 'fem'))) {
            continue;
        }
        $fila[($m['para']['slug'] ?? '') ?: ($m['de']['slug'] ?? '')][] = $m;
    }
    $lista = array();
    while (count($lista) < $n && $fila) {
        foreach ($fila as $k => &$ms) {
            if (count($lista) >= $n) {
                break;
            }
            $m = array_shift($ms);
            $vistos[$m['id']] = 1;
            $lista[] = $m;
            if (!$ms) {
                unset($fila[$k]);
            }
        }
        unset($ms);
    }
    if (!$lista) {
        return;
    }
    $link = home_url('/mercado-da-bola/') . '#' . $bloco;
    if ($parte) {
        echo '<div class="tsp-secao__parte tsp-mc" id="' . esc_attr($ancora) . '"><div class="tsp-mc__cab"><h3>' . esc_html($titulo) . '</h3><a class="tsp-vertudo" href="' . esc_url($link) . '">Mercado completo →</a></div>';
    } else {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-mc" id="' . esc_attr($ancora) . '" aria-labelledby="h-' . esc_attr($ancora) . '">';
        echo '<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="h-' . esc_attr($ancora) . '">' . esc_html($titulo) . '</h2><span class="tsp-secao__sub">Contratações, saídas e renovações para 2027</span></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url($link) . '">Mercado completo →</a></span></div>';
    }
    echo tsp_mc_trilho($lista); // phpcs:ignore -- HTML já escapado
    echo $parte ? '</div>' : '</section>';
}

/* ---------- Página do clube: mercado e Elenco 2027 ---------- */

function tsp_mc_do_clube($slug)
{
    return array_values(array_filter(tsp_mc_itens(), function ($m) use ($slug) {
        return in_array($slug, array($m['de']['slug'] ?? '', $m['para']['slug'] ?? ''), true);
    }));
}

function tsp_mc_clube_secoes($termo)
{
    $slug = $termo->slug;
    $mov = tsp_mc_do_clube($slug);
    $h = '';
    if ($mov) {
        $grupos = array('Chegaram' => array(), 'Saíram' => array(), 'Renovaram' => array());
        foreach ($mov as $m) {
            if (($m['tipo'] ?? '') === 'renovacao') {
                $grupos['Renovaram'][] = $m;
            } elseif (($m['para']['slug'] ?? '') === $slug) {
                $grupos['Chegaram'][] = $m;
            } else {
                $grupos['Saíram'][] = $m;
            }
        }
        $h .= '<section class="tsp-secao tsp-secao--caixa tsp-mc" id="mercado" aria-labelledby="tsp-mc-tit"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="tsp-mc-tit">Mercado da bola ' . esc_html(tsp_de($termo)) . '</h2><span class="tsp-secao__sub">Temporada 2027</span></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/')) . '">Todos os clubes →</a></span></div>';
        foreach ($grupos as $rot => $lista) {
            if ($lista) {
                $h .= '<h3 class="tsp-mc__sub">' . esc_html($rot) . ' <small>(' . count($lista) . ')</small></h3>' . tsp_mc_trilho($lista);
            }
        }
        $h .= '</section>';
    }
    $el = tsp_mc_elenco($slug);
    if (!empty($el['jogadores'])) {
        $h .= '<section class="tsp-secao tsp-secao--caixa tsp-el" id="elenco" aria-labelledby="tsp-el-tit"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="tsp-el-tit">Elenco ' . esc_html(tsp_de($termo)) . ' 2027</h2><span class="tsp-secao__sub">' . count($el['jogadores']) . ' jogadores · atualizado em ' . esc_html(wp_date('d/m/Y', strtotime($el['atualizado'] ?: 'now'))) . '</span></div></div>';
        $chave = '';
        if (function_exists('tsp_jogos_api_do_slug') && function_exists('tsp_jogos_base_times')) {
            $tid = tsp_jogos_api_do_slug($slug);
            $bt = $tid ? tsp_jogos_base_times() : array();
            $chave = $bt[$tid]['chave'] ?? '';
        }
        foreach (array('Goleiro' => 'Goleiros', 'Zagueiro' => 'Zagueiros', 'Lateral' => 'Laterais', 'Volante' => 'Volantes', 'Meia' => 'Meias', 'Atacante' => 'Atacantes', '' => 'Outros') as $pos => $rot) {
            $js = array_filter($el['jogadores'], function ($x) use ($pos) {
                $p = $x['posicao'] ?? '';
                return $pos === '' ? !in_array($p, array('Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meia', 'Atacante'), true) : $p === $pos;
            });
            if (!$js) {
                continue;
            }
            usort($js, function ($a, $b) {
                return ((int) ($a['numero'] ?? 999)) <=> ((int) ($b['numero'] ?? 999)) ?: strcoll($a['nome'], $b['nome']);
            });
            $h .= '<h3 class="tsp-mc__sub">' . esc_html($rot) . '</h3><div class="tsp-el__grade">';
            foreach ($js as $x) {
                $idade = !empty($x['nascimento']) ? (int) floor((time() - strtotime($x['nascimento'])) / (365.25 * DAY_IN_SECONDS)) : 0;
                $url = ($chave && empty($x['novo']) && function_exists('tsp_tf_jog_url')) ? tsp_tf_jog_url($chave, $x['nome']) : '';
                $h .= $url ? '<a class="tsp-el__jog" href="' . esc_url($url) . '">' : '<div class="tsp-el__jog">';
                $h .= tsp_mc_foto($x['nome'], (array) ($x['foto'] ?? array()), 96);
                $h .= !empty($x['novo']) ? '<span class="tsp-el__novo">Reforço 2027</span>' : '';
                $h .= '<strong>' . (!empty($x['numero']) ? '<b>' . (int) $x['numero'] . '</b> ' : '') . esc_html($x['nome']) . '</strong>';
                $sub = trim(($idade ? $idade . ' anos' : '') . (!empty($x['nacionalidade']) && $x['nacionalidade'] !== 'Brasil' ? ' · ' . $x['nacionalidade'] : ''));
                $h .= $sub ? '<small>' . esc_html($sub) . '</small>' : '';
                $h .= $url ? '</a>' : '</div>';
            }
            $h .= '</div>';
        }
        $h .= '<p class="tsp-nota">Elenco: site oficial do clube' . (!empty($el['fonte']) ? ' (<a href="' . esc_url($el['fonte']) . '" rel="nofollow noopener" target="_blank">fonte</a>)' : '') . ', somado às chegadas e saídas oficiais do mercado conferidas pelo TSP. As estatísticas de 2027 entram aqui quando a temporada começar.</p></section>';
    }
    return $h;
}

/* ---------- Página /mercado-da-bola/ ---------- */

add_action('init', function () {
    add_rewrite_rule('^mercado-da-bola/?$', 'index.php?tsp_mercado=1', 'top');
    if (get_option('tsp_mc_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_mc_regras', '1', true);
    }
    if (!wp_next_scheduled('tsp_mc_atualizar_hora')) {
        wp_schedule_event(time() + 120, 'hourly', 'tsp_mc_atualizar_hora');
    }
});
add_action('tsp_mc_atualizar_hora', function () {
    tsp_mc_baixar('mercado.json');
    tsp_mc_baixar('elencos.json');
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_mercado';
    return $v;
});

function tsp_mc_rotulos()
{
    return array('a' => 'Série A', 'b' => 'Série B', 'fem' => 'Feminino', 'd1' => 'Paulistão A1', 'd2' => 'Paulistão A2', 'd3' => 'Paulistão A3', 'd4' => 'Paulistão A4');
}

add_action('template_redirect', function () {
    if (!get_query_var('tsp_mercado')) {
        return;
    }
    $itens = tsp_mc_itens();
    $d = tsp_mc_arquivo('mercado.json');
    $ult = $itens ? $itens[0]['data'] : '';
    $titulo = 'Mercado da Bola 2027: contratações, saídas e renovações dos clubes paulistas';
    $chegadas = count(array_filter($itens, function ($m) {
        return in_array($m['tipo'] ?? '', array('contratacao', 'emprestimo', 'retorno', 'promovido'), true);
    }));
    $resp = 'O mercado da bola dos clubes paulistas para 2027 tem ' . count($itens) . ' movimentações confirmadas pelo TSP (' . $chegadas . ' chegadas), de Corinthians, Palmeiras, Santos e São Paulo ao Paulistão A4 e ao futebol feminino. Atualizado todos os dias' . ($ult ? '; última movimentação em ' . wp_date('d/m/Y', strtotime($ult . ' 12:00')) : '') . '.';
    foreach (array('pre_get_document_title', 'wpseo_title') as $f) {
        add_filter($f, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($resp) {
        return mb_substr($resp, 0, 155);
    }, 99);
    add_filter('wpseo_canonical', function () {
        return home_url('/mercado-da-bola/');
    }, 99);
    add_filter('wpseo_opengraph_url', function () {
        return home_url('/mercado-da-bola/');
    }, 99);
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    echo '<main class="tsp-container tsp-mcp">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <span>Mercado da Bola</span></nav>';
    echo '<header class="tsp-mcp__cab"><h1>' . esc_html($titulo) . '</h1><div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div></header>';
    echo '<div class="tsp-mcp__filtros" role="group" aria-label="Filtrar por divisão"><button type="button" class="ativo" data-f="">Todos</button>';
    foreach (tsp_mc_rotulos() as $k => $r) {
        echo '<button type="button" data-f="' . esc_attr($k) . '">' . esc_html($r) . '</button>';
    }
    // Clubes que aparecem no mercado, para o seletor
    $clubes = array();
    foreach ($itens as $m) {
        foreach (array('de', 'para') as $l) {
            if (!empty($m[$l]['slug'])) {
                $t = get_term_by('slug', $m[$l]['slug'], 'times');
                $clubes[$m[$l]['slug']] = $t ? $t->name : $m[$l]['nome'];
            }
        }
    }
    asort($clubes);
    echo '<select class="tsp-mcp__clube" aria-label="Filtrar por clube"><option value="">Todos os clubes</option>';
    foreach ($clubes as $s => $n) {
        echo '<option value="' . esc_attr($s) . '">' . esc_html($n) . '</option>';
    }
    echo '</select></div>';
    if (!$itens) {
        echo '<p class="tsp-vazio">As primeiras movimentações de 2027 entram aqui assim que forem confirmadas.</p>';
    }
    $por_dia = array();
    foreach ($itens as $m) {
        $por_dia[$m['data']][] = $m;
    }
    foreach ($por_dia as $dia => $lista) {
        $hoje = wp_date('Y-m-d');
        $rot = $dia === $hoje ? 'Hoje' : ($dia === wp_date('Y-m-d', time() - DAY_IN_SECONDS) ? 'Ontem' : wp_date('l, d/m/Y', strtotime($dia . ' 12:00')));
        echo '<section class="tsp-mcp__dia"><h2>' . esc_html(ucfirst($rot)) . '</h2><div class="tsp-mcp__grade">' . implode('', array_map('tsp_mc_card', $lista)) . '</div></section>'; // phpcs:ignore
    }
    echo '<p class="tsp-nota">Como apuramos: cada movimentação é conferida em duas fontes (anúncio oficial do clube e imprensa). "Acertado" = negócio fechado segundo a imprensa, ainda sem anúncio oficial. Sondagens e boatos não entram. Fotos: sites oficiais dos clubes, com crédito.</p>';
    echo '</main>';
    get_footer();
    exit;
});

/* ---------- Comportamento: setas do carrossel e filtros da página ---------- */
add_action('wp_footer', function () {
    echo "<script>(function(){document.addEventListener('click',function(e){var b=e.target.closest('[data-mc]');if(b){var t=b.parentNode.querySelector('.tsp-mc__trilho');t.scrollBy({left:(+b.dataset.mc)*t.clientWidth*.9,behavior:'smooth'});return}"
        . "var f=e.target.closest('.tsp-mcp__filtros button');if(f){document.querySelectorAll('.tsp-mcp__filtros button').forEach(function(x){x.classList.toggle('ativo',x===f)});aplicar()}});"
        . "var s=document.querySelector('.tsp-mcp__clube');if(!s)return;s.addEventListener('change',aplicar);"
        . "function aplicar(){var f=(document.querySelector('.tsp-mcp__filtros .ativo')||{}).dataset;f=f?f.f:'';var c=s.value;document.querySelectorAll('.tsp-mcp__dia').forEach(function(d){var n=0;d.querySelectorAll('.tsp-mc__card').forEach(function(k){var ok=(!f||(' '+k.dataset.blocos+' ').indexOf(' '+f+' ')>-1)&&(!c||(' '+k.dataset.clubes+' ').indexOf(' '+c+' ')>-1);k.hidden=!ok;if(ok)n++});d.hidden=!n})}"
        . "var h=location.hash.replace('#','');if(h){var b=document.querySelector('.tsp-mcp__filtros [data-f=\"'+h+'\"]');if(b)b.click()}})();</script>\n";
}, 30);
