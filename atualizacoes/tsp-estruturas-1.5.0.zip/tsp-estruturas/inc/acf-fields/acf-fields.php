<?php

add_action('acf/include_fields', function () {
    if (! function_exists('acf_add_local_field_group')) {
        return;
    }

    include 'materia.php';
    include 'time.php';
    include 'aposta.php';
    include 'banner.php';
    include 'campeonato.php';
    include 'config-site.php';
    include 'bloco-apostas.php';
    include 'bloco-campeonatos.php';
    include 'bloco-home.php';
});
