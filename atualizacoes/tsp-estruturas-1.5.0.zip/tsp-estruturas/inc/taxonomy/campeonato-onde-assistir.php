<?php

add_action('init', function () {
    register_taxonomy('onde-assistir-campeonato', array(
        0 => 'onde-assistir',
    ), array(
        'labels' => array(
            'name' => 'Campeonato',
            'singular_name' => 'Campeonato',
            'menu_name' => 'Campeonato',
            'all_items' => 'Todos Onde Assistir',
            'edit_item' => 'Editar Onde Assistir',
            'view_item' => 'Ver Onde Assistir',
            'update_item' => 'Atualizar Onde Assistir',
            'add_new_item' => 'Adicionar novo Onde Assistir',
            'new_item_name' => 'Novo nome de Onde Assistir',
            'parent_item' => 'Onde Assistir ascendente',
            'parent_item_colon' => 'Onde Assistir ascendente:',
            'search_items' => 'Pesquisar Onde Assistir',
            'not_found' => 'Não foi possível encontrar onde assistir',
            'no_terms' => 'Não há onde assistir',
            'filter_by_item' => 'Filtrar por onde assistir',
            'items_list_navigation' => 'Navegação na lista de Onde Assistir',
            'items_list' => 'Lista de Onde Assistir',
            'back_to_items' => '← Ir para onde assistir',
            'item_link' => 'Link de Onde Assistir',
            'item_link_description' => 'Um link para um onde assistir',
        ),
        'public' => true,
        'hierarchical' => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
    ));
});
