<?php

add_action('init', function () {
    register_taxonomy('serie', array(
        0 => 'materia',
    ), array(
        'labels' => array(
            'name' => 'Series',
            'singular_name' => 'Serie',
            'menu_name' => 'Series',
            'all_items' => 'Todos os Series',
            'edit_item' => 'Editar Serie',
            'view_item' => 'Ver Serie',
            'update_item' => 'Atualizar Serie',
            'add_new_item' => 'Adicionar novo Serie',
            'new_item_name' => 'Novo nome de Serie',
            'search_items' => 'Pesquisar Series',
            'popular_items' => 'Series populares',
            'separate_items_with_commas' => 'Separe series com vírgulas',
            'add_or_remove_items' => 'Adicionar ou remover series',
            'choose_from_most_used' => 'Escolha entre series mais comuns',
            'not_found' => 'Não foi possível encontrar series',
            'no_terms' => 'Não há series',
            'items_list_navigation' => 'Navegação na lista de Series',
            'items_list' => 'Lista de Series',
            'back_to_items' => '← Ir para series',
            'item_link' => 'Link de Serie',
            'item_link_description' => 'Um link para um serie',
        ),
        'public' => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
    ));
});
