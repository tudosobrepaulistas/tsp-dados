<?php

add_action('init', function () {
    register_taxonomy('campeonato', array(
        0 => 'materia',
        1 => 'aposta',
    ), array(
        'labels' => array(
            'name' => 'Campeonatos',
            'singular_name' => 'Campeonato',
            'menu_name' => 'Campeonatos',
            'all_items' => 'Todos os Campeonato',
            'edit_item' => 'Editar Campeonato',
            'view_item' => 'Ver Campeonato',
            'update_item' => 'Atualizar Campeonato',
            'add_new_item' => 'Adicionar novo Campeonato',
            'new_item_name' => 'Novo nome de Campeonato',
            'search_items' => 'Pesquisar Campeonato',
            'popular_items' => 'Campeonato populares',
            'separate_items_with_commas' => 'Separe campeonato com vírgulas',
            'add_or_remove_items' => 'Adicionar ou remover campeonato',
            'choose_from_most_used' => 'Escolha entre campeonato mais comuns',
            'not_found' => 'Não foi possível encontrar campeonato',
            'no_terms' => 'Não há campeonato',
            'items_list_navigation' => 'Navegação na lista de Campeonato',
            'items_list' => 'Lista de Campeonato',
            'back_to_items' => '← Ir para campeonato',
            'item_link' => 'Link de Campeonato',
            'item_link_description' => 'Um link para um campeonato',
        ),
        'public' => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
    ));
});
