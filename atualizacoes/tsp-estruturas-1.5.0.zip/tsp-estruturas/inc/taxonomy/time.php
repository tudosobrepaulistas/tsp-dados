<?php

add_action('init', function () {
    register_taxonomy('times', array(
        0 => 'materia',
        1 => 'aposta',
    ), array(
        'labels' => array(
            'name' => 'Times',
            'singular_name' => 'times',
            'menu_name' => 'Times',
            'all_items' => 'Todos os Times',
            'edit_item' => 'Editar times',
            'view_item' => 'Ver times',
            'update_item' => 'Atualizar times',
            'add_new_item' => 'Adicionar novo times',
            'new_item_name' => 'Novo nome de times',
            'search_items' => 'Pesquisar Times',
            'popular_items' => 'Times populares',
            'separate_items_with_commas' => 'Separe times com vírgulas',
            'add_or_remove_items' => 'Adicionar ou remover times',
            'choose_from_most_used' => 'Escolha entre times mais comuns',
            'not_found' => 'Não foi possível encontrar times',
            'no_terms' => 'Não há times',
            'items_list_navigation' => 'Navegação na lista de Times',
            'items_list' => 'Lista de Times',
            'back_to_items' => '← Ir para times',
            'item_link' => 'Link de times',
            'item_link_description' => 'Um link para um times',
        ),
        'public' => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
    ));
});
