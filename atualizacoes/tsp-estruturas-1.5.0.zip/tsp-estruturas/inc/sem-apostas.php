<?php
/**
 * SEM APOSTAS (MP 1.394/2026): o site deixa de exibir propaganda de casas de apostas.
 * Não apaga nada do banco de dados: a limpeza acontece na hora de mostrar a página,
 * em qualquer tema (o atual e o novo). Para desfazer, basta desativar o plugin.
 *
 * O que sai:
 * 1. Blocos "PUBLICIDADE | BETNACIONAL ... Autorização SPA/MF ..." das matérias "Onde assistir".
 * 2. Chamadas "Clique aqui, faça seu cadastro na Betnacional e use o código TUDOSOBREPAULISTA".
 * 3. Qualquer link ou banner que leve a site de apostas (o texto do link fica, sem o link).
 * 4. Seção /aposta/ (palpites) e o arquivo /campeonato/apostas/: respondem "410 - removido" e saem do sitemap.
 * O que fica: menções jornalísticas (ex.: caso VaideBet, nome oficial "Copa Paulista Rivalo"),
 * que são notícia e não propaganda.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_bets_padrao_dominio()
{
    return '(?:betnacional|bet365|betano|superbet|sportingbet|estrelabet|pixbet|novibet|betfair|blaze\.|esportesdasorte|rivalo|7k\.bet|7kbet|betmgm|f12\.bet|vaidebet|br4bet|1xbet|parimatch|betsson|kto\.|mcgames|apostaganha|galera\.bet|\.bet\.br|\.bet(?=[/"\'?#]))';
}

// Limpa um trecho de HTML (conteúdo de matéria, descrição de time, widget)
function tsp_bets_limpar_texto($c)
{
    if (!is_string($c) || $c === '' || !preg_match('~bet|aposta|TUDOSOBREPAULISTA~i', $c)) {
        return $c;
    }
    $regras = array(
        // 1. Bloco de publicidade das matérias "Onde assistir"
        '~(?:<br\s*/?>\s*)*<strong>\s*PUBLICIDADE\s*\|[^<]*</strong>.*?Autoriza(?:ç|c)(?:ã|a)o\s+SPA/MF[^<]*~isu',
        // 2. "Frase! Clique aqui, faça seu cadastro na Betnacional e use o código: TUDOSOBREPAULISTA."
        '~[^.!?<>]{0,200}[!?.]?\s*(?:<strong[^>]*>)?\s*<a[^>]*>\s*Clique aqui,?\s*</a>\s*(?:</strong>)?\s*fa(?:ç|c)a seu cadastro.*?(?-i:TUDOSOBREPAULISTA)\.?\s*(?:</strong>)?~isu',
        '~[^.!?<>]{0,200}(?:use|utilize) o c(?:ó|o)digo:?\s*(?:<strong[^>]*>)?\s*(?-i:TUDOSOBREPAULISTA)\.?\s*(?:</strong>)?~iu',
    );
    foreach ($regras as $r) {
        $novo = preg_replace($r, '', $c);
        if (is_string($novo)) {
            $c = $novo;
        }
    }
    // parágrafos que ficaram vazios
    $novo = preg_replace('~<p>(?:\s|&nbsp;|<br\s*/?>)*</p>~iu', '', $c);
    if (is_string($novo)) {
        $c = $novo;
    }
    // 3. Links para sites de apostas
    return tsp_bets_limpar_links($c);
}

function tsp_bets_limpar_links($html)
{
    $dom = tsp_bets_padrao_dominio();
    // link com imagem (banner) → some inteiro
    $regras = array(
        // link com imagem (banner) → some inteiro
        array('~<a\s[^>]*href=["\'][^"\']*' . $dom . '[^"\']*["\'][^>]*>\s*(?:<picture.*?</picture>|<img[^>]*>)\s*</a>~is', ''),
        // link "Clique aqui" para site de apostas → some inteiro
        array('~<a\s[^>]*href=["\'][^"\']*' . $dom . '[^"\']*["\'][^>]*>(?:(?!</a>).){0,300}?Clique(?:(?!</a>).){0,300}?</a>\s*,?~is', ''),
        // link de texto → fica só o texto
        array('~<a\s[^>]*href=["\'][^"\']*' . $dom . '[^"\']*["\'][^>]*>(.*?)</a>~is', '$1'),
        // imagem hospedada em site de apostas
        array('~<img\s[^>]*src=["\'][^"\']*' . $dom . '[^"\']*["\'][^>]*>~i', ''),
    );
    foreach ($regras as $r) {
        $novo = preg_replace($r[0], $r[1], $html);
        if (is_string($novo)) {
            $html = $novo;
        }
    }
    return $html;
}

foreach (array('the_content', 'the_excerpt', 'term_description', 'get_the_archive_description', 'widget_text', 'widget_text_content', 'widget_block_content') as $tsp_f) {
    add_filter($tsp_f, 'tsp_bets_limpar_texto', 999);
}

// Rede de segurança: links/banners de apostas em qualquer parte da página (cabeçalho, barra lateral, rodapé)
add_action('template_redirect', function () {
    if (is_admin() || wp_doing_ajax()) {
        return;
    }
    ob_start(function ($html) {
        if (!is_string($html) || stripos($html, '<html') === false) {
            return $html;
        }
        return tsp_bets_limpar_links($html);
    });
}, 1);

// Seção de palpites e arquivo de apostas: "410 - conteúdo removido" (o Google tira do índice)
add_action('template_redirect', function () {
    $fora = is_singular('aposta') || is_post_type_archive('aposta')
        || (is_tax('campeonato') && in_array(get_queried_object()->slug ?? '', array('apostas'), true));
    if (!$fora) {
        return;
    }
    status_header(410);
    nocache_headers();
    header('X-Robots-Tag: noindex', true);
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="robots" content="noindex"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Conteúdo removido · Tudo Sobre Paulista</title></head><body style="font-family:system-ui,sans-serif;max-width:640px;margin:60px auto;padding:0 20px;line-height:1.5"><h1>Conteúdo removido</h1><p>Esta página não está mais disponível.</p><p><a href="' . esc_url(home_url('/')) . '">Ir para a página inicial</a></p></body></html>';
    exit;
}, 0);

// Fora do sitemap do Yoast
add_filter('wpseo_sitemap_exclude_post_type', function ($excluir, $tipo) {
    return $tipo === 'aposta' ? true : $excluir;
}, 10, 2);
add_filter('wpseo_exclude_from_sitemap_by_term_ids', function ($ids) {
    $t = get_term_by('slug', 'apostas', 'campeonato');
    if ($t) {
        $ids[] = $t->term_id;
    }
    return $ids;
});


// Palpites guardados (não apagados): fora da API pública do site, para ninguém listar os títulos
add_filter('register_post_type_args', function ($args, $tipo) {
    if ($tipo === 'aposta') {
        $args['show_in_rest'] = false;
    }
    return $args;
}, 20, 2);
