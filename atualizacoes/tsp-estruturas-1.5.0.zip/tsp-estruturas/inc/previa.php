<?php
/**
 * Prévia do tema novo SOMENTE para administradores logados.
 *
 * Como funciona:
 * - O administrador clica em "Prévia do tema novo" na barra do WordPress.
 * - Um cookie (tsp_previa=1) fica no navegador DELE por 12 horas.
 * - Enquanto o cookie existir e ele estiver logado como administrador, o site
 *   é desenhado com o tema novo só para ele. Visitantes, o Google e qualquer
 *   pessoa sem login continuam vendo o tema atual (Divi), sem nenhuma mudança.
 * - O painel (wp-admin), o editor, o login, o cron e a API continuam sempre no tema atual.
 * - Páginas vistas em prévia nunca entram no cache.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_TEMA_NOVO', 'tsp-nova-era');
define('TSP_PREVIA_COOKIE', 'tsp_previa');

function tsp_previa_contexto_publico()
{
    if (is_admin() || wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI) || (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST)) {
        return false;
    }
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
    if (strpos($uri, '/wp-json/') !== false || strpos($uri, 'rest_route=') !== false || strpos($uri, 'wp-login.php') !== false) {
        return false;
    }
    return true;
}

function tsp_previa_ativa()
{
    static $resultado = null;
    if ($resultado !== null) {
        return $resultado;
    }
    // ?tsp_previa=0 desliga na hora, mesmo se o tema novo tiver algum erro
    if (isset($_GET['tsp_previa']) && $_GET['tsp_previa'] === '0') {
        return $resultado = false;
    }
    if (empty($_COOKIE[TSP_PREVIA_COOKIE]) || $_COOKIE[TSP_PREVIA_COOKIE] !== '1') {
        return $resultado = false;
    }
    if (!function_exists('wp_get_current_user') || !did_action('plugins_loaded')) {
        return false; // ainda cedo demais para saber quem é o usuário; não memoriza
    }
    if (!tsp_previa_contexto_publico()) {
        return $resultado = false;
    }
    if (!is_user_logged_in() || !current_user_can('manage_options')) {
        return $resultado = false;
    }
    $tema = wp_get_theme(TSP_TEMA_NOVO);
    return $resultado = ($tema->exists() && !$tema->errors());
}

// Troca o tema só na resposta desta pessoa (não grava nada no banco)
add_action('plugins_loaded', function () {
    add_filter('stylesheet', function ($s) {
        return tsp_previa_ativa() ? TSP_TEMA_NOVO : $s;
    }, 99);
    add_filter('template', function ($s) {
        return tsp_previa_ativa() ? TSP_TEMA_NOVO : $s;
    }, 99);
}, 1);

// Liga/desliga pelo link da barra (com proteção contra links forjados)
add_action('init', function () {
    if (!isset($_GET['tsp_previa'])) {
        return;
    }
    if (!is_user_logged_in() || !current_user_can('manage_options')) {
        return;
    }
    $ligar = $_GET['tsp_previa'] === '1';
    // Ligar exige o link assinado da barra; desligar é sempre permitido (não traz risco)
    $nonce = isset($_GET['_tspn']) ? sanitize_text_field(wp_unslash($_GET['_tspn'])) : '';
    if ($ligar && !wp_verify_nonce($nonce, 'tsp_previa')) {
        wp_die('Link expirado. Volte e clique de novo no botão da barra.', 'Prévia do tema', array('response' => 403));
    }
    $args = array(
        'expires'  => $ligar ? time() + 12 * HOUR_IN_SECONDS : time() - YEAR_IN_SECONDS,
        'path'     => COOKIEPATH ? COOKIEPATH : '/',
        'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    );
    setcookie(TSP_PREVIA_COOKIE, $ligar ? '1' : '', $args);
    $destino = remove_query_arg(array('tsp_previa', '_tspn'));
    if (strpos($destino, 'wp-admin') !== false) {
        $destino = home_url('/');
    }
    wp_safe_redirect($destino);
    exit;
}, 1);

// Nada visto em prévia vai para o cache
add_action('send_headers', function () {
    if (!tsp_previa_ativa()) {
        return;
    }
    nocache_headers();
    header('X-TSP-Previa: 1');
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
    do_action('litespeed_control_set_nocache', 'TSP: prévia do tema novo');
});
add_action('template_redirect', function () {
    if (tsp_previa_ativa()) {
        do_action('litespeed_control_set_nocache', 'TSP: prévia do tema novo');
    }
}, 0);

// Botão na barra do WordPress
add_action('admin_bar_menu', function ($barra) {
    if (!current_user_can('manage_options')) {
        return;
    }
    $existe = wp_get_theme(TSP_TEMA_NOVO)->exists();
    $ligada = !empty($_COOKIE[TSP_PREVIA_COOKIE]) && $_COOKIE[TSP_PREVIA_COOKIE] === '1';
    if (!$existe) {
        $barra->add_node(array('id' => 'tsp-previa', 'title' => 'Tema novo: não instalado', 'href' => admin_url('themes.php')));
        return;
    }
    $base = is_admin() ? home_url('/') : (is_ssl() ? 'https://' : 'http://') . sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'] ?? '')) . sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'] ?? '/'));
    $link = add_query_arg(array('tsp_previa' => $ligada ? '0' : '1', '_tspn' => wp_create_nonce('tsp_previa')), $base);
    $barra->add_node(array(
        'id'    => 'tsp-previa',
        'title' => $ligada ? '● Prévia do tema novo LIGADA (só você vê) · Desligar' : 'Ver prévia do tema novo',
        'href'  => $link,
        'meta'  => array('title' => 'Só administradores logados veem a prévia. Visitantes continuam no tema atual.'),
    ));
}, 90);

add_action('wp_head', function () {
    if (tsp_previa_ativa()) {
        echo '<style>#wp-admin-bar-tsp-previa>.ab-item{background:#E18330!important;color:#141414!important;font-weight:700}</style>';
    }
});
