<?php

add_action('init', function () {
    register_post_type('aposta', array(
        'labels' => array(
            'name' => 'Apostas',
            'singular_name' => 'Aposta',
            'menu_name' => 'Apostas',
            'all_items' => 'Todos os Apostas',
            'edit_item' => 'Editar Aposta',
            'view_item' => 'Ver Aposta',
            'view_items' => 'Ver Apostas',
            'add_new_item' => 'Adicionar novo Aposta',
            'new_item' => 'Novo Aposta',
            'parent_item_colon' => 'Aposta ascendente:',
            'search_items' => 'Pesquisar Apostas',
            'not_found' => 'Não foi possível encontrar apostas',
            'not_found_in_trash' => 'Não foi possível encontrar apostas na lixeira',
            'archives' => 'Arquivos de Aposta',
            'attributes' => 'Atributos de Aposta',
            'insert_into_item' => 'Inserir no aposta',
            'uploaded_to_this_item' => 'Enviado para este aposta',
            'filter_items_list' => 'Filtrar lista de apostas',
            'filter_by_date' => 'Filtrar apostas por data',
            'items_list_navigation' => 'Navegação na lista de Apostas',
            'items_list' => 'Lista de Apostas',
            'item_published' => 'Aposta publicado.',
            'item_published_privately' => 'Aposta publicado de forma privada.',
            'item_reverted_to_draft' => 'Aposta revertido para rascunho.',
            'item_scheduled' => 'Aposta agendado.',
            'item_updated' => 'Aposta atualizado.',
            'item_link' => 'Link de Aposta',
            'item_link_description' => 'Um link para um aposta.',
        ),
        'public' => true,
        'show_in_rest' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-money-alt',
        'supports' => array(
            0 => 'title',
            1 => 'editor',
            2 => 'thumbnail',
        ),
        'taxonomies' => array(
            0 => 'campeonato',
            1 => 'times',
        ),
        'has_archive' => 'aposta',
        'rewrite' => array(
            'feeds' => false,
        ),
        'delete_with_user' => false,
    ));
});
