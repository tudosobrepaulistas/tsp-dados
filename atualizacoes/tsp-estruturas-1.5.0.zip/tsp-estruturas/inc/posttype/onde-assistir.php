<?php

add_action('init', function () {
    register_post_type('onde-assistir', array(
        'labels' => array(
            'name' => 'Onde Assitir',
            'singular_name' => 'Onde Assitir',
            'menu_name' => 'Onde Assistir',
            'all_items' => 'Todos os Onde Assistir',
            'edit_item' => 'Editar Onde Assistir',
            'view_item' => 'Ver Onde Assistir',
            'view_items' => 'Ver Onde Assistir',
            'add_new_item' => 'Adicionar novo Onde Assistir',
            'add_new' => 'Adicionar novo Onde Assistir',
            'new_item' => 'Novo Onde Assistir',
            'parent_item_colon' => 'Onde Assistir ascendente:',
            'search_items' => 'Pesquisar Onde Assistir',
            'not_found' => 'Não foi possível encontrar onde assistir',
            'not_found_in_trash' => 'Não foi possível encontrar onde assistir na lixeira',
            'archives' => 'Onde Assistir',
            'attributes' => 'Atributos de Onde Assistir',
            'insert_into_item' => 'Inserir no onde assistir',
            'uploaded_to_this_item' => 'Enviado para este onde assistir',
            'filter_items_list' => 'Filtrar lista de onde assistir',
            'filter_by_date' => 'Filtrar onde assistir por data',
            'items_list_navigation' => 'Navegação na lista de Onde Assistir',
            'items_list' => 'Lista de Onde Assistir',
            'item_published' => 'Onde Assistir publicado.',
            'item_published_privately' => 'Onde Assistir publicado de forma privada.',
            'item_reverted_to_draft' => 'Onde Assistir revertido para rascunho.',
            'item_scheduled' => 'Onde Assistir agendado.',
            'item_updated' => 'Onde Assistir atualizado.',
            'item_link' => 'Link de Onde Assistir',
            'item_link_description' => 'Um link para um onde assistir.',
        ),
        'public' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-desktop',
        'supports' => array(
            0 => 'title',
            1 => 'editor',
            2 => 'thumbnail',
        ),
        'taxonomies' => array(
            0 => 'onde-assistir',
        ),
        'has_archive' => true,
        'rewrite' => array(
            'feeds' => false,
        ),
        'delete_with_user' => false,
    ));
});
