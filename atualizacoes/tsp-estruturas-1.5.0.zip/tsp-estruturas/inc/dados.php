<?php
/**
 * Dados do tema novo (tabelas, rodadas, competições femininas, faixa do topo).
 * Ficam numa opção do WordPress ("tsp_dados") e são editados em
 * Ferramentas → TSP · Dados do tema. Só administradores acessam.
 * Mais tarde a Máquina de Notícias atualiza esses dados sozinha.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_dados($chave = null, $padrao = array())
{
    $d = get_option('tsp_dados', array());
    if (!is_array($d)) {
        $d = array();
    }
    if ($chave === null) {
        return $d;
    }
    return isset($d[$chave]) ? $d[$chave] : $padrao;
}

add_action('admin_menu', function () {
    add_management_page('TSP · Dados do tema', 'TSP · Dados do tema', 'manage_options', 'tsp-dados', 'tsp_dados_tela');
});

function tsp_dados_tela()
{
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão.');
    }
    $aviso = '';
    $texto = null;
    if (isset($_POST['tsp_dados_json'])) {
        check_admin_referer('tsp_dados_salvar');
        $texto = wp_unslash($_POST['tsp_dados_json']);
        $novo = json_decode($texto, true);
        if (!is_array($novo)) {
            $aviso = '<div class="notice notice-error"><p>Não salvei: o texto não é um JSON válido (' . esc_html(json_last_error_msg()) . ').</p></div>';
        } else {
            $novo = tsp_dados_limpar($novo);
            update_option('tsp_dados', $novo, false);
            $novo_atual = get_option('tsp_dados_versoes', array());
            $novo_atual = is_array($novo_atual) ? array_slice($novo_atual, -4) : array();
            $novo_atual[] = array('quando' => current_time('mysql'), 'quem' => get_current_user_id());
            update_option('tsp_dados_versoes', $novo_atual, false);
            do_action('litespeed_purge_url', home_url('/'));
            $aviso = '<div class="notice notice-success"><p>Dados salvos. A página inicial foi marcada para atualizar.</p></div>';
            $texto = null;
        }
    }
    if ($texto === null) {
        $texto = wp_json_encode(tsp_dados(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    echo '<div class="wrap"><h1>TSP · Dados do tema</h1>' . $aviso;
    echo '<p>Tabelas, rodadas e competições usadas pelo tema novo. Só aparecem no tema novo (e na prévia).</p>';
    echo '<form method="post">';
    wp_nonce_field('tsp_dados_salvar');
    echo '<textarea name="tsp_dados_json" rows="30" style="width:100%;font-family:monospace;font-size:12px">' . esc_textarea($texto) . '</textarea>';
    submit_button('Salvar dados');
    echo '</form></div>';
}

// Só texto e números: nada de HTML ou script entra pelos dados
function tsp_dados_limpar($v)
{
    if (is_array($v)) {
        $saida = array();
        foreach ($v as $k => $x) {
            $saida[is_int($k) ? $k : sanitize_key($k)] = tsp_dados_limpar($x);
        }
        return $saida;
    }
    if (is_int($v) || is_float($v) || is_bool($v) || $v === null) {
        return $v;
    }
    return sanitize_text_field((string) $v);
}
