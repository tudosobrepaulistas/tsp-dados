TSP Estruturas 1.2.0

Fase 1 e 2 da troca de tema do Tudo Sobre Paulista.
- Com o tema Divi Child ativo: o plugin corrige a reconstrução das regras de endereço a cada visita. Nada muda no visual.
- Com outro tema ativo ou em prévia: o plugin registra Matérias, Apostas, Banners, Onde Assistir, Times, Série, Campeonato e os campos ACF, com os mesmos nomes e endereços.
- Prévia do tema novo: botão na barra do WordPress, só para administradores logados. Visitantes e Google continuam no tema atual. Para sair na hora: abra qualquer página com ?tsp_previa=0 no fim do endereço.
- Ferramentas → TSP · Dados do tema: tabelas, rodadas e competições usadas pelo tema novo.
Para desfazer tudo: desativar o plugin.
- Sem apostas (MP 1.394): o site não mostra blocos 'PUBLICIDADE | BETNACIONAL', chamadas 'faça seu cadastro... código TUDOSOBREPAULISTA', links e banners de casas de apostas. Nada é apagado do banco. A seção /aposta/ responde 410 (removido) e sai do sitemap.
