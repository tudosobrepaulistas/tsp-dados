<?php
/*
Plugin Name: TSP Relatório da Redação
Description: Nota diária de 0 a 10 das matérias (como professor de redação), ranking e relatório por redator; relatório de matérias por redator, time, data, categoria, campeonato e série (com média de caracteres); limites de publicação por fase do dia e de agendamento; painel de progresso do redator com metas, mensagens e sugestões de pauta dos times que ele cobre; pagamento por matéria com MEI. Fechamento do dia 10 ao dia 9, pagamento dia 20.
Version: 1.9.8
Author: TSP
Requires at least: 6.3
Requires PHP: 7.4
Text Domain: tsp-relatorio
*/

if (!defined('ABSPATH')) {
    exit;
}

// Dia em que começa o fechamento (10 → do dia 10 até o dia 9 do mês seguinte) e dia do pagamento
const TSP_REL_DIA_FECHAMENTO = 10;
const TSP_REL_DIA_PAGAMENTO = 20;

require_once __DIR__ . '/inc/coordenacao.php';
require_once __DIR__ . '/inc/regras.php';
require_once __DIR__ . '/inc/painel.php';
require_once __DIR__ . '/inc/avaliacao.php';
require_once __DIR__ . '/inc/correcoes.php';
require_once __DIR__ . '/inc/limpeza.php';
require_once __DIR__ . '/inc/audiencia.php';
require_once __DIR__ . '/inc/pautas.php';
require_once __DIR__ . '/inc/carentes.php';
require_once __DIR__ . '/inc/notas.php';

function tsp_rel_tipos()
{
    return array_values(array_filter(array('materia', 'post'), 'post_type_exists'));
}

/* ---------- Caracteres do texto (guardado na matéria; recalcula quando ela é salva) ---------- */

function tsp_rel_contar($post)
{
    $t = (string) $post->post_content;
    $t = preg_replace('~<!--.*?-->~s', '', $t);           // marcas dos blocos
    $t = preg_replace('~<(script|style|figure|iframe)[^>]*>.*?</\1>~is', '', $t); // embeds e legendas de foto
    $t = strip_shortcodes($t);
    $t = html_entity_decode(wp_strip_all_tags($t), ENT_QUOTES, 'UTF-8');
    $t = trim(preg_replace('~\s+~u', ' ', $t));
    return mb_strlen($t);
}

function tsp_rel_caracteres($post)
{
    $v = get_post_meta($post->ID, 'tsp_caracteres', true);
    if ($v === '' || $v === false) {
        $v = tsp_rel_contar($post);
        update_post_meta($post->ID, 'tsp_caracteres', $v);
    }
    return (int) $v;
}

add_action('save_post', function ($id, $post) {
    if (in_array($post->post_type, tsp_rel_tipos(), true) && !wp_is_post_revision($id)) {
        update_post_meta($id, 'tsp_caracteres', tsp_rel_contar($post));
    }
}, 20, 2);

/* ---------- Períodos ---------- */

function tsp_rel_fechamento($deslocamento = 0)
{
    $tz = tsp_rel_tz();
    $hoje = new DateTimeImmutable('now', $tz);
    $ini = $hoje->setDate((int) $hoje->format('Y'), (int) $hoje->format('n'), TSP_REL_DIA_FECHAMENTO)->setTime(0, 0);
    if ((int) $hoje->format('j') < TSP_REL_DIA_FECHAMENTO) {
        $ini = $ini->modify('-1 month');
    }
    if ($deslocamento) {
        $ini = $ini->modify(($deslocamento > 0 ? '+' : '') . $deslocamento . ' month');
    }
    $fim = $ini->modify('+1 month')->modify('-1 day')->setTime(23, 59, 59);
    $pag = $fim->modify('+1 day')->setDate((int) $fim->format('Y'), (int) $fim->format('n'), TSP_REL_DIA_PAGAMENTO);
    return array($ini, $fim, $pag);
}

function tsp_rel_periodo()
{
    $tz = wp_timezone();
    $p = sanitize_key($_GET['periodo'] ?? 'fechamento');
    $pag = null;
    switch ($p) {
        case 'fechamento_anterior':
            list($ini, $fim, $pag) = tsp_rel_fechamento(-1);
            $nome = 'Fechamento anterior';
            break;
        case 'mes':
            $ini = new DateTimeImmutable('first day of this month 00:00', $tz);
            $fim = new DateTimeImmutable('last day of this month 23:59:59', $tz);
            $nome = 'Mês atual';
            break;
        case 'mes_anterior':
            $ini = new DateTimeImmutable('first day of last month 00:00', $tz);
            $fim = new DateTimeImmutable('last day of last month 23:59:59', $tz);
            $nome = 'Mês anterior';
            break;
        case 'personalizado':
            $de = sanitize_text_field($_GET['de'] ?? '');
            $ate = sanitize_text_field($_GET['ate'] ?? '');
            $ini = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $de . ' 00:00:00', $tz) ?: new DateTimeImmutable('today', $tz);
            $fim = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $ate . ' 23:59:59', $tz) ?: new DateTimeImmutable('today 23:59:59', $tz);
            $nome = 'Período personalizado';
            break;
        default:
            $p = 'fechamento';
            list($ini, $fim, $pag) = tsp_rel_fechamento(0);
            $nome = 'Fechamento atual';
    }
    return compact('p', 'ini', 'fim', 'pag', 'nome');
}

/* ---------- Dados ---------- */

function tsp_rel_dados($per, $filtros)
{
    $args = array(
        'post_type'              => tsp_rel_tipos(),
        'post_status'            => 'publish',
        'posts_per_page'         => -1,
        'orderby'                => 'date',
        'order'                  => 'ASC',
        'no_found_rows'          => true,
        'date_query'             => array(array('after' => $per['ini']->format('Y-m-d H:i:s'), 'before' => $per['fim']->format('Y-m-d H:i:s'), 'inclusive' => true)),
        'meta_query'             => array(array('key' => 'tsp_versao_de', 'compare' => 'NOT EXISTS')), // versões por clube não contam
    );
    if (!empty($filtros['autor'])) {
        $args['author'] = (int) $filtros['autor'];
    }
    $tax = array();
    foreach (array('times', 'category', 'campeonato', 'serie') as $tx) {
        if (!empty($filtros[$tx]) && taxonomy_exists($tx)) {
            $tax[] = array('taxonomy' => $tx, 'field' => 'term_id', 'terms' => (int) $filtros[$tx]);
        }
    }
    if ($tax) {
        $args['tax_query'] = $tax;
    }
    $q = new WP_Query($args);
    $linhas = array();
    foreach ($q->posts as $p) {
        $nomes = function ($tx) use ($p) {
            if (!taxonomy_exists($tx)) {
                return array();
            }
            $t = get_the_terms($p, $tx);
            return ($t && !is_wp_error($t)) ? wp_list_pluck($t, 'name') : array();
        };
        $linhas[] = array(
            'id'      => $p->ID,
            'titulo'  => get_the_title($p),
            'link'    => get_permalink($p),
            'data'    => get_post_datetime($p),
            'autor'   => (int) $p->post_author,
            'chars'   => ($c = tsp_rel_caracteres($p)),
            'edit'    => get_edit_post_link($p->ID, 'url'),
            'problemas' => tsp_rel_problemas($p, $c),
            'aval'    => tsp_rel_aval($p->ID)[0],
            'obs'     => tsp_rel_aval($p->ID)[1],
            'ia'      => get_post_meta($p->ID, 'tsp_ia_origem', true) === 'audio' ? 'Áudio + IA' : (get_post_meta($p->ID, 'tsp_ia', true) === '1' ? 'Apoio de IA' : ''),
            'times'   => $nomes('times'),
            'category' => $nomes('category'),
            'campeonato' => $nomes('campeonato'),
            'serie'   => $nomes('serie'),
        );
    }
    $fa = $filtros['aval'] ?? '';
    if ($fa !== '') {
        $linhas = array_values(array_filter($linhas, function ($l) use ($fa) {
            if ($fa === 'erros') {
                return (bool) $l['problemas'];
            }
            return $fa === 'pendente' ? $l['aval'] === '' : $l['aval'] === $fa;
        }));
    }
    return $linhas;
}

function tsp_rel_agrupar($linhas, $chave)
{
    $g = array();
    foreach ($linhas as $l) {
        if ($chave === 'autor') {
            $u = get_userdata($l['autor']);
            $grupos = array($u ? $u->display_name : 'Usuário apagado');
        } elseif ($chave === 'dia') {
            $grupos = array($l['data']->format('d/m/Y'));
        } else {
            $grupos = $l[$chave] ?: array('(sem ' . ($chave === 'category' ? 'categoria' : $chave) . ')');
        }
        foreach ($grupos as $n) {
            if (!isset($g[$n])) {
                $g[$n] = array('n' => 0, 'chars' => 0, 'ia' => 0);
            }
            $g[$n]['n']++;
            $g[$n]['chars'] += $l['chars'];
            $g[$n]['ia'] += $l['ia'] ? 1 : 0;
        }
    }
    if ($chave !== 'dia') {
        uasort($g, function ($a, $b) {
            return $b['n'] <=> $a['n'];
        });
    }
    return $g;
}

/* ---------- Tela ---------- */

add_action('admin_menu', function () {
    add_menu_page('Relatório da Redação', 'Relatório', 'edit_posts', 'tsp-relatorio', 'tsp_rel_tela', 'dashicons-chart-bar', 3);
});

function tsp_rel_filtros()
{
    $f = array();
    foreach (array('autor', 'times', 'category', 'campeonato', 'serie') as $k) {
        $f[$k] = (int) ($_GET[$k] ?? 0);
    }
    $f['aval'] = sanitize_key($_GET['aval'] ?? '');
    // Quem não é administrador nem coordenador vê só as próprias matérias
    if (!tsp_rel_coord()) {
        $f['autor'] = get_current_user_id();
    }
    return $f;
}

// Planilha (CSV) antes de qualquer saída da tela
add_action('admin_init', function () {
    if (($_GET['page'] ?? '') !== 'tsp-relatorio' || empty($_GET['csv']) || !current_user_can('edit_posts')) {
        return;
    }
    check_admin_referer('tsp_rel_csv');
    $per = tsp_rel_periodo();
    $linhas = tsp_rel_dados($per, tsp_rel_filtros());
    nocache_headers();
    if ($_GET['csv'] === 'pag' && current_user_can('manage_options')) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="pagamento-tsp-' . $per['ini']->format('Y-m-d') . '-a-' . $per['fim']->format('Y-m-d') . '.csv"');
        $o = fopen('php://output', 'w');
        fwrite($o, "\xEF\xBB\xBF");
        fputcsv($o, array('Redator', 'E-mail', 'Matérias que contam', 'Recusadas', 'Valor por matéria', 'Subtotal', 'MEI', 'Total'), ';');
        foreach (tsp_rel_tabela_pagamento($linhas) as $r) {
            fputcsv($o, array($r['nome'], $r['email'], $r['n'], $r['recusadas'], number_format($r['valor'], 2, ',', ''), number_format($r['bruto'], 2, ',', ''), number_format($r['mei'], 2, ',', ''), number_format($r['total'], 2, ',', '')), ';');
        }
        fclose($o);
        exit;
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="relatorio-tsp-' . $per['ini']->format('Y-m-d') . '-a-' . $per['fim']->format('Y-m-d') . '.csv"');
    $o = fopen('php://output', 'w');
    fwrite($o, "\xEF\xBB\xBF"); // acentos certos no Excel
    fputcsv($o, array('Data', 'Hora', 'Redator', 'Título', 'Caracteres', 'Times', 'Categoria', 'Campeonato', 'Série', 'IA', 'Possíveis erros', 'Avaliação', 'Observação', 'Link'), ';');
    foreach ($linhas as $l) {
        $u = get_userdata($l['autor']);
        fputcsv($o, array($l['data']->format('d/m/Y'), $l['data']->format('H:i'), $u ? $u->display_name : '', $l['titulo'], $l['chars'], implode(', ', $l['times']), implode(', ', $l['category']), implode(', ', $l['campeonato']), implode(', ', $l['serie']), $l['ia'], implode(' | ', $l['problemas']), tsp_rel_avaliacoes()[$l['aval']] ?? $l['aval'], $l['obs'], $l['link']), ';');
    }
    fclose($o);
    exit;
});

function tsp_rel_tabela_pagamento($linhas)
{
    $por = array();
    $rec = array();
    foreach ($linhas as $l) {
        $por[$l['autor']] = ($por[$l['autor']] ?? 0) + ($l['aval'] === 'recusada' ? 0 : 1);
        $rec[$l['autor']] = ($rec[$l['autor']] ?? 0) + ($l['aval'] === 'recusada' ? 1 : 0);
    }
    $out = array();
    foreach ($por as $id => $n) {
        $u = get_userdata($id);
        // Administrador (Redação/robô) e usuário apagado não entram no pagamento
        $valor = ($u && !tsp_rel_isento($id)) ? tsp_rel_valor_materia($id, $n) : 0;
        $out[] = array('nome' => $u ? $u->display_name : 'Usuário apagado', 'email' => $u ? $u->user_email : '', 'n' => $n, 'recusadas' => $rec[$id], 'valor' => $valor, 'isento' => $u && tsp_rel_isento($id)) + tsp_rel_pagamento($n, $valor);
    }
    usort($out, function ($a, $b) {
        return $b['total'] <=> $a['total'];
    });
    return $out;
}

function tsp_rel_select($nome, $rotulo, $opcoes, $atual)
{
    echo '<label>' . esc_html($rotulo) . '<select name="' . esc_attr($nome) . '"><option value="0">Todos</option>';
    foreach ($opcoes as $id => $txt) {
        echo '<option value="' . (int) $id . '"' . selected($atual, $id, false) . '>' . esc_html($txt) . '</option>';
    }
    echo '</select></label>';
}

function tsp_rel_tabela($titulo, $g, $total_n)
{
    if (!$g) {
        return;
    }
    echo '<details class="tsp-rel-d"' . ($titulo === 'Por redator' ? ' open' : '') . '><summary>' . esc_html($titulo) . ' <span>(' . count($g) . ')</span></summary><table class="widefat striped tsp-rel-t"><thead><tr><th>' . esc_html($titulo === 'Por dia' ? 'Dia' : 'Nome') . '</th><th class="n">Matérias</th><th class="n">%</th><th class="n">Média de caracteres</th><th class="n">Total de caracteres</th><th class="n">Com IA</th></tr></thead><tbody>';
    foreach ($g as $nome => $v) {
        echo '<tr><td>' . esc_html($nome) . '</td><td class="n"><strong>' . number_format_i18n($v['n']) . '</strong></td><td class="n">' . ($total_n ? number_format_i18n(100 * $v['n'] / $total_n, 1) : '0') . '%</td><td class="n">' . number_format_i18n($v['n'] ? $v['chars'] / $v['n'] : 0) . '</td><td class="n">' . number_format_i18n($v['chars']) . '</td><td class="n">' . number_format_i18n($v['ia']) . '</td></tr>';
    }
    echo '</tbody></table></details>';
}

function tsp_rel_tela()
{
    $per = tsp_rel_periodo();
    $f = tsp_rel_filtros();
    $linhas = tsp_rel_dados($per, $f);
    $n = count($linhas);
    $chars = array_sum(wp_list_pluck($linhas, 'chars'));
    $admin = current_user_can('manage_options');
    $coord = tsp_rel_coord();
    ?>
    <style>
        .tsp-rel form{display:flex;flex-wrap:wrap;gap:10px 16px;align-items:flex-end;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px;margin:12px 0}
        .tsp-rel label{display:flex;flex-direction:column;gap:4px;font-weight:600}
        .tsp-rel-cards{display:flex;flex-wrap:wrap;gap:12px;margin:12px 0}
        .tsp-rel-cards div{background:#fff;border:1px solid #dcdcde;border-left:4px solid #E8862A;border-radius:8px;padding:12px 16px;min-width:170px}
        .tsp-rel-cards b{display:block;font-size:26px;line-height:1.2}
        .tsp-rel-t{max-width:980px;margin-bottom:8px}.tsp-rel-t .n{text-align:right}
        .tsp-rel-d{background:#fff;border:1px solid #dcdcde;border-radius:8px;margin:0 0 10px;max-width:1000px}.tsp-rel-d summary{cursor:pointer;font-size:16px;font-weight:700;padding:12px 14px}.tsp-rel-d summary span{color:#777;font-weight:400}.tsp-rel-d table{border:0;border-top:1px solid #dcdcde;max-width:none}
        .tsp-rel-lista td{vertical-align:top}.tsp-rel-lista textarea{display:block;width:100%;min-width:170px;margin:4px 0}.tsp-rel-erro{display:inline-block;background:#fcf0f1;color:#8a2424;border-radius:4px;padding:1px 6px;margin:1px 0;font-size:12px}.tsp-rel-ok{color:#1a7f37;font-size:12px}
        .tsp-rel [data-pers]{display:none}.tsp-rel.is-pers [data-pers]{display:flex}
    </style>
    <div class="wrap tsp-rel<?php echo $per['p'] === 'personalizado' ? ' is-pers' : ''; ?>">
        <h1>Relatório da Redação</h1>
        <p><strong><?php echo esc_html($per['nome']); ?>:</strong> <?php echo esc_html($per['ini']->format('d/m/Y') . ' a ' . $per['fim']->format('d/m/Y')); ?>
            <?php if ($per['pag']) : ?> · <strong>Pagamento: <?php echo esc_html($per['pag']->format('d/m/Y')); ?></strong><?php endif; ?></p>
        <form method="get">
            <input type="hidden" name="page" value="tsp-relatorio">
            <label>Período
                <select name="periodo" onchange="this.closest('.tsp-rel').classList.toggle('is-pers', this.value==='personalizado')">
                    <?php foreach (array('fechamento' => 'Fechamento atual (dia 10 a 9)', 'fechamento_anterior' => 'Fechamento anterior', 'mes' => 'Mês atual', 'mes_anterior' => 'Mês anterior', 'personalizado' => 'Personalizado') as $k => $t) : ?>
                        <option value="<?php echo esc_attr($k); ?>" <?php selected($per['p'], $k); ?>><?php echo esc_html($t); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label data-pers>De<input type="date" name="de" value="<?php echo esc_attr($per['ini']->format('Y-m-d')); ?>"></label>
            <label data-pers>Até<input type="date" name="ate" value="<?php echo esc_attr($per['fim']->format('Y-m-d')); ?>"></label>
            <?php
            if ($coord) {
                $us = get_users(array('capability' => array('edit_posts'), 'orderby' => 'display_name', 'fields' => array('ID', 'display_name')));
                tsp_rel_select('autor', 'Redator', wp_list_pluck($us, 'display_name', 'ID'), $f['autor']);
            }
            foreach (array('times' => 'Time', 'category' => 'Categoria', 'campeonato' => 'Campeonato', 'serie' => 'Série') as $tx => $rot) {
                if (taxonomy_exists($tx)) {
                    $ts = get_terms(array('taxonomy' => $tx, 'hide_empty' => true, 'number' => 0));
                    tsp_rel_select($tx, $rot, is_wp_error($ts) ? array() : wp_list_pluck($ts, 'name', 'term_id'), $f[$tx]);
                }
            }
            ?>
            <label>Conferência<select name="aval">
                <?php foreach (array('' => 'Todas', 'erros' => 'Com possíveis erros', 'pendente' => 'Pendentes', 'ok' => 'OK', 'devolutiva' => 'Devolutiva', 'corrigida' => 'Corrigida (rever)', 'recusada' => 'Recusada') as $k => $t) : ?>
                    <option value="<?php echo esc_attr($k); ?>" <?php selected($f['aval'], $k); ?>><?php echo esc_html($t); ?></option>
                <?php endforeach; ?>
            </select></label>
            <button class="button button-primary">Ver relatório</button>
            <a class="button" href="<?php echo esc_url(wp_nonce_url(add_query_arg(array_merge($_GET, array('csv' => 1))), 'tsp_rel_csv')); ?>">Baixar planilha (CSV)</a>
        </form>

        <?php if ($f['autor'] && $per['p'] === 'fechamento') : ?>
            <details class="tsp-rel-d" open><summary>Progresso <?php echo esc_html(get_userdata($f['autor']) ? get_userdata($f['autor'])->display_name : ''); ?></summary><div style="padding:0 14px 12px;max-width:640px"><?php tsp_rel_painel_redator($f['autor']); ?></div></details>
        <?php endif; ?>
        <?php if ($admin) : ?>
            <?php if (!empty($_GET['corr'])) : ?><div class="notice notice-success"><p>Conferência feita: os redatores com possíveis erros foram avisados (painel e e-mail) e a coordenação recebeu a cópia para acompanhar.</p></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:10px 0"><?php wp_nonce_field('tsp_corr_agora'); ?><input type="hidden" name="action" value="tsp_corr_agora"><button class="button">📣 Conferir agora e avisar os redatores</button> <span class="description">A conferência também roda sozinha de hora em hora. Prazos: 🔴 grave 6h · 🟠 média 24h · 🟡 leve 48h. Sem correção no prazo, a matéria vira Recusada (comissão cancelada).</span></form>
        <?php endif; ?>
        <div class="tsp-rel-cards">
            <div>Matérias<b><?php echo number_format_i18n($n); ?></b></div>
            <div>Média de caracteres<b><?php echo number_format_i18n($n ? $chars / $n : 0); ?></b></div>
            <div>Total de caracteres<b><?php echo number_format_i18n($chars); ?></b></div>
            <div>Com IA (áudio ou apoio)<b><?php echo number_format_i18n(count(array_filter(wp_list_pluck($linhas, 'ia')))); ?></b></div>
            <div>Com possíveis erros<b><?php echo number_format_i18n(count(array_filter(wp_list_pluck($linhas, 'problemas')))); ?></b></div>
            <div>Devolutivas / recusadas<b><?php $tsp_av = array_count_values(wp_list_pluck($linhas, 'aval')); echo (int) ($tsp_av['devolutiva'] ?? 0) . ' / ' . (int) ($tsp_av['recusada'] ?? 0); ?></b></div>
        </div>
        <?php
        if (!$n) {
            echo '<p>Nenhuma matéria publicada nesse período com esses filtros.</p></div>';
            return;
        }
        if ($admin) {
            $pg = tsp_rel_tabela_pagamento($linhas);
            echo '<details class="tsp-rel-d" open><summary>Pagamento do período <span>(' . count($pg) . ')</span></summary><table class="widefat striped tsp-rel-t"><thead><tr><th>Redator</th><th class="n">Matérias que contam</th><th class="n">Recusadas</th><th class="n">Valor/matéria</th><th class="n">Subtotal</th><th class="n">MEI</th><th class="n">Total</th></tr></thead><tbody>';
            $tot = 0;
            foreach ($pg as $r) {
                $tot += $r['total'];
                echo '<tr><td>' . esc_html($r['nome']) . ($r['isento'] ? ' <em>(administrador, não recebe)</em>' : '') . '</td><td class="n">' . (int) $r['n'] . '</td><td class="n">' . (int) $r['recusadas'] . '</td><td class="n">' . esc_html(tsp_rel_reais($r['valor'])) . '</td><td class="n">' . esc_html(tsp_rel_reais($r['bruto'])) . '</td><td class="n">' . ($r['mei'] ? esc_html(tsp_rel_reais($r['mei'])) : '—') . '</td><td class="n"><strong>' . esc_html(tsp_rel_reais($r['total'])) . '</strong></td></tr>';
            }
            echo '</tbody><tfoot><tr><th colspan="6">Total do período</th><th class="n">' . esc_html(tsp_rel_reais($tot)) . '</th></tr></tfoot></table>';
            echo '<p style="padding:0 14px 12px"><a class="button" href="' . esc_url(wp_nonce_url(add_query_arg(array_merge($_GET, array('csv' => 'pag'))), 'tsp_rel_csv')) . '">Baixar pagamento (CSV)</a> MEI de ' . esc_html(tsp_rel_reais(TSP_REL_MEI)) . ' para quem soma ' . esc_html(tsp_rel_reais(TSP_REL_MEI_MINIMO)) . ' ou mais. Valor: R$ 5,00 por matéria; com ' . TSP_REL_META_MATERIAS . ' ou mais no fechamento, R$ 5,45 cada. Rascunhos e matérias recusadas não contam.</p></details>';
        }
        if ($coord && !$f['autor']) {
            tsp_rel_tabela('Por redator', tsp_rel_agrupar($linhas, 'autor'), $n);
        }
        tsp_rel_tabela('Por time', tsp_rel_agrupar($linhas, 'times'), $n);
        tsp_rel_tabela('Por campeonato', tsp_rel_agrupar($linhas, 'campeonato'), $n);
        tsp_rel_tabela('Por série', tsp_rel_agrupar($linhas, 'serie'), $n);
        tsp_rel_tabela('Por categoria', tsp_rel_agrupar($linhas, 'category'), $n);
        tsp_rel_tabela('Por dia', tsp_rel_agrupar($linhas, 'dia'), $n);
        ?>
        <details class="tsp-rel-d"<?php echo $f['aval'] !== '' ? ' open' : ''; ?>><summary>Matérias do período <span>(<?php echo (int) $n; ?>)</span></summary>
        <table class="widefat striped tsp-rel-t tsp-rel-lista"><thead><tr><th>Data</th><th>Redator</th><th>Matéria</th><th class="n">Caract.</th><th>Possíveis erros</th><th>Conferência</th></tr></thead><tbody>
        <?php foreach (array_reverse($linhas) as $l) : $u = get_userdata($l['autor']); ?>
            <tr>
                <td><?php echo esc_html($l['data']->format('d/m H\hi')); ?></td>
                <td><?php echo esc_html($u ? $u->display_name : ''); ?></td>
                <td><a href="<?php echo esc_url($l['link']); ?>" target="_blank"><?php echo esc_html($l['titulo']); ?></a><br><small><a href="<?php echo esc_url($l['link']); ?>" target="_blank">ver</a><?php if ($l['edit']) : ?> · <a href="<?php echo esc_url($l['edit']); ?>">editar</a><?php endif; ?><?php echo $l['times'] ? ' · ' . esc_html(implode(', ', $l['times'])) : ''; ?><?php echo $l['ia'] ? ' · ' . esc_html($l['ia']) : ''; ?></small></td>
                <td class="n"><?php echo number_format_i18n($l['chars']); ?></td>
                <td><?php echo $l['problemas'] ? '<span class="tsp-rel-erro">' . implode('</span> <span class="tsp-rel-erro">', array_map(function ($x) {
                    $g = tsp_corr_classificar($x)[0];
                    return esc_html(tsp_corr_gravidades()[$g][0] . ' · ' . $x);
                }, $l['problemas'])) . '</span>' : '<span class="tsp-rel-ok">Nada encontrado</span>'; ?></td>
                <td>
                    <?php if ($coord) : ?>
                        <select data-aval><?php foreach (tsp_rel_avaliacoes() as $k => $t) : ?><option value="<?php echo esc_attr($k); ?>" <?php selected($l['aval'], $k); ?>><?php echo esc_html($t); ?></option><?php endforeach; ?></select>
                        <textarea data-obs rows="2" placeholder="Observação para o redator"><?php echo esc_textarea($l['obs']); ?></textarea>
                        <button type="button" class="button button-small" data-aval-salvar="<?php echo (int) $l['id']; ?>">Salvar</button>
                    <?php else : ?>
                        <strong><?php echo esc_html(tsp_rel_avaliacoes()[$l['aval']] ?? $l['aval']); ?></strong><?php echo $l['obs'] ? '<br>' . esc_html($l['obs']) : ''; ?>
                    <?php endif; ?>
                    <?php echo tsp_corr_html_linha($l['id']); // phpcs:ignore -- HTML com escape ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody></table></details>
        <?php echo $coord ? tsp_rel_aval_js() . tsp_corr_js() : ''; // phpcs:ignore ?>
        <p class="description">Caracteres = texto da matéria com espaços, sem título, legendas, códigos e vídeos. Só matérias publicadas (rascunho não conta). Recusadas não entram no pagamento. Redatores veem apenas as próprias matérias; coordenação e administração veem a equipe toda.</p>
    </div>
    <?php
}


// Atualização automática pelo GitHub do TSP (Painel → Atualizações)
require_once __DIR__ . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('plugin', 'tsp-relatorio', plugin_basename(__FILE__), get_file_data(__FILE__, array('v' => 'Version'))['v']);
