<?php
/**
 * Times que cada redator cobre + Sugestões de pauta.
 *  - No perfil, o redator marca os times que cobre (o painel pede, se estiver vazio).
 *  - O site publica só a lista de clubes cobertos (endereço e nome do clube, nada sobre os redatores) em /wp-json/tsp/v1/cobertura.
 *  - O robô de pautas do TSP (8h, 12h e 18h) procura notícias desses clubes em sites de notícia e grava sugestões
 *    em api/pautas.json da Base TSP; o site lê a cada 15 minutos e mostra no painel de quem cobre o clube.
 *  - "Vou fazer": o redator pega a pauta e os colegas veem que ela já tem dono.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_PAUTAS_URL = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/pautas.json';

function tsp_rel_times_cobre($user_id)
{
    $v = get_user_meta($user_id, 'tsp_times_cobre', true);
    return is_array($v) ? array_map('intval', $v) : array();
}

/* ---------- Campo no perfil ---------- */

function tsp_rel_campo_times($u)
{
    if (!user_can($u, 'edit_posts')) {
        return;
    }
    $sel = tsp_rel_times_cobre($u->ID);
    $times = get_terms(array('taxonomy' => 'times', 'hide_empty' => false, 'number' => 0));
    // Redação cobre só Paulistão A1, A2 e A3 (A4, sem divisão e feminino são da Máquina de Notícias)
    $redacao = function_exists('tsp_rel_clubes_redacao') ? tsp_rel_clubes_redacao() : array();
    if ($redacao) {
        $times = array_filter((array) $times, function ($t) use ($redacao) {
            return is_object($t) && isset($redacao[$t->slug]);
        });
    }
    echo '<h2 id="tsp-times-cobre">Times que você cobre</h2><p class="description">A redação cobre o Paulistão A1, A2 e A3. A4, clubes sem divisão e futebol feminino ficam com a Máquina de Notícias.</p><table class="form-table"><tr><th>Seus times</th><td>';
    echo '<input type="search" id="tsp-times-filtro" placeholder="Digite para achar o clube (ex.: palm)" style="width:100%;max-width:420px;margin-bottom:6px">';
    echo '<div id="tsp-times-lista" style="max-height:260px;overflow:auto;border:1px solid #dcdcde;border-radius:6px;padding:8px;max-width:420px;background:#fff">';
    foreach ((array) $times as $t) {
        if (!is_object($t)) {
            continue;
        }
        echo '<label style="display:block;margin:2px 0" data-nome="' . esc_attr(remove_accents(mb_strtolower($t->name))) . '"><input type="checkbox" name="tsp_times_cobre[]" value="' . (int) $t->term_id . '"' . checked(in_array((int) $t->term_id, $sel, true), true, false) . '> ' . esc_html($t->name) . '</label>';
    }
    echo '</div><p class="description">Marque os clubes que você acompanha. Todos os dias às 8h, 12h e 18h aparecem no seu painel sugestões de pauta desses times.</p>';
    echo "<script>(function(){var f=document.getElementById('tsp-times-filtro');if(!f)return;f.addEventListener('input',function(){var q=f.value.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();document.querySelectorAll('#tsp-times-lista label').forEach(function(l){l.style.display=(!q||l.dataset.nome.indexOf(q)>-1||l.querySelector('input').checked)?'block':'none';});});})();</script>";
    echo '</td></tr></table>';
}
add_action('show_user_profile', 'tsp_rel_campo_times');
add_action('edit_user_profile', 'tsp_rel_campo_times');

function tsp_rel_salvar_times($id)
{
    if (!current_user_can('edit_user', $id) || !isset($_POST['tsp_times_cobre_enviado'])) {
        return;
    }
    $v = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['tsp_times_cobre'] ?? array())))));
    update_user_meta($id, 'tsp_times_cobre', $v);
}
add_action('personal_options_update', 'tsp_rel_salvar_times');
add_action('edit_user_profile_update', 'tsp_rel_salvar_times');
add_action('show_user_profile', function () {
    echo '<input type="hidden" name="tsp_times_cobre_enviado" value="1">';
}, 1);
add_action('edit_user_profile', function () {
    echo '<input type="hidden" name="tsp_times_cobre_enviado" value="1">';
}, 1);

/* ---------- Lista de clubes cobertos para o robô (sem nomes de pessoas) ---------- */

add_action('rest_api_init', function () {
    register_rest_route('tsp/v1', '/cobertura', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            $clubes = array();
            foreach (get_users(array('capability' => array('edit_posts'), 'fields' => 'ID')) as $uid) {
                foreach (tsp_rel_times_cobre($uid) as $tid) {
                    $t = get_term($tid, 'times');
                    $redacao = function_exists('tsp_rel_clubes_redacao') ? tsp_rel_clubes_redacao() : array();
                    if ($t && !is_wp_error($t) && (!$redacao || isset($redacao[$t->slug]))) {
                        $clubes[$t->slug] = $t->name;
                    }
                }
            }
            ksort($clubes);
            $r = rest_ensure_response(array('clubes' => $clubes));
            $r->header('X-Robots-Tag', 'noindex');
            return $r;
        },
    ));
});

/* ---------- Lê as pautas da Base TSP ---------- */

add_filter('cron_schedules', function ($s) {
    $s['tsp_pautas_15'] = array('interval' => 900, 'display' => 'A cada 15 minutos (TSP Pautas)');
    return $s;
});
add_action('init', function () {
    if (!wp_next_scheduled('tsp_pautas_ler')) {
        wp_schedule_event(time() + 180, 'tsp_pautas_15', 'tsp_pautas_ler');
    }
});
add_action('tsp_pautas_ler', 'tsp_pautas_importar');

function tsp_pautas_importar()
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 900), TSP_PAUTAS_URL), array('timeout' => 20));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return false;
    }
    $d = json_decode(wp_remote_retrieve_body($r), true);
    if (!is_array($d) || !isset($d['itens'])) {
        return false;
    }
    $ok = array();
    foreach ((array) $d['itens'] as $it) {
        $fontes = array();
        foreach (array_slice((array) ($it['fontes'] ?? array()), 0, 4) as $f) {
            $u = esc_url_raw($f['url'] ?? '');
            if ($u && preg_match('~^https://~', $u)) {
                $fontes[] = array('nome' => sanitize_text_field($f['nome'] ?? ''), 'url' => $u);
            }
        }
        if (empty($it['id']) || empty($it['clube']) || empty($it['titulo']) || !$fontes) {
            continue;
        }
        $ok[] = array('id' => sanitize_key($it['id']), 'clube' => sanitize_title($it['clube']), 'titulo' => sanitize_text_field($it['titulo']), 'resumo' => sanitize_textarea_field($it['resumo'] ?? ''),
            'angulo' => sanitize_text_field($it['angulo'] ?? ''), 'quando' => sanitize_text_field($it['quando'] ?? ''), 'fontes' => $fontes);
    }
    update_option('tsp_pautas', array('gerado' => sanitize_text_field($d['gerado'] ?? ''), 'itens' => $ok), false);
    return true;
}

/* ---------- "Vou fazer" ---------- */

add_action('wp_ajax_tsp_pauta_pegar', function () {
    check_ajax_referer('tsp_pauta', 'nonce');
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('Sem permissão.');
    }
    $id = sanitize_key($_POST['id'] ?? '');
    $donos = (array) get_option('tsp_pautas_donos', array());
    if (!empty($donos[$id]) && (int) $donos[$id] !== get_current_user_id()) {
        $u = get_userdata((int) $donos[$id]);
        wp_send_json_error(($u ? $u->display_name : 'Um colega') . ' já está nessa pauta.');
    }
    $donos[$id] = get_current_user_id();
    update_option('tsp_pautas_donos', array_slice($donos, -500, null, true), false);
    wp_send_json_success('É sua! Bom trabalho. ✍️');
});

// Pautas dos times do redator (sem as que o Thiago, a Máquina ou outro já pegaram)
function tsp_rel_pautas_minhas($autor, $slugs = null)
{
    if ($slugs === null) {
        $slugs = array();
        foreach (tsp_rel_times_cobre($autor) as $tid) {
            $t = get_term($tid, 'times');
            if ($t && !is_wp_error($t)) {
                $slugs[$t->slug] = $t->name;
            }
        }
    }
    $p = get_option('tsp_pautas', array());
    $donos = (array) get_option('tsp_pautas_donos', array());
    return array_filter(array_merge((array) ($p['itens'] ?? array()), tsp_pautas_da_maquina()), function ($it) use ($slugs, $donos, $autor) {
        // Pauta que o Thiago ou a Máquina já fizeram sai da lista do redator (08/11/2026)
        $d = (int) ($donos[$it['id']] ?? 0);
        return isset($slugs[$it['clube']]) && (!$d || $d === (int) $autor || tsp_corr_autor_redator($d));
    });
}

function tsp_rel_pautas_html($autor)
{
    $tids = tsp_rel_times_cobre($autor);
    if (!$tids) {
        return '<h3>Pautas do dia</h3><div class="tsp-p-msg aviso">Conta pra gente quais times você cobre e, todo dia às 8h, 12h e 18h, chegam aqui sugestões de pauta fresquinhas desses clubes. <a href="' . esc_url(admin_url('profile.php#tsp-times-cobre')) . '">Escolher meus times →</a></div>';
    }
    $slugs = array();
    foreach ($tids as $tid) {
        $t = get_term($tid, 'times');
        if ($t && !is_wp_error($t)) {
            $slugs[$t->slug] = $t->name;
        }
    }
    $donos = (array) get_option('tsp_pautas_donos', array());
    $minhas = tsp_rel_pautas_minhas($autor, $slugs);
    $h = '<h3>Pautas do dia para os seus times (' . count($minhas) . ')</h3>';
    if (!$minhas) {
        return $h . '<p>Ainda não chegaram pautas para ' . esc_html(implode(', ', $slugs)) . '. As próximas saem às 8h, 12h e 18h.</p>';
    }
    $h .= '<div class="tsp-pautas">';
    foreach (array_slice(array_reverse($minhas), 0, 12) as $it) {
        $dono = (int) ($donos[$it['id']] ?? 0);
        $h .= '<div class="tsp-pauta"><span class="tsp-pauta-clube">' . esc_html($slugs[$it['clube']]) . '</span>' . ($it['quando'] ? ' <small>' . esc_html($it['quando']) . '</small>' : '') . '<strong>' . esc_html($it['titulo']) . '</strong>';
        $h .= $it['resumo'] ? '<p>' . esc_html($it['resumo']) . '</p>' : '';
        $h .= $it['angulo'] ? '<p><em>Ideia de ângulo: ' . esc_html($it['angulo']) . '</em></p>' : '';
        $h .= !empty($it['fontes']) ? '<p>Fontes para conferir: ' : '<p><em>Pedida pela Máquina: apure com o clube.</em>';
        foreach ((array) ($it['fontes'] ?? array()) as $i => $f) {
            $h .= ($i ? ' · ' : '') . '<a href="' . esc_url($f['url']) . '" target="_blank" rel="noopener nofollow">' . esc_html($f['nome'] ?: wp_parse_url($f['url'], PHP_URL_HOST)) . '</a>';
        }
        $h .= '</p>';
        if ($dono && $dono !== (int) $autor) {
            $u = get_userdata($dono);
            $h .= '<small>✍️ ' . esc_html($u ? $u->display_name : 'Um colega') . ' já está nessa.</small>';
        } elseif ($dono) {
            $h .= '<small>✍️ Essa é sua!</small>';
        } else {
            $h .= '<button type="button" class="button button-small" data-pauta="' . esc_attr($it['id']) . '">Vou fazer</button>';
        }
        $h .= '</div>';
    }
    $h .= '</div><p class="description">Pautas são sugestões: confira nas fontes, apure e escreva com as suas palavras.</p>';
    $h .= "<style>.tsp-pautas{display:grid;gap:8px}.tsp-pauta{border:1px solid #dcdcde;border-radius:8px;padding:8px 10px}.tsp-pauta strong{display:block;font-size:14px;margin:4px 0}.tsp-pauta p{margin:4px 0}.tsp-pauta-clube{background:#E8862A;color:#111;border-radius:99px;padding:1px 8px;font-size:11px;font-weight:700}</style>";
    $h .= "<script>document.addEventListener('click',function(e){var b=e.target.closest('[data-pauta]');if(!b)return;var fd=new FormData();fd.append('action','tsp_pauta_pegar');fd.append('nonce'," . wp_json_encode(wp_create_nonce('tsp_pauta')) . ");fd.append('id',b.getAttribute('data-pauta'));b.disabled=true;fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){var s=document.createElement('small');s.textContent=j.data;b.replaceWith(s);});});</script>";
    return $h;
}


/* ---------- Pautas pedidas pela Máquina (sem notícia confirmada) também vão para quem cobre o clube ---------- */
function tsp_pautas_da_maquina()
{
    $av = (array) get_option('tsp_maq_avisos', array());
    $out = array();
    foreach (array_slice((array) ($av['avisos'] ?? array()), -40) as $a) {
        if (empty($a['clube']) || (empty($a['sugestao']) && empty($a['motivo']))) {
            continue;
        }
        if (!empty($a['quando']) && strtotime($a['quando']) < time() - 2 * DAY_IN_SECONDS) {
            continue;
        }
        $t = wp_strip_all_tags($a['sugestao'] ?: $a['motivo']);
        $out[] = array('id' => 'mq' . substr(md5($a['clube'] . $t), 0, 10), 'clube' => sanitize_title($a['clube']), 'titulo' => mb_substr($t, 0, 160), 'resumo' => mb_strlen($t) > 160 ? $t : '', 'angulo' => '', 'quando' => !empty($a['quando']) ? wp_date('d/m H\h', strtotime($a['quando'])) : '', 'fontes' => array());
    }
    return $out;
}

/* ---------- Thiago (administrador) e coordenação: pautas de TODOS os clubes ---------- */
function tsp_rel_pautas_todas_html()
{
    $p = get_option('tsp_pautas', array());
    $donos = (array) get_option('tsp_pautas_donos', array());
    $todas = array_reverse(array_merge((array) ($p['itens'] ?? array()), tsp_pautas_da_maquina()));
    $h = '<p>Pautas do pauteiro-robô e as pedidas pela Máquina, de todos os clubes. Clique em <strong>Eu faço</strong> e ela sai da lista dos redatores.</p>';
    if (!$todas) {
        return $h . '<p>Sem pautas nas últimas 48 horas.</p>';
    }
    $h .= '<div class="tsp-pautas" style="max-height:520px;overflow:auto">';
    foreach (array_slice($todas, 0, 60) as $it) {
        $t = get_term_by('slug', $it['clube'], 'times');
        $dono = (int) ($donos[$it['id']] ?? 0);
        $h .= '<div class="tsp-pauta"><span class="tsp-pauta-clube">' . esc_html($t ? $t->name : $it['clube']) . '</span>' . ($it['quando'] ? ' <small>' . esc_html($it['quando']) . '</small>' : '') . '<strong>' . esc_html($it['titulo']) . '</strong>';
        foreach ((array) ($it['fontes'] ?? array()) as $i => $f) {
            $h .= ($i ? ' · ' : '') . '<a href="' . esc_url($f['url']) . '" target="_blank" rel="noopener nofollow">' . esc_html($f['nome'] ?: wp_parse_url($f['url'], PHP_URL_HOST)) . '</a>';
        }
        if ($dono) {
            $u = get_userdata($dono);
            $h .= '<br><small>✍️ ' . esc_html($u ? $u->display_name : '—') . '</small>';
        } else {
            $h .= '<br><button type="button" class="button button-small" data-pauta="' . esc_attr($it['id']) . '">Eu faço</button>';
        }
        $h .= '</div>';
    }
    $h .= '</div>';
    $h .= "<style>.tsp-pautas{display:grid;gap:8px}.tsp-pauta{border:1px solid #dcdcde;border-radius:8px;padding:8px 10px}.tsp-pauta strong{display:block;font-size:14px;margin:4px 0}.tsp-pauta-clube{background:#E8862A;color:#111;border-radius:99px;padding:1px 8px;font-size:11px;font-weight:700}</style>";
    $h .= "<script>document.addEventListener('click',function(e){var b=e.target.closest('[data-pauta]');if(!b)return;var fd=new FormData();fd.append('action','tsp_pauta_pegar');fd.append('nonce'," . wp_json_encode(wp_create_nonce('tsp_pauta')) . ");fd.append('id',b.getAttribute('data-pauta'));b.disabled=true;fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){var s=document.createElement('small');s.textContent=j.data;b.replaceWith(s);});});</script>";
    return $h;
}

add_action('wp_dashboard_setup', function () {
    if (current_user_can('manage_options') || (function_exists('tsp_rel_coord') && tsp_rel_coord())) {
        wp_add_dashboard_widget('tsp_pautas_todas', '📝 Pautas de todos os clubes', function () {
            echo tsp_rel_pautas_todas_html(); // phpcs:ignore
        });
    }
}, 20);
