<?php
/**
 * Nota das matérias (14/11/2026, regra do Thiago): todo dia às 23h59 o site corrige, como um professor de redação,
 * cada matéria que os redatores publicaram no dia e dá uma nota de 0 a 10.
 *
 * Custo zero: roda no próprio WordPress, sem inteligência artificial e sem serviço pago. A veracidade vem da checagem
 * que o editor-chefe automático e a coordenação já fazem (pedidos de erro de informação e plágio); o resto
 * (lide, clareza, profundidade, português, SEO, AEO e GEO) é medido no texto por regras fixas.
 *
 *  - Cada redator recebe à noite (painel + e-mail) a nota de cada matéria, a média, a posição no ranking e
 *    onde está perdendo pontos. É orientação: não trava a publicação e não mexe no pagamento.
 *  - Administrador e coordenação recebem o ranking do dia.
 *  - Relatório → 🎓 Notas: ranking por período e relatório individual de cada redator.
 *  - Nos 7 dias seguintes a nota é refeita todas as noites: se aparecer erro de informação, ela cai.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_NOTAS_VERSAO = 1;

// chave => [nome, peso, o que o professor olha]
function tsp_notas_criterios()
{
    return array(
        'veracidade' => array('Veracidade e apuração', 2.0, 'Informação certa, conferida e com a origem dita (quem informou, em que veículo, em que nota oficial).'),
        'lide' => array('Lide e entendimento da notícia', 1.5, 'O primeiro parágrafo conta o principal: quem, o quê, quando e onde; o começo entrega o que o título promete.'),
        'clareza' => array('Clareza e coesão', 1.5, 'Frases curtas e diretas, uma ideia por frase, parágrafos curtos.'),
        'profundidade' => array('Profundidade e contexto', 1.5, 'Texto completo: dados, números, falas, contexto e o que vem a seguir.'),
        'lingua' => array('Gramática, ortografia e pontuação', 1.5, 'Português correto: acentos, crase, vírgulas, espaços e pontuação.'),
        'seo' => array('SEO (Google)', 1.0, 'Título com o clube e a informação principal, intertítulos, foto com crédito, subtítulo e tags.'),
        'aeo' => array('AEO (respostas diretas)', 0.5, 'Resposta logo na primeira frase e intertítulos em forma de pergunta, como as pessoas buscam.'),
        'geo' => array('GEO (citação por IAs)', 0.5, 'Fonte com link, atribuição clara e fatos concretos (nomes, números, datas) que uma IA possa citar.'),
    );
}

// código => [critério, desconto por ocorrência, máximo de desconto, feedback para o redator, dica geral]
function tsp_notas_problemas()
{
    return array(
        'plagio' => array('veracidade', 10, 10, 'Matéria com trecho copiado de outro site sem crédito (plágio): nota zero.', 'Nunca copie frases de outro veículo: leia, entenda e escreva com as suas palavras, citando a fonte.'),
        'erro_grave' => array('veracidade', 2.0, 2.0, 'O editor-chefe encontrou erro de informação e ele não foi corrigido no prazo.', 'Confira placar, nomes, datas e números em duas fontes antes de publicar.'),
        'erro_corrigido' => array('veracidade', 1.0, 2.0, 'O editor-chefe encontrou erro de informação (você corrigiu, mas ele chegou a ser publicado).', 'Confira placar, nomes, datas e números em duas fontes antes de publicar: o leitor viu a informação errada.'),
        'sem_origem' => array('veracidade', 0.8, 0.8, 'O texto não diz de onde veio a informação (nenhum "segundo", "informou", "em nota" ou link para a fonte).', 'Sempre diga a origem: "segundo o clube", "em nota", "de acordo com o ge", com link.'),
        'lide_longo' => array('lide', 0.4, 0.4, 'O primeiro parágrafo tem %s palavras. O lide bom tem até 60: diga logo o principal e deixe o detalhe para depois.', 'Lide curto: até 60 palavras, com quem, o quê, quando e onde.'),
        'lide_curto' => array('lide', 0.3, 0.3, 'O primeiro parágrafo tem só %s palavras: faltou contar o fato completo (quem, o quê, quando e onde).', 'O lide precisa contar a notícia inteira em uma ou duas frases.'),
        'lide_sem_clube' => array('lide', 0.4, 0.4, 'O primeiro parágrafo não cita o clube da matéria.', 'Cite o clube logo no primeiro parágrafo: é ele que o leitor e o Google procuram.'),
        'lide_sem_quando' => array('lide', 0.3, 0.3, 'O primeiro parágrafo não diz quando o fato aconteceu (dia da semana ou data).', 'Diga quando: "nesta sexta-feira (13)", "no sábado (14), às 16h".'),
        'titulo_desconectado' => array('lide', 0.4, 0.4, 'O começo do texto não entrega o que o título promete (poucas palavras do título aparecem nos dois primeiros parágrafos).', 'O título e o primeiro parágrafo contam a mesma notícia: o que está no título precisa estar no começo do texto.'),
        'frases_longas' => array('clareza', 0.3, 0.6, 'As frases têm em média %s palavras. O ideal é até 20: quebre as frases longas em duas.', 'Uma ideia por frase. Frase com mais de 25 palavras quase sempre pode virar duas.'),
        'frase_gigante' => array('clareza', 0.2, 0.6, 'Frase com %s palavras, difícil de acompanhar: "%s"', 'Corte frases com mais de 40 palavras: ponto final no lugar de vírgula ou de "e".'),
        'paragrafo_longo' => array('clareza', 0.2, 0.4, 'Parágrafo com %s palavras: divida em dois ou três.', 'Parágrafo de notícia tem de 2 a 4 frases (até 70 palavras), principalmente no celular.'),
        'muro_de_texto' => array('clareza', 0.4, 0.4, 'O texto tem %s palavras em um ou dois parágrafos só: fica cansativo de ler.', 'Separe o texto em parágrafos curtos e use intertítulos.'),
        'texto_curto' => array('profundidade', 0.3, 1.0, 'Texto com %s palavras: falta contexto (números, falas, próximo jogo, situação na tabela).', 'Uma matéria completa tem de 350 a 600 palavras: o fato, os detalhes, as falas e o contexto.'),
        'poucos_dados' => array('profundidade', 0.2, 0.2, 'Quase não há dados concretos (números, datas, placares, valores).', 'Use números: placar, minutos, idade, contrato até quando, posição na tabela, data do próximo jogo.'),
        'sem_fala_contexto' => array('profundidade', 0.3, 0.3, 'Não há fala de ninguém nem informação atribuída: o texto fica raso.', 'Traga a fala do técnico, do jogador ou a nota oficial, entre aspas e com o nome e o cargo de quem falou.'),
        'n_antes_pb' => array('lingua', 0.15, 0.45, 'Ortografia: "%s" (antes de P e B se usa M).', 'Antes de P e B, sempre M: "campeonato", "pernambucano", "embate".'),
        'erro_comum' => array('lingua', 0.15, 0.6, 'Português: "%s" → %s.', 'Revise os erros mais comuns: crase, "há/atrás", "fazem dois anos", "a partir".'),
        'espaco_pontuacao' => array('lingua', 0.1, 0.3, 'Espaço antes da pontuação: "%s".', 'Vírgula e ponto ficam colados na palavra anterior, com espaço depois.'),
        'sem_espaco_depois' => array('lingua', 0.1, 0.3, 'Falta espaço depois da pontuação: "%s".', 'Depois de vírgula e ponto, sempre um espaço.'),
        'minuscula_apos_ponto' => array('lingua', 0.1, 0.3, 'Frase começando com letra minúscula depois do ponto: "%s".', 'Depois do ponto final, letra maiúscula.'),
        'palavra_repetida' => array('lingua', 0.1, 0.3, 'Palavra repetida: "%s".', 'Releia o texto antes de publicar: palavras repetidas e erros de digitação aparecem na releitura.'),
        'aspas_parenteses' => array('lingua', 0.1, 0.3, 'Aspas ou parênteses abertos e não fechados no parágrafo: "%s".', 'Toda aspa e todo parêntese aberto precisa ser fechado.'),
        'espaco_aspas' => array('lingua', 0.05, 0.15, 'Espaço sobrando dentro das aspas: "%s".', 'As aspas ficam coladas no texto da fala: “assim”, e não “ assim ”.'),
        'sem_ponto_final' => array('lingua', 0.1, 0.3, 'Parágrafo sem pontuação no fim: "%s".', 'Todo parágrafo termina com ponto (ou interrogação, exclamação, aspas).'),
        'pontuacao_dupla' => array('lingua', 0.1, 0.2, 'Pontuação exagerada: "%s".', 'Em notícia, um ponto de exclamação no máximo, e só em fala.'),
        'placar_com_x' => array('lingua', 0.05, 0.05, 'Placar escrito como "%s" no texto: escreva "2 a 1".', 'No texto, o placar é "2 a 1"; o "2 x 1" fica para o título, se precisar.'),
        'titulo_tamanho' => array('seo', 0.2, 0.2, 'Título com %s caracteres: o ideal para o Google é entre 40 e 75.', 'Título de 40 a 75 caracteres, com o clube e a informação principal no começo.'),
        'titulo_sem_clube' => array('seo', 0.2, 0.2, 'O título não cita o clube marcado na matéria.', 'Coloque o nome do clube no título: é a palavra mais buscada.'),
        'sem_intertitulo' => array('seo', 0.2, 0.2, 'Texto com mais de 300 palavras e nenhum intertítulo.', 'A cada 3 ou 4 parágrafos, um intertítulo (de preferência uma pergunta, como "Quando é o próximo jogo?").'),
        'sem_foto' => array('seo', 0.2, 0.2, 'Matéria sem foto de destaque.', 'Toda matéria precisa de foto real de destaque, com crédito.'),
        'foto_sem_credito' => array('seo', 0.1, 0.1, 'Foto sem crédito.', 'Preencha o crédito da foto: "Foto: Fulano/Clube".'),
        'sem_subtitulo' => array('seo', 0.1, 0.1, 'Matéria sem subtítulo.', 'O subtítulo completa o título com um dado novo.'),
        'poucas_tags' => array('seo', 0.1, 0.1, 'Menos de 3 tags.', 'Use de 3 a 6 tags: clube, adversário, jogador e competição.'),
        'primeira_frase_longa' => array('aeo', 0.2, 0.2, 'A primeira frase tem %s palavras: a resposta precisa vir mais direta.', 'A primeira frase responde à pergunta do leitor em até 30 palavras (o Google e os assistentes leem a primeira frase).'),
        'sem_pergunta' => array('aeo', 0.2, 0.2, 'Nenhum intertítulo em forma de pergunta.', 'Use intertítulos que são perguntas de busca: "Onde assistir?", "Quem é o novo técnico?", e responda logo abaixo.'),
        'paragrafos_densos' => array('aeo', 0.1, 0.1, 'Parágrafos longos em média (%s palavras): difícil achar a resposta.', 'Parágrafos curtos facilitam para o Google mostrar o seu texto como resposta.'),
        'sem_link_fonte' => array('geo', 0.2, 0.2, 'Nenhum link para a fonte da informação.', 'Coloque o link da fonte (nota do clube, matéria original, comunicado): as IAs citam quem mostra a origem.'),
        'sem_atribuicao' => array('geo', 0.15, 0.15, 'Nenhuma atribuição clara ("disse", "afirmou", "segundo", "em nota").', 'Atribua cada informação importante a alguém: "disse o técnico Fulano", "segundo a FPF".'),
        'poucas_entidades' => array('geo', 0.15, 0.15, 'Poucos fatos concretos (nomes próprios e números) para uma IA citar.', 'Nomes completos, cargos, datas, números e locais deixam o texto citável.'),
    );
}

/* ---------- Ferramentas de texto ---------- */

function tsp_notas_sem_acento($s)
{
    $s = mb_strtolower((string) $s, 'UTF-8');
    return strtr($s, array('á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'é' => 'e', 'ê' => 'e', 'è' => 'e', 'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ò' => 'o', 'ú' => 'u', 'ù' => 'u', 'ü' => 'u', 'ç' => 'c'));
}

function tsp_notas_limpar($h)
{
    $h = html_entity_decode(strip_tags((string) $h), ENT_QUOTES, 'UTF-8');
    return trim(preg_replace('~[\s\x{00A0}]+~u', ' ', $h));
}

// Parágrafos (de <p> e de <br><br>) e intertítulos do HTML
function tsp_notas_partes($html)
{
    $html = preg_replace('~<!--.*?-->~s', '', (string) $html);
    $html = preg_replace('~<(script|style|figure|iframe|figcaption)[^>]*>.*?</\1>~is', ' ', $html);
    $inter = array();
    if (preg_match_all('~<h[2-4][^>]*>(.*?)</h[2-4]>~is', $html, $m)) {
        foreach ($m[1] as $x) {
            $t = tsp_notas_limpar($x);
            if ($t !== '') {
                $inter[] = $t;
            }
        }
    }
    $html = preg_replace('~<h[2-4][^>]*>.*?</h[2-4]>~is', "\n\n", $html);
    $html = preg_replace('~(<br\s*/?>\s*){2,}~i', "\n\n", $html);
    $html = preg_replace('~<br\s*/?>~i', "\u{2028}", $html); // quebra simples: linha nova dentro do parágrafo (listas)
    $html = preg_replace('~</(p|li|blockquote|div|ul|ol)>~i', "\n\n", $html);
    $pars = array();
    foreach (preg_split("~\n\s*\n~", $html) as $p) {
        $t = tsp_notas_limpar($p);
        if (preg_match_all('~[\p{L}\d]+~u', $t) >= 4) {
            $pars[] = $t;
        }
    }
    return array($pars, $inter);
}

function tsp_notas_palavras($t)
{
    return (int) preg_match_all('~[\p{L}\d]+(?:[-\'][\p{L}\d]+)*~u', (string) $t);
}

function tsp_notas_frases($t)
{
    $f = preg_split('~(?<=[.!?…])["”»]?\s+(?=["“«—\-]?[\p{Lu}\d])|\s*\x{2028}\s*~u', (string) $t);
    return array_values(array_filter(array_map('trim', $f), function ($x) {
        return tsp_notas_palavras($x) >= 3;
    }));
}

function tsp_notas_corte($t, $n = 110)
{
    $t = trim((string) $t);
    return mb_strlen($t) > $n ? rtrim(mb_substr($t, 0, $n)) . '…' : $t;
}

function tsp_notas_trecho($texto, $pos, $len)
{
    $ini = max(0, $pos - 25);
    return trim(mb_substr($texto, $ini, $len + 50));
}

/* ---------- O professor: avalia uma matéria ---------- */

/**
 * $d = [titulo, html, clubes => [nomes], foto => bool, credito => bool, subtitulo => bool, tags => int,
 *       erros => ['aberto' => n, 'corrigido' => n], plagio => bool]
 * Volta [nota, c => [critério => pontos], p => [[código, texto do feedback]]]
 */
function tsp_notas_avaliar($d)
{
    $cri = tsp_notas_criterios();
    $tab = tsp_notas_problemas();
    $achados = array();
    $add = function ($cod, $args = array()) use (&$achados, $tab) {
        $txt = $tab[$cod][3];
        if ($args) {
            $txt = vsprintf($txt, array_map(function ($a) {
                return is_string($a) ? tsp_notas_corte($a, 110) : $a;
            }, (array) $args));
        }
        $achados[] = array($cod, $txt);
    };

    list($pars, $inter) = tsp_notas_partes($d['html'] ?? '');
    $texto = implode("\n", $pars);
    $plano = tsp_notas_sem_acento($texto);
    $tit = tsp_notas_limpar($d['titulo'] ?? '');
    $n_pal = tsp_notas_palavras($texto);
    $lide = $pars[0] ?? '';
    $clubes = array_filter(array_map('tsp_notas_sem_acento', (array) ($d['clubes'] ?? array())));
    $tem_clube = function ($t) use ($clubes) {
        $t = tsp_notas_sem_acento($t);
        foreach ($clubes as $c) {
            // nome inteiro ou a palavra mais forte do nome (ex.: "Red Bull Bragantino" → "bragantino")
            $partes = array_filter(preg_split('~[\s\-]+~u', $c), function ($w) {
                return mb_strlen($w) >= 5 && !in_array($w, array('clube', 'esporte', 'futebol', 'feminino', 'associacao', 'atletica', 'sociedade', 'esportiva'), true);
            });
            if (strpos($t, $c) !== false) {
                return true;
            }
            foreach ($partes as $w) {
                if (preg_match('~\b' . preg_quote($w, '~') . '\b~u', $t)) {
                    return true;
                }
            }
        }
        return !$clubes; // sem clube marcado: não desconta aqui (o relatório já cobra "Sem time marcado")
    };

    $atrib_re = '~(*UCP)\b(segundo|de acordo com|conforme|informou|informa|informaram|disse|disseram|afirmou|afirmaram|declarou|explicou|confirmou|confirmaram|anunciou|anunciaram|divulgou|publicou|em nota|em comunicado|comunicou|revelou|apurou|destacou|ressaltou|completou|contou|garantiu|avaliou|comentou|projetou|admitiu|lembrou|escalou|oficializou|detalhou|divulgad[ao]s?|informad[ao]s?|confirmad[ao]s?|anunciad[ao]s?|publicad[ao]s?)\b~u';
    $tem_atrib = (bool) preg_match($atrib_re, $plano) || (bool) preg_match('~(*UCP)\b(segundo|de acordo com|conforme)\b~u', $plano);
    $links_ext = preg_match_all('~<a\s[^>]*href=["\']https?://(?![^"\']*tudosobrepaulista\.com\.br)[^"\']+["\']~i', (string) ($d['html'] ?? ''));
    $falas = preg_match_all('~[“"«][^”"»]{15,}[”"»]~u', $texto) + preg_match_all('~—\s*\p{Lu}[\p{L}\s]+,~u', $texto);
    $numeros = preg_match_all('~\d+~u', $texto);

    /* Veracidade */
    if (!empty($d['plagio'])) {
        $add('plagio');
    }
    for ($i = 0; $i < (int) ($d['erros']['aberto'] ?? 0); $i++) {
        $add('erro_grave');
    }
    for ($i = 0; $i < (int) ($d['erros']['corrigido'] ?? 0); $i++) {
        $add('erro_corrigido');
    }
    if (!$tem_atrib && !$links_ext) {
        $add('sem_origem');
    }

    /* Lide */
    $n_lide = tsp_notas_palavras($lide);
    if ($n_lide > 70) {
        $add('lide_longo', array($n_lide));
    } elseif ($n_lide && $n_lide < 15) {
        $add('lide_curto', array($n_lide));
    }
    if ($lide !== '' && !$tem_clube($lide . ' ' . ($pars[1] ?? ''))) {
        $add('lide_sem_clube');
    }
    $quando = '~(*UCP)\b(segunda|terca|quarta|quinta|sexta)(-feira)?\b|\bsabado\b|\bdomingo\b|\bnest[ea]s?\b|\bontem\b|\bhoje\b|\bamanha\b|\d{1,2}/\d{1,2}|\(\d{1,2}\)|\b\d{1,2}(º)? de (janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\b|\b(na|no) (ultim[ao]|proxim[ao]|madrugada|manha|tarde|noite)\b|\bem (19|20)\d\d\b|\b(19|20)\d\d\b~u';
    if ($lide !== '' && !preg_match($quando, tsp_notas_sem_acento($lide . ' ' . ($pars[1] ?? '')))) {
        $add('lide_sem_quando');
    }
    $vazias = array('sobre', 'depois', 'antes', 'contra', 'durante', 'entre', 'ainda', 'apenas', 'diretoria', 'clube', 'para', 'pela', 'pelo', 'como', 'mais', 'menos', 'quando', 'onde', 'qual', 'quem', 'neste', 'nesta', 'desta', 'deste', 'seu', 'sua', 'seus', 'suas', 'caso', 'temporada');
    $pt = array_values(array_filter(preg_split('~[^\p{L}\d]+~u', tsp_notas_sem_acento($tit)), function ($w) use ($vazias) {
        return mb_strlen($w) >= 5 && !in_array($w, $vazias, true);
    }));
    if (count($pt) >= 3) {
        $ini = tsp_notas_sem_acento($lide . ' ' . ($pars[1] ?? ''));
        $ach = 0;
        foreach ($pt as $w) {
            $ach += (strpos($ini, mb_substr($w, 0, max(5, mb_strlen($w) - 2))) !== false) ? 1 : 0;
        }
        if ($ach / count($pt) < 0.4) {
            $add('titulo_desconectado');
        }
    }

    /* Clareza */
    $frases = tsp_notas_frases($texto);
    $tam = array_map('tsp_notas_palavras', $frases);
    $media_f = $tam ? array_sum($tam) / count($tam) : 0;
    if ($media_f > 25) {
        $add('frases_longas', array(number_format($media_f, 0)));
        $achados[count($achados) - 1][] = 2; // desconto dobrado
    } elseif ($media_f > 20) {
        $add('frases_longas', array(number_format($media_f, 0)));
    }
    $gig = 0;
    foreach ($frases as $i => $f) {
        if ($tam[$i] > 40 && $gig < 3) {
            $add('frase_gigante', array($tam[$i], $f));
            $gig++;
        }
    }
    $longos = 0;
    $soma_p = 0;
    foreach ($pars as $p) {
        $np = tsp_notas_palavras($p);
        $soma_p += $np;
        if ($np > 90 && $longos < 2) {
            $add('paragrafo_longo', array($np));
            $longos++;
        }
    }
    if (count($pars) <= 2 && $n_pal > 220) {
        $add('muro_de_texto', array($n_pal));
    }

    /* Profundidade */
    if ($n_pal < 200) {
        $add('texto_curto', array($n_pal));
        $achados[count($achados) - 1][] = 4; // desconto de 1,0 (máximo)
    } elseif ($n_pal < 280) {
        $add('texto_curto', array($n_pal));
        $achados[count($achados) - 1][] = 2;
    } elseif ($n_pal < 350) {
        $add('texto_curto', array($n_pal));
    }
    if ($numeros < 3) {
        $add('poucos_dados');
    }
    if (!$falas && !$tem_atrib) {
        $add('sem_fala_contexto');
    }

    /* Português */
    $vistos = array();
    $uma = function ($cod, $args) use (&$vistos, $add) {
        $k = $cod . '|' . implode('|', (array) $args);
        if (!isset($vistos[$k])) {
            $vistos[$k] = 1;
            $add($cod, $args);
        }
    };
    if (preg_match_all('~(*UCP)\b[\p{Ll}]*n[pb][\p{Ll}]*\b~u', $texto, $m)) {
        foreach (array_slice(array_unique($m[0]), 0, 3) as $w) {
            if (!preg_match('~^(online|inbox|input|snapchat|onboarding)$~', $w)) {
                $uma('n_antes_pb', array($w));
            }
        }
    }
    $comuns = array(
        '~(*UCP)\bà partir\b~iu' => 'escreva "a partir" (sem crase)',
        '~(*UCP)\bà (ele|eles|ela|elas|você|vocês|um|uma|uns|umas|todos|todas|esse|essa|este|esta|isso|isto|cada|qualquer|nenhum|nenhuma|seu|sua|meu|minha)\b~iu' => 'sem crase antes de pronome, artigo indefinido ou palavra masculina',
        '~(*UCP)\bà (jogo|time|clube|técnico|treinador|campeonato|estádio|elenco|grupo|título|gol|pé|domingo|sábado)\b~iu' => 'sem crase antes de palavra masculina',
        '~(*UCP)\b(excessão|excessões)\b~iu' => 'o certo é "exceção"',
        '~(*UCP)\bconcerteza\b~iu' => 'o certo é "com certeza"',
        '~(*UCP)\bderrepente\b~iu' => 'o certo é "de repente"',
        '~(*UCP)\bmenas\b~iu' => 'o certo é "menos"',
        '~(*UCP)\bseje\b~iu' => 'o certo é "seja"',
        '~(*UCP)\bpor que (?=[\p{Ll}]+ (o|a|os|as) )~u' => '',
        '~(*UCP)\bfazem (dois|duas|três|quatro|cinco|seis|sete|oito|nove|dez|\d+|muitos|vários|alguns|poucos) (anos|meses|dias|semanas|horas)\b~iu' => 'tempo decorrido usa "faz" no singular ("faz dois anos")',
        '~(*UCP)\bhá (\S+ ){1,3}atrás\b~iu' => 'redundância: use só "há" ou só "atrás"',
        '~(*UCP)\ba nível de\b~iu' => 'use "em nível de" ou "no âmbito de"',
        '~(*UCP)\bvai estar [\p{L}]+ndo\b~iu' => 'gerundismo: use "vai fazer"',
        '~(*UCP)\bentre eu\b~iu' => 'o certo é "entre mim"',
        '~(*UCP)\b(pra|pro|pros|pras|vc|pq|tb|tbm|vcs)\b~u' => 'linguagem informal: use "para", "você", "porque", "também"',
        '~(*UCP)\bmeia-noite e meio\b~iu' => 'o certo é "meia-noite e meia"',
        '~(*UCP)\bperca de\b~iu' => 'o substantivo é "perda"',
        '~(*UCP)\bmal (estar|humor)\b~iu' => 'o certo é "mal-estar"/"mau humor"',
        '~(*UCP)\b(a|à) (nível)\b~iu' => '',
        '~(*UCP)\bpor ventura\b~iu' => 'o certo é "porventura"',
        '~(*UCP)\bao invés de\b~iu' => 'quando é substituição, use "em vez de"',
        '~(*UCP)\b(vigésima|trigésima) (primeiro|segundo)\b~iu' => 'concordância do ordinal',
        '~(*UCP)\b(\d{1,2})(hs|hrs)\b~iu' => 'horário se escreve "16h" (sem "hs")',
        '~(*UCP)\b(\d{1,2}):(\d{2}) ?h\b~iu' => 'horário se escreve "16h30"',
    );
    foreach ($comuns as $re => $msg) {
        if ($msg !== '' && preg_match_all($re, $texto, $m)) {
            foreach (array_slice(array_unique($m[0]), 0, 2) as $w) {
                $uma('erro_comum', array($w, $msg));
            }
        }
    }
    if (preg_match_all('~[\p{L}\d]\s+[,;!?](?!\S*\d)|[\p{L}]\s+\.(?![.\d])~u', $texto, $m, PREG_OFFSET_CAPTURE)) {
        foreach (array_slice($m[0], 0, 3) as $x) {
            $uma('espaco_pontuacao', array(tsp_notas_trecho($texto, mb_strlen(substr($texto, 0, $x[1])), 10)));
        }
    }
    if (preg_match_all('~[\p{Ll}]{2}[,;][\p{L}]|[\p{Ll}]{3}\.[\p{Lu}][\p{Ll}]~u', $texto, $m)) {
        foreach (array_slice(array_unique($m[0]), 0, 3) as $w) {
            if (!preg_match('~\.(com|br|net|org|gov)~i', $w)) {
                $uma('sem_espaco_depois', array($w));
            }
        }
    }
    if (preg_match_all('~[\p{Ll}]{2}\. [\p{Ll}]+~u', $texto, $m)) {
        foreach (array_slice(array_unique($m[0]), 0, 3) as $w) {
            if (!preg_match('~(etc|sr|sra|dr|dra|av|n|nº|prof|aprox)\. ~iu', $w)) {
                $uma('minuscula_apos_ponto', array($w));
            }
        }
    }
    if (preg_match_all('~(*UCP)\b([\p{L}]{2,})\s+\1\b~iu', $texto, $m)) {
        foreach (array_slice(array_unique($m[0]), 0, 3) as $w) {
            if (!preg_match('~^(se se|que que|nos nos|tic tac|pega pega|bate bate|corre corre)$~iu', $w)) {
                $uma('palavra_repetida', array($w));
            }
        }
    }
    foreach ($pars as $p) {
        $ab = substr_count($p, '(') !== substr_count($p, ')');
        $as = substr_count($p, '“') !== substr_count($p, '”') || substr_count($p, '"') % 2 === 1;
        if ($ab || $as) {
            $uma('aspas_parenteses', array(mb_substr($p, 0, 80)));
        }
        if (tsp_notas_palavras($p) > 8 && !preg_match('~[.!?:…"”»)\]]\s*$~u', $p)) {
            $uma('sem_ponto_final', array(mb_substr($p, -60)));
        }
    }
    if (preg_match_all('~“\s+[\p{L}]+|[\p{L}]+\s+”~u', $texto, $m)) {
        foreach (array_slice(array_unique($m[0]), 0, 2) as $w) {
            $uma('espaco_aspas', array($w));
        }
    }
    if (preg_match_all('~[!?]{2,}~u', $texto, $m)) {
        $uma('pontuacao_dupla', array($m[0][0]));
    }
    if (preg_match('~(*UCP)\b\d{1,2} ?x ?\d{1,2}\b~u', $texto, $m)) {
        $uma('placar_com_x', array($m[0]));
    }

    /* SEO */
    $lt = mb_strlen($tit);
    if ($lt < 40 || $lt > 75) {
        $add('titulo_tamanho', array($lt));
    }
    if ($clubes && !$tem_clube($tit)) {
        $add('titulo_sem_clube');
    }
    if ($n_pal > 300 && !$inter) {
        $add('sem_intertitulo');
    }
    if (empty($d['foto'])) {
        $add('sem_foto');
    } elseif (empty($d['credito'])) {
        $add('foto_sem_credito');
    }
    if (array_key_exists('subtitulo', $d) && !$d['subtitulo']) {
        $add('sem_subtitulo');
    }
    if (array_key_exists('tags', $d) && (int) $d['tags'] < 3) {
        $add('poucas_tags');
    }

    /* AEO */
    $f1 = $frases[0] ?? '';
    $n_f1 = tsp_notas_palavras($f1);
    if ($n_f1 > 32) {
        $add('primeira_frase_longa', array($n_f1));
    }
    if ($n_pal > 250 && !array_filter($inter, function ($x) {
        return (bool) preg_match('~\?\s*$~u', $x);
    })) {
        $add('sem_pergunta');
    }
    $media_p = $pars ? $soma_p / count($pars) : 0;
    if ($media_p > 75) {
        $add('paragrafos_densos', array(number_format($media_p, 0)));
    }

    /* GEO */
    if (!$links_ext) {
        $add('sem_link_fonte');
    }
    if (!$tem_atrib) {
        $add('sem_atribuicao');
    }
    $nomes = preg_match_all('~(?<=[\p{Ll},;:] )\p{Lu}[\p{Ll}]{2,}~u', $texto);
    if ($nomes < 4 || $numeros < 3) {
        $add('poucas_entidades');
    }

    /* Soma: cada critério começa cheio e perde pontos, com limite por tipo de problema */
    $desc = array();
    $por_cod = array();
    foreach ($achados as $a) {
        $t = $tab[$a[0]];
        $v = $t[1] * (isset($a[2]) ? (int) $a[2] : 1);
        $ja = $por_cod[$a[0]] ?? 0;
        $v = max(0, min($v, $t[2] - $ja));
        $por_cod[$a[0]] = $ja + $v;
        $desc[$t[0]] = ($desc[$t[0]] ?? 0) + $v;
    }
    $c = array();
    $nota = 0;
    foreach ($cri as $k => $x) {
        $c[$k] = round(max(0, $x[1] - ($desc[$k] ?? 0)), 2);
        $nota += $c[$k];
    }
    if (!empty($d['plagio'])) {
        $nota = 0;
    }
    return array('nota' => round(max(0, min(10, $nota)), 1), 'c' => $c, 'p' => array_map(function ($a) {
        return array($a[0], $a[1]);
    }, $achados), 'palavras' => $n_pal, 'v' => TSP_NOTAS_VERSAO);
}

/* ---------- Ligação com o WordPress ---------- */

function tsp_notas_dados_post($p)
{
    $thumb = get_post_thumbnail_id($p);
    $cred = $thumb ? (function_exists('tsp_credito_foto') ? tsp_credito_foto($p->ID) : trim((string) wp_get_attachment_caption($thumb))) : '';
    $t = get_the_terms($p, 'times');
    $erros = array('aberto' => 0, 'corrigido' => 0);
    $c = function_exists('tsp_corr') ? tsp_corr($p->ID) : array();
    foreach ((array) ($c['itens'] ?? array()) as $i) {
        if (($i['g'] ?? '') === 'grave' && empty($i['auto'])) {
            $erros[(($c['status'] ?? '') === 'corrigida') ? 'corrigido' : 'aberto']++;
        }
    }
    // erro aberto mas ainda no prazo: conta como "corrigido" (desconto menor) até o prazo vencer
    if ($erros['aberto'] && in_array($c['status'] ?? '', array('aberta', 'rever'), true)) {
        $erros['corrigido'] += $erros['aberto'];
        $erros['aberto'] = 0;
    }
    $pl = get_post_meta($p->ID, 'tsp_plagio', true);
    return array(
        'titulo' => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'),
        'html' => $p->post_content,
        'clubes' => ($t && !is_wp_error($t)) ? wp_list_pluck($t, 'name') : array(),
        'foto' => (bool) $thumb,
        'credito' => $cred !== '',
        'subtitulo' => function_exists('tsp_subtitulo') ? tsp_subtitulo($p->ID) !== '' : true,
        'tags' => count(wp_get_post_tags($p->ID, array('fields' => 'ids'))),
        'erros' => $erros,
        'plagio' => is_array($pl) && !empty($pl['em']),
    );
}

function tsp_notas_calcular_post($p)
{
    $r = tsp_notas_avaliar(tsp_notas_dados_post($p));
    $r['em'] = time();
    update_post_meta($p->ID, 'tsp_nota', $r['nota']);
    update_post_meta($p->ID, 'tsp_nota_det', $r);
    return $r;
}

function tsp_notas_posts($ini, $fim, $autor = 0, $so_com_nota = false)
{
    $q = array('post_type' => tsp_rel_tipos(), 'post_status' => array('publish', 'pending'), 'posts_per_page' => -1, 'no_found_rows' => true,
        'date_query' => array(array('after' => $ini->format('Y-m-d H:i:s'), 'before' => $fim->format('Y-m-d H:i:s'), 'inclusive' => true)),
        'meta_query' => array(array('key' => 'tsp_versao_de', 'compare' => 'NOT EXISTS')));
    if ($autor) {
        $q['author'] = (int) $autor;
    }
    if ($so_com_nota) {
        $q['meta_query'][] = array('key' => 'tsp_nota', 'compare' => 'EXISTS');
    }
    return array_values(array_filter(get_posts($q), function ($p) {
        // pendente só entra se for plágio (tirada do ar); o resto do pendente ainda não foi publicado
        return tsp_corr_autor_redator($p->post_author) && ($p->post_status === 'publish' || get_post_meta($p->ID, 'tsp_plagio', true));
    }));
}

// Agrupa por redator: n, média, melhor, pior, média por critério e problemas mais frequentes
function tsp_notas_agrupar($posts)
{
    $g = array();
    foreach ($posts as $p) {
        $det = get_post_meta($p->ID, 'tsp_nota_det', true);
        if (!is_array($det) || !isset($det['nota'])) {
            continue;
        }
        $a = (int) $p->post_author;
        if (!isset($g[$a])) {
            $g[$a] = array('autor' => $a, 'n' => 0, 'soma' => 0, 'melhor' => null, 'pior' => null, 'c' => array(), 'cod' => array(), 'posts' => array());
        }
        $x = &$g[$a];
        $x['n']++;
        $x['soma'] += $det['nota'];
        if (!$x['melhor'] || $det['nota'] > $x['melhor'][0]) {
            $x['melhor'] = array($det['nota'], $p->ID);
        }
        if (!$x['pior'] || $det['nota'] < $x['pior'][0]) {
            $x['pior'] = array($det['nota'], $p->ID);
        }
        foreach ((array) $det['c'] as $k => $v) {
            $x['c'][$k] = ($x['c'][$k] ?? 0) + $v;
        }
        $vistos = array();
        foreach ((array) $det['p'] as $pr) {
            if (!isset($vistos[$pr[0]])) {
                $x['cod'][$pr[0]] = ($x['cod'][$pr[0]] ?? 0) + 1;
                $vistos[$pr[0]] = 1;
            }
        }
        $x['posts'][] = array($p->ID, $det['nota']);
        unset($x);
    }
    foreach ($g as &$x) {
        $x['media'] = round($x['soma'] / max(1, $x['n']), 1);
        foreach ($x['c'] as $k => $v) {
            $x['c'][$k] = $v / $x['n'];
        }
        arsort($x['cod']);
    }
    unset($x);
    uasort($g, function ($a, $b) {
        return $b['media'] <=> $a['media'] ?: $b['n'] <=> $a['n'];
    });
    return $g;
}

// Os 3 pontos onde o redator mais perde: critérios com menor aproveitamento + o problema que mais se repete em cada um
function tsp_notas_melhorar($x)
{
    $cri = tsp_notas_criterios();
    $tab = tsp_notas_problemas();
    $ap = array();
    foreach ($cri as $k => $c) {
        $ap[$k] = ($x['c'][$k] ?? $c[1]) / $c[1];
    }
    asort($ap);
    $out = array();
    foreach ($ap as $k => $v) {
        if ($v >= 0.9 || count($out) >= 3) {
            continue;
        }
        $cod = null;
        foreach ($x['cod'] as $cd => $n) {
            if ($tab[$cd][0] === $k) {
                $cod = $cd;
                break;
            }
        }
        $linha = $cri[$k][0] . ' (' . number_format_i18n(100 * $v, 0) . '% dos pontos)';
        if ($cod) {
            $linha .= ': em ' . $x['cod'][$cod] . ' de ' . $x['n'] . ' matérias. ' . $tab[$cod][4];
        } else {
            $linha .= ': ' . $cri[$k][2];
        }
        $out[] = $linha;
    }
    return $out;
}

function tsp_notas_fmt($n)
{
    return number_format_i18n((float) $n, 1);
}

/* ---------- Rotina das 23h59 ---------- */

add_action('init', function () {
    if (!wp_next_scheduled('tsp_notas_rotina')) {
        $t = new DateTimeImmutable('today 23:59', tsp_rel_tz());
        if ($t->getTimestamp() <= time()) {
            $t = $t->modify('+1 day');
        }
        wp_schedule_event($t->getTimestamp(), 'daily', 'tsp_notas_rotina');
    }
});
add_action('tsp_notas_rotina', 'tsp_notas_rotina');

// Rede de segurança: se o WordPress perdeu as 23h59 (site sem visita), a rotina de hora em hora faz pelo dia anterior
add_action('tsp_corr_rotina', function () {
    $ontem = (new DateTimeImmutable('yesterday', tsp_rel_tz()))->format('Y-m-d');
    if ((int) (new DateTimeImmutable('now', tsp_rel_tz()))->format('G') < 12 && get_option('tsp_notas_ultimo_dia') < $ontem) {
        tsp_notas_rotina($ontem);
    }
}, 20);

function tsp_notas_rotina($dia = '')
{
    if (get_transient('tsp_notas_trava')) {
        return;
    }
    set_transient('tsp_notas_trava', 1, 15 * MINUTE_IN_SECONDS);
    @set_time_limit(300);
    $tz = tsp_rel_tz();
    $agora = new DateTimeImmutable('now', $tz);
    if (!$dia) {
        // a rotina das 23h59 pode rodar alguns minutos depois da meia-noite: nesse caso o dia é o anterior
        $dia = ((int) $agora->format('G') < 12 ? $agora->modify('-1 day') : $agora)->format('Y-m-d');
    }
    if (get_option('tsp_notas_ultimo_dia') >= $dia) {
        delete_transient('tsp_notas_trava');
        return;
    }
    $d0 = new DateTimeImmutable($dia . ' 00:00:00', $tz);
    $d1 = $d0->setTime(23, 59, 59);
    // 1) nota das matérias do dia e revisão dos 7 dias anteriores (erro de informação apontado depois derruba a nota)
    foreach (tsp_notas_posts($d0->modify('-7 days'), $d1) as $p) {
        tsp_notas_calcular_post($p);
    }
    update_option('tsp_notas_ultimo_dia', $dia, false);
    // 2) avisos
    tsp_notas_avisar_dia($d0, $d1);
    delete_transient('tsp_notas_trava');
}

function tsp_notas_posicao($autor, $ranking)
{
    $i = 0;
    foreach ($ranking as $a => $x) {
        $i++;
        if ((int) $a === (int) $autor) {
            return array($i, count($ranking));
        }
    }
    return array(0, count($ranking));
}

function tsp_notas_avisar_dia($d0, $d1)
{
    $hoje = tsp_notas_agrupar(tsp_notas_posts($d0, $d1, 0, true));
    if (!$hoje) {
        return;
    }
    list($fi, $ff) = tsp_rel_fechamento(0);
    $fech = tsp_notas_agrupar(tsp_notas_posts($fi, $ff, 0, true));
    $dia = $d0->format('d/m');
    // resumo guardado para o painel do redator (sem recalcular a cada abertura do painel)
    $res = array('dia' => $dia, 'fech' => $fi->format('d/m') . ' a ' . $ff->format('d/m'), 'r' => array());
    $i = 0;
    foreach ($fech as $a => $x) {
        $res['r'][$a] = array('media' => $x['media'], 'n' => $x['n'], 'pos' => ++$i, 'tot' => count($fech), 'hoje' => isset($hoje[$a]) ? $hoje[$a]['media'] : null, 'melhorar' => tsp_notas_melhorar($x));
    }
    update_option('tsp_notas_resumo', $res, false);
    foreach ($hoje as $autor => $x) {
        $u = get_userdata($autor);
        if (!$u) {
            continue;
        }
        list($pos, $tot) = tsp_notas_posicao($autor, $fech);
        $f = $fech[$autor] ?? null;
        $l = array('Oi, ' . trim(strtok($u->display_name, ' ')) . '! Esta é a correção das matérias que você publicou hoje (' . $dia . '), com nota de 0 a 10, como numa prova de redação.', '');
        $l[] = '🎓 Sua média hoje: ' . tsp_notas_fmt($x['media']) . ' em ' . $x['n'] . ' matéria(s).';
        if ($f) {
            $l[] = '📊 No fechamento (' . $fi->format('d/m') . ' a ' . $ff->format('d/m') . '): média ' . tsp_notas_fmt($f['media']) . ' em ' . $f['n'] . ' matérias · ' . $pos . 'º lugar de ' . $tot . ' no ranking.';
        }
        $mel = tsp_notas_melhorar($x);
        if ($mel) {
            $l[] = '';
            $l[] = 'Onde você mais perdeu pontos hoje:';
            foreach ($mel as $m) {
                $l[] = '• ' . $m;
            }
        }
        $l[] = '';
        $l[] = 'Matéria a matéria:';
        usort($x['posts'], function ($a, $b) {
            return $a[1] <=> $b[1];
        });
        foreach ($x['posts'] as $pp) {
            $det = get_post_meta($pp[0], 'tsp_nota_det', true);
            $l[] = '📰 ' . tsp_notas_fmt($pp[1]) . ' · ' . html_entity_decode(get_the_title($pp[0]), ENT_QUOTES, 'UTF-8');
            $pr = (array) ($det['p'] ?? array());
            $l[] = '   – ' . ($pr ? $pr[0][1] . (count($pr) > 1 ? ' (+' . (count($pr) - 1) . ' ponto(s) na correção completa)' : '') : 'Nota máxima nos critérios automáticos. Parabéns!');
        }
        $l[] = '';
        $l[] = 'Correção completa de cada matéria: Relatório → 🎓 Notas. Critérios: veracidade (2), lide (1,5), clareza (1,5), profundidade (1,5), português (1,5), SEO (1), AEO (0,5) e GEO (0,5).';
        $l[] = 'Isto é orientação para você crescer: não trava a publicação e não muda o pagamento. Qualquer dúvida, fale com o Vinicios Cotrim. — Redação TSP';
        tsp_corr_avisar($autor, '🎓 Sua nota de hoje: ' . tsp_notas_fmt($x['media']) . ' (' . $x['n'] . ' matéria' . ($x['n'] > 1 ? 's' : '') . ')', $l, admin_url('admin.php?page=tsp-notas&redator=' . $autor));
    }
    // Ranking para administrador e coordenação
    $soma = 0;
    $n = 0;
    foreach ($hoje as $x) {
        $soma += $x['soma'];
        $n += $x['n'];
    }
    $l = array('Correção das matérias dos redatores de hoje (' . $dia . '): média geral ' . tsp_notas_fmt($soma / max(1, $n)) . ' em ' . $n . ' matérias.', '', '🏆 Ranking de hoje:');
    $i = 0;
    foreach ($hoje as $autor => $x) {
        $u = get_userdata($autor);
        $l[] = (++$i) . 'º ' . ($u ? $u->display_name : '#' . $autor) . ' · ' . tsp_notas_fmt($x['media']) . ' (' . $x['n'] . ' matérias; pior ' . tsp_notas_fmt($x['pior'][0]) . ')';
    }
    $l[] = '';
    $l[] = '📊 Ranking do fechamento (' . $fi->format('d/m') . ' a ' . $ff->format('d/m') . '):';
    $i = 0;
    foreach ($fech as $autor => $x) {
        $u = get_userdata($autor);
        $l[] = (++$i) . 'º ' . ($u ? $u->display_name : '#' . $autor) . ' · ' . tsp_notas_fmt($x['media']) . ' (' . $x['n'] . ' matérias)';
    }
    $l[] = '';
    $l[] = 'Relatório individual de cada redator em Relatório → 🎓 Notas.';
    $dest = array_merge(get_users(array('role' => 'administrator')), tsp_corr_coordenadores());
    $ja = array();
    foreach ($dest as $d) {
        if (empty($ja[$d->ID])) {
            $ja[$d->ID] = 1;
            tsp_corr_avisar($d->ID, '🎓 Notas da redação · ' . $dia . ' · média ' . tsp_notas_fmt($soma / max(1, $n)), $l, admin_url('admin.php?page=tsp-notas'));
        }
    }
}

/* ---------- Tela Relatório → 🎓 Notas ---------- */

add_action('admin_menu', function () {
    add_submenu_page('tsp-relatorio', 'Notas da redação', '🎓 Notas', 'edit_posts', 'tsp-notas', 'tsp_notas_tela');
}, 21);

// Calcular agora (administrador/coordenação): dá nota às matérias do período que ainda não têm
add_action('admin_post_tsp_notas_calcular', function () {
    if (!tsp_rel_coord() || !check_admin_referer('tsp_notas_calcular')) {
        wp_die('Sem permissão.');
    }
    @set_time_limit(300);
    $per = tsp_notas_periodo();
    $n = 0;
    foreach (tsp_notas_posts($per['ini'], $per['fim']) as $p) {
        $det = get_post_meta($p->ID, 'tsp_nota_det', true);
        if (!is_array($det) || (int) ($det['v'] ?? 0) !== TSP_NOTAS_VERSAO || !empty($_GET['todas'])) {
            tsp_notas_calcular_post($p);
            if (++$n >= 600) {
                break;
            }
        }
    }
    wp_safe_redirect(add_query_arg(array('page' => 'tsp-notas', 'periodo' => $per['p'], 'calculadas' => $n), admin_url('admin.php')));
    exit;
});

function tsp_notas_periodo()
{
    $tz = tsp_rel_tz();
    $p = sanitize_key($_GET['periodo'] ?? 'fechamento');
    if ($p === 'hoje' || $p === 'ontem' || $p === '7dias') {
        $hoje = new DateTimeImmutable('today', $tz);
        $ini = $p === 'hoje' ? $hoje : ($p === 'ontem' ? $hoje->modify('-1 day') : $hoje->modify('-6 days'));
        $fim = $p === 'ontem' ? $hoje->modify('-1 second') : $hoje->setTime(23, 59, 59);
        return array('p' => $p, 'ini' => $ini, 'fim' => $fim, 'nome' => array('hoje' => 'Hoje', 'ontem' => 'Ontem', '7dias' => 'Últimos 7 dias')[$p]);
    }
    return tsp_rel_periodo();
}

function tsp_notas_cor($n)
{
    return $n >= 8 ? '#1a7f37' : ($n >= 6 ? '#9a6700' : '#b32d2e');
}

function tsp_notas_tela()
{
    $coord = tsp_rel_coord();
    $per = tsp_notas_periodo();
    $alvo = $coord ? (int) ($_GET['redator'] ?? 0) : get_current_user_id();
    $cri = tsp_notas_criterios();
    echo '<div class="wrap"><h1>🎓 Notas da redação</h1>';
    echo '<p>Todo dia às 23h59 cada matéria de redator recebe uma nota de 0 a 10, como numa prova de redação. Critérios: ';
    $ps = array();
    foreach ($cri as $c) {
        $ps[] = esc_html($c[0]) . ' (' . esc_html(number_format_i18n($c[1], 1)) . ')';
    }
    echo implode(' · ', $ps) . '. A nota é refeita por 7 dias se o editor-chefe apontar erro de informação.</p>';
    if (isset($_GET['calculadas'])) {
        echo '<div class="notice notice-success"><p>' . (int) $_GET['calculadas'] . ' matéria(s) receberam nota agora.</p></div>';
    }
    echo '<form method="get" style="margin:10px 0"><input type="hidden" name="page" value="tsp-notas">';
    if ($alvo && $coord) {
        echo '<input type="hidden" name="redator" value="' . (int) $alvo . '">';
    }
    echo '<select name="periodo">';
    foreach (array('hoje' => 'Hoje', 'ontem' => 'Ontem', '7dias' => 'Últimos 7 dias', 'fechamento' => 'Fechamento atual', 'fechamento_anterior' => 'Fechamento anterior', 'mes' => 'Mês atual', 'mes_anterior' => 'Mês anterior') as $k => $v) {
        echo '<option value="' . esc_attr($k) . '"' . selected($per['p'], $k, false) . '>' . esc_html($v) . '</option>';
    }
    echo '</select> <button class="button">Ver</button>';
    if ($coord) {
        echo ' <a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=tsp_notas_calcular&periodo=' . $per['p']), 'tsp_notas_calcular')) . '">Dar nota às matérias do período que ainda não têm</a>';
    }
    echo '</form><p><strong>' . esc_html($per['nome']) . ':</strong> ' . esc_html($per['ini']->format('d/m/Y') . ' a ' . $per['fim']->format('d/m/Y')) . '</p>';

    $g = tsp_notas_agrupar(tsp_notas_posts($per['ini'], $per['fim'], $alvo && !$coord ? $alvo : 0, true));
    if (!$g) {
        echo '<p>Nenhuma matéria com nota neste período ainda.</p></div>';
        return;
    }
    if ($coord && !$alvo) {
        echo '<h2>🏆 Ranking</h2><table class="widefat striped"><thead><tr><th>#</th><th>Redator</th><th class="n">Matérias</th><th class="n">Média</th><th class="n">Melhor</th><th class="n">Pior</th>';
        foreach ($cri as $c) {
            echo '<th class="n" title="' . esc_attr($c[2]) . '">' . esc_html(strtok($c[0], ' ')) . ' <small>/' . esc_html(number_format_i18n($c[1], 1)) . '</small></th>';
        }
        echo '<th></th></tr></thead><tbody>';
        $i = 0;
        foreach ($g as $a => $x) {
            $u = get_userdata($a);
            echo '<tr><td>' . (++$i) . 'º</td><td>' . esc_html($u ? $u->display_name : '#' . $a) . '</td><td class="n">' . (int) $x['n'] . '</td><td class="n"><strong style="color:' . esc_attr(tsp_notas_cor($x['media'])) . '">' . esc_html(tsp_notas_fmt($x['media'])) . '</strong></td><td class="n">' . esc_html(tsp_notas_fmt($x['melhor'][0])) . '</td><td class="n">' . esc_html(tsp_notas_fmt($x['pior'][0])) . '</td>';
            foreach ($cri as $k => $c) {
                echo '<td class="n">' . esc_html(number_format_i18n($x['c'][$k] ?? 0, 2)) . '</td>';
            }
            echo '<td><a href="' . esc_url(add_query_arg(array('page' => 'tsp-notas', 'periodo' => $per['p'], 'redator' => $a), admin_url('admin.php'))) . '">Relatório →</a></td></tr>';
        }
        echo '</tbody></table></div>';
        return;
    }
    $x = $g[$alvo] ?? reset($g);
    $u = get_userdata($x['autor']);
    list($pos, $tot) = tsp_notas_posicao($x['autor'], $coord ? $g : tsp_notas_agrupar(tsp_notas_posts($per['ini'], $per['fim'], 0, true)));
    if ($coord) {
        echo '<p><a href="' . esc_url(add_query_arg(array('page' => 'tsp-notas', 'periodo' => $per['p']), admin_url('admin.php'))) . '">← Ranking</a></p>';
    }
    echo '<h2>' . esc_html($u ? $u->display_name : '') . ': média <span style="color:' . esc_attr(tsp_notas_cor($x['media'])) . '">' . esc_html(tsp_notas_fmt($x['media'])) . '</span> em ' . (int) $x['n'] . ' matérias · ' . (int) $pos . 'º de ' . (int) $tot . '</h2>';
    echo '<table class="widefat" style="max-width:720px"><thead><tr><th>Critério</th><th class="n">Média</th><th class="n">Máximo</th><th>Aproveitamento</th></tr></thead><tbody>';
    foreach ($cri as $k => $c) {
        $v = $x['c'][$k] ?? 0;
        $pc = (int) round(100 * $v / $c[1]);
        echo '<tr><td title="' . esc_attr($c[2]) . '">' . esc_html($c[0]) . '</td><td class="n">' . esc_html(number_format_i18n($v, 2)) . '</td><td class="n">' . esc_html(number_format_i18n($c[1], 1)) . '</td><td><div style="background:#eee;border-radius:9px;height:8px;width:200px"><div style="height:8px;border-radius:9px;width:' . (2 * $pc) . 'px;background:' . esc_attr($pc >= 85 ? '#1a7f37' : ($pc >= 65 ? '#E8862A' : '#b32d2e')) . '"></div></div> ' . (int) $pc . '%</td></tr>';
    }
    echo '</tbody></table>';
    $mel = tsp_notas_melhorar($x);
    echo '<h3>O que melhorar</h3>' . ($mel ? '<ol><li>' . implode('</li><li>', array_map('esc_html', $mel)) . '</li></ol>' : '<p>Nada importante: ótimo trabalho no período!</p>');
    $tab = tsp_notas_problemas();
    echo '<h3>Problemas que mais se repetem</h3><ul>';
    foreach (array_slice($x['cod'], 0, 8, true) as $cod => $n) {
        echo '<li><strong>' . (int) $n . ' de ' . (int) $x['n'] . ' matérias:</strong> ' . esc_html($tab[$cod][4]) . '</li>';
    }
    echo '</ul><h3>Matérias</h3><table class="widefat striped"><thead><tr><th class="n">Nota</th><th>Matéria</th><th>Correção do professor</th></tr></thead><tbody>';
    usort($x['posts'], function ($a, $b) {
        return $a[1] <=> $b[1];
    });
    foreach (array_slice($x['posts'], 0, 300) as $pp) {
        $det = get_post_meta($pp[0], 'tsp_nota_det', true);
        $fb = array_map(function ($pr) {
            return esc_html($pr[1]);
        }, array_slice((array) ($det['p'] ?? array()), 0, 6));
        echo '<tr><td class="n"><strong style="color:' . esc_attr(tsp_notas_cor($pp[1])) . '">' . esc_html(tsp_notas_fmt($pp[1])) . '</strong></td><td><a href="' . esc_url(get_permalink($pp[0])) . '" target="_blank">' . esc_html(get_the_title($pp[0])) . '</a><br><small>' . esc_html(get_the_date('d/m H\hi', $pp[0])) . '</small></td><td>' . ($fb ? implode('<br>', $fb) : '✓ Sem problemas nos critérios automáticos') . '</td></tr>';
    }
    echo '</tbody></table></div>';
}

// Caixa no painel do redator: média, posição e o que melhorar (dados da última correção das 23h59)
function tsp_notas_painel_html($autor)
{
    $res = get_option('tsp_notas_resumo');
    $x = is_array($res) ? ($res['r'][$autor] ?? null) : null;
    if (!$x) {
        return '';
    }
    $h = '<h3>🎓 Sua nota de redação · fechamento ' . esc_html($res['fech']) . '</h3><div class="tsp-p-meta"><strong style="font-size:18px;color:' . esc_attr(tsp_notas_cor($x['media'])) . '">' . esc_html(tsp_notas_fmt($x['media'])) . '</strong> de média em ' . (int) $x['n'] . ' matérias · ' . (int) $x['pos'] . 'º de ' . (int) $x['tot'] . ' no ranking';
    if ($x['hoje'] !== null) {
        $h .= ' · em ' . esc_html($res['dia']) . ': ' . esc_html(tsp_notas_fmt($x['hoje']));
    }
    if ($x['melhorar']) {
        $h .= '<br><strong>Para subir a nota:</strong><br>• ' . implode('<br>• ', array_map('esc_html', array_slice($x['melhorar'], 0, 3)));
    }
    return $h . '<br><a href="' . esc_url(admin_url('admin.php?page=tsp-notas')) . '">Ver a correção de cada matéria →</a></div>';
}
