/* TSP Nova Era — menu do celular e "copiar link". */
(function () {
  var corpo = document.body;
  var btn = document.querySelector('.tsp-menu-btn');
  if (btn) {
    btn.addEventListener('click', function () {
      var aberto = corpo.classList.toggle('tsp-menu-aberto');
      btn.setAttribute('aria-expanded', aberto ? 'true' : 'false');
      btn.setAttribute('aria-label', aberto ? 'Fechar menu' : 'Abrir menu');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && corpo.classList.contains('tsp-menu-aberto')) btn.click();
    });
  }
  // Menus suspensos (no celular abrem com toque; no computador também abrem com o mouse)
  document.addEventListener('click', function (e) {
    var b = e.target.closest('.tsp-nav__abre');
    var abertos = document.querySelectorAll('.tsp-nav__item.aberto');
    abertos.forEach(function (li) {
      if (!b || li !== b.parentNode) { li.classList.remove('aberto'); var x = li.querySelector('.tsp-nav__abre'); if (x) x.setAttribute('aria-expanded', 'false'); }
    });
    if (!b) return;
    var li = b.parentNode, aberto = li.classList.toggle('aberto');
    b.setAttribute('aria-expanded', aberto ? 'true' : 'false');
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    document.querySelectorAll('.tsp-nav__item.aberto').forEach(function (li) { li.classList.remove('aberto'); });
  });

  // Vídeo do YouTube: só carrega o player quando o leitor clica (site mais rápido)
  document.addEventListener('click', function (e) {
    var play = e.target.closest('.tsp-yt');
    if (!play || play.querySelector('iframe')) return;
    var f = document.createElement('iframe');
    f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(play.getAttribute('data-video')) + '?autoplay=1&rel=0';
    f.allow = 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture';
    f.allowFullscreen = true;
    f.title = play.getAttribute('aria-label') || 'Vídeo';
    play.innerHTML = '';
    play.appendChild(f);
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copiar]');
    if (!b || !navigator.clipboard) return;
    navigator.clipboard.writeText(b.getAttribute('data-copiar')).then(function () {
      var t = b.textContent; b.textContent = 'Link copiado!';
      setTimeout(function () { b.textContent = t; }, 1800);
    });
  });
})();

// Rodadas: setas ‹ › trocam a rodada exibida
(function () {
  document.querySelectorAll('[data-rodadas]').forEach(function (box) {
    var listas = Array.prototype.slice.call(box.querySelectorAll('.tsp-rodadas__lista'));
    var tit = box.querySelector('h3[data-titulo], strong[data-titulo]');
    var i = listas.findIndex(function (l) { return !l.hidden; });
    function mostra(n) {
      if (n < 0 || n >= listas.length) { return; }
      listas[i].hidden = true; i = n; listas[i].hidden = false;
      tit.textContent = listas[i].getAttribute('data-titulo');
      box.querySelector('[data-dir="-1"]').disabled = i === 0;
      box.querySelector('[data-dir="1"]').disabled = i === listas.length - 1;
    }
    box.querySelectorAll('.tsp-rodadas__seta').forEach(function (b) {
      b.addEventListener('click', function () { mostra(i + parseInt(b.getAttribute('data-dir'), 10)); });
    });
    if (i >= 0) { mostra(i); }
  });
})();

/* Vitrine de ofertas: setas ‹ › */
document.addEventListener('click', function (e) {
  var b = e.target.closest && e.target.closest('[data-of]');
  if (!b) { return; }
  var t = b.closest('.tsp-ofertas').querySelector('.tsp-ofertas__trilho');
  t.scrollBy({ left: parseInt(b.getAttribute('data-of'), 10) * t.clientWidth * 0.9, behavior: 'smooth' });
});

/* Chips "Outros clubes": ver todos */
document.addEventListener('click', function (e) {
  var b = e.target.closest && e.target.closest('[data-chips]');
  if (!b) { return; }
  var c = b.previousElementSibling;
  var aberto = c.classList.toggle('tsp-chips--recolhido') === false;
  b.setAttribute('aria-expanded', aberto ? 'true' : 'false');
  b.textContent = aberto ? 'Mostrar menos ↑' : b.textContent.replace('Mostrar menos ↑', '');
  if (!aberto) { b.textContent = 'Ver todos os ' + c.children.length + ' clubes ↓'; }
});
