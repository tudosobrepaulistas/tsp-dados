<?php
/**
 * Página do campeonato. Com guia cadastrado (inc/campeonato.php): guia completo + notícias.
 * Sem guia: a lista de notícias de sempre (archive.php). Página 2 em diante: só as notícias.
 */
$tsp_t = get_queried_object();
$tsp_g = $tsp_t ? tsp_campeonato_guia($tsp_t->slug) : null;
if (!$tsp_g || is_paged()) {
	require get_template_directory() . '/archive.php';
	return;
}
get_header();
$tsp_d = $tsp_g['dado'];
$tsp_tabs = tsp_dado('tabelas');
$tsp_tab = $tsp_tabs[$tsp_d] ?? array();
$tsp_resp = tsp_campeonato_resposta($tsp_g);
$tsp_clubes = tsp_campeonato_clubes($tsp_g);
$tsp_art = tsp_campeonato_artilharia($tsp_d);
$tsp_faq = tsp_campeonato_faq($tsp_g);
$tsp_jogos = tsp_rodadas_html($tsp_d, 'resultados') . tsp_rodadas_html($tsp_d, 'proximos');
if (!$tsp_jogos) {
	$tsp_jogos = tsp_jogos_html($tsp_d, 'resultados') . tsp_jogos_html($tsp_d, 'proximos');
}
$tsp_titulo = $tsp_g['nome'] . ' ' . $tsp_g['temporada'];
?>
<main class="tsp-container tsp-camp">
	<header class="tsp-camp__cab">
		<?php tsp_breadcrumbs(); ?>
		<h1><?php echo esc_html($tsp_titulo); ?>: tabela, jogos e classificação</h1>
		<p class="tsp-camp__resumo"><?php echo esc_html($tsp_g['resumo']); ?></p>
		<?php if ($tsp_resp) : ?>
			<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p><?php echo esc_html($tsp_resp); ?></p>
			<?php if (!empty($tsp_tab['nota'])) : ?><small><?php echo esc_html($tsp_tab['nota']); ?></small><?php endif; ?></div>
		<?php endif; ?>
		<?php if (function_exists('tsp_sim_botao_html') && preg_match('~serie-a~', (string) get_queried_object()->slug)) { echo tsp_sim_botao_html(); } // phpcs:ignore ?>
		<nav class="tsp-camp__indice" aria-label="Nesta página">
			<?php if (!empty($tsp_tab['linhas'])) : ?><a href="#classificacao">Classificação</a><?php endif; ?>
			<?php if ($tsp_jogos) : ?><a href="#jogos">Jogos</a><?php endif; ?>
			<?php if ($tsp_clubes) : ?><a href="#paulistas">Paulistas</a><?php endif; ?>
			<?php if ($tsp_art) : ?><a href="#artilharia">Artilharia</a><?php endif; ?>
			<a href="#regulamento">Regulamento</a>
			<?php if (!empty($tsp_g['transmissao'])) : ?><a href="#onde-assistir">Onde assistir</a><?php endif; ?>
			<a href="#perguntas">Perguntas</a>
			<a href="#noticias">Notícias</a>
		</nav>
	</header>

	<?php if (!empty($tsp_tab['linhas']) || $tsp_jogos) : ?>
	<section class="tsp-secao tsp-secao--solta" id="classificacao">
		<?php tsp_secao_cab('Classificação do ' . $tsp_g['curto'] . ' ' . $tsp_g['temporada']); ?>
		<?php $tsp_ge = function_exists('tsp_tabela_ge') ? tsp_tabela_ge($tsp_d) : ''; if ($tsp_ge) : echo $tsp_ge; // phpcs:ignore ?>
		<?php else : ?>
		<div class="tsp-tab-jogos">
			<?php if (!empty($tsp_tab['linhas'])) : ?>
				<div class="tsp-caixa tsp-tab-jogos__tabela"><?php echo tsp_tabela_html($tsp_d, 30); echo tsp_legenda($tsp_d); ?></div>
			<?php endif; ?>
			<?php if ($tsp_jogos) : ?><div class="tsp-tab-jogos__lado" id="jogos"><?php echo $tsp_jogos; ?></div><?php endif; ?>
		</div>
	<?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ($tsp_clubes) : ?>
	<section class="tsp-secao" id="paulistas">
		<?php tsp_secao_cab('Clubes paulistas no ' . $tsp_g['curto']); ?>
		<div class="tsp-camp__clubes">
			<?php
			$tsp_pos = array();
			foreach ((array) ($tsp_tab['linhas'] ?? array()) as $r) {
				$tsp_pos[$r[1]] = $r;
			}
			foreach ($tsp_clubes as $s) {
				$t = get_term_by('slug', $s, 'times');
				if (!$t) {
					continue;
				}
				$r = $tsp_pos[tsp_clube_nome_tabela($t)] ?? ($tsp_pos[$t->name] ?? null);
				echo '<a class="tsp-camp__clube" href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 40) . '<strong>' . esc_html($t->name) . '</strong>';
				echo $r ? '<span>' . (int) $r[0] . 'º lugar · ' . (int) $r[2] . ' pontos</span>' : '<span>Notícias e jogos</span>';
				echo '</a>';
			}
			?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ($tsp_art) : ?>
	<section class="tsp-secao" id="artilharia">
		<?php tsp_secao_cab('Artilharia do ' . $tsp_g['curto'] . ' ' . $tsp_g['temporada']); ?>
		<div class="tsp-caixa"><table class="tsp-tabela"><thead><tr><th>#</th><th class="tsp-tabela__time">Jogador</th><th>Clube</th><th>Gols</th></tr></thead><tbody>
		<?php foreach ($tsp_art as $i => $a) : ?>
			<tr><td><?php echo (int) $i + 1; ?></td><td class="tsp-tabela__time"><?php echo esc_html($a['jogador']); ?></td><td><?php echo esc_html($a['time']); ?></td><td><strong><?php echo (int) $a['gols']; ?></strong></td></tr>
		<?php endforeach; ?>
		</tbody></table></div>
	</section>
	<?php endif; ?>

	<section class="tsp-secao" id="regulamento">
		<?php tsp_secao_cab('Regulamento e formato'); ?>
		<div class="tsp-camp__guia">
			<dl class="tsp-camp__ficha">
				<?php foreach ((array) $tsp_g['formato'] as $f) : ?>
					<div><dt><?php echo esc_html($f[0]); ?></dt><dd><?php echo esc_html($f[1]); ?></dd></div>
				<?php endforeach; ?>
			</dl>
			<?php if (!empty($tsp_g['regras'])) : ?>
				<ul class="tsp-camp__regras"><?php foreach ($tsp_g['regras'] as $r) : ?><li><?php echo esc_html($r); ?></li><?php endforeach; ?></ul>
			<?php endif; ?>
		</div>
	</section>

	<?php if (!empty($tsp_g['transmissao'])) : ?>
	<section class="tsp-secao" id="onde-assistir">
		<?php tsp_secao_cab('Onde assistir ao ' . $tsp_g['curto'] . ' ' . $tsp_g['temporada']); ?>
		<p class="tsp-camp__texto"><?php echo esc_html($tsp_g['transmissao']); ?></p>
	</section>
	<?php endif; ?>

	<section class="tsp-secao" id="perguntas">
		<?php tsp_secao_cab('Perguntas frequentes'); ?>
		<div class="tsp-faq">
			<?php foreach ($tsp_faq as $f) : ?>
				<details><summary><?php echo esc_html($f[0]); ?></summary><p><?php echo esc_html($f[1]); ?></p></details>
			<?php endforeach; ?>
		</div>
	</section>

	<section class="tsp-secao" id="noticias">
		<?php tsp_secao_cab('Últimas notícias do ' . $tsp_g['curto']); ?>
		<?php if (have_posts()) :
			$tsp_ids = wp_list_pluck($GLOBALS['wp_query']->posts, 'ID');
			tsp_layout_b($tsp_ids, 4);
			tsp_paginacao();
		else : ?>
			<p class="tsp-vazio">Nenhuma notícia por aqui ainda.</p>
		<?php endif; ?>
	</section>
</main>
<?php
get_footer();
