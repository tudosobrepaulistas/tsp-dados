<?php
/**
 * SEO das páginas de clube e de campeonato (09/11/2026, pedido do Thiago).
 * Problema: no Google aparecia "Notícias de Comercial" — sem a cidade, o leitor não sabe que é o Comercial de
 * Ribeirão Preto, e quem busca "Comercial RP" ou "Comercial Ribeirão Preto" não encontra o TSP.
 * Regra: o título leva o nome do clube + cidade (quando a cidade não está no nome) + sigla da região quando existe
 * (RP, Rio Preto, ABC). Clubes com nome igual ao da cidade (Rio Claro, Taubaté...) ganham o nome completo do clube.
 * Título escrito à mão no Yoast (campo do próprio clube) sempre vale mais que este automático.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_cidade_clube($slug)
{
    static $m = null;
    if ($m === null) {
        $m = include __DIR__ . '/cidades.php';
    }
    $g = tsp_clube_dados($slug);
    if (!empty($g['guia']['cidade'])) {
        return $g['guia']['cidade'];
    }
    return $m[$slug] ?? '';
}

// Nome completo para clubes que têm o mesmo nome da cidade (o Google confunde com notícias da cidade)
function tsp_seo_nome_completo($slug)
{
    $n = array(
        'rioclaro' => 'Rio Claro FC', 'taubate' => 'EC Taubaté', 'marilia' => 'Marília AC', 'catanduva' => 'Catanduva FC',
        'mirassol' => 'Mirassol FC', 'santos' => 'Santos FC', 'saojose' => 'São José EC', 'santoandre' => 'EC Santo André',
        'saocaetano' => 'AD São Caetano', 'batatais' => 'Batatais FC', 'barretos' => 'Barretos EC', 'tupa' => 'Tupã FC', 'olimpia' => 'Olímpia FC',
        'botafogosp' => 'Botafogo-SP (Ribeirão Preto)',
    );
    return $n[$slug] ?? '';
}

function tsp_seo_sigla_cidade($cidade)
{
    $s = array('Ribeirão Preto' => 'RP', 'São José do Rio Preto' => 'Rio Preto', 'São Bernardo do Campo' => 'ABC', 'Santo André' => 'ABC', 'São Caetano do Sul' => 'ABC', 'São José dos Campos' => 'SJC', 'Presidente Prudente' => 'Prudente');
    return $s[$cidade] ?? '';
}

function tsp_seo_norm($t)
{
    return strtolower(remove_accents((string) $t));
}

// "Comercial de Ribeirão Preto (Comercial-RP)", "Rio Claro FC", "Palmeiras"
function tsp_seo_nome_clube($termo)
{
    $nome = $termo->name;
    $completo = tsp_seo_nome_completo($termo->slug);
    $cidade = tsp_cidade_clube($termo->slug);
    $cid = preg_replace('~\s*\(.*\)$~', '', $cidade);
    if ($completo) {
        return $completo;
    }
    if ($cid === '' || $cid === 'São Paulo' || strpos(tsp_seo_norm($nome), tsp_seo_norm($cid)) !== false) {
        return $nome;
    }
    // Clubes grandes e já únicos no nome não precisam da cidade
    if (in_array($termo->slug, array('corinthians', 'palmeiras', 'saopaulo', 'bragantino', 'novorizontino', 'pontepreta', 'guarani', 'ituano', 'ferroviaria', 'interdelimeira', 'xvdepiracicaba', 'botafogosp'), true)) {
        return $nome;
    }
    $sig = tsp_seo_sigla_cidade($cid);
    if ($sig && strpos(tsp_seo_norm($nome), tsp_seo_norm($sig)) !== false) {
        return $nome; // "América de Rio Preto" já diz a cidade
    }
    return $nome . ' de ' . $cid . ($sig && strpos($nome, $sig) === false ? ' (' . $nome . '-' . $sig . ')' : '');
}

function tsp_seo_termo_tem_titulo_manual($termo)
{
    if (class_exists('WPSEO_Taxonomy_Meta')) {
        $t = WPSEO_Taxonomy_Meta::get_term_meta($termo, $termo->taxonomy, 'title');
        return is_string($t) && trim($t) !== '';
    }
    return false;
}

function tsp_seo_paginas_titulo()
{
    if (is_paged()) {
        return '';
    }
    $o = get_queried_object();
    if (!$o || empty($o->taxonomy) || tsp_seo_termo_tem_titulo_manual($o)) {
        return '';
    }
    $ano = wp_date('Y');
    if ($o->taxonomy === 'times') {
        $de = (strpos(tsp_de($o), 'da ') === 0 ? 'da ' : 'do ');
        $nc = tsp_seo_nome_clube($o);
        $cid = preg_replace('~\s*\(.*\)$~', '', tsp_cidade_clube($o->slug));
        // Clube com o mesmo nome da cidade e sem nome completo conferido: "futebol" no título separa das notícias da cidade
        if ($nc === $o->name && $cid && tsp_seo_norm($o->name) === tsp_seo_norm($cid)) {
            return $o->name . ' futebol: notícias do time hoje, jogos e tabela | TSP';
        }
        // Com sigla da região: "Comercial-RP: notícias do Comercial de Ribeirão Preto hoje | TSP"
        if (preg_match('~^(.+) \((.+-[^)]+)\)$~u', $nc, $m)) {
            return $m[2] . ': notícias ' . $de . $m[1] . ' hoje | TSP';
        }
        return 'Notícias ' . $de . $nc . ' hoje: jogos, tabela e elenco | TSP';
    }
    if ($o->taxonomy === 'campeonato') {
        $n = $o->name;
        return $n . (preg_match('~20\d\d~', $n) ? '' : ' ' . $ano) . ': tabela, classificação, jogos e notícias | TSP';
    }
    return '';
}

function tsp_seo_paginas_desc()
{
    $o = get_queried_object();
    if (!$o || empty($o->taxonomy) || is_paged()) {
        return '';
    }
    if (class_exists('WPSEO_Taxonomy_Meta')) {
        $d = WPSEO_Taxonomy_Meta::get_term_meta($o, $o->taxonomy, 'desc');
        if (is_string($d) && trim($d) !== '') {
            return '';
        }
    }
    if ($o->taxonomy === 'times') {
        $cid = tsp_cidade_clube($o->slug);
        $de = (strpos(tsp_de($o), 'da ') === 0 ? 'da ' : 'do ');
        return 'Últimas notícias ' . $de . tsp_seo_nome_clube($o) . ($cid && $cid !== 'São Paulo' && strpos(tsp_seo_nome_clube($o), preg_replace('~\s*\(.*\)$~', '', $cid)) === false ? ', de ' . $cid : '') . ': resultados, próximos jogos, classificação, elenco, contratações e bastidores. Atualizado todo dia pelo Tudo Sobre Paulista.';
    }
    if ($o->taxonomy === 'campeonato') {
        return $o->name . ': tabela e classificação atualizadas, jogos da rodada com horário e estádio, resultados e notícias dos clubes paulistas no Tudo Sobre Paulista.';
    }
    return '';
}

add_filter('wpseo_title', function ($t) {
    $n = is_tax(array('times', 'campeonato')) ? tsp_seo_paginas_titulo() : '';
    return $n ?: $t;
}, 50);
add_filter('wpseo_opengraph_title', function ($t) {
    $n = is_tax(array('times', 'campeonato')) ? tsp_seo_paginas_titulo() : '';
    return $n ?: $t;
}, 50);
add_filter('pre_get_document_title', function ($t) {
    $n = is_tax(array('times', 'campeonato')) ? tsp_seo_paginas_titulo() : '';
    return $n ?: $t;
}, 50);
add_filter('wpseo_metadesc', function ($d) {
    $n = is_tax(array('times', 'campeonato')) ? tsp_seo_paginas_desc() : '';
    return $n ?: $d;
}, 50);
add_filter('wpseo_opengraph_desc', function ($d) {
    $n = is_tax(array('times', 'campeonato')) ? tsp_seo_paginas_desc() : '';
    return $n ?: $d;
}, 50);
// Sem Yoast: a descrição sai na mão
add_action('wp_head', function () {
    if (defined('WPSEO_VERSION') || !is_tax(array('times', 'campeonato'))) {
        return;
    }
    $d = tsp_seo_paginas_desc();
    if ($d) {
        echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
    }
}, 2);
