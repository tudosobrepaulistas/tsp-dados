<?php
/**
 * Campinho da temporada (25/11/2026, pedido do Thiago): depois que os jogos da temporada começam, o campinho da página
 * do clube mostra o esquema mais usado nos últimos jogos e, em cada setor, os jogadores com MAIS MINUTOS ali.
 * Tudo das escalações confirmadas na base do TSP (fichas técnicas com fonte) e sempre como recorte (regra 16).
 * Antes dos jogos o tema monta o "time base" com o elenco anunciado (inc/mercado.php).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_cp_minuto($m)
{
    return preg_match('~^\s*(\d+)~', (string) $m, $x) ? min(120, (int) $x[1]) : 0;
}

function tsp_cp_norm($n)
{
    return sanitize_title(remove_accents((string) $n));
}

/**
 * @return array|null ['formacao' => '4-4-2', 'linhas' => [[['nome','min','tit','jogos'],...], ...] (goleiro primeiro),
 *                     'n' => jogos com escalação, 'de' => ts, 'ate' => ts, 'tecnico' => '']
 */
function tsp_campinho_temporada($api_id, $desde, $max_jogos = 8)
{
    $api_id = (int) $api_id;
    $ck = 'tsp_cp_' . $api_id . '_' . (int) $desde . '_' . (int) get_option('tsp_jogos_base_ver', 0);
    $c = wp_cache_get($ck, 'tsp');
    if ($c !== false) {
        return $c ?: null;
    }
    $js = tsp_jogos_buscar("(casa_id = %d OR fora_id = %d) AND status IN ('FT','AET','PEN') AND inicio >= %d", array($api_id, $api_id, (int) $desde), 'inicio DESC', 40);
    $jogos = array();
    foreach ($js as $j) {
        if (strpos((string) $j->liga, 'fem_') === 0) {
            continue;
        }
        $d = tsp_jogos_detalhes($j->id);
        $lado = (int) $j->casa_id === $api_id ? 'casa' : 'fora';
        $esc = (array) ($d['esc_tsp'][$lado] ?? array());
        if (empty($esc['time'])) {
            continue;
        }
        $linhas = array();
        foreach (explode(';', (string) $esc['time']) as $parte) {
            $nomes = array_values(array_filter(array_map('trim', explode(',', $parte))));
            if ($nomes) {
                $linhas[] = $nomes;
            }
        }
        if (count($linhas) < 3 || array_sum(array_map('count', $linhas)) !== 11) {
            continue; // escalação sem as linhas separadas não serve para o esquema
        }
        $jogos[] = array('j' => $j, 'linhas' => $linhas, 'entraram' => (array) ($esc['entraram'] ?? array()), 'tecnico' => $esc['tecnico'] ?? '');
        if (count($jogos) >= $max_jogos) {
            break;
        }
    }
    if (count($jogos) < 3) {
        wp_cache_set($ck, 0, 'tsp', 600);
        return null;
    }
    // Esquema mais usado nos últimos 5 jogos (empate: o do jogo mais recente)
    $conta = array();
    foreach (array_slice($jogos, 0, 5) as $g) {
        $f = implode('-', array_slice(array_map('count', $g['linhas']), 1));
        $conta[$f] = ($conta[$f] ?? 0) + 1;
    }
    $formacao = implode('-', array_slice(array_map('count', $jogos[0]['linhas']), 1));
    foreach ($conta as $f => $n) {
        if ($n > ($conta[$formacao] ?? 0)) {
            $formacao = $f;
        }
    }
    // Minutos de cada jogador e em que setor ele mais começou
    $u = array();
    foreach ($jogos as $g) {
        $saiu = array();
        foreach ($g['entraram'] as $s) {
            if (!empty($s['saiu'])) {
                $saiu[tsp_cp_norm($s['saiu'])] = tsp_cp_minuto($s['minuto'] ?? 0) ?: 90;
            }
        }
        foreach ($g['linhas'] as $li => $nomes) {
            foreach ($nomes as $nm) {
                $k = tsp_cp_norm($nm);
                $u[$k] = $u[$k] ?? array('nome' => $nm, 'min' => 0, 'tit' => 0, 'jogos' => 0, 'linha' => array());
                $u[$k]['min'] += $saiu[$k] ?? 90;
                $u[$k]['tit']++;
                $u[$k]['jogos']++;
                $u[$k]['linha'][$li] = ($u[$k]['linha'][$li] ?? 0) + 1;
            }
        }
        foreach ($g['entraram'] as $s) {
            $k = tsp_cp_norm($s['jogador'] ?? '');
            if (!$k) {
                continue;
            }
            $u[$k] = $u[$k] ?? array('nome' => $s['jogador'], 'min' => 0, 'tit' => 0, 'jogos' => 0, 'linha' => array());
            $u[$k]['min'] += max(0, 90 - (tsp_cp_minuto($s['minuto'] ?? 0) ?: 90));
            $u[$k]['jogos']++;
        }
    }
    // Preenche cada setor do esquema com quem tem mais minutos ali (setor = onde mais começou)
    $qtd = array_merge(array(1), array_map('intval', explode('-', $formacao)));
    $usado = array();
    $linhas = array();
    foreach ($qtd as $li => $q) {
        $cand = array_filter($u, function ($x) use ($li) {
            if (empty($x['linha'])) {
                return false;
            }
            arsort($x['linha']);
            return (int) key($x['linha']) === $li;
        });
        uasort($cand, function ($a, $b) {
            return $b['min'] <=> $a['min'];
        });
        $linhas[$li] = array();
        foreach ($cand as $k => $x) {
            if (count($linhas[$li]) < $q && !isset($usado[$k])) {
                $linhas[$li][] = $x;
                $usado[$k] = 1;
            }
        }
        // setor incompleto: quem mais jogou naquele setor, mesmo que more em outro
        if (count($linhas[$li]) < $q) {
            $resto = array_filter($u, function ($x) use ($li) {
                return !empty($x['linha'][$li]);
            });
            uasort($resto, function ($a, $b) {
                return $b['min'] <=> $a['min'];
            });
            foreach ($resto as $k => $x) {
                if (count($linhas[$li]) < $q && !isset($usado[$k])) {
                    $linhas[$li][] = $x;
                    $usado[$k] = 1;
                }
            }
        }
    }
    $r = array('formacao' => $formacao, 'linhas' => $linhas, 'n' => count($jogos), 'de' => (int) end($jogos)['j']->inicio,
        'ate' => (int) $jogos[0]['j']->inicio, 'tecnico' => $jogos[0]['tecnico']);
    wp_cache_set($ck, $r, 'tsp', 600);
    return $r;
}
