<?php
/**
 * Regra do Thiago (25/11/2026): número calculado pela base do TSP é RECORTE, não total.
 * A base ainda está recebendo as rodadas anteriores, então todo número que sai dela diz, de forma explícita,
 * quantos jogos entraram na conta e de quando a quando ("recorte dos últimos 12 jogos registrados, de 05/10 a 22/11").
 * Vale para time, jogador, treinador, confronto e página do jogo. Número oficial (tabela da CBF/FPF) ou de matéria com
 * fonte não é recorte e não leva o aviso.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Jogos encerrados de um time na base: quantos, o primeiro e o último
function tsp_recorte_time($api_id)
{
    static $cache = array();
    $api_id = (int) $api_id;
    if (isset($cache[$api_id])) {
        return $cache[$api_id];
    }
    $js = array_values(array_filter(tsp_jogos_buscar("(casa_id = %d OR fora_id = %d) AND status IN ('FT','AET','PEN')", array($api_id, $api_id), 'inicio ASC', 1000), function ($j) {
        return strpos((string) $j->liga, 'fem_') !== 0; // a página do time é do masculino
    }));
    return $cache[$api_id] = array('n' => count($js), 'de' => $js ? (int) $js[0]->inicio : 0, 'ate' => $js ? (int) end($js)->inicio : 0);
}

// Frase curta para FAQ e resposta rápida: "no recorte dos últimos 12 jogos registrados pelo TSP (de 05/10 a 22/11)"
function tsp_recorte_frase($n, $de = 0, $ate = 0)
{
    $n = (int) $n;
    $per = ($de && $ate) ? ' (de ' . wp_date('d/m/Y', $de) . ' a ' . wp_date('d/m/Y', $ate) . ')' : '';
    return 'no recorte ' . ($n === 1 ? 'do último jogo registrado' : 'dos últimos ' . $n . ' jogos registrados') . ' pelo TSP' . $per;
}

// Aviso visível, logo abaixo do título do bloco
function tsp_recorte_aviso($n, $de = 0, $ate = 0, $extra = '')
{
    if ((int) $n < 1) {
        return '';
    }
    $t = 'Recorte: ' . ((int) $n === 1 ? 'último jogo registrado' : 'últimos ' . (int) $n . ' jogos registrados') . ' na base do TSP'
        . (($de && $ate) ? ', de ' . wp_date('d/m/Y', $de) . ' a ' . wp_date('d/m/Y', $ate) : '')
        . '. Não é o total da temporada: a base ainda está recebendo as rodadas anteriores.' . ($extra ? ' ' . $extra : '');
    return '<p class="tsp-recorte">' . esc_html($t) . '</p>';
}

add_action('wp_enqueue_scripts', function () {
    wp_register_style('tsp-recorte', false);
    wp_enqueue_style('tsp-recorte');
    wp_add_inline_style('tsp-recorte', '.tsp-recorte{margin:4px 0 10px;padding:7px 10px;border-left:3px solid #E18330;background:#FBF3EA;color:#5C4A36;font-size:13px;line-height:1.45;border-radius:0 6px 6px 0}');
});
