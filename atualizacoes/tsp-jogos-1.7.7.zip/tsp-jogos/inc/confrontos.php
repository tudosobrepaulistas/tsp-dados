<?php
/**
 * Confrontos entre dois times (08/11/2026) e reforço de SEO/AEO/GEO das páginas de jogo.
 *  - /confronto/palmeiras-x-corinthians/ : resposta rápida (retrospecto na base do TSP, último e próximo jogo),
 *    lista de todos os jogos entre os dois, histórico de confrontos com fontes (texto do pré-jogo),
 *    notícias com os dois clubes e perguntas frequentes (FAQPage). Atualiza sozinha depois de cada jogo.
 *  - Página do jogo: caixa "Resposta rápida" no topo, perguntas frequentes com dados estruturados
 *    e link para a página de confrontos.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_conf_chave($id, $nome)
{
    return sanitize_title(tsp_jogos_nome_time($id, $nome));
}

function tsp_conf_url($ja, $na, $jb, $nb)
{
    $a = tsp_conf_chave($ja, $na);
    $b = tsp_conf_chave($jb, $nb);
    return apply_filters('tsp_conf_url', home_url('/confronto/' . $a . '-x-' . $b . '/'), $a, $b);
}

add_action('init', function () {
    add_rewrite_rule('^confronto/([a-z0-9-]+)-x-([a-z0-9-]+)/?$', 'index.php?tsp_confronto=$matches[1]|$matches[2]', 'top');
    if (get_option('tsp_conf_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_conf_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_confronto';
    return $v;
});

// Acha o id do time pela chave do endereço (nome sem acento)
function tsp_conf_time_por_chave($chave)
{
    global $wpdb;
    $t = tsp_jogos_tabela();
    $ids = $wpdb->get_results("SELECT casa_id AS id, casa AS nome FROM $t GROUP BY casa_id UNION SELECT fora_id, fora FROM $t GROUP BY fora_id");
    foreach ($ids as $r) {
        if (tsp_conf_chave($r->id, $r->nome) === $chave) {
            return array((int) $r->id, tsp_jogos_nome_time($r->id, $r->nome));
        }
    }
    return array(0, '');
}

function tsp_conf_jogos($a, $b)
{
    return tsp_jogos_buscar('(casa_id = %d AND fora_id = %d) OR (casa_id = %d AND fora_id = %d)', array($a, $b, $b, $a), 'inicio DESC', 200);
}

function tsp_conf_resumo($jogos, $a, $na, $nb)
{
    $v = $e = $d = 0;
    $ultimo = $proximo = null;
    foreach ($jogos as $j) {
        if ($j->gols_casa !== null && !in_array($j->status, array('NS', 'PST', 'CANC'), true)) {
            $ultimo = $ultimo ?: $j;
            $ga = (int) ((int) $j->casa_id === (int) $a ? $j->gols_casa : $j->gols_fora);
            $gb = (int) ((int) $j->casa_id === (int) $a ? $j->gols_fora : $j->gols_casa);
            $ga > $gb ? $v++ : ($ga < $gb ? $d++ : $e++);
        } elseif ($j->inicio > time() - 3 * HOUR_IN_SECONDS) {
            $proximo = $j; // a lista vem do mais novo para o mais antigo: fica o mais próximo
        }
    }
    return compact('v', 'e', 'd', 'ultimo', 'proximo');
}

function tsp_conf_linha_jogo($j)
{
    $c = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $f = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $pl = $j->gols_casa !== null && $j->status !== 'NS' ? (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : 'x';
    return array($c, $f, $pl);
}

add_action('template_redirect', function () {
    $q = get_query_var('tsp_confronto');
    if (!$q) {
        return;
    }
    list($ca, $cb) = array_pad(explode('|', $q), 2, '');
    list($a, $na) = tsp_conf_time_por_chave($ca);
    list($b, $nb) = tsp_conf_time_por_chave($cb);
    $jogos = ($a && $b) ? tsp_conf_jogos($a, $b) : array();
    if (!$jogos) {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        return;
    }
    $r = tsp_conf_resumo($jogos, $a, $na, $nb);
    tsp_cf_pagina($a, $na, $b, $nb, $jogos, $r); // 25/11/2026: dossiê completo do confronto (inc/confronto-dossie.php)
});

/* ---------- Página do jogo: resposta rápida, FAQ e link de confrontos ---------- */
function tsp_conf_bloco_jogo($j, $post_id)
{
    $casa = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $fora = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $liga = tsp_jogos_nome_liga($j->liga);
    $quando = wp_date('l, d/m/Y, \à\s H\hi', $j->inicio);
    $onde = trim((string) get_post_meta($post_id, 'tsp_onde_assistir', true));
    $d = tsp_jogos_detalhes($j->id);
    $canais = array();
    foreach ((array) ($d['prejogo']['onde_assistir']['canais'] ?? array()) as $c) {
        if (!empty($c['nome'])) {
            $canais[] = $c['nome'];
        }
    }
    $fim = $j->gols_casa !== null && !in_array($j->status, array('NS', 'PST', 'CANC'), true) && !tsp_jogos_ao_vivo($j);
    if ($fim) {
        $resp = $casa . ' ' . (int) $j->gols_casa . ' x ' . (int) $j->gols_fora . ' ' . $fora . ' foi o resultado do jogo de ' . wp_date('d/m/Y', $j->inicio) . ' (' . $liga . ')' . ($j->estadio ? ', no ' . $j->estadio : '') . '.' . (!empty($d['penaltis']) ? ' Pênaltis: ' . $d['penaltis'] . '.' : '');
    } else {
        $resp = $casa . ' x ' . $fora . ' será ' . $quando . ' (horário de Brasília)' . ($j->estadio ? ', no ' . $j->estadio . ($j->cidade ? ', em ' . $j->cidade : '') : '') . ' (' . $liga . ')' . '.' . ($canais ? ' Transmissão: ' . implode(', ', $canais) . '.' : ($onde ? ' Onde assistir: ' . wp_strip_all_tags($onde) . '.' : ''));
    }
    $faq = array();
    if (!$fim) {
        $faq[] = array('Que horas é o jogo ' . $casa . ' x ' . $fora . '?', $casa . ' x ' . $fora . ' começa ' . $quando . ', horário de Brasília.');
        if ($canais) {
            $faq[] = array('Onde assistir ' . $casa . ' x ' . $fora . '?', 'A partida terá transmissão de ' . implode(', ', $canais) . '.');
        }
    } else {
        $faq[] = array('Quanto foi ' . $casa . ' x ' . $fora . '?', $resp);
    }
    if ($j->estadio) {
        $faq[] = array('Onde vai ser ' . $casa . ' x ' . $fora . '?', 'No ' . $j->estadio . ($j->cidade ? ', em ' . $j->cidade : '') . '.');
    }
    // 1.8.8: mais perguntas que o torcedor faz no Google, todas respondidas com dados da base (nada estimado)
    if ($fim) {
        $gols = array();
        foreach ((array) ($d['eventos'] ?? array()) as $e) {
            if (strtolower($e['type'] ?? '') === 'goal' && !empty($e['player']['name'])) {
                $gols[] = $e['player']['name'] . ' (' . tsp_jogos_nome_time($e['team']['id'] ?? 0, $e['team']['name'] ?? '') . (!empty($e['time']['elapsed']) ? ', ' . (int) $e['time']['elapsed'] . "'" : '') . (stripos($e['detail'] ?? '', 'own') !== false ? ', contra' : '') . ')';
            }
        }
        if ($gols) {
            $faq[] = array('Quem fez os gols de ' . $casa . ' x ' . $fora . '?', implode('; ', $gols) . '.');
        }
    } else {
        foreach (array('casa' => $casa, 'fora' => $fora) as $lado => $nome) {
            $pv = (array) ($d['prejogo']['provaveis'][$lado] ?? array());
            if (!empty($pv['time'])) {
                $faq[] = array('Qual a provável escalação do ' . $nome . '?', mb_substr(wp_strip_all_tags($pv['time']), 0, 300) . (!empty($pv['tecnico']) ? ' Técnico: ' . $pv['tecnico'] . '.' : ''));
            }
        }
    }
    if ($j->arbitro) {
        $faq[] = array(($fim ? 'Quem apitou ' : 'Quem apita ') . $casa . ' x ' . $fora . '?', 'O árbitro ' . ($fim ? 'foi ' : 'é ') . $j->arbitro . '.');
    }
    if (function_exists('tsp_turbo_linha_tabela')) {
        $ta = tsp_turbo_linha_tabela($j->liga, $j->casa_id);
        $tb = tsp_turbo_linha_tabela($j->liga, $j->fora_id);
        if ($ta && $tb) {
            $faq[] = array('Como estão ' . $casa . ' e ' . $fora . ' no ' . $liga . '?', sprintf('O %s é o %dº colocado, com %d pontos em %d jogos; o %s é o %dº, com %d pontos em %d jogos.', $casa, $ta[0], $ta[3], $ta[4], $fora, $tb[0], $tb[3], $tb[4]));
        }
    }
    if (!empty($d['prejogo']['retrospecto'])) {
        $faq[] = array('Qual o retrospecto do confronto?', mb_substr(wp_strip_all_tags($d['prejogo']['retrospecto']), 0, 400));
    }
    $url = tsp_conf_url($j->casa_id, $j->casa, $j->fora_id, $j->fora);
    $h = '<aside class="tsp-resumo" aria-label="Resposta rápida"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p><p><a href="' . esc_url($url) . '">Todos os confrontos entre ' . esc_html($casa) . ' e ' . esc_html($fora) . ' →</a></p></aside>';
    $faq_html = '<section class="tsp-jogo__bloco"><h2>Perguntas frequentes</h2>';
    foreach ($faq as $x) {
        $faq_html .= '<h3>' . esc_html($x[0]) . '</h3><p>' . esc_html($x[1]) . '</p>';
    }
    $faq_html .= '</section>';
    return array($h, $faq_html, $faq);
}

add_filter('the_content', function ($c) {
    if (!is_singular('jogo') || !in_the_loop()) {
        return $c;
    }
    $j = tsp_jogos_do_post(get_the_ID());
    if (!$j) {
        return $c;
    }
    list($topo, $faq_html) = tsp_conf_bloco_jogo($j, get_the_ID());
    return $topo . $c . $faq_html;
}, 21);

add_action('wp_head', function () {
    if (!is_singular('jogo')) {
        return;
    }
    $j = tsp_jogos_do_post(get_queried_object_id());
    if (!$j) {
        return;
    }
    list(, , $faq) = tsp_conf_bloco_jogo($j, get_queried_object_id());
    $ld = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($x) {
        return array('@type' => 'Question', 'name' => $x[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $x[1]));
    }, $faq));
    echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
});
