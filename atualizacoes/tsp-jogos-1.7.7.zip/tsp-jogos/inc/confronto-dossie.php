<?php
/**
 * Dossiê do confronto (25/11/2026, pedido do Thiago): /confronto/time-a-x-time-b/ vira a página mais completa da internet
 * sobre o confronto, respondendo TODAS as intenções de busca. Tudo sai da base do TSP (custo zero) e do pré-jogo com fontes:
 *  - ficha do próximo jogo (data, hora, estádio, cidade, competição, rodada, árbitro, VAR, transmissão, ingressos);
 *  - situação na tabela, momento (últimos 5), mandante em casa x visitante fora, números da temporada lado a lado;
 *  - artilheiros, técnicos (com números da base), disciplina (cartões), prováveis escalações, desfalques e dúvidas;
 *  - retrospecto: base do TSP + histórico geral com fontes (prejogo.confronto), maiores vitórias, jogos marcantes, curiosidades;
 *  - notícias, perguntas frequentes (FAQPage) e SportsEvent. Dado que falta não aparece (nunca é estimado).
 * Nada de apostas, odds ou palpite.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Números de um time nos jogos encerrados da base (todas as competições da temporada ou uma liga)
function tsp_cf_numeros($id, $liga = '', $temporada = 0)
{
    $w = '(casa_id = %d OR fora_id = %d) AND status IN (\'FT\',\'AET\',\'PEN\')';
    $args = array($id, $id);
    if ($liga) {
        $w .= ' AND liga = %s';
        $args[] = $liga;
    }
    if ($temporada) {
        $w .= ' AND temporada = %d';
        $args[] = $temporada;
    }
    $lista = tsp_jogos_buscar($w, $args, 'inicio DESC', 120);
    $n = array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'gp' => 0, 'gc' => 0, 'sem_sofrer' => 0, 'sem_marcar' => 0, 'ambos' => 0, 'tres_mais' => 0,
        'casa' => array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'gp' => 0, 'gc' => 0), 'fora' => array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'gp' => 0, 'gc' => 0),
        'am' => 0, 'vm' => 0, 'com_ficha' => 0, 'tecnico' => '');
    foreach ($lista as $x) {
        $lado = (int) $x->casa_id === (int) $id ? 'casa' : 'fora';
        $a = (int) ($lado === 'casa' ? $x->gols_casa : $x->gols_fora);
        $b = (int) ($lado === 'casa' ? $x->gols_fora : $x->gols_casa);
        $r = $a > $b ? 'v' : ($a < $b ? 'd' : 'e');
        $n['j']++;
        $n[$r]++;
        $n['gp'] += $a;
        $n['gc'] += $b;
        $n['sem_sofrer'] += $b === 0 ? 1 : 0;
        $n['sem_marcar'] += $a === 0 ? 1 : 0;
        $n['ambos'] += ($a > 0 && $b > 0) ? 1 : 0;
        $n['tres_mais'] += ($a + $b) >= 3 ? 1 : 0;
        $n[$lado]['j']++;
        $n[$lado][$r]++;
        $n[$lado]['gp'] += $a;
        $n[$lado]['gc'] += $b;
        $d = tsp_jogos_detalhes($x->id);
        $e = (array) ($d['esc_tsp'][$lado] ?? array());
        if ($e) {
            if (!$n['tecnico'] && !empty($e['tecnico'])) {
                $n['tecnico'] = (string) $e['tecnico'];
            }
            if (isset($e['cartoes'])) {
                $n['com_ficha']++;
                $n['am'] += count((array) ($e['cartoes']['amarelos'] ?? array()));
                $n['vm'] += count((array) ($e['cartoes']['vermelhos'] ?? array()));
            }
        }
    }
    return $n;
}

function tsp_cf_pct($a, $b)
{
    return $b ? number_format_i18n(100 * $a / $b, 0) . '%' : '–';
}

function tsp_cf_media($a, $b)
{
    return $b ? number_format_i18n($a / $b, 2) : '–';
}

function tsp_cf_aprov($n)
{
    return $n['j'] ? number_format_i18n(100 * (3 * $n['v'] + $n['e']) / (3 * $n['j']), 1) . '%' : '–';
}

function tsp_cf_tecnico_base($nome)
{
    if (!$nome || !function_exists('tsp_mc_arquivo')) {
        return null;
    }
    $t = tsp_mc_arquivo('tecnicos.json');
    $k = sanitize_title(remove_accents($nome));
    foreach ((array) ($t['tecnicos'] ?? array()) as $kk => $x) {
        if ($kk === $k || sanitize_title(remove_accents($x['nome'] ?? '')) === $k) {
            return $x;
        }
    }
    return null;
}

function tsp_cf_pagina($a, $na, $b, $nb, $jogos, $r)
{
    $prox = $r['proximo'];
    $ult = $r['ultimo'];
    $ref = $prox ?: $ult;
    $liga = $ref ? $ref->liga : '';
    $temporada = $ref ? (int) $ref->temporada : 0;
    $nliga = $liga ? tsp_jogos_nome_liga($liga) : '';
    // Pré-jogo e dossiê histórico (o mais recente que tiver)
    $pre = $prox ? (array) (tsp_jogos_detalhes($prox->id)['prejogo'] ?? array()) : array();
    $dos = (array) ($pre['confronto'] ?? array());
    if (!$dos) {
        foreach ($jogos as $j) {
            $p = (array) (tsp_jogos_detalhes($j->id)['prejogo'] ?? array());
            if (!empty($p['confronto'])) {
                $dos = (array) $p['confronto'];
                break;
            }
        }
    }
    $retro_txt = '';
    $retro_fontes = array();
    foreach ($jogos as $j) {
        $p = (array) (tsp_jogos_detalhes($j->id)['prejogo'] ?? array());
        if (!empty($p['retrospecto'])) {
            $retro_txt = (string) $p['retrospecto'];
            $retro_fontes = (array) ($p['fontes'] ?? array());
            break;
        }
    }
    // Lados do próximo jogo (mandante primeiro)
    $casa_id = $prox ? (int) $prox->casa_id : (int) $a;
    $fora_id = $prox ? (int) $prox->fora_id : (int) $b;
    $nc = (int) $casa_id === (int) $a ? $na : $nb;
    $nf = (int) $fora_id === (int) $a ? $na : $nb;
    $cache = 'tsp_cf_' . md5($a . '-' . $b . '-' . get_option('tsp_jogos_base_hash') . '-' . $liga);
    $num = get_transient($cache);
    if (!is_array($num)) {
        $num = array(
            'c_tem' => tsp_cf_numeros($casa_id, '', $temporada), 'f_tem' => tsp_cf_numeros($fora_id, '', $temporada),
            'c_liga' => $liga ? tsp_cf_numeros($casa_id, $liga, $temporada) : array(), 'f_liga' => $liga ? tsp_cf_numeros($fora_id, $liga, $temporada) : array(),
        );
        set_transient($cache, $num, 6 * HOUR_IN_SECONDS);
    }
    $tc = $liga && function_exists('tsp_turbo_linha_tabela') ? tsp_turbo_linha_tabela($liga, $casa_id) : null;
    $tf = $liga && function_exists('tsp_turbo_linha_tabela') ? tsp_turbo_linha_tabela($liga, $fora_id) : null;
    $art = (array) (get_option('tsp_jogos_artilharia', array())[$liga] ?? array());
    $art_de = function ($id) use ($art) {
        return array_slice(array_values(array_filter($art, function ($x) use ($id) {
            return (int) ($x['time_id'] ?? 0) === (int) $id;
        })), 0, 3);
    };
    $pv = (array) ($pre['provaveis'] ?? array());
    $tec_c = (string) ($pv['casa']['tecnico'] ?? '') ?: $num['c_tem']['tecnico'];
    $tec_f = (string) ($pv['fora']['tecnico'] ?? '') ?: $num['f_tem']['tecnico'];
    $canais = array();
    foreach ((array) ($pre['onde_assistir']['canais'] ?? array()) as $c) {
        if (!empty($c['nome'])) {
            $canais[] = $c['nome'] . (!empty($c['tipo']) ? ' (' . $c['tipo'] . ')' : '');
        }
    }
    $arb = (array) ($pre['arbitragem'] ?? array());
    $arbitro = $prox ? ($prox->arbitro ?: (string) ($arb['arbitro'] ?? '')) : '';

    // ---------- Textos de resposta ----------
    $total = $r['v'] + $r['e'] + $r['d'];
    $quando = $prox ? wp_date('l, d/m/Y', $prox->inicio) . ', às ' . wp_date('H\hi', $prox->inicio) : '';
    $onde = $prox && $prox->estadio ? $prox->estadio . ($prox->cidade ? ', em ' . $prox->cidade : '') : '';
    $resp = $prox ? sprintf('%s x %s será %s (horário de Brasília)%s, pelo %s%s.', $nc, $nf, $quando, $onde ? ', no ' . $onde : '', $nliga, $prox->rodada ? ' (' . $prox->rodada . ')' : '') : '';
    if ($canais) {
        $resp .= ' Transmissão: ' . implode(', ', $canais) . '.';
    }
    $hist = '';
    if (!empty($dos['total']['jogos'])) {
        $t = $dos['total'];
        $hist = sprintf('Na história, são %d jogos: %d vitórias do %s, %d empates e %d vitórias do %s%s.', (int) $t['jogos'], (int) ($t['vitorias'][0] ?? 0), $dos['times'][0] ?? $na, (int) ($t['empates'] ?? 0), (int) ($t['vitorias'][1] ?? 0), $dos['times'][1] ?? $nb, !empty($t['ate']) ? ' (até ' . $t['ate'] . ')' : '');
    }
    $base_txt = $total ? sprintf('No recorte de %d jogos entre os dois registrados na base do TSP (não é o histórico completo), o %s venceu %d, o %s venceu %d e houve %d empate%s.', $total, $na, $r['v'], $nb, $r['d'], $r['e'], $r['e'] === 1 ? '' : 's') : '';
    $resp_curta = trim($resp . ' ' . ($hist ?: $base_txt));
    if (!$resp_curta) {
        $resp_curta = sprintf('%s e %s ainda não se enfrentaram nos jogos registrados na base do TSP.', $na, $nb);
    }
    $titulo = $na . ' x ' . $nb . ': ' . ($prox ? 'data, horário, onde assistir, escalações e retrospecto' : 'retrospecto, estatísticas e todos os jogos');
    $desc = $prox ? sprintf('%s x %s: %s, %s. Onde assistir, prováveis escalações, desfalques, tabela, momento e retrospecto completo.', $nc, $nf, wp_date('d/m', $prox->inicio) . ' às ' . wp_date('H\hi', $prox->inicio), $prox->estadio ?: $nliga) : $resp_curta;

    // ---------- FAQ ----------
    $faq = array();
    if ($prox) {
        $faq[] = array('Quando é o jogo ' . $nc . ' x ' . $nf . '?', $nc . ' x ' . $nf . ' será ' . wp_date('l, d/m/Y', $prox->inicio) . ', pelo ' . $nliga . ($prox->rodada ? ' (' . $prox->rodada . ')' : '') . '.');
        $faq[] = array('Que horas é ' . $nc . ' x ' . $nf . '?', 'A bola rola às ' . wp_date('H\hi', $prox->inicio) . ' (horário de Brasília).');
        if ($onde) {
            $faq[] = array('Onde vai ser ' . $nc . ' x ' . $nf . '?', 'No ' . $onde . '. O ' . $nc . ' tem o mando de campo.');
        }
        $faq[] = array('Onde assistir ' . $nc . ' x ' . $nf . '?', $canais ? 'A transmissão será de ' . implode(', ', $canais) . '.' : 'A transmissão ainda não foi confirmada pelos canais oficiais. O TSP atualiza esta página assim que houver anúncio.');
        if ($arbitro) {
            $faq[] = array('Quem apita ' . $nc . ' x ' . $nf . '?', 'O árbitro é ' . $arbitro . (!empty($arb['var']) ? '; no VAR, ' . $arb['var'] : '') . '.');
        }
    }
    if ($hist || $base_txt) {
        $faq[] = array('Qual o retrospecto de ' . $na . ' x ' . $nb . '?', trim($hist . ' ' . $base_txt));
        if ($hist) {
            $t = $dos['total'];
            $va = (int) ($t['vitorias'][0] ?? 0);
            $vb = (int) ($t['vitorias'][1] ?? 0);
            $faq[] = array('Quem ganhou mais vezes entre ' . $na . ' e ' . $nb . '?', $va === $vb ? 'O confronto está empatado em vitórias: ' . $va . ' para cada lado.' : (($va > $vb ? ($dos['times'][0] ?? $na) : ($dos['times'][1] ?? $nb)) . ' tem mais vitórias: ' . max($va, $vb) . ' contra ' . min($va, $vb) . ', com ' . (int) ($t['empates'] ?? 0) . ' empates.'));
        }
    }
    if ($ult) {
        list($c1, $f1, $pl1) = tsp_conf_linha_jogo($ult);
        $faq[] = array('Qual foi o último jogo entre ' . $na . ' e ' . $nb . '?', $c1 . ' ' . $pl1 . ' ' . $f1 . ', em ' . wp_date('d/m/Y', $ult->inicio) . ' (' . tsp_jogos_nome_liga($ult->liga) . ')' . ($ult->estadio ? ', no ' . $ult->estadio : '') . '.');
    } elseif (!empty($dos['ultimo'])) {
        $faq[] = array('Qual foi o último jogo entre ' . $na . ' e ' . $nb . '?', (string) $dos['ultimo']);
    }
    if (!empty($dos['maiores'])) {
        $faq[] = array('Qual a maior goleada de ' . $na . ' x ' . $nb . '?', implode(' ', array_map('strval', (array) $dos['maiores'])));
    }
    if ($tc && $tf) {
        $faq[] = array('Como estão ' . $nc . ' e ' . $nf . ' na tabela?', sprintf('O %s é o %dº colocado, com %d pontos em %d jogos; o %s é o %dº, com %d pontos em %d jogos.', $nc, $tc[0], $tc[3], $tc[4], $nf, $tf[0], $tf[3], $tf[4]));
    }
    $fc = tsp_turbo_forma_numeros($casa_id);
    $ff = tsp_turbo_forma_numeros($fora_id);
    if ($fc['n'] && $ff['n']) {
        $faq[] = array('Como chegam ' . $nc . ' e ' . $nf . '?', sprintf('Nos últimos %d jogos, o %s tem %d vitórias, %d empates e %d derrotas; o %s, nos últimos %d, tem %d vitórias, %d empates e %d derrotas.', $fc['n'], $nc, $fc['v'], $fc['e'], $fc['d'], $nf, $ff['n'], $ff['v'], $ff['e'], $ff['d']));
    }
    $ac = $art_de($casa_id);
    $af = $art_de($fora_id);
    if ($ac || $af) {
        $faq[] = array('Quem é o artilheiro de cada time no ' . $nliga . '?', trim(($ac ? 'No ' . $nc . ', ' . $ac[0]['jogador'] . ' (' . (int) $ac[0]['gols'] . ' gols). ' : '') . ($af ? 'No ' . $nf . ', ' . $af[0]['jogador'] . ' (' . (int) $af[0]['gols'] . ' gols).' : '')));
    }
    if ($tec_c && $tec_f) {
        $faq[] = array('Quem são os técnicos de ' . $nc . ' e ' . $nf . '?', $tec_c . ' comanda o ' . $nc . ', e ' . $tec_f . ' comanda o ' . $nf . '.');
    }
    foreach (array('casa' => $nc, 'fora' => $nf) as $lado => $nome) {
        if (!empty($pv[$lado]['time'])) {
            $faq[] = array('Qual a provável escalação do ' . $nome . '?', wp_strip_all_tags($pv[$lado]['time']) . '.');
        }
        if (!empty($pv[$lado]['desfalques'])) {
            $faq[] = array('Quais são os desfalques do ' . $nome . '?', wp_strip_all_tags($pv[$lado]['desfalques']) . '.');
        }
    }
    $lc = $num['c_liga'];
    $lf = $num['f_liga'];
    if (!empty($lc['j']) && !empty($lf['j'])) {
        $faq[] = array('Qual a média de gols de ' . $nc . ' e ' . $nf . '?', sprintf('No recorte dos jogos do %s registrados pelo TSP (não é o total da temporada), o %s marca %s e sofre %s gols por jogo em %d jogos; o %s marca %s e sofre %s em %d jogos.', $nliga, $nc, tsp_cf_media($lc['gp'], $lc['j']), tsp_cf_media($lc['gc'], $lc['j']), (int) $lc['j'], $nf, tsp_cf_media($lf['gp'], $lf['j']), tsp_cf_media($lf['gc'], $lf['j']), (int) $lf['j']));
    }
    $faq = array_slice(array_values(array_filter($faq, function ($x) {
        return trim((string) $x[1]) !== '';
    })), 0, 16);

    // ---------- SEO ----------
    foreach (array('pre_get_document_title', 'wpseo_title') as $fl) {
        add_filter($fl, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($desc) {
        return mb_substr($desc, 0, 158);
    }, 99);
    add_action('wp_head', function () use ($faq, $prox, $nc, $nf, $nliga) {
        $ld = array(array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($x) {
            return array('@type' => 'Question', 'name' => $x[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $x[1]));
        }, $faq)));
        if ($prox) {
            $ev = array('@context' => 'https://schema.org', '@type' => 'SportsEvent', 'name' => $nc . ' x ' . $nf, 'sport' => 'Futebol',
                'startDate' => wp_date('c', $prox->inicio), 'eventStatus' => 'https://schema.org/EventScheduled', 'description' => $nliga,
                'homeTeam' => array('@type' => 'SportsTeam', 'name' => $nc), 'awayTeam' => array('@type' => 'SportsTeam', 'name' => $nf));
            if ($prox->estadio) {
                $ev['location'] = array('@type' => 'Place', 'name' => $prox->estadio, 'address' => $prox->cidade ?: $prox->estadio);
            }
            $ld[] = $ev;
        }
        foreach ($ld as $x) {
            echo '<script type="application/ld+json">' . wp_json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
        }
    });

    // ---------- Página ----------
    status_header(200);
    get_header();
    echo '<style>.tsp-cf__menu{display:flex;gap:.4rem;flex-wrap:wrap;margin:.6rem 0 1rem}.tsp-cf__menu a{padding:.3rem .7rem;border:1px solid #ddd;border-radius:999px;font-size:.85rem;text-decoration:none}'
        . '.tsp-cf__placar{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:.8rem;text-align:center;padding:1rem;border:1px solid #e5e5e5;border-radius:14px;margin:1rem 0}'
        . '.tsp-cf__placar img{width:64px;height:64px;object-fit:contain}.tsp-cf__vs{font-size:1.1rem;font-weight:700}.tsp-cf__ficha{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:.5rem;margin:.6rem 0}'
        . '.tsp-cf__ficha div{border:1px solid #eee;border-radius:10px;padding:.5rem .7rem}.tsp-cf__ficha dt{font-size:.75rem;opacity:.7}.tsp-cf__ficha dd{margin:0;font-weight:600}'
        . '.tsp-cf__duas{display:grid;grid-template-columns:1fr 1fr;gap:1rem}@media(max-width:640px){.tsp-cf__duas{grid-template-columns:1fr}}'
        . '.tsp-cf table td:first-child,.tsp-cf table th:first-child{text-align:left}.tsp-cf table td,.tsp-cf table th{text-align:center}.tsp-cf .tsp-resumo p{margin:.3rem 0}</style>';
    echo '<main class="tsp-container tsp-com-lateral"><article class="tsp-materia tsp-confronto tsp-cf">';
    echo '<h1 class="tsp-materia__titulo">' . esc_html($titulo) . '</h1>';
    echo '<aside class="tsp-resumo" aria-label="Resposta rápida"><strong>Resposta rápida</strong><p>' . esc_html($resp_curta) . '</p></aside>';
    $menu = array('jogo' => 'Jogo', 'tabela' => 'Tabela', 'momento' => 'Momento', 'numeros' => 'Números', 'escalacoes' => 'Escalações', 'retrospecto' => 'Retrospecto', 'jogos' => 'Todos os jogos', 'faq' => 'Perguntas');
    echo '<nav class="tsp-cf__menu" aria-label="Nesta página">';
    foreach ($menu as $k => $v) {
        echo '<a href="#cf-' . esc_attr($k) . '">' . esc_html($v) . '</a>';
    }
    echo '</nav><div class="tsp-corpo">';

    // 1) Ficha do jogo
    if ($prox) {
        $jl = function_exists('tsp_jogos_post_do_jogo') ? tsp_jogos_post_do_jogo($prox->id) : 0;
        echo '<h2 id="cf-jogo">Quando é ' . esc_html($nc . ' x ' . $nf) . '?</h2>';
        echo '<p>' . esc_html($resp) . '</p>';
        echo '<div class="tsp-cf__placar"><div>' . tsp_jogos_escudo_html($casa_id, $nc) . '<br><b>' . esc_html($nc) . '</b><br><small>mandante</small></div><div class="tsp-cf__vs">' . esc_html(wp_date('d/m', $prox->inicio)) . '<br>' . esc_html(wp_date('H\hi', $prox->inicio)) . '</div><div>' . tsp_jogos_escudo_html($fora_id, $nf) . '<br><b>' . esc_html($nf) . '</b><br><small>visitante</small></div></div>'; // phpcs:ignore
        $ficha = array_filter(array(
            'Data' => wp_date('l, d/m/Y', $prox->inicio), 'Horário' => wp_date('H\hi', $prox->inicio) . ' (Brasília)', 'Competição' => $nliga, 'Rodada/fase' => $prox->rodada,
            'Estádio' => $prox->estadio, 'Cidade' => $prox->cidade, 'Transmissão' => $canais ? implode(', ', $canais) : 'Em atualização', 'Árbitro' => $arbitro ?: 'Em atualização',
            'VAR' => (string) ($arb['var'] ?? ''), 'Ingressos' => (string) ($pre['ingressos']['texto'] ?? ''),
        ));
        echo '<dl class="tsp-cf__ficha">';
        foreach ($ficha as $k => $v) {
            echo '<div><dt>' . esc_html($k) . '</dt><dd>' . esc_html($v) . '</dd></div>';
        }
        echo '</dl>';
        if ($jl && get_post_status($jl) === 'publish') {
            echo '<p><a href="' . esc_url(get_permalink($jl)) . '">Página do jogo, com placar ao vivo e ficha técnica →</a></p>';
        }
        if (!empty($pre['analise'])) {
            echo '<h3>O que está em jogo</h3>';
            foreach ((array) $pre['analise'] as $p) {
                echo '<p>' . esc_html($p) . '</p>';
            }
        }
    }

    // 2) Tabela
    if ($tc && $tf) {
        echo '<h2 id="cf-tabela">Como ' . esc_html($nc) . ' e ' . esc_html($nf) . ' estão no ' . esc_html($nliga) . '?</h2>';
        echo '<p>' . esc_html(sprintf('O %s é o %dº colocado, com %d pontos em %d jogos (%d vitórias, %d empates, %d derrotas, saldo %+d). O %s é o %dº, com %d pontos em %d jogos (%d vitórias, %d empates, %d derrotas, saldo %+d). Diferença: %d ponto%s.', $nc, $tc[0], $tc[3], $tc[4], $tc[5], $tc[6], $tc[7], $tc[8], $nf, $tf[0], $tf[3], $tf[4], $tf[5], $tf[6], $tf[7], $tf[8], abs($tc[3] - $tf[3]), abs($tc[3] - $tf[3]) === 1 ? '' : 's')) . '</p>';
        echo '<div class="tsp-rolagem"><table class="tsp-stats"><thead><tr><th>Time</th><th>Pos.</th><th>P</th><th>J</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th><th>SG</th><th>Aprov.</th></tr></thead><tbody>';
        foreach (array(array($nc, $tc), array($nf, $tf)) as $x) {
            $t = $x[1];
            echo '<tr><td>' . esc_html($x[0]) . '</td><td>' . (int) $t[0] . 'º</td><td><b>' . (int) $t[3] . '</b></td><td>' . (int) $t[4] . '</td><td>' . (int) $t[5] . '</td><td>' . (int) $t[6] . '</td><td>' . (int) $t[7] . '</td><td>' . (int) ($t[10] ?? 0) . '</td><td>' . (int) ($t[11] ?? 0) . '</td><td>' . sprintf('%+d', (int) $t[8]) . '</td><td>' . esc_html($t[4] ? number_format_i18n(100 * $t[3] / (3 * $t[4]), 1) . '%' : '–') . '</td></tr>';
        }
        echo '</tbody></table></div>';
        echo '<p class="tsp-nota"><a href="' . esc_url(home_url('/campeonato/')) . '">Tabela completa do ' . esc_html($nliga) . '</a></p>';
    }

    // 3) Momento
    echo '<h2 id="cf-momento">Como chegam ' . esc_html($nc) . ' e ' . esc_html($nf) . '?</h2>';
    echo '<div class="tsp-cf__duas"><div><h3>' . esc_html($nc) . ': últimos 5 jogos</h3>' . tsp_jogos_forma_html($casa_id, $nc) . '<h3>' . esc_html($nc) . ' como mandante</h3>' . tsp_jogos_forma_html($casa_id, $nc, 'casa') . '</div>'; // phpcs:ignore
    echo '<div><h3>' . esc_html($nf) . ': últimos 5 jogos</h3>' . tsp_jogos_forma_html($fora_id, $nf) . '<h3>' . esc_html($nf) . ' como visitante</h3>' . tsp_jogos_forma_html($fora_id, $nf, 'fora') . '</div></div>'; // phpcs:ignore

    // 4) Números lado a lado
    $blocos = array();
    if (!empty($lc['j']) && !empty($lf['j'])) {
        $blocos[] = array('No ' . $nliga . ' (recorte: ' . (int) $lc['j'] . ' jogos do ' . $nc . ' e ' . (int) $lf['j'] . ' do ' . $nf . ' registrados)', $lc, $lf);
    }
    if (!empty($num['c_tem']['j']) && !empty($num['f_tem']['j'])) {
        $blocos[] = array('Em todas as competições (recorte: ' . (int) $num['c_tem']['j'] . ' jogos do ' . $nc . ' e ' . (int) $num['f_tem']['j'] . ' do ' . $nf . ' registrados)', $num['c_tem'], $num['f_tem']);
    }
    if ($blocos) {
        echo '<h2 id="cf-numeros">' . esc_html($nc . ' x ' . $nf) . ': estatísticas comparadas</h2>';
        echo '<p class="tsp-recorte">' . esc_html('Recorte: só os jogos já registrados na base do TSP (o número de jogos de cada time está no título de cada tabela). Não é o total da temporada: a base ainda está recebendo as rodadas anteriores.') . '</p>';
        foreach ($blocos as $bl) {
            list($tt, $x, $y) = $bl;
            $linhas = array(
                'Jogos' => array($x['j'], $y['j']), 'Vitórias' => array($x['v'], $y['v']), 'Empates' => array($x['e'], $y['e']), 'Derrotas' => array($x['d'], $y['d']),
                'Aproveitamento' => array(tsp_cf_aprov($x), tsp_cf_aprov($y)), 'Gols marcados' => array($x['gp'], $y['gp']), 'Gols sofridos' => array($x['gc'], $y['gc']),
                'Média de gols marcados' => array(tsp_cf_media($x['gp'], $x['j']), tsp_cf_media($y['gp'], $y['j'])), 'Média de gols sofridos' => array(tsp_cf_media($x['gc'], $x['j']), tsp_cf_media($y['gc'], $y['j'])),
                'Jogos sem sofrer gol' => array($x['sem_sofrer'] . ' (' . tsp_cf_pct($x['sem_sofrer'], $x['j']) . ')', $y['sem_sofrer'] . ' (' . tsp_cf_pct($y['sem_sofrer'], $y['j']) . ')'),
                'Jogos sem marcar' => array($x['sem_marcar'] . ' (' . tsp_cf_pct($x['sem_marcar'], $x['j']) . ')', $y['sem_marcar'] . ' (' . tsp_cf_pct($y['sem_marcar'], $y['j']) . ')'),
                'Jogos em que os dois marcaram' => array(tsp_cf_pct($x['ambos'], $x['j']), tsp_cf_pct($y['ambos'], $y['j'])),
                'Jogos com 3 gols ou mais' => array(tsp_cf_pct($x['tres_mais'], $x['j']), tsp_cf_pct($y['tres_mais'], $y['j'])),
                $nc . ' em casa / ' . $nf . ' fora' => array($x['casa']['j'] ? $x['casa']['v'] . 'V ' . $x['casa']['e'] . 'E ' . $x['casa']['d'] . 'D' : '–', $y['fora']['j'] ? $y['fora']['v'] . 'V ' . $y['fora']['e'] . 'E ' . $y['fora']['d'] . 'D' : '–'),
            );
            if ($x['com_ficha'] && $y['com_ficha']) {
                $linhas['Cartões amarelos por jogo'] = array(tsp_cf_media($x['am'], $x['com_ficha']), tsp_cf_media($y['am'], $y['com_ficha']));
                $linhas['Cartões vermelhos'] = array($x['vm'], $y['vm']);
            }
            echo '<h3>' . esc_html($tt) . '</h3><div class="tsp-rolagem"><table class="tsp-stats"><thead><tr><th></th><th>' . esc_html($nc) . '</th><th>' . esc_html($nf) . '</th></tr></thead><tbody>';
            foreach ($linhas as $k => $v) {
                echo '<tr><td>' . esc_html($k) . '</td><td>' . esc_html((string) $v[0]) . '</td><td>' . esc_html((string) $v[1]) . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '<p class="tsp-nota">Recorte calculado com os jogos registrados na base do TSP (resultados conferidos em 2 fontes), não o total da temporada. Cartões: só jogos com ficha técnica registrada.</p>';
    }
    if ($ac || $af) {
        echo '<h3>Artilheiros no ' . esc_html($nliga) . ' (recorte dos jogos registrados)</h3><div class="tsp-cf__duas">';
        foreach (array(array($nc, $ac), array($nf, $af)) as $x) {
            echo '<div><b>' . esc_html($x[0]) . '</b><ol>';
            foreach ($x[1] as $g) {
                echo '<li>' . esc_html($g['jogador']) . ' – ' . (int) $g['gols'] . ' gols</li>';
            }
            echo $x[1] ? '' : '<li>Em atualização</li>';
            echo '</ol></div>';
        }
        echo '</div>';
    }

    // 5) Técnicos e escalações
    echo '<h2 id="cf-escalacoes">Prováveis escalações, desfalques e técnicos</h2>';
    echo '<div class="tsp-cf__duas">';
    foreach (array('casa' => array($nc, $tec_c), 'fora' => array($nf, $tec_f)) as $lado => $x) {
        echo '<div><h3>' . esc_html($x[0]) . '</h3>';
        if ($x[1]) {
            $tb = tsp_cf_tecnico_base($x[1]);
            echo '<p><b>Técnico:</b> ' . esc_html($x[1]) . ($tb && !empty($tb['jogos']) ? ' — ' . esc_html(sprintf('recorte de %d jogos registrados na base do TSP: %dV %dE %dD (%s%%)', $tb['jogos'], $tb['V'], $tb['E'], $tb['D'], number_format_i18n((float) $tb['aproveitamento'], 1))) : '') . '</p>';
        }
        $p = (array) ($pv[$lado] ?? array());
        echo '<p><b>Provável escalação:</b> ' . esc_html(!empty($p['time']) ? wp_strip_all_tags($p['time']) : 'Em atualização (sai até 6 horas antes do jogo)') . '</p>';
        if (!empty($p['desfalques'])) {
            echo '<p><b>Desfalques:</b> ' . esc_html(wp_strip_all_tags($p['desfalques'])) . '</p>';
        }
        if (!empty($p['duvidas'])) {
            echo '<p><b>Dúvidas:</b> ' . esc_html(wp_strip_all_tags($p['duvidas'])) . '</p>';
        }
        echo '</div>';
    }
    echo '</div>';
    if (!empty($pv['fontes']) && function_exists('tsp_jogos_fontes_html')) {
        echo tsp_jogos_fontes_html(array_slice((array) $pv['fontes'], 0, 4)); // phpcs:ignore
    }
    $tbc = tsp_cf_tecnico_base($tec_c);
    if ($tbc && $tec_f && !empty($tbc['contra'][sanitize_title(remove_accents($tec_f))])) {
        $h2h = $tbc['contra'][sanitize_title(remove_accents($tec_f))];
        echo '<p><b>' . esc_html($tec_c . ' x ' . $tec_f) . ':</b> ' . esc_html(sprintf('recorte de %d jogos registrados na base do TSP, com %d vitórias de %s, %d empates e %d vitórias de %s.', $h2h['jogos'], $h2h['V'], $tec_c, $h2h['E'], $h2h['D'], $tec_f)) . '</p>';
    }

    // 6) Retrospecto
    echo '<h2 id="cf-retrospecto">Qual o retrospecto de ' . esc_html($na . ' x ' . $nb) . '?</h2>';
    if ($hist) {
        echo '<p><b>' . esc_html($hist) . '</b></p>';
        $t = $dos['total'];
        echo '<div class="tsp-rolagem"><table class="tsp-stats"><thead><tr><th>Histórico geral</th><th>Jogos</th><th>Vitórias ' . esc_html($dos['times'][0] ?? $na) . '</th><th>Empates</th><th>Vitórias ' . esc_html($dos['times'][1] ?? $nb) . '</th>' . (isset($t['gols']) ? '<th>Gols</th>' : '') . '</tr></thead><tbody><tr><td>Todos os jogos</td><td>' . (int) $t['jogos'] . '</td><td>' . (int) ($t['vitorias'][0] ?? 0) . '</td><td>' . (int) ($t['empates'] ?? 0) . '</td><td>' . (int) ($t['vitorias'][1] ?? 0) . '</td>' . (isset($t['gols']) ? '<td>' . esc_html(implode(' x ', (array) $t['gols'])) . '</td>' : '') . '</tr>';
        foreach ((array) ($dos['recortes'] ?? array()) as $rc) {
            echo '<tr><td>' . esc_html($rc['nome'] ?? '') . '</td><td>' . (int) ($rc['jogos'] ?? 0) . '</td><td>' . (int) ($rc['vitorias'][0] ?? 0) . '</td><td>' . (int) ($rc['empates'] ?? 0) . '</td><td>' . (int) ($rc['vitorias'][1] ?? 0) . '</td>' . (isset($t['gols']) ? '<td>' . esc_html(implode(' x ', (array) ($rc['gols'] ?? array()))) . '</td>' : '') . '</tr>';
        }
        echo '</tbody></table></div>';
    }
    if ($base_txt) {
        echo '<p>' . esc_html($base_txt) . '</p>';
    }
    foreach (array('primeiro' => 'Primeiro jogo', 'ultimo' => 'Último encontro antes da base do TSP') as $k => $rot) {
        if (!empty($dos[$k])) {
            echo '<p><b>' . esc_html($rot) . ':</b> ' . esc_html((string) $dos[$k]) . '</p>';
        }
    }
    foreach (array('maiores' => 'Maiores vitórias', 'marcantes' => 'Jogos marcantes', 'decisoes' => 'Decisões e mata-matas', 'artilheiros' => 'Artilheiros do confronto', 'curiosidades' => 'Curiosidades') as $k => $rot) {
        if (!empty($dos[$k])) {
            echo '<h3>' . esc_html($rot) . '</h3><ul>';
            foreach ((array) $dos[$k] as $x) {
                echo '<li>' . esc_html((string) $x) . '</li>';
            }
            echo '</ul>';
        }
    }
    if (!$hist && $retro_txt) {
        echo '<p>' . esc_html($retro_txt) . '</p>';
    }
    $fontes = array_merge((array) ($dos['fontes'] ?? array()), $hist ? array() : $retro_fontes);
    if ($fontes && function_exists('tsp_jogos_fontes_html')) {
        echo tsp_jogos_fontes_html(array_slice(array_unique($fontes), 0, 6)); // phpcs:ignore
    }
    if (!$hist && !$retro_txt && !$total) {
        echo '<p>Histórico geral do confronto: em atualização.</p>';
    }

    // 7) Todos os jogos
    echo '<h2 id="cf-jogos">Todos os jogos entre ' . esc_html($na) . ' e ' . esc_html($nb) . ' na base do TSP</h2><div class="tsp-rolagem"><table class="tsp-stats tsp-confronto__tabela"><thead><tr><th>Data</th><th>Jogo</th><th>Competição</th><th>Estádio</th></tr></thead><tbody>';
    foreach ($jogos as $j) {
        list($c, $f, $pl) = tsp_conf_linha_jogo($j);
        $pid = function_exists('tsp_jogos_post_do_jogo') ? tsp_jogos_post_do_jogo($j->id) : 0;
        $txt = esc_html($c . ' ' . $pl . ' ' . $f);
        echo '<tr><td>' . esc_html(wp_date('d/m/Y', $j->inicio)) . '</td><td>' . ($pid && get_post_status($pid) === 'publish' ? '<a href="' . esc_url(get_permalink($pid)) . '">' . $txt . '</a>' : $txt) . '</td><td>' . esc_html(tsp_jogos_nome_liga($j->liga) . ' ' . $j->temporada) . '</td><td>' . esc_html($j->estadio) . '</td></tr>';
    }
    echo '</tbody></table></div>';

    // 8) Notícias
    $sa = tsp_jogos_slug_do_time($a);
    $sb = tsp_jogos_slug_do_time($b);
    $tax = array_filter(array($sa ? array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $sa) : null, $sb ? array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $sb) : null));
    $q = new WP_Query($tax ? array('post_type' => array('materia', 'post'), 'posts_per_page' => 8, 'no_found_rows' => true, 'ignore_sticky_posts' => true, 'tax_query' => array_merge(array('relation' => count($tax) > 1 ? 'AND' : 'OR'), array_values($tax))) : array('post_type' => array('materia', 'post'), 'posts_per_page' => 8, 'no_found_rows' => true, 's' => $na . ' ' . $nb));
    if ($q->posts) {
        echo '<h2>Notícias de ' . esc_html($na . ' x ' . $nb) . '</h2><ul class="tsp-jogo__noticias">';
        foreach ($q->posts as $p) {
            echo '<li><a href="' . esc_url(get_permalink($p)) . '">' . esc_html(get_the_title($p)) . '</a></li>';
        }
        echo '</ul>';
    }

    // 9) FAQ
    echo '<h2 id="cf-faq">Perguntas frequentes sobre ' . esc_html($na . ' x ' . $nb) . '</h2>';
    foreach ($faq as $x) {
        echo '<h3>' . esc_html($x[0]) . '</h3><p>' . esc_html($x[1]) . '</p>';
    }
    echo '<p class="tsp-nota">Página atualizada automaticamente com a base do Tudo Sobre Paulista (resultados com 2 fontes) e com o pré-jogo apurado em matérias e comunicados oficiais. Dado que ainda não foi confirmado aparece como "em atualização".</p>';
    echo '</div></article><aside class="tsp-lateral" aria-label="Mais do TSP">';
    if (function_exists('tsp_lista_ultimas')) {
        tsp_lista_ultimas(6);
    }
    echo '</aside></main>';
    get_footer();
    exit;
}
