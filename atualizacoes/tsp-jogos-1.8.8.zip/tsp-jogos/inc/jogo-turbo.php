<?php
/**
 * Fase 1 do plano de SEO (13/11/2026): página do jogo turbinada.
 *  - Título do Google: "X x Y: onde assistir, escalações e estatísticas (15/11)"; depois do jogo,
 *    "X 2 x 1 Y: resultado, gols e estatísticas (15/11)". Descrição = a resposta rápida (o que o torcedor procura).
 *  - Bloco "Estatísticas de X x Y": campanha na competição e últimos 5 jogos, da base do TSP
 *    (resultados conferidos em 2 fontes). Nada é estimado: sem dado, a linha não aparece.
 *  - "Matérias sobre X x Y": primeiro as que citam os dois clubes perto da data do jogo (raio-x, escalações,
 *    onde assistir, pós-jogo), depois as de cada clube.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_turbo_encerrado($j)
{
    return $j->gols_casa !== null && in_array($j->status, array('FT', 'AET', 'PEN'), true);
}

// Título da página (H1) e do Google
function tsp_turbo_titulo($j, $com_data = false)
{
    $c = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $f = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $t = tsp_turbo_encerrado($j)
        ? $c . ' ' . (int) $j->gols_casa . ' x ' . (int) $j->gols_fora . ' ' . $f . ': resultado, gols e estatísticas'
        : $c . ' x ' . $f . ': onde assistir, escalações e estatísticas';
    return $com_data ? $t . ' (' . wp_date('d/m', $j->inicio) . ')' : $t;
}

function tsp_turbo_desc($j, $post_id)
{
    if (!function_exists('tsp_conf_bloco_jogo')) {
        return '';
    }
    list($topo) = tsp_conf_bloco_jogo($j, $post_id);
    if (!preg_match('~<p>(.*?)</p>~s', $topo, $m)) {
        return '';
    }
    $d = html_entity_decode(wp_strip_all_tags($m[1]), ENT_QUOTES, 'UTF-8');
    if (mb_strlen($d) > 155) {
        $d = rtrim(mb_substr($d, 0, 152), " ,.;") . '...';
    }
    return $d;
}

function tsp_turbo_jogo_atual()
{
    static $j = false;
    if ($j === false) {
        $j = is_singular('jogo') ? tsp_jogos_do_post(get_queried_object_id()) : null;
    }
    return $j;
}

foreach (array('wpseo_title', 'wpseo_opengraph_title', 'wpseo_twitter_title', 'pre_get_document_title') as $f) {
    add_filter($f, function ($t) {
        $j = tsp_turbo_jogo_atual();
        return $j ? tsp_turbo_titulo($j, true) . ' | TSP' : $t;
    }, 60);
}
foreach (array('wpseo_metadesc', 'wpseo_opengraph_desc', 'wpseo_twitter_description') as $f) {
    add_filter($f, function ($d) {
        $j = tsp_turbo_jogo_atual();
        return $j ? (tsp_turbo_desc($j, get_queried_object_id()) ?: $d) : $d;
    }, 60);
}
add_action('wp_head', function () {
    $j = tsp_turbo_jogo_atual();
    if ($j && !defined('WPSEO_VERSION')) {
        echo '<meta name="description" content="' . esc_attr(tsp_turbo_desc($j, get_queried_object_id())) . '">' . "\n";
    }
}, 2);

/* ---------- Estatísticas de X x Y (base do TSP) ---------- */
function tsp_turbo_linha_tabela($liga, $time_id)
{
    foreach ((array) (tsp_jogos_classificacao($liga)['grupos'] ?? array()) as $g) {
        foreach ((array) $g as $r) {
            if ((int) $r[1] === (int) $time_id) {
                return $r;
            }
        }
    }
    return null;
}

function tsp_turbo_forma_numeros($time_id)
{
    $v = $e = $d = $gp = $gc = 0;
    $lista = tsp_jogos_forma($time_id);
    foreach ($lista as $x) {
        $a = (int) ($x->casa_id == $time_id ? $x->gols_casa : $x->gols_fora);
        $b = (int) ($x->casa_id == $time_id ? $x->gols_fora : $x->gols_casa);
        $gp += $a;
        $gc += $b;
        $a > $b ? $v++ : ($a < $b ? $d++ : $e++);
    }
    return array('n' => count($lista), 'v' => $v, 'e' => $e, 'd' => $d, 'gp' => $gp, 'gc' => $gc);
}

function tsp_turbo_num($x, $casas = 1)
{
    return number_format_i18n($x, $casas);
}

function tsp_turbo_estatisticas_html($j)
{
    $casa = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $fora = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $linhas = array();
    $liga = tsp_jogos_nome_liga($j->liga);

    // Campanha na competição (tabela da base)
    $ta = tsp_turbo_linha_tabela($j->liga, $j->casa_id);
    $tb = tsp_turbo_linha_tabela($j->liga, $j->fora_id);
    if ($ta && $tb) {
        $aprov = function ($r) {
            return (int) $r[4] ? tsp_turbo_num(100 * (int) $r[3] / (3 * (int) $r[4]), 0) . '%' : '-';
        };
        $linhas[] = array('Posição no ' . $liga, (int) $ta[0] . 'º', (int) $tb[0] . 'º');
        $linhas[] = array('Pontos', (int) $ta[3], (int) $tb[3]);
        $linhas[] = array('Jogos', (int) $ta[4], (int) $tb[4]);
        $linhas[] = array('Vitórias / empates / derrotas', (int) $ta[5] . ' / ' . (int) $ta[6] . ' / ' . (int) $ta[7], (int) $tb[5] . ' / ' . (int) $tb[6] . ' / ' . (int) $tb[7]);
        $linhas[] = array('Aproveitamento', $aprov($ta), $aprov($tb));
        if (isset($ta[10], $tb[10]) && ((int) $ta[10] + (int) $ta[11] + (int) $tb[10] + (int) $tb[11]) > 0) {
            $linhas[] = array('Gols marcados / sofridos', (int) $ta[10] . ' / ' . (int) $ta[11], (int) $tb[10] . ' / ' . (int) $tb[11]);
            if ((int) $ta[4] && (int) $tb[4]) {
                $linhas[] = array('Média de gols marcados', tsp_turbo_num((int) $ta[10] / (int) $ta[4]), tsp_turbo_num((int) $tb[10] / (int) $tb[4]));
            }
        }
        $linhas[] = array('Saldo de gols', ((int) $ta[8] > 0 ? '+' : '') . (int) $ta[8], ((int) $tb[8] > 0 ? '+' : '') . (int) $tb[8]);
    }

    // Últimos 5 jogos (qualquer competição registrada)
    $fa = tsp_turbo_forma_numeros($j->casa_id);
    $fb = tsp_turbo_forma_numeros($j->fora_id);
    if ($fa['n'] && $fb['n']) {
        $linhas[] = array(($fa['n'] === $fb['n'] ? 'Últimos ' . $fa['n'] . ' jogos' : 'Últimos jogos') . ' (V / E / D)', $fa['v'] . ' / ' . $fa['e'] . ' / ' . $fa['d'], $fb['v'] . ' / ' . $fb['e'] . ' / ' . $fb['d']);
        $linhas[] = array('Gols nos últimos jogos (feitos / sofridos)', $fa['gp'] . ' / ' . $fa['gc'], $fb['gp'] . ' / ' . $fb['gc']);
    }

    // Retrospecto entre os dois fica de fora de propósito: a base só tem a temporada completa desde a 28ª rodada da
    // Série A, então a conta sairia incompleta. O retrospecto com fontes aparece no bloco do pré-jogo quando existe.
    $ret = '';
    if (count($linhas) < 2) {
        return '';
    }
    $h = '<section class="tsp-jogo__bloco" id="estatisticas"><h2>Estatísticas de ' . esc_html($casa . ' x ' . $fora) . '</h2>';
    $h .= '<table class="tsp-stats tsp-stats--comparar"><thead><tr><th>' . esc_html($casa) . '</th><th></th><th>' . esc_html($fora) . '</th></tr></thead><tbody>';
    foreach ($linhas as $l) {
        $h .= '<tr><td>' . esc_html((string) $l[1]) . '</td><th>' . esc_html($l[0]) . '</th><td>' . esc_html((string) $l[2]) . '</td></tr>';
    }
    $h .= '</tbody></table>';
    $h .= '<p class="tsp-nota">' . esc_html(trim($ret . ' Números da base própria do TSP, com resultados conferidos em 2 fontes jornalísticas' . ($ta ? '; tabela do ' . $liga . ' atualizada a cada rodada' : '') . '.')) . '</p>';
    return $h . '</section>';
}

/* ---------- Matérias sobre o jogo ---------- */
function tsp_turbo_materias_html($j)
{
    $casa = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $fora = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $sa = tsp_jogos_slug_do_time($j->casa_id);
    $sb = tsp_jogos_slug_do_time($j->fora_id);
    $slugs = array_values(array_filter(array($sa, $sb)));
    if (!$slugs) {
        return '';
    }
    $janela = array(array('after' => wp_date('Y-m-d H:i:s', $j->inicio - 6 * DAY_IN_SECONDS), 'before' => wp_date('Y-m-d H:i:s', $j->inicio + 2 * DAY_IN_SECONDS), 'inclusive' => true));
    $base = array('post_type' => array('materia', 'post'), 'post_status' => 'publish', 'no_found_rows' => true, 'ignore_sticky_posts' => true, 'date_query' => $janela);
    $posts = array();
    // 1) Matérias que citam os dois clubes (ou os dois nomes no título)
    $tax = count($slugs) === 2
        ? array('relation' => 'AND', array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $sa), array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $sb))
        : array(array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $slugs));
    $q = new WP_Query($base + array('posts_per_page' => 8, 'tax_query' => $tax));
    foreach ($q->posts as $p) {
        $posts[$p->ID] = $p;
    }
    // 2) Completa com as de cada clube
    if (count($posts) < 8) {
        $q = new WP_Query($base + array('posts_per_page' => 8, 'post__not_in' => array_keys($posts) ?: array(0), 'tax_query' => array(array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $slugs))));
        foreach ($q->posts as $p) {
            if (count($posts) < 8) {
                $posts[$p->ID] = $p;
            }
        }
    }
    if (!$posts) {
        return '';
    }
    // Matérias de serviço (raio-x, escalação, onde assistir) primeiro
    uasort($posts, function ($a, $b) {
        $s = function ($p) {
            return preg_match('~raio-x|escala[çc]|onde assistir|resultado|gols? de|ficha~iu', $p->post_title) ? 0 : 1;
        };
        return $s($a) <=> $s($b) ?: strcmp($b->post_date, $a->post_date);
    });
    $h = '<section class="tsp-jogo__bloco"><h2>Matérias sobre ' . esc_html($casa . ' x ' . $fora) . '</h2><ul class="tsp-jogo__noticias">';
    foreach ($posts as $p) {
        $h .= '<li><a href="' . esc_url(get_permalink($p)) . '">' . esc_html(get_the_title($p)) . '</a></li>';
    }
    return $h . '</ul></section>';
}

add_action('wp_enqueue_scripts', function () {
    if (!is_singular('jogo')) {
        return;
    }
    wp_register_style('tsp-jogo-turbo', false);
    wp_enqueue_style('tsp-jogo-turbo');
    wp_add_inline_style('tsp-jogo-turbo', '.tsp-stats--comparar{width:100%;border-collapse:collapse;font-size:14.5px}.tsp-stats--comparar td,.tsp-stats--comparar th{padding:8px 6px;border-top:1px solid #EEEBE5;text-align:center}.tsp-stats--comparar tbody th{font-weight:600;color:#6F6A62;font-size:13px}.tsp-stats--comparar td{font-weight:800;width:28%}.tsp-stats--comparar thead th{font-size:15px}@media(max-width:520px){.tsp-stats--comparar{font-size:13.5px}.tsp-stats--comparar tbody th{font-size:12px}}');
});
