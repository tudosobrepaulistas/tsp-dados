<?php
/**
 * Limpeza do Google depois da invasão (out/2026): endereços que nunca mais vão existir respondem
 * "410 – Apagado" logo no começo, sem carregar o site. O Google entende que é para esquecer de vez
 * (bem mais rápido que o 404) e o servidor não gasta força com centenas de milhares de visitas do robô.
 *  - /p/...            páginas falsas de produtos criadas pelo invasor
 *  - /sitemap-cvy...   mapa falso do invasor
 *  - /Nome-Do-Produto-d-123456  páginas falsas de produtos em francês (na raiz, com maiúsculas, terminadas em -d-número, sem barra)
 *  - /player/, /match/, /referee/, /stadium/, /staff/, /club/, /table/  páginas do plugin de estatísticas antigo
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_limpeza_padrao()
{
    return '~^/(p|player|match|referee|stadium|staff|club|table)(/|$)|^/sitemap-cvy|^/(?=[^/]*[A-Z])[^/]+-d-\d{4,8}$~';
}

add_action('plugins_loaded', function () {
    if (is_admin() || (defined('WP_CLI') && WP_CLI) || wp_doing_cron() || wp_doing_ajax()) {
        return;
    }
    $caminho = (string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $base = (string) parse_url(home_url('/'), PHP_URL_PATH);
    if ($base !== '/' && strpos($caminho, rtrim($base, '/')) === 0) {
        $caminho = substr($caminho, strlen(rtrim($base, '/')));
    }
    // 13/11/2026 (Search Console): spam do invasor também em ?t=outlet-123 e páginas /aposta/ antigas paginadas
    $q = (string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY);
    $lixo_q = (bool) preg_match('~(^|&)t=outlet~i', $q);
    if (!$lixo_q && !preg_match(tsp_limpeza_padrao(), $caminho) && !preg_match('~^/(p|player|match|referee|stadium|staff|club|table)(/|$)~i', $caminho)) {
        return;
    }
    status_header(410);
    header('X-Robots-Tag: noindex');
    header('Cache-Control: public, max-age=86400');
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><meta name="robots" content="noindex"><title>Página removida</title>'
        . '<p style="font-family:sans-serif;margin:40px">Esta página não existe mais. <a href="' . esc_url(home_url('/')) . '">Ir para o Tudo Sobre Paulista</a></p>';
    exit;
}, 0);

// 13/11/2026: feeds RSS (tag, categoria, clube) não devem ir para o índice do Google; continuam funcionando para leitores de RSS
add_action('template_redirect', function () {
    if (is_feed()) {
        header('X-Robots-Tag: noindex, follow', true);
    }
}, 1);
