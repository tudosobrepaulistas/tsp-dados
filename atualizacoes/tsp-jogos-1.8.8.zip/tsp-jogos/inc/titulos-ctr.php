<?php
/**
 * Fase 0 do plano de SEO (13/11/2026): títulos e descrições das páginas com muita impressão e CTR baixo.
 *  - Lista em tsp-dados/api/titulos.json, lida junto com a Base TSP (15 em 15 minutos).
 *    Cada item: {"url": "/caminho/", "titulo": "...", "descricao": "...", "confronto": "time-a-x-time-b" (opcional)}.
 *    O título e a descrição da lista valem por cima de qualquer outro (Yoast, Editor SEO). Tirou da lista, volta o antigo.
 *  - "confronto": a página vira a página principal do confronto. Ganha no topo uma caixa automática com retrospecto,
 *    último e próximo jogo (base do TSP), e o endereço automático /confronto/time-a-x-time-b/ redireciona (301) para ela,
 *    para o Google não ver duas páginas disputando a mesma busca.
 *  - Limpeza: texto de rascunho de SEO que vazou para dentro da página ("SEO TITLE: ... SLUG RECOMENDADO ...") some da tela.
 *  - Matérias antigas de "onde assistir" / "escalações": caixa no topo avisando que o jogo já aconteceu,
 *    com link para o próximo jogo entre os dois times (o leitor que chega pelo Google não sai frustrado).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_TITULOS_URL = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/titulos.json';

add_action('tsp_jogos_base', 'tsp_titulos_baixar');

function tsp_titulos_baixar()
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 300), TSP_TITULOS_URL), array('timeout' => 20));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return;
    }
    $d = json_decode(wp_remote_retrieve_body($r), true);
    if (!is_array($d) || !isset($d['itens'])) {
        return;
    }
    $mapa = array();
    foreach ((array) $d['itens'] as $it) {
        $c = tsp_titulos_caminho((string) ($it['url'] ?? ''));
        if ($c === '') {
            continue;
        }
        $mapa[$c] = array(
            'titulo'    => mb_substr(sanitize_text_field((string) ($it['titulo'] ?? '')), 0, 80),
            'descricao' => mb_substr(sanitize_text_field((string) ($it['descricao'] ?? '')), 0, 170),
            'confronto' => preg_match('~^([a-z0-9-]+)-x-([a-z0-9-]+)$~', (string) ($it['confronto'] ?? '')) ? (string) $it['confronto'] : '',
        );
    }
    update_option('tsp_titulos_ctr', $mapa, true);
}

function tsp_titulos_caminho($url)
{
    $p = (string) wp_parse_url($url, PHP_URL_PATH);
    $p = '/' . trim(strtolower(rawurldecode($p)), '/') . '/';
    return $p === '//' ? '' : $p;
}

// Item da lista para a página aberta agora
function tsp_titulos_atual()
{
    static $it = null;
    if ($it !== null) {
        return $it;
    }
    $mapa = (array) get_option('tsp_titulos_ctr', array());
    $it = $mapa ? ($mapa[tsp_titulos_caminho($_SERVER['REQUEST_URI'] ?? '')] ?? array()) : array();
    return $it;
}

foreach (array('wpseo_title', 'wpseo_opengraph_title', 'wpseo_twitter_title') as $f) {
    add_filter($f, function ($t) {
        $it = tsp_titulos_atual();
        return !empty($it['titulo']) ? $it['titulo'] . ' | TSP' : $t;
    }, 120);
}
add_filter('pre_get_document_title', function ($t) {
    $it = tsp_titulos_atual();
    return !empty($it['titulo']) ? $it['titulo'] . ' | TSP' : $t;
}, 120);
foreach (array('wpseo_metadesc', 'wpseo_opengraph_desc', 'wpseo_twitter_description') as $f) {
    add_filter($f, function ($d) {
        $it = tsp_titulos_atual();
        return !empty($it['descricao']) ? $it['descricao'] : $d;
    }, 120);
}
add_action('wp_head', function () {
    $it = tsp_titulos_atual();
    if (!defined('WPSEO_VERSION') && !empty($it['descricao'])) {
        echo '<meta name="description" content="' . esc_attr($it['descricao']) . '">' . "\n";
    }
}, 2);

/* ---------- Confronto: a página da lista é a principal; /confronto/a-x-b/ redireciona para ela ---------- */
function tsp_titulos_destino_confronto($a, $b)
{
    foreach ((array) get_option('tsp_titulos_ctr', array()) as $cam => $it) {
        if (!empty($it['confronto']) && in_array($it['confronto'], array($a . '-x-' . $b, $b . '-x-' . $a), true)) {
            return home_url($cam);
        }
    }
    return '';
}

add_action('template_redirect', function () {
    $q = (string) get_query_var('tsp_confronto');
    if ($q === '') {
        return;
    }
    list($a, $b) = array_pad(explode('|', $q), 2, '');
    $destino = tsp_titulos_destino_confronto($a, $b);
    if ($destino) {
        wp_safe_redirect($destino, 301);
        exit;
    }
}, 1);

// Liga o endereço do jogo/confronto à página principal: os links "Todos os confrontos" já apontam para ela
add_filter('tsp_conf_url', function ($url, $a, $b) {
    return tsp_titulos_destino_confronto($a, $b) ?: $url;
}, 10, 3);

// Caixa automática no topo da página principal do confronto
function tsp_titulos_caixa_confronto($chave)
{
    if (!function_exists('tsp_conf_time_por_chave') || !preg_match('~^([a-z0-9-]+)-x-([a-z0-9-]+)$~', $chave, $m)) {
        return '';
    }
    list($a, $na) = tsp_conf_time_por_chave($m[1]);
    list($b, $nb) = tsp_conf_time_por_chave($m[2]);
    if (!$a || !$b) {
        return '';
    }
    $jogos = tsp_conf_jogos($a, $b);
    if (!$jogos) {
        return '';
    }
    // Só o próximo jogo: a base tem a temporada completa só desde a 28ª rodada da Série A, então "último jogo" e
    // retrospecto calculados por ela poderiam sair incompletos. O histórico fica no texto da página (com fontes).
    $r = tsp_conf_resumo($jogos, $a, $na, $nb);
    if (!$r['proximo']) {
        return '';
    }
    $h = '<aside class="tsp-resumo tsp-resumo--confronto" aria-label="Próximo jogo"><strong>Próximo ' . esc_html($na . ' x ' . $nb) . '</strong>';
    {
        list($c, $f) = tsp_conf_linha_jogo($r['proximo']);
        $pid = tsp_jogos_post_do_jogo($r['proximo']->id);
        $txt = $c . ' x ' . $f . ', ' . wp_date('l, d/m \à\s H\hi', $r['proximo']->inicio) . ($r['proximo']->estadio ? ', no ' . $r['proximo']->estadio : '') . ' (' . tsp_jogos_nome_liga($r['proximo']->liga) . ').';
        $h .= '<p>' . esc_html($txt) . ($pid ? ' <a href="' . esc_url(get_permalink($pid)) . '">Onde assistir e escalações →</a>' : '') . '</p>';
    }
    return $h . '</aside>';
}

add_filter('the_content', function ($c) {
    if (!is_singular() || !in_the_loop() || !is_main_query()) {
        return $c;
    }
    $it = tsp_titulos_atual();
    if (!empty($it['confronto'])) {
        $c = tsp_titulos_caixa_confronto($it['confronto']) . $c;
    }
    return $c;
}, 5);

// Rascunho de SEO que vazou para o texto (ex.: "SEO TITLE: ... PALAVRA-CHAVE PRINCIPAL: ... –>"): some da tela.
// Roda por último, no HTML final (o WordPress troca "-->" por "&#8211;>" quando o comentário foi mal fechado).
add_filter('the_content', function ($c) {
    $i = strpos($c, 'SEO TITLE:');
    if ($i === false || $i > 3000) {
        return $c;
    }
    return preg_replace('~SEO TITLE:.*?(?:&#8211;|–)>~su', '', $c, 1);
}, 999);

/* ---------- Matérias antigas de serviço ("onde assistir", "escalações"): aponta para o próximo jogo ---------- */
function tsp_titulos_times_do_titulo($titulo)
{
    $t = trim(preg_replace('~^(onde assistir( ao vivo)?( a| ao)?|provável escalação de|prováveis escalações de|raio-x de)\s+~iu', '', html_entity_decode($titulo, ENT_QUOTES, 'UTF-8')));
    if (!preg_match('~^(.+?)\s+x\s+(.+?)(?:\s*[:—–(-]|\s+(?:pela|pelo|na|no|hoje|ao vivo|feminino)\b|$)~iu', $t, $m)) {
        return array();
    }
    return array(sanitize_title(trim($m[1])), sanitize_title(trim($m[2])));
}

function tsp_titulos_caixa_servico($post)
{
    if (!function_exists('tsp_conf_time_por_chave')) {
        return '';
    }
    $titulo = get_the_title($post);
    if (!preg_match('~onde assistir|escala[çc]|raio-x~iu', $titulo) || preg_match('~feminin~iu', $titulo)) {
        return '';
    }
    $publicado = (int) get_post_time('U', true, $post);
    if ($publicado > time() - 6 * HOUR_IN_SECONDS) {
        return ''; // matéria recém-publicada: o jogo ainda é este
    }
    $chave = 'tsp_srv_' . $post->ID . '_' . floor(time() / (6 * HOUR_IN_SECONDS));
    $h = get_transient($chave);
    if ($h !== false) {
        return $h;
    }
    $h = '';
    $times = tsp_titulos_times_do_titulo($titulo);
    if ($times) {
        list($a, $na) = tsp_conf_time_por_chave($times[0]);
        list($b, $nb) = tsp_conf_time_por_chave($times[1]);
        if ($a && $b) {
            $jogos = tsp_conf_jogos($a, $b);
            // O jogo da matéria = o primeiro entre os dois até 5 dias depois da publicação. Se ainda não aconteceu, nada de aviso.
            $da_materia = null;
            foreach ($jogos as $x) { // do mais novo para o mais antigo
                if ((int) $x->inicio >= $publicado - 12 * HOUR_IN_SECONDS && (int) $x->inicio <= $publicado + 5 * DAY_IN_SECONDS) {
                    $da_materia = $x;
                }
            }
            if ($da_materia ? (int) $da_materia->inicio > time() - 3 * HOUR_IN_SECONDS : $publicado > time() - 2 * DAY_IN_SECONDS) {
                set_transient($chave, '', HOUR_IN_SECONDS);
                return '';
            }
            $r = tsp_conf_resumo($jogos, $a, $na, $nb);
            $h = '<aside class="tsp-resumo tsp-resumo--antigo" aria-label="Próximo jogo"><strong>Este jogo já aconteceu</strong>';
            if ($r['proximo']) {
                list($c, $f) = tsp_conf_linha_jogo($r['proximo']);
                $pid = tsp_jogos_post_do_jogo($r['proximo']->id);
                $txt = 'O próximo ' . $c . ' x ' . $f . ' será ' . wp_date('l, d/m/Y, \à\s H\hi', $r['proximo']->inicio) . ' (' . tsp_jogos_nome_liga($r['proximo']->liga) . ').';
                $h .= '<p>' . esc_html($txt) . ($pid ? ' <a href="' . esc_url(get_permalink($pid)) . '">Veja onde assistir e as escalações →</a>' : '') . '</p>';
            } else {
                $link = '';
                foreach (array($a, $b) as $tid) {
                    $slug = tsp_jogos_slug_do_time($tid);
                    $termo = $slug ? get_term_by('slug', $slug, 'times') : null;
                    if ($termo && !$link && !is_wp_error(get_term_link($termo))) {
                        $link = '<a href="' . esc_url(get_term_link($termo)) . '">Veja os próximos jogos ' . esc_html(function_exists('tsp_de') ? tsp_de($termo) : 'do ' . $termo->name) . ' →</a>';
                    }
                }
                $h .= '<p>Ainda não há novo ' . esc_html($na . ' x ' . $nb) . ' marcado. ' . $link . '</p>';
            }
            $h .= '</aside>';
        }
    }
    set_transient($chave, $h, 6 * HOUR_IN_SECONDS);
    return $h;
}

add_filter('the_content', function ($c) {
    if (!is_singular(array('materia', 'post')) || !in_the_loop() || !is_main_query()) {
        return $c;
    }
    return tsp_titulos_caixa_servico(get_post()) . $c;
}, 6);

add_action('wp_enqueue_scripts', function () {
    wp_register_style('tsp-titulos', false);
    wp_enqueue_style('tsp-titulos');
    wp_add_inline_style('tsp-titulos', '.tsp-resumo--antigo{border-left:4px solid #E18330}.tsp-resumo--antigo a,.tsp-resumo--confronto a{color:#A8520C;font-weight:700;white-space:nowrap}.tsp-resumo--confronto p,.tsp-resumo--antigo p{margin:6px 0 0}');
});
