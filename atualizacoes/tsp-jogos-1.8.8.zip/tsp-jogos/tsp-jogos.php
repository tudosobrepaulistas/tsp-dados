<?php
/*
Plugin Name: TSP Jogos
Description: Jogos, resultados, classificação, artilharia, Editor SEO e ofertas do TSP, lidos da Base TSP própria (GitHub), conferida por jornalista em 2 fontes.
Version: 1.8.8
Author: TSP
Requires at least: 6.3
Requires PHP: 7.4
Text Domain: tsp-jogos
*/

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_JOGOS_VERSAO', '1.8.8');
define('TSP_JOGOS_DIR', plugin_dir_path(__FILE__));

require_once TSP_JOGOS_DIR . 'inc/api.php';
require_once TSP_JOGOS_DIR . 'inc/banco.php';
require_once TSP_JOGOS_DIR . 'inc/sincronizar.php';
require_once TSP_JOGOS_DIR . 'inc/paginas.php';
require_once TSP_JOGOS_DIR . 'inc/admin.php';
require_once TSP_JOGOS_DIR . 'inc/integracao.php';
require_once TSP_JOGOS_DIR . 'inc/base-tsp.php';
require_once TSP_JOGOS_DIR . 'inc/rodadas.php';
require_once TSP_JOGOS_DIR . 'inc/editor-seo.php';
require_once TSP_JOGOS_DIR . 'inc/ofertas.php';
require_once TSP_JOGOS_DIR . 'inc/limpeza.php';
require_once TSP_JOGOS_DIR . 'inc/escudos.php';
require_once TSP_JOGOS_DIR . 'inc/estadios.php';
require_once TSP_JOGOS_DIR . 'inc/simulador.php';
require_once TSP_JOGOS_DIR . 'inc/copa-auto.php';
require_once TSP_JOGOS_DIR . 'inc/chaves.php';
require_once TSP_JOGOS_DIR . 'inc/confrontos.php';
require_once TSP_JOGOS_DIR . 'inc/time-numeros.php';
require_once TSP_JOGOS_DIR . 'inc/time-ficha.php';
require_once TSP_JOGOS_DIR . 'inc/sitemap.php';
require_once TSP_JOGOS_DIR . 'inc/jogo-turbo.php';
require_once TSP_JOGOS_DIR . 'inc/titulos-ctr.php';

register_activation_hook(__FILE__, 'tsp_jogos_ativar');
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tsp_jogos_diario');
    wp_clear_scheduled_hook('tsp_jogos_ao_vivo');
    wp_clear_scheduled_hook('tsp_jogos_base');
});

function tsp_jogos_ativar()
{
    tsp_jogos_criar_tabela();
    update_option('tsp_est_refazer_enderecos', 1);
}

// Atualizações enviadas por "Substituir": recria a tabela e as regras de endereço quando a versão muda
add_action('plugins_loaded', function () {
    if (get_option('tsp_jogos_versao') !== TSP_JOGOS_VERSAO) {
        tsp_jogos_criar_tabela();
        update_option('tsp_jogos_versao', TSP_JOGOS_VERSAO, false);
        update_option('tsp_est_refazer_enderecos', 1);
        delete_option('tsp_jogos_base_etag');
        // escudos que falharam antes: tenta de novo já
        update_option('tsp_jogos_escudos', array_filter((array) get_option('tsp_jogos_escudos', array()), function ($e) {
            return !empty($e['url']);
        }), false);
        delete_option('tsp_jogos_base_hash'); // relê a Base TSP inteira na próxima rodada (dados novos, como o simulador)
        // 1.4.0: API-Football retirada → apaga a chave e os agendamentos antigos
        wp_clear_scheduled_hook('tsp_jogos_diario');
        wp_clear_scheduled_hook('tsp_jogos_ao_vivo');
        foreach (array('tsp_jogos_chave', 'tsp_jogos_teto', 'tsp_jogos_uso', 'tsp_jogos_plano_bloqueado', 'tsp_jogos_fonte') as $o) {
            delete_option($o);
        }
    }
});

// Segurança: desliga o editor de arquivos do painel (Aparência → Editor de arquivos de tema / Plugins → Editor).
// Se alguém roubar uma senha de administrador, não consegue colar código no site por ali.
add_filter('map_meta_cap', function ($caps, $cap) {
    if (in_array($cap, array('edit_themes', 'edit_plugins', 'edit_files'), true)) {
        return array('do_not_allow');
    }
    return $caps;
}, 10, 2);


// Atualização automática pelo GitHub do TSP (Painel → Atualizações)
require_once __DIR__ . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('plugin', 'tsp-jogos', plugin_basename(__FILE__), get_file_data(__FILE__, array('v' => 'Version'))['v']);
