<?php
/**
 * TSP Nova Era — tema do Tudo Sobre Paulista (base: Radar Palestrino 2.11).
 * Precisa do plugin "TSP Estruturas" (Matérias, Times, Campeonatos, dados de tabelas).
 * SEO (título, descrição, schema, sitemap) continua com o Yoast: o tema não duplica nada disso.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_VERSAO', '1.0.0.' . filemtime(__DIR__ . '/style.css'));

require get_template_directory() . '/inc/clubes.php';
require get_template_directory() . '/inc/componentes.php';
require get_template_directory() . '/inc/clube.php';
require get_template_directory() . '/inc/guia.php';
require get_template_directory() . '/inc/sofascore.php';
require get_template_directory() . '/inc/campeonato.php';
require get_template_directory() . '/inc/compartilhar.php';
require get_template_directory() . '/inc/revisao.php';
require get_template_directory() . '/inc/materia.php';
require get_template_directory() . '/inc/ofertas.php';
require get_template_directory() . '/inc/fotos.php';
require get_template_directory() . '/inc/links.php';
require get_template_directory() . '/inc/seo-paginas.php';
require get_template_directory() . '/inc/telegram.php';
require get_template_directory() . '/inc/mercado.php';

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets'));
    register_nav_menus(array(
        'principal' => 'Menu principal (tema novo)',
        'rodape'    => 'Menu do rodapé (tema novo)',
    ));
});

add_action('widgets_init', function () {
    foreach (array('tsp-banner-home-1' => 'Home · banner 1 (depois do Feminino)', 'tsp-banner-home-2' => 'Home · banner 2 (fim da página)', 'tsp-banner-materia' => 'Matéria · lateral', 'tsp-banner-clube' => 'Página do clube · anunciante local', 'tsp-banner-divisoes-d1' => 'Home · entre A1 e A2 (ofertas)', 'tsp-banner-divisoes-d3' => 'Home · entre A3 e A4 (ofertas)') as $id => $nome) {
        register_sidebar(array('id' => $id, 'name' => $nome, 'before_widget' => '<div class="tsp-widget">', 'after_widget' => '</div>', 'before_title' => '<span class="tsp-sr">', 'after_title' => '</span>'));
    }
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('tsp-fontes', 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800&family=Public+Sans:wght@400;600;700&display=swap', array(), null);
    wp_enqueue_style('tsp-estilo', get_stylesheet_uri(), array(), TSP_VERSAO);
    wp_enqueue_script('tsp-main', get_template_directory_uri() . '/assets/main.js', array(), TSP_VERSAO, array('strategy' => 'defer', 'in_footer' => true));
});

add_filter('wp_resource_hints', function ($urls, $tipo) {
    if ($tipo === 'preconnect') {
        $urls[] = array('href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous');
        $urls[] = 'https://fonts.googleapis.com';
    }
    return $urls;
}, 10, 2);

// Mais leve: sem emojis do WordPress e sem estilos de blocos fora das matérias
add_action('init', function () {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'wp_generator');
});
add_action('wp_enqueue_scripts', function () {
    if (!is_singular()) {
        wp_dequeue_style('wp-block-library');
        wp_dequeue_style('global-styles');
        wp_dequeue_style('classic-theme-styles');
    }
}, 100);

add_filter('excerpt_length', function () {
    return 26;
});
add_filter('excerpt_more', function () {
    return '…';
});

// Conteúdo antigo montado com o Divi: sem o Divi, os códigos [et_pb_...] apareceriam como texto.
// Aqui eles são removidos e só o texto de dentro fica.
add_filter('the_content', function ($c) {
    if (strpos($c, '[et_pb_') === false && strpos($c, '[/et_pb_') === false) {
        return $c;
    }
    return preg_replace('~\[/?et_pb_[^\]]*\]~', '', $c);
}, 5);

// Códigos curtos do tema antigo que não existem no tema novo (ex.: [todos_times]) não aparecem como texto
function tsp_shortcodes_antigos()
{
    return array('arquivo_onde_assitir', 'autor', 'banner_aposta', 'banner_aposta_materia', 'banner_whatsapp_materia', 'banners', 'blocos-apostas', 'blocos-home', 'campeonatos', 'copy_assistir', 'copy_materia', 'destaques', 'destaques2', 'destaques3', 'destaques5', 'destaques6', 'destaques7', 'mais_materias', 'materias_arquivo', 'palpites', 'titulo_arquivo', 'todos_times', 'ultimas_apostas', 'ultimas_noticias', 'ultimos_onde_assistir', 'videos', 'vitrine');
}
add_filter('the_content', function ($c) {
    if (strpos($c, '[') === false) {
        return $c;
    }
    $nomes = implode('|', array_map('preg_quote', tsp_shortcodes_antigos()));
    $c = preg_replace('~\[/?(?:' . $nomes . ')(?:\s[^\]]*)?\]~', '', $c);
    // Tabelas e formulários de plugins antigos que não existem mais (AnWP Football Leagues, Contact Form 7)
    return preg_replace('~\[/?(?:anwpfl-[a-z\-]+|contact-form-7)(?:\s[^\]]*)?\]~', '', $c);
}, 6);

// Arquivos de times, campeonatos e busca: 16 por página = 1 destaque + 3 ao lado + 12 (mesmos endereços de sempre)
add_action('pre_get_posts', function ($q) {
    if (is_admin() || !$q->is_main_query()) {
        return;
    }
    if ($q->is_archive() || $q->is_search()) {
        // página do clube: 4 destaques + 8 notícias = 12; campeonatos e busca: 16
        $q->set('posts_per_page', $q->is_tax('times') ? 12 : 16);
        // Clube e campeonato: só matérias (as páginas automáticas de jogo ficam no bloco de jogos, sem foto)
        if (($q->is_tax('times') || $q->is_tax('campeonato')) && !$q->get('post_type')) {
            $q->set('post_type', tsp_tipos());
        }
        if ($q->is_search() && !$q->get('post_type')) {
            $q->set('post_type', tsp_tipos());
        }
    }
});

// Personalizar → TSP: redes sociais
add_action('customize_register', function ($c) {
    $c->add_section('tsp_redes', array('title' => 'TSP: redes e WhatsApp', 'priority' => 30));
    $campos = array(
        'tsp_whatsapp'  => array('Link do grupo de WhatsApp', 'https://chat.whatsapp.com/LsgWJv02mM8D7pBMVnnc60'),
        'tsp_instagram' => array('Instagram', 'https://www.instagram.com/tudosobrepaulistas/'),
        'tsp_youtube'   => array('YouTube', 'https://www.youtube.com/@TudoSobrePaulista'),
        'tsp_tiktok'    => array('TikTok', 'https://vm.tiktok.com/ZMSPTNxc3/'),
    );
    foreach ($campos as $id => $x) {
        $c->add_setting($id, array('default' => $x[1], 'sanitize_callback' => 'esc_url_raw'));
        $c->add_control($id, array('label' => $x[0], 'section' => 'tsp_redes', 'type' => 'url'));
    }
});

// Menu principal com menus suspensos: cada divisão mostra seus 16 clubes com escudo, em duas colunas de 8
function tsp_menu_item_clubes($rotulo, $link, $slugs, $titulo_painel, $prefixo_celular = '')
{
    $termos = get_terms(array('taxonomy' => 'times', 'slug' => $slugs, 'hide_empty' => false));
    if (is_wp_error($termos) || !$termos) {
        echo '<li><a href="' . esc_url($link) . '">' . esc_html($rotulo) . '</a></li>';
        return;
    }
    usort($termos, function ($a, $b) {
        return strcoll(remove_accents($a->name), remove_accents($b->name));
    });
    $id = 'tsp-sub-' . sanitize_title($rotulo);
    echo '<li class="tsp-nav__item tem-sub"><a href="' . esc_url($link) . '">' . ($prefixo_celular ? '<span class="tsp-so-cel">' . esc_html($prefixo_celular) . ' </span>' : '') . esc_html($rotulo) . '</a>';
    echo '<button type="button" class="tsp-nav__abre" aria-expanded="false" aria-controls="' . esc_attr($id) . '" aria-label="' . esc_attr('Clubes: ' . $titulo_painel) . '"><span aria-hidden="true">▾</span></button>';
    echo '<div class="tsp-nav__painel" id="' . esc_attr($id) . '"><a class="tsp-nav__painel-tit" href="' . esc_url($link) . '">' . esc_html($titulo_painel) . ' →</a><ul class="tsp-nav__clubes">';
    foreach ($termos as $t) {
        echo '<li><a href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 22) . '<span>' . esc_html($t->name) . '</span></a></li>';
    }
    echo '</ul></div></li>';
}

function tsp_menu_padrao()
{
    $g = tsp_grupos();
    echo '<ul class="tsp-nav__lista">';
    echo '<li><a href="' . esc_url(home_url('/')) . '">Início</a></li>';
    tsp_menu_item_clubes('Série A', home_url('/campeonato/brasileiro-serie-a/'), array_merge(tsp_grupo_slugs('a4'), tsp_grupo_slugs('mb')), 'Brasileirão Série A');
    tsp_menu_item_clubes('Série B', home_url('/campeonato/brasileiro-serie-b/'), tsp_grupo_slugs('sb'), 'Brasileirão Série B');
    foreach (array('d1', 'd2', 'd3', 'd4') as $k) {
        tsp_menu_item_clubes(str_replace('Paulistão ', '', $g[$k]['titulo']), home_url($g[$k]['link']), tsp_grupo_slugs($k), $g[$k]['titulo'], 'Paulistão');
    }
    tsp_menu_item_clubes('Feminino', home_url('/campeonato/brasileirao-feminino/'), tsp_grupo_slugs('fem'), 'Futebol Feminino');
    echo '<li><a href="' . esc_url(home_url('/mercado-da-bola/')) . '">Mercado</a></li>';
    echo '<li><a href="' . esc_url(get_theme_mod('tsp_youtube', 'https://www.youtube.com/@TudoSobrePaulista')) . '" target="_blank" rel="noopener">Vídeos</a></li>';
    echo '</ul>';
}

// Títulos dos arquivos sem o prefixo "Times:" / "Campeonato:"
add_filter('get_the_archive_title_prefix', '__return_empty_string');

// Códigos que estavam em Divi → Opções do tema → Integração (Google Tag Manager). Pixel do Facebook de terceiros removido em 03/11/2026.
// Filtro anti-robô (07/11/2026): robôs da China, Hong Kong e Singapura e navegadores automáticos
// não carregam Analytics nem anúncios. O site continua abrindo para todos; só os contadores e a publicidade ficam de fora,
// o que limpa o GA4 e protege a conta de anúncios de tráfego inválido.
add_action('wp_head', function () {
    echo "<script>window.tspRobo=(function(){try{var n=navigator,u=n.userAgent||'',z=(Intl.DateTimeFormat().resolvedOptions().timeZone||'');"
        . "if(n.webdriver||/HeadlessChrome|PhantomJS|bot|crawl|spider|scrap|python|curl|wget/i.test(u))return 1;"
        . "if(/^Asia\\/(Shanghai|Chongqing|Chungking|Harbin|Urumqi|Kashgar|Hong_Kong|Macau|Macao|Singapore)$/.test(z)||/^(PRC|Hongkong|Singapore)$/.test(z))return 1;"
        . "var l=(n.languages&&n.languages.join(',')||n.language||'');if(/^zh/i.test(l))return 1;return 0}catch(e){return 0}})();</script>\n";
}, 0);

add_action('wp_head', function () {
    echo "<!-- Google Tag Manager -->\n<script>if(!window.tspRobo)(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-5747RQPR');</script>\n<!-- End Google Tag Manager -->\n";
}, 1);
// (o <noscript> do Tag Manager saiu: só robô navega sem JavaScript)

// Anúncios da JoinAds: o código vem de fora do tema; aqui ele passa a carregar só para quem não é robô.
add_action('wp_head', function () {
    ob_start();
}, 2);
add_action('wp_head', function () {
    $h = ob_get_clean();
    $h = preg_replace('~<link[^>]+href="https://script\.joinads\.me/[^"]+"[^>]*as="script"[^>]*>\s*~i', '', $h);
    $h = preg_replace_callback('~<script\b[^>]*\bsrc="(https://script\.joinads\.me/[^"]+\.js)"[^>]*>\s*</script>~i', function ($m) {
        return "<script>if(!window.tspRobo){var s=document.createElement('script');s.type='module';s.async=true;s.crossOrigin='anonymous';s.src=" . wp_json_encode($m[1]) . ";document.head.appendChild(s)}</script>";
    }, $h);
    echo $h; // phpcs:ignore
}, PHP_INT_MAX);
// Botão robotip/neoai (de terceiro) removido em 03/11/2026.

// Páginas com placar e tabela ficam no cache do LiteSpeed por no máximo 15 minutos
add_action('template_redirect', function () {
    if (is_front_page() || is_tax(array('campeonato', 'times')) || is_singular('jogo')) {
        do_action('litespeed_control_set_ttl', 900);
    }
});


// Atualização automática do tema pelo GitHub do TSP (Painel → Atualizações)
require_once get_template_directory() . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('tema', get_template(), get_template(), wp_get_theme(get_template())->get('Version'));


// Cabeçalhos de segurança (HTTPS sempre, sem embutir o site em outros, sem adivinhar tipo de arquivo)
add_action('send_headers', function () {
    if (is_admin() || headers_sent()) {
        return;
    }
    header('Strict-Transport-Security: max-age=31536000');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
});

// Política editorial no código do site (Google/IA: princípios de publicação e política de correções)
add_filter('wpseo_schema_organization', function ($org) {
    $p = get_page_by_path('politica-editorial');
    if ($p && $p->post_status === 'publish') {
        $url = get_permalink($p);
        $org['publishingPrinciples'] = $url;
        $org['correctionsPolicy'] = $url;
        $org['ethicsPolicy'] = $url;
    }
    return $org;
});

// Botões flutuantes "ir para o topo" e "ir para o fim" (aparecem depois de rolar um pouco)
add_action('wp_footer', function () {
    ?>
<div class="tsp-rolar" id="tsp-rolar" hidden>
	<button type="button" data-rolar="topo" aria-label="Ir para o topo da página" title="Ir para o topo">↑</button>
	<button type="button" data-rolar="fim" aria-label="Ir para o fim da página" title="Ir para o fim">↓</button>
</div>
<style>
.tsp-rolar{position:fixed;right:16px;bottom:24px;z-index:60;display:flex;flex-direction:column;gap:8px}
.tsp-rolar[hidden]{display:none}
.tsp-rolar button{width:46px;height:46px;border-radius:50%;border:2px solid #E8862A;background:#111;color:#fff;font-size:22px;font-weight:800;line-height:1;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.25);transition:transform .15s,background .15s}
.tsp-rolar button:hover,.tsp-rolar button:focus-visible{background:#E8862A;color:#111;transform:translateY(-2px);outline:none}
.tsp-rolar button[disabled]{opacity:.35;cursor:default;transform:none}
@media (max-width:600px){.tsp-rolar{right:10px;bottom:84px}.tsp-rolar button{width:42px;height:42px;font-size:20px}}
@media print{.tsp-rolar{display:none}}
</style>
<script>
(function(){var c=document.getElementById('tsp-rolar');if(!c)return;var t=c.querySelector('[data-rolar=topo]'),f=c.querySelector('[data-rolar=fim]'),liso=!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function ver(){var y=window.scrollY||0,h=document.documentElement.scrollHeight-window.innerHeight;c.hidden=y<500||h<1200;t.disabled=y<50;f.disabled=y>h-50}
c.addEventListener('click',function(e){var b=e.target.closest('[data-rolar]');if(!b||b.disabled)return;window.scrollTo({top:b.dataset.rolar==='topo'?0:document.documentElement.scrollHeight,behavior:liso?'smooth':'auto'})});
window.addEventListener('scroll',ver,{passive:true});window.addEventListener('resize',ver);ver()})();
</script>
    <?php
}, 50);


// Restos de cópia do ChatGPT nas matérias antigas (data-start="..." data-end="...") saem do HTML
add_filter('the_content', function ($c) {
    return strpos($c, 'data-start=') === false ? $c : preg_replace('~\s+data-(?:start|end)="\d+"~', '', $c);
}, 7);

// Páginas antigas de "tabela" que ficaram vazias (dependiam de um plugin que saiu) vão para a página do campeonato
add_action('template_redirect', function () {
    if (!is_page()) {
        return;
    }
    $mapa = array(
        'tabela-brasileirao-serie-a' => 'brasileiro-serie-a', 'tabela-brasileirao-serie-b' => 'brasileiro-serie-b',
        'tabela-brasileirao-serie-c' => 'brasileiro-serie-c', 'tabela-brasileirao-serie-d' => 'brasileiro-serie-d',
        'tabela-copa-do-brasil' => 'copadobrasil', 'tabela-libertadores' => 'libertadores', 'tabela-conmebol-sul-americana' => 'sulamericana',
        'tabela-copa-paulista' => 'copapaulista', 'tabela-paulista-a1' => 'paulistao-a1', 'tabela-paulista-a2' => 'paulistao-a2',
        'tabela-paulista-a3' => 'paulistao-a3', 'tabela-paulista-a4' => 'paulistao-a4', 'tabela-paulista-b1' => 'paulistao-b1',
        'tabela-brasileirao-feminino' => 'brasileirao-feminino', 'tabela-libertadores-feminina' => 'libertadores-feminina',
        'tabela-mundial-de-clubes' => 'mundial-de-clubes', 'tabela-copa-sul-sudeste' => 'copa-sul-sudeste', 'copa-sp-de-futebol-junior' => 'copinha',
    );
    $slug = urldecode((string) get_post_field('post_name', get_queried_object_id()));
    $slug = str_replace("\u{2060}", '', $slug); // "tabela-⁠paulista-sub-20" tem um caractere invisível no endereço
    if ($slug === 'tabela-paulista-sub-20') {
        $mapa[$slug] = 'paulista-sub20';
    }
    if (isset($mapa[$slug])) {
        $l = get_term_link($mapa[$slug], 'campeonato');
        if (!is_wp_error($l)) {
            wp_safe_redirect($l, 301);
            exit;
        }
    }
}, 5);
