<?php
/**
 * Página inicial do TSP. Ordem aprovada em 26/10/2026:
 * Série A num bloco só (escudos dos 6 clubes; 8 matérias dos 4 grandes + 4 de Mirassol e Bragantino, sem segundo título) → Tabela e jogos da Série A →
 * Vídeos da Série A (só os 6 clubes) → Série B (8 matérias, 2 por clube) → Tabela e jogos da Série B →
 * Vídeos da Série B (só os 4 clubes) → Feminino (1 + 3 + 4, tabelas das competições) → banner (ordem de 07/11/2026) →
 * Paulistão A1 → A2 → WhatsApp → A3 → A4 (só clubes sem calendário nacional) → banner.
 * Mercado da Bola (14/11/2026): entre os 4 grandes e Mirassol/Bragantino (6 clubes da Série A), entre a tabela e os vídeos
 * da Série B, entre o Feminino e o A1, e logo depois de cada divisão do Paulistão (A1, A2, A3, A4).
 * Dias de Copa do Brasil/Libertadores (automático pela base de jogos): a competição abre a home só no dia do jogo; no dia seguinte volta o Brasileirão.
 * Tudo entra sozinho pela classificação "Times" da matéria. Uma matéria não se repete em dois blocos.
 */
get_header();

$tsp_vistos = array();
$tsp_g = tsp_grupos();
$tsp_base = tsp_base_ids($tsp_vistos); // base (Sub-20 e menores, masculino e feminino): blocos próprios no fim, fora dos demais (inclusive dos vídeos)
// Vídeos primeiro: a coletiva vai para o bloco de vídeos e não se repete nas notícias
$tsp_vid_a = tsp_ids_videos(array_merge(tsp_grupo_slugs('a4'), tsp_grupo_slugs('mb')), 5, $tsp_vistos);
$tsp_vid_b = tsp_ids_videos(tsp_grupo_slugs('sb'), 5, $tsp_vistos);
$tsp_copa = tsp_copa_ativa(); // dia de Copa do Brasil / Libertadores
$tsp_mc = array(); // Mercado da Bola (14/11/2026): um movimento não se repete em dois blocos
?>
<main class="tsp-container tsp-home">
	<h1 class="tsp-sr"><?php bloginfo('name'); ?>: notícias dos times de São Paulo</h1>

	<?php if ($tsp_copa) { tsp_bloco_copa_destaque($tsp_copa, $tsp_vistos); tsp_bloco_copa_jogos($tsp_copa); } // destaque da copa e, logo abaixo, a tabela (chaveamento) ?>

	<?php echo function_exists('tsp_sim_botao_html') ? tsp_sim_botao_html() : ''; // phpcs:ignore -- botão do Simulador TSP Brasileirão ?>

	<section class="tsp-secao tsp-secao--caixa" id="serie-a" aria-labelledby="h-serie-a">
		<?php tsp_secao_cab('Brasileirão Série A', $tsp_g['a4']['link'], array_merge($tsp_g['a4']['clubes'], $tsp_g['mb']['clubes']), '', 'h-serie-a', true); ?>
		<?php $tsp_fora = array(); // dia de copa: as matérias da copa já estão no bloco de cima (vistos); as outras do clube (ex.: Libertadores) seguem aqui com o chapéu da competição ?>
		<?php tsp_layout_a(tsp_com_federacao(tsp_ids_bloco(array_values(array_diff(tsp_grupo_slugs('a4'), $tsp_fora)), $tsp_vistos), 'serie_a', $tsp_vistos)); ?>
		<?php tsp_bloco_mercado('a', 'Mercado da Bola · Série A', 'mercado-serie-a', $tsp_mc, true); ?>
		<div class="tsp-secao__parte" id="mirassol-bragantino">
			<?php tsp_layout_b(tsp_ids_por_clube(array_values(array_diff(tsp_grupo_slugs('mb'), $tsp_fora)), 2, $tsp_vistos, true)); ?>
		</div>
	</section>

	<?php tsp_bloco_tabela('serie_a', 'Brasileirão Série A · Tabela e jogos', '/campeonato/brasileiro-serie-a/', 'tabela-a', true); ?>

	<?php tsp_bloco_videos($tsp_vid_a, 'Vídeos · Coletivas da Série A', 'videos'); ?>

	<section class="tsp-secao tsp-secao--caixa" id="serie-b" aria-labelledby="h-serie-b">
		<?php tsp_secao_cab('Brasileirão Série B', $tsp_g['sb']['link'], $tsp_g['sb']['clubes'], '', 'h-serie-b', true); ?>
		<?php tsp_layout_a(tsp_com_federacao(tsp_ids_bloco(tsp_grupo_slugs('sb'), $tsp_vistos), 'serie_b', $tsp_vistos)); ?>
	</section>

	<?php tsp_bloco_tabela('serie_b', 'Brasileirão Série B · Tabela e jogos', '/campeonato/brasileiro-serie-b/', 'tabela-b', false); ?>

	<?php tsp_bloco_mercado('b', 'Mercado da Bola · Série B', 'mercado-serie-b', $tsp_mc); ?>

	<?php tsp_bloco_videos($tsp_vid_b, 'Vídeos · Coletivas da Série B', 'videos-b'); ?>

	<section class="tsp-secao" id="feminino" aria-labelledby="h-fem">
		<?php tsp_secao_cab('Futebol Feminino', $tsp_g['fem']['link'], $tsp_g['fem']['clubes'], '', 'h-fem', true); ?>
		<?php tsp_layout_a(tsp_com_federacao(tsp_ids_grupo(tsp_grupo_slugs('fem'), 9, $tsp_vistos), 'fem', $tsp_vistos)); ?>
		<?php tsp_bloco_feminino_comp(); ?>
	</section>

	<?php tsp_bloco_mercado('fem', 'Mercado da Bola · Futebol Feminino', 'mercado-feminino', $tsp_mc); ?>

	<?php tsp_banner('tsp-banner-home-1'); ?>

	<?php foreach (array('d1', 'd2', 'd3', 'd4') as $tsp_k) : ?>
		<section class="tsp-secao" id="paulistao-a<?php echo esc_attr(substr($tsp_k, 1)); ?>" aria-labelledby="h-<?php echo esc_attr($tsp_k); ?>">
			<?php tsp_secao_cab($tsp_g[$tsp_k]['titulo'], $tsp_g[$tsp_k]['link'], array(), $tsp_g[$tsp_k]['sub'], 'h-' . $tsp_k); ?>
			<?php tsp_chips_divisao($tsp_g[$tsp_k]['divisao']); ?>
			<?php tsp_layout_a(tsp_com_federacao(tsp_ids_grupo(tsp_divisao_home_slugs($tsp_k), 9, $tsp_vistos), $tsp_k, $tsp_vistos)); ?>
			<?php echo tsp_sofa_recolhivel('paulistao_a' . substr($tsp_k, 1), 'Classificação · Paulistão A' . substr($tsp_k, 1)); ?>
		</section>
		<?php tsp_bloco_mercado($tsp_k, 'Mercado da Bola · ' . $tsp_g[$tsp_k]['titulo'], 'mercado-paulistao-a' . substr($tsp_k, 1), $tsp_mc); ?>
		<?php if ($tsp_k === 'd2') { tsp_cta_whatsapp(); } ?>
		<?php if ($tsp_k === 'd1' || $tsp_k === 'd3') { tsp_banner('tsp-banner-divisoes-' . $tsp_k); } ?>
	<?php endforeach; ?>

	<?php $tsp_outros = tsp_outros_clubes(); if ($tsp_outros) : ?>
		<section class="tsp-secao" id="outros-clubes" aria-labelledby="h-outros">
			<?php tsp_secao_cab('Outros clubes paulistas', '/todos-os-times/', array(), 'Segunda Divisão (Bezinha) e clubes sem divisão', 'h-outros'); ?>
			<?php tsp_chips_divisao($tsp_outros, 16); ?>
			<?php tsp_layout_a(tsp_com_federacao(tsp_ids_grupo(array_keys($tsp_outros), 9, $tsp_vistos), 'outros', $tsp_vistos)); ?>
		</section>
	<?php endif; ?>

	<?php tsp_bloco_base($tsp_base); ?>

	<?php tsp_bloco_base_fem($tsp_base['fem']); ?>

	<?php tsp_banner('tsp-banner-home-2'); ?>
</main>
<?php
get_footer();
