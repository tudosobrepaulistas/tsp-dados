<?php
/*
Plugin Name: TSP Ofertas Shopee
Description: Monta sozinho a vitrine de produtos de cada clube com links de afiliado da Shopee (API oficial de afiliados). Só produtos que citam o clube da página; réplicas/"tailandesas" ficam de fora. Atualiza uma vez por dia.
Version: 1.0.0
Author: TSP
Requires at least: 6.3
Requires PHP: 7.4
Text Domain: tsp-shopee
*/

if (!defined('ABSPATH')) {
    exit;
}

const TSP_SHOPEE_API = 'https://open-api.affiliate.shopee.com.br/graphql';
const TSP_SHOPEE_POR_RODADA = 6;   // clubes atualizados a cada hora
const TSP_SHOPEE_MAX_PRODUTOS = 12;

/* ---------- API ---------- */

function tsp_shopee_chamar($query)
{
    $app = trim((string) get_option('tsp_shopee_app', ''));
    $sec = trim((string) get_option('tsp_shopee_secret', ''));
    if ($app === '' || $sec === '') {
        return new WP_Error('tsp_shopee_chave', 'Cole o App ID e a chave secreta em Ferramentas → Ofertas Shopee.');
    }
    $corpo = wp_json_encode(array('query' => $query));
    $ts = time();
    $assinatura = hash('sha256', $app . $ts . $corpo . $sec);
    $r = wp_remote_post(get_option('tsp_shopee_endpoint', TSP_SHOPEE_API) ?: TSP_SHOPEE_API, array(
        'timeout' => 20,
        'headers' => array(
            'Content-Type'  => 'application/json',
            'Authorization' => 'SHA256 Credential=' . $app . ', Timestamp=' . $ts . ', Signature=' . $assinatura,
        ),
        'body'    => $corpo,
    ));
    if (is_wp_error($r)) {
        return $r;
    }
    $d = json_decode(wp_remote_retrieve_body($r), true);
    if (!is_array($d)) {
        return new WP_Error('tsp_shopee_resposta', 'Resposta inesperada da Shopee (código ' . (int) wp_remote_retrieve_response_code($r) . ').');
    }
    if (!empty($d['errors'])) {
        $e = $d['errors'][0];
        return new WP_Error('tsp_shopee_api', 'Shopee: ' . ($e['message'] ?? 'erro') . (isset($e['extensions']['code']) ? ' (código ' . $e['extensions']['code'] . ')' : ''));
    }
    return $d['data'] ?? array();
}

function tsp_shopee_buscar($palavra, $limite = 40)
{
    $q = 'query { productOfferV2(keyword: ' . wp_json_encode($palavra) . ', page: 1, limit: ' . (int) $limite . ') { nodes { itemId productName imageUrl priceMin priceMax offerLink productLink shopName sales ratingStar } } }';
    $d = tsp_shopee_chamar($q);
    if (is_wp_error($d)) {
        return $d;
    }
    return (array) ($d['productOfferV2']['nodes'] ?? array());
}

/* ---------- Quais produtos entram ---------- */

function tsp_shopee_norm($s)
{
    return trim(preg_replace('~[^a-z0-9]+~', ' ', strtolower(remove_accents((string) $s))));
}

// Nomes que o produto precisa citar para ser do clube (ex.: "Red Bull Bragantino" → "red bull bragantino" ou "bragantino")
function tsp_shopee_nomes($termo)
{
    $nome = preg_replace('~ (Feminino|Sub-\d+)$~i', '', $termo->name);
    $n = tsp_shopee_norm($nome);
    $nomes = array($n);
    $genericas = array('clube', 'esporte', 'esportivo', 'atletico', 'futebol', 'associacao', 'sport', 'club', 'paulista', 'sociedade', 'uniao', 'grupo', 'sao', 'santa', 'santo', 'nacional', 'brasil', 'paulo', 'preta', 'andre', 'bento', 'carlos', 'jose', 'gremio', 'novo', 'cruz', 'rita', 'barbara', 'catanduva');
    $palavras = explode(' ', $n);
    $ultima = end($palavras);
    if (count($palavras) > 1 && strlen($ultima) >= 5 && !in_array($ultima, $genericas, true)) {
        $nomes[] = $ultima;
    }
    return array_unique(array_filter($nomes));
}

function tsp_shopee_aceita($nome_produto, $nomes)
{
    $p = ' ' . tsp_shopee_norm($nome_produto) . ' ';
    // Fora: réplicas e falsificações
    if (preg_match('~ (tailandes[a]?|tailandia|replica|1 1|primeira linha|linha aaa|aaa|pirata|similar|inspirad[ao]) ~', $p)) {
        return false;
    }
    foreach ($nomes as $n) {
        if (strpos($p, ' ' . $n . ' ') !== false) {
            return true;
        }
    }
    return false;
}

function tsp_shopee_reais($v)
{
    $v = (float) $v;
    return $v > 0 ? number_format($v, 2, ',', '.') : '';
}

function tsp_shopee_vitrine_clube($termo)
{
    $nomes = tsp_shopee_nomes($termo);
    $nome = preg_replace('~ (Feminino|Sub-\d+)$~i', '', $termo->name);
    $itens = tsp_shopee_buscar($nome . ' camisa');
    if (is_wp_error($itens)) {
        return $itens;
    }
    if (count($itens) < 10) {
        $mais = tsp_shopee_buscar($nome);
        if (!is_wp_error($mais)) {
            $itens = array_merge($itens, $mais);
        }
    }
    $out = array();
    foreach ($itens as $it) {
        $link = (string) ($it['offerLink'] ?? '');
        if (!$link || empty($it['imageUrl']) || !tsp_shopee_aceita($it['productName'] ?? '', $nomes)) {
            continue;
        }
        $id = (string) ($it['itemId'] ?? md5($link));
        $out[$id] = array(
            'titulo' => mb_substr(wp_strip_all_tags($it['productName']), 0, 90),
            'preco'  => tsp_shopee_reais($it['priceMin'] ?? 0),
            'antigo' => '',
            'img'    => esc_url_raw($it['imageUrl']),
            'link'   => esc_url_raw($link),
            'loja'   => 'Shopee',
            'vendas' => (int) ($it['sales'] ?? 0),
        );
    }
    uasort($out, function ($a, $b) {
        return $b['vendas'] <=> $a['vendas'];
    });
    return array_values(array_slice($out, 0, TSP_SHOPEE_MAX_PRODUTOS));
}

/* ---------- Clubes e atualização diária ---------- */

function tsp_shopee_clubes()
{
    $ts = get_terms(array('taxonomy' => 'times', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 120));
    $out = array();
    foreach ((array) $ts as $t) {
        if (is_object($t) && !preg_match('~(sub-?\d+|feminin)~i', $t->slug . ' ' . $t->name)) {
            $out[] = $t;
        }
    }
    return $out;
}

function tsp_shopee_rodada($qtd = TSP_SHOPEE_POR_RODADA)
{
    $vit = (array) get_option('tsp_shopee_vitrines', array());
    $fila = array();
    foreach (tsp_shopee_clubes() as $t) {
        $idade = time() - (int) ($vit[$t->slug]['em'] ?? 0);
        if ($idade > DAY_IN_SECONDS) {
            $fila[] = array($idade, $t);
        }
    }
    usort($fila, function ($a, $b) {
        return $b[0] <=> $a[0];
    });
    $feitos = 0;
    $erro = '';
    foreach (array_slice($fila, 0, $qtd) as $x) {
        $p = tsp_shopee_vitrine_clube($x[1]);
        if (is_wp_error($p)) {
            $erro = $p->get_error_message();
            break;
        }
        $vit[$x[1]->slug] = array('em' => time(), 'produtos' => $p);
        $feitos++;
    }
    update_option('tsp_shopee_vitrines', $vit, false);
    update_option('tsp_shopee_log', array('quando' => current_time('mysql'), 'feitos' => $feitos, 'erro' => $erro), false);
    if ($feitos) {
        do_action('litespeed_purge_all');
    }
    return array($feitos, $erro);
}

add_action('init', function () {
    if (!wp_next_scheduled('tsp_shopee_hora')) {
        wp_schedule_event(time() + 300, 'hourly', 'tsp_shopee_hora');
    }
});
add_action('tsp_shopee_hora', function () {
    if (get_option('tsp_shopee_app')) {
        tsp_shopee_rodada();
    }
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tsp_shopee_hora');
});

// O tema chama isto para montar a vitrine do clube
function tsp_shopee_produtos($slug)
{
    $vit = (array) get_option('tsp_shopee_vitrines', array());
    return (array) ($vit[$slug]['produtos'] ?? array());
}

/* ---------- Tela: Ferramentas → Ofertas Shopee ---------- */

add_action('admin_menu', function () {
    add_management_page('Ofertas Shopee', 'Ofertas Shopee', 'manage_options', 'tsp-shopee', 'tsp_shopee_tela');
});

function tsp_shopee_tela()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    $msg = '';
    if (isset($_POST['tsp_shopee_salvar']) && check_admin_referer('tsp_shopee')) {
        update_option('tsp_shopee_app', sanitize_text_field(wp_unslash($_POST['app'] ?? '')), false);
        $s = trim((string) wp_unslash($_POST['secret'] ?? ''));
        if ($s !== '') {
            update_option('tsp_shopee_secret', sanitize_text_field($s), false);
        }
        $msg = '<div class="notice notice-success"><p>Salvo. Agora clique em "Testar conexão".</p></div>';
    }
    if (isset($_POST['tsp_shopee_testar']) && check_admin_referer('tsp_shopee')) {
        $r = tsp_shopee_buscar('camisa palmeiras', 5);
        if (is_wp_error($r)) {
            $msg = '<div class="notice notice-error"><p><strong>Não funcionou:</strong> ' . esc_html($r->get_error_message()) . '</p><p>Mande um print desta mensagem para o Claude (sem mostrar a chave).</p></div>';
        } else {
            $nomes = array_map(function ($i) {
                return esc_html(($i['productName'] ?? '') . ' — R$ ' . tsp_shopee_reais($i['priceMin'] ?? 0));
            }, $r);
            $msg = '<div class="notice notice-success"><p><strong>Conexão OK!</strong> Exemplo de busca "camisa palmeiras":</p><ul style="list-style:disc;margin-left:20px"><li>' . implode('</li><li>', $nomes) . '</li></ul></div>';
        }
    }
    if (isset($_POST['tsp_shopee_agora']) && check_admin_referer('tsp_shopee')) {
        list($n, $e) = tsp_shopee_rodada(10);
        $msg = $e ? '<div class="notice notice-error"><p>' . esc_html($e) . '</p></div>' : '<div class="notice notice-success"><p>' . (int) $n . ' clube(s) atualizado(s). Os outros entram sozinhos, de hora em hora.</p></div>';
    }
    $app = (string) get_option('tsp_shopee_app', '');
    $tem = (string) get_option('tsp_shopee_secret', '') !== '';
    $log = (array) get_option('tsp_shopee_log', array());
    $vit = (array) get_option('tsp_shopee_vitrines', array());
    echo '<div class="wrap"><h1>Ofertas Shopee</h1>' . $msg; // phpcs:ignore
    echo '<p>Com a API de afiliados da Shopee, o site busca produtos de cada clube, gera o link de afiliado e monta a vitrine sozinho (uma vez por dia por clube). Só entram produtos que citam o nome do clube; réplicas e "tailandesas" ficam de fora.</p>';
    echo '<form method="post">';
    wp_nonce_field('tsp_shopee');
    echo '<table class="form-table"><tr><th><label for="app">App ID</label></th><td><input type="text" id="app" name="app" class="regular-text" value="' . esc_attr($app) . '" autocomplete="off"></td></tr>';
    echo '<tr><th><label for="secret">Chave secreta</label></th><td><input type="password" id="secret" name="secret" class="regular-text" value="" autocomplete="new-password" placeholder="' . ($tem ? '•••••••• (já salva; deixe vazio para manter)' : 'cole aqui') . '"><p class="description">A chave fica guardada só no seu site e nunca aparece de novo nesta tela.</p></td></tr></table>';
    echo '<p><button class="button button-primary" name="tsp_shopee_salvar" value="1">Salvar</button> <button class="button" name="tsp_shopee_testar" value="1">Testar conexão</button> <button class="button" name="tsp_shopee_agora" value="1">Atualizar 10 clubes agora</button></p></form>';
    echo '<p><strong>Última atualização automática:</strong> ' . esc_html($log['quando'] ?? 'ainda não') . (isset($log['feitos']) ? ' · ' . (int) $log['feitos'] . ' clube(s)' : '') . (!empty($log['erro']) ? ' · <span style="color:#b32d2e">' . esc_html($log['erro']) . '</span>' : '') . '</p>';
    if ($vit) {
        echo '<h2>Vitrines prontas (' . count($vit) . ')</h2><table class="widefat striped" style="max-width:640px"><thead><tr><th>Clube</th><th>Produtos</th><th>Atualizado</th></tr></thead><tbody>';
        foreach ($vit as $slug => $v) {
            $t = get_term_by('slug', $slug, 'times');
            echo '<tr><td>' . esc_html($t ? $t->name : $slug) . '</td><td>' . count((array) ($v['produtos'] ?? array())) . '</td><td>' . esc_html(wp_date('d/m H\hi', (int) ($v['em'] ?? 0))) . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';
}

// Atualização automática pelo GitHub do TSP
require_once __DIR__ . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('plugin', 'tsp-shopee', plugin_basename(__FILE__), get_file_data(__FILE__, array('v' => 'Version'))['v']);
