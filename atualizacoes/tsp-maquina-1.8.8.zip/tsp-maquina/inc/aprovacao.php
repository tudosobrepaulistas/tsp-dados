<?php
/**
 * Central de aprovação (09/11/2026): um lugar só, no topo do menu, para o Thiago ver e decidir
 *  1) o que a Máquina deixou esperando (rascunhos sem foto): pôr foto e publicar, ou jogar fora;
 *  2) o que está agendado: publicar agora ou cancelar;
 *  3) as pautas (pauteiro + pedidas pela Máquina): "Eu faço" ou "Descartar".
 * Notícia velha (mais de 2 dias) aparece marcada como "caducou".
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', function () {
    $n = count(tsp_maq_rascunhos_todos());
    add_menu_page('Aprovação', 'Aprovação' . ($n ? ' <span class="awaiting-mod">' . $n . '</span>' : ''), 'manage_options', 'tsp-aprovacao', 'tsp_apr_tela', 'dashicons-yes-alt', 2);
});

function tsp_maq_rascunhos_todos()
{
    return get_posts(array('post_type' => tsp_maq_tipo(), 'post_status' => array('draft', 'pending'), 'numberposts' => 100, 'meta_key' => 'tsp_maq_id', 'orderby' => 'date', 'order' => 'DESC'));
}

function tsp_apr_caducou($p)
{
    $tipo = get_post_meta($p->ID, 'tsp_maq_tipo', true);
    return in_array($tipo, array('noticia', 'posjogo', 'coletiva', 'video'), true) && (time() - get_post_time('U', true, $p)) > 2 * DAY_IN_SECONDS;
}

add_action('admin_post_tsp_apr', function () {
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão.');
    }
    check_admin_referer('tsp_apr');
    $acao = sanitize_key($_REQUEST['acao'] ?? '');
    $ids = array_filter(array_map('intval', (array) ($_REQUEST['ids'] ?? array())));
    $msg = '';
    if ($acao === 'lixeira') {
        foreach ($ids as $id) {
            if (get_post_meta($id, 'tsp_maq_id', true) && get_post_status($id) !== 'publish') {
                wp_trash_post($id);
            }
        }
        $msg = count($ids) . ' matéria(s) na lixeira';
    } elseif ($acao === 'caducadas') {
        $n = 0;
        foreach (tsp_maq_rascunhos_todos() as $p) {
            if (tsp_apr_caducou($p)) {
                wp_trash_post($p->ID);
                $n++;
            }
        }
        $msg = $n . ' notícia(s) velha(s) na lixeira';
    } elseif ($acao === 'publicar') {
        foreach ($ids as $id) {
            tsp_maq_publicar_agora($id);
        }
        $msg = count($ids) . ' publicada(s)';
    } elseif (in_array($acao, array('pauta_faco', 'pauta_descarta'), true)) {
        $pid = sanitize_key($_REQUEST['pauta'] ?? '');
        $donos = (array) get_option('tsp_pautas_donos', array());
        $donos[$pid] = $acao === 'pauta_faco' ? get_current_user_id() : -1;
        update_option('tsp_pautas_donos', array_slice($donos, -500, null, true), false);
        $msg = $acao === 'pauta_faco' ? 'Pauta é sua (saiu da lista dos redatores)' : 'Pauta descartada';
        if ($acao === 'pauta_faco') {
            $rid = tsp_apr_rascunho_da_pauta($pid);
            if ($rid) {
                wp_safe_redirect(get_edit_post_link($rid, 'url'));
                exit;
            }
        }
    } elseif ($acao === 'pauta_devolve') {
        $pid = sanitize_key($_REQUEST['pauta'] ?? '');
        $donos = (array) get_option('tsp_pautas_donos', array());
        unset($donos[$pid]);
        update_option('tsp_pautas_donos', $donos, false);
        $msg = 'Pauta devolvida para a lista';
    }
    wp_safe_redirect(add_query_arg(array('page' => 'tsp-aprovacao', 'ok' => rawurlencode($msg)), admin_url('admin.php')) . '#' . sanitize_key($_REQUEST['volta'] ?? ''));
    exit;
});

// Acha a pauta pelo id (pauteiro ou pedida pela Máquina)
function tsp_apr_pauta($pid)
{
    $p = get_option('tsp_pautas', array());
    foreach (array_merge((array) ($p['itens'] ?? array()), function_exists('tsp_pautas_da_maquina') ? tsp_pautas_da_maquina() : array()) as $it) {
        if (($it['id'] ?? '') === $pid) {
            return $it;
        }
    }
    return null;
}

// Rascunho da pauta (10/11/2026): "Eu faço" já abre o editor com título provisório e o clube marcado.
// A pauta e as fontes ficam numa caixa ao lado do texto, não dentro da matéria.
function tsp_apr_rascunho_da_pauta($pid)
{
    $ja = get_posts(array('post_type' => 'post', 'post_status' => array('draft', 'pending', 'future', 'publish'), 'meta_key' => 'tsp_pauta_id', 'meta_value' => $pid, 'numberposts' => 1, 'fields' => 'ids'));
    if ($ja) {
        return (int) $ja[0];
    }
    $it = tsp_apr_pauta($pid);
    if (!$it) {
        return 0;
    }
    $id = wp_insert_post(array('post_type' => 'post', 'post_status' => 'draft', 'post_title' => wp_strip_all_tags($it['titulo'] ?? ''), 'post_content' => '', 'post_author' => get_current_user_id()));
    if (!$id || is_wp_error($id)) {
        return 0;
    }
    update_post_meta($id, 'tsp_pauta_id', $pid);
    update_post_meta($id, 'tsp_pauta', wp_slash(wp_json_encode($it, JSON_UNESCAPED_UNICODE)));
    if (!empty($it['clube']) && term_exists($it['clube'], 'times')) {
        wp_set_object_terms($id, array($it['clube']), 'times');
    }
    return (int) $id;
}

// Caixa "Pauta" ao lado do editor
add_action('add_meta_boxes_post', function ($post) {
    if (!get_post_meta($post->ID, 'tsp_pauta', true)) {
        return;
    }
    add_meta_box('tsp-pauta', '📝 Pauta desta matéria', function ($post) {
        $it = json_decode((string) get_post_meta($post->ID, 'tsp_pauta', true), true);
        if (!is_array($it)) {
            return;
        }
        echo '<p><strong>' . esc_html($it['titulo'] ?? '') . '</strong></p>';
        if (!empty($it['resumo'])) {
            echo '<p>' . esc_html($it['resumo']) . '</p>';
        }
        if (!empty($it['angulo'])) {
            echo '<p><em>Ângulo: ' . esc_html($it['angulo']) . '</em></p>';
        }
        if (!empty($it['fontes'])) {
            echo '<p>Fontes para conferir:</p><ul style="list-style:disc;padding-left:18px">';
            foreach ((array) $it['fontes'] as $f) {
                echo '<li><a href="' . esc_url($f['url']) . '" target="_blank" rel="noopener nofollow">' . esc_html(($f['nome'] ?? '') ?: wp_parse_url($f['url'], PHP_URL_HOST)) . '</a></li>';
            }
            echo '</ul>';
        } else {
            echo '<p><em>Pedida pela Máquina: apure com o clube.</em></p>';
        }
        echo '<p class="description">O título veio da pauta: reescreva antes de publicar. Esta caixa não aparece no site.</p>';
    }, 'post', 'side', 'high');
});

function tsp_apr_url($args)
{
    return wp_nonce_url(add_query_arg(array_merge(array('action' => 'tsp_apr'), $args), admin_url('admin-post.php')), 'tsp_apr');
}

function tsp_apr_tela()
{
    $ok = isset($_GET['ok']) ? sanitize_text_field(wp_unslash($_GET['ok'])) : '';
    echo '<div class="wrap tsp-apr"><h1>✅ Aprovação</h1><p>Tudo o que a Máquina e o pauteiro deixaram para você decidir, num lugar só.</p>';
    if ($ok) {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($ok) . '.</p></div>';
    }
    echo '<style>.tsp-apr .card{max-width:none;padding:14px 18px;margin:14px 0}.tsp-apr table td{vertical-align:top}.tsp-apr .velha{background:#fbebeb;color:#a00;border-radius:4px;padding:1px 6px;font-size:11px;font-weight:700}.tsp-apr .tipo{background:#f0efec;border-radius:4px;padding:1px 6px;font-size:11px}.tsp-apr .acoes a{margin-right:6px}.tsp-apr nav a{margin-right:14px;font-weight:600}</style>';
    $rasc = tsp_maq_rascunhos_todos();
    $ag = function_exists('tsp_maq_agendadas') ? tsp_maq_agendadas(50) : array();
    $pautas = array();
    $p = get_option('tsp_pautas', array());
    $donos = (array) get_option('tsp_pautas_donos', array());
    foreach (array_merge((array) ($p['itens'] ?? array()), function_exists('tsp_pautas_da_maquina') ? tsp_pautas_da_maquina() : array()) as $it) {
        if (empty($donos[$it['id']])) {
            $pautas[] = $it;
        }
    }
    $minhas = array();
    $todas = array_merge((array) ($p['itens'] ?? array()), function_exists('tsp_pautas_da_maquina') ? tsp_pautas_da_maquina() : array());
    $vistos = array();
    foreach ($todas as $it) {
        if ((int) ($donos[$it['id']] ?? 0) === get_current_user_id() && !isset($vistos[$it['id']])) {
            $vistos[$it['id']] = 1;
            $minhas[] = $it;
        }
    }
    if ($minhas) {
        echo '<div class="card" id="minhas" style="border-left:4px solid #2271b1"><h2>✍️ Minhas pautas (' . count($minhas) . ')</h2><p>As que você pegou com <strong>Eu faço</strong>. <strong>Escrever</strong> abre a matéria já com o clube marcado e a pauta ao lado.</p><table class="widefat striped"><tbody>';
        foreach (array_reverse($minhas) as $it) {
            $t = get_term_by('slug', $it['clube'], 'times');
            $rid = get_posts(array('post_type' => 'post', 'post_status' => array('draft', 'pending', 'future', 'publish'), 'meta_key' => 'tsp_pauta_id', 'meta_value' => $it['id'], 'numberposts' => 1));
            $situ = $rid ? ($rid[0]->post_status === 'publish' ? '✅ publicada' : '📝 rascunho começado') : '';
            echo '<tr><td style="width:180px"><strong>' . esc_html($t ? $t->name : $it['clube']) . '</strong><br><small>' . esc_html($it['quando'] ?? '') . '</small></td><td>' . esc_html($it['titulo']) . ($situ ? ' <span class="tipo">' . esc_html($situ) . '</span>' : '') . '</td><td class="acoes" style="width:260px">';
            if ($rid && $rid[0]->post_status === 'publish') {
                echo '<a class="button" href="' . esc_url(get_permalink($rid[0])) . '" target="_blank">Ver no site</a>';
            } else {
                echo '<a class="button button-primary" href="' . esc_url(tsp_apr_url(array('acao' => 'pauta_faco', 'pauta' => $it['id'], 'volta' => 'minhas'))) . '">' . ($rid ? 'Continuar' : 'Escrever') . '</a><a class="button" href="' . esc_url(tsp_apr_url(array('acao' => 'pauta_devolve', 'pauta' => $it['id'], 'volta' => 'minhas'))) . '">Devolver</a>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '<nav>' . ($minhas ? '<a href="#minhas">✍️ Minhas pautas (' . count($minhas) . ')</a>' : '') . '<a href="#esperando">1. Esperando você (' . count($rasc) . ')</a><a href="#agendadas">2. Agendadas (' . count($ag) . ')</a><a href="#pautas">3. Pautas (' . count($pautas) . ')</a></nav>';

    // 1. Rascunhos
    echo '<div class="card" id="esperando"><h2>1. Esperando você</h2><p>Matérias prontas da Máquina que não saíram (quase sempre por falta de foto). <strong>Pôr foto e publicar</strong> abre o editor: coloque a foto em "Imagem destacada" (crédito na legenda) e clique em Publicar.</p>';
    if (!$rasc) {
        echo '<p>Nada esperando. 👍</p>';
    } else {
        $velhas = array_filter($rasc, 'tsp_apr_caducou');
        if ($velhas) {
            echo '<p><a class="button" href="' . esc_url(tsp_apr_url(array('acao' => 'caducadas', 'volta' => 'esperando'))) . '" onclick="return confirm(\'Mandar para a lixeira as ' . count($velhas) . ' notícias velhas?\')">🗑 Jogar fora as ' . count($velhas) . ' notícias que caducaram</a></p>';
        }
        echo '<table class="widefat striped"><thead><tr><th>Matéria</th><th>Criada</th><th>O que fazer</th></tr></thead><tbody>';
        foreach ($rasc as $x) {
            $tipo = get_post_meta($x->ID, 'tsp_maq_tipo', true);
            $rot = array('noticia' => 'notícia', 'historia' => 'história', 'coletiva' => 'coletiva', 'posjogo' => 'pós-jogo', 'video' => 'vídeo')[$tipo] ?? $tipo;
            echo '<tr><td><strong>' . esc_html($x->post_title) . '</strong> <span class="tipo">' . esc_html($rot) . '</span>' . (tsp_apr_caducou($x) ? ' <span class="velha">caducou</span>' : '') . (function_exists('tsp_maq_fontes_html') ? tsp_maq_fontes_html($x->ID) : '') . (($ob = get_post_meta($x->ID, 'tsp_maq_obs', true)) ? '<div style="margin-top:4px;color:#8a4b00">' . esc_html($ob) . '</div>' : '') . '</td>';
            echo '<td>' . esc_html(get_the_date('d/m H\hi', $x)) . '</td><td class="acoes"><a class="button button-primary" href="' . esc_url(get_edit_post_link($x->ID)) . '">Pôr foto e publicar</a><a class="button" href="' . esc_url(tsp_apr_url(array('acao' => 'lixeira', 'ids' => array($x->ID), 'volta' => 'esperando'))) . '">Jogar fora</a></td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';

    // 2. Agendadas
    echo '<div class="card" id="agendadas"><h2>2. Agendadas pela Máquina</h2><p>Já têm foto e fontes e vão sair sozinhas no horário. Você pode adiantar ou cancelar.</p>';
    if (!$ag) {
        echo '<p>Nenhuma agendada agora.</p>';
    } else {
        echo '<table class="widefat striped"><thead><tr><th>Sai às</th><th>Matéria</th><th>O que fazer</th></tr></thead><tbody>';
        foreach ($ag as $x) {
            echo '<tr><td>' . esc_html(get_the_date('d/m H\hi', $x)) . '</td><td><strong>' . esc_html($x->post_title) . '</strong>' . (function_exists('tsp_maq_fontes_html') ? tsp_maq_fontes_html($x->ID) : '') . '</td><td class="acoes"><a class="button button-primary" href="' . esc_url(tsp_apr_url(array('acao' => 'publicar', 'ids' => array($x->ID), 'volta' => 'agendadas'))) . '">Publicar agora</a><a class="button" href="' . esc_url(get_edit_post_link($x->ID)) . '">Ver/editar</a><a class="button" href="' . esc_url(tsp_apr_url(array('acao' => 'lixeira', 'ids' => array($x->ID), 'volta' => 'agendadas'))) . '" onclick="return confirm(\'Cancelar esta matéria?\')">Cancelar</a></td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';

    // 3. Pautas
    echo '<div class="card" id="pautas"><h2>3. Pautas</h2><p>Assuntos para apurar: do pauteiro (com fontes) e pedidos pela Máquina quando ela não achou notícia confirmada. <strong>Eu faço</strong> tira a pauta da lista dos redatores e já abre a matéria para você escrever (ela fica guardada em "Minhas pautas", no topo desta tela); <strong>Descartar</strong> some com ela.</p>';
    if (!$pautas) {
        echo '<p>Sem pautas abertas nas últimas 48 horas.</p>';
    } else {
        echo '<table class="widefat striped"><thead><tr><th>Clube</th><th>Pauta</th><th>O que fazer</th></tr></thead><tbody>';
        foreach (array_reverse($pautas) as $it) {
            $t = get_term_by('slug', $it['clube'], 'times');
            echo '<tr><td><strong>' . esc_html($t ? $t->name : $it['clube']) . '</strong><br><small>' . esc_html($it['quando'] ?? '') . '</small></td><td>' . esc_html($it['titulo']) . (!empty($it['resumo']) ? '<br><small>' . esc_html($it['resumo']) . '</small>' : '');
            foreach ((array) ($it['fontes'] ?? array()) as $i => $f) {
                echo ($i ? ' · ' : '<br>') . '<a href="' . esc_url($f['url']) . '" target="_blank" rel="noopener nofollow">' . esc_html($f['nome'] ?: wp_parse_url($f['url'], PHP_URL_HOST)) . '</a>';
            }
            echo '</td><td class="acoes"><a class="button button-primary" href="' . esc_url(tsp_apr_url(array('acao' => 'pauta_faco', 'pauta' => $it['id'], 'volta' => 'pautas'))) . '">Eu faço</a><a class="button" href="' . esc_url(tsp_apr_url(array('acao' => 'pauta_descarta', 'pauta' => $it['id'], 'volta' => 'pautas'))) . '">Descartar</a></td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div><p>Também mandar uma pauta sua para a Máquina escrever? Mande pelo chat com o Claude (fato, links, foto).</p></div>';
}

// Atalho na barra preta do topo
add_action('admin_bar_menu', function ($bar) {
    if (!current_user_can('manage_options')) {
        return;
    }
    $n = count(tsp_maq_rascunhos_todos());
    $bar->add_node(array('id' => 'tsp-aprovacao', 'title' => '✅ Aprovação' . ($n ? ' (' . $n . ')' : ''), 'href' => admin_url('admin.php?page=tsp-aprovacao')));
}, 80);
