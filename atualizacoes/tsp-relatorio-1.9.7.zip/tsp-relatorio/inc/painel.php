<?php
/**
 * Painel do redator (primeira caixa do Painel do WordPress):
 *  - Saudação (bom dia / boa tarde / boa noite).
 *  - Hoje: ciclos manhã/tarde/noite (x de 4), meta do dia 8 matérias (até 12 com o incentivo extra) e agendadas nas próximas 24h (x de 20).
 *  - Fechamento (dia 10 a 9): meta mínima de 200 matérias (abaixo: R$ 5,00 cada; 200 ou mais: R$ 5,45 cada),
 *    valor acumulado, projeção, média de caracteres, dias com a meta de 8 batida e sequência.
 *  - Mensagens automáticas.
 * Administrador vê a visão geral de todos os redatores.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_rel_saudacao($nome)
{
    $h = (int) (new DateTimeImmutable('now', tsp_rel_tz()))->format('G');
    $s = ($h >= 5 && $h < 12) ? 'Bom dia' : (($h >= 12 && $h < 18) ? 'Boa tarde' : 'Boa noite');
    $primeiro = trim(strtok((string) $nome, ' '));
    return $s . ($primeiro !== '' ? ', ' . $primeiro : '') . '!';
}

function tsp_rel_kpis($autor)
{
    $tz = tsp_rel_tz();
    $agora = new DateTimeImmutable('now', $tz);
    $hoje = $agora->setTime(0, 0);
    $k = array('fases' => array());
    foreach (tsp_rel_fases() as $f => $x) {
        list($de, $ate) = tsp_rel_janela_fase($f, $agora);
        $k['fases'][$f] = array('nome' => $x[0], 'feitas' => tsp_rel_contar_autor($autor, $de, $ate, 'publish'), 'cota' => tsp_rel_ocupacao($autor, $f, $agora), 'passou' => $agora > $ate, 'agora' => tsp_rel_fase_de($agora) === $f);
    }
    $k['hoje'] = tsp_rel_contar_autor($autor, $hoje, $hoje->setTime(23, 59, 59));
    $k['agendadas'] = tsp_rel_contar_autor($autor, $agora, $agora->modify('+24 hours'), 'future');

    list($ini, $fim, $pag) = tsp_rel_fechamento(0);
    $ids = get_posts(array('post_type' => tsp_rel_tipos(), 'post_status' => 'publish', 'author' => (int) $autor, 'posts_per_page' => -1, 'no_found_rows' => true,
        'meta_query' => array(tsp_rel_meta_valida()),
        'date_query' => array(array('after' => $ini->format('Y-m-d H:i:s'), 'before' => $fim->format('Y-m-d H:i:s'), 'inclusive' => true))));
    $por_dia = array();
    $chars = 0;
    foreach ($ids as $p) {
        $d = get_post_datetime($p)->setTimezone($tz)->format('Y-m-d');
        $por_dia[$d] = ($por_dia[$d] ?? 0) + 1;
        $chars += tsp_rel_caracteres($p);
    }
    $n = count($ids);
    $valor = tsp_rel_valor_materia($autor, $n);
    $k['fech'] = array('ini' => $ini, 'fim' => $fim, 'pag' => $pag, 'n' => $n, 'valor' => $valor, 'media' => $n ? round($chars / $n) : 0) + tsp_rel_pagamento($n, $valor);
    $dias_total = (int) $ini->diff($fim)->days + 1;
    $dias_passados = min($dias_total, (int) $ini->diff($agora)->days + 1);
    $k['fech']['dias_total'] = $dias_total;
    $k['fech']['dias_passados'] = $dias_passados;
    $proj = $dias_passados ? (int) round($n / $dias_passados * $dias_total) : 0;
    $k['fech']['projecao'] = $proj;
    $k['fech']['projecao_valor'] = round($proj * tsp_rel_valor_materia($autor, $proj), 2);
    $k['fech']['dias_meta'] = count(array_filter($por_dia, function ($v) {
        return $v >= TSP_REL_META_DIA;
    }));
    $seq = 0;
    $d = ($k['hoje'] >= TSP_REL_META_DIA) ? $hoje : $hoje->modify('-1 day');
    while (($por_dia[$d->format('Y-m-d')] ?? 0) >= TSP_REL_META_DIA) {
        $seq++;
        $d = $d->modify('-1 day');
    }
    $k['fech']['sequencia'] = $seq;
    return $k;
}

function tsp_rel_mensagens($k)
{
    $m = array();
    $meta_dia = TSP_REL_META_DIA;
    $max_dia = 3 * TSP_REL_POR_FASE;
    foreach ($k['fases'] as $chave => $f) {
        $nome = mb_strtolower($f['nome']);
        if ($f['agora'] && $f['cota'] < TSP_REL_POR_FASE) {
            $falta = TSP_REL_POR_FASE - $f['cota'];
            $m[] = array('aviso', $f['cota'] ? 'Bora! Só ' . ($falta === 1 ? 'mais 1 matéria' : 'mais ' . $falta . ' matérias') . ' e o ciclo da ' . $nome . ' está fechado. 💪' : 'O ciclo da ' . $nome . ' começou: são ' . TSP_REL_POR_FASE . ' matérias para brilhar. Vamos nessa! 🚀');
        }
        if ($f['agora'] && $f['cota'] >= TSP_REL_POR_FASE) {
            $m[] = array('ok', 'Ciclo da ' . $nome . ' fechado com chave de ouro! 🏆 As próximas já vão direto para o ciclo seguinte.');
        }
        if ($f['passou'] && $f['feitas'] > 0 && $f['feitas'] < TSP_REL_POR_FASE) {
            $m[] = array('aviso', 'A ' . $nome . ' fechou com ' . $f['feitas'] . ' de ' . TSP_REL_POR_FASE . '. Tudo bem: o próximo ciclo é uma nova chance de compensar!');
        }
    }
    if ($k['hoje'] >= $max_dia) {
        $m[] = array('ok', 'Dia completo: ' . $k['hoje'] . ' matérias, meta batida e incentivo extra garantido! Você é fera. 🔥');
    } elseif ($k['hoje'] >= $meta_dia) {
        $m[] = array('ok', 'Meta do dia batida: ' . $k['hoje'] . ' matérias! 🎯 Cada uma a mais até ' . $max_dia . ' é incentivo extra no seu fechamento. Bora?');
    } elseif ($k['hoje'] > 0) {
        $m[] = array('aviso', 'Hoje você já fez ' . $k['hoje'] . '. Faltam só ' . ($meta_dia - $k['hoje']) . ' para a meta do dia (' . $meta_dia . '). Vai que é sua! ⚽');
    }
    $f = $k['fech'];
    $meta = TSP_REL_META_MATERIAS;
    $esperado = $meta * $f['dias_passados'] / max(1, $f['dias_total']);
    if ($f['n'] >= $meta) {
        $m[] = array('ok', 'Meta do fechamento batida! 🎉 ' . $f['n'] . ' matérias, e todas agora valem ' . tsp_rel_reais(TSP_REL_VALOR_META) . '. Você passou de ' . tsp_rel_reais(TSP_REL_MEI_MINIMO) . '. Bora para a próxima!');
    } elseif ($f['n'] >= $esperado) {
        $m[] = array('ok', 'Você está voando! ✈️ No ritmo para chegar às ' . $meta . ' matérias, bater ' . tsp_rel_reais(TSP_REL_MEI_MINIMO) . ' e fazer cada matéria valer ' . tsp_rel_reais(TSP_REL_VALOR_META) . '.');
    } else {
        $faltam = $meta - $f['n'];
        $dias = max(1, $f['dias_total'] - $f['dias_passados'] + 1);
        $m[] = array('aviso', 'Você já tem ' . $f['n'] . ' de ' . $meta . '. Com cerca de ' . ceil($faltam / $dias) . ' por dia até ' . $f['fim']->format('d/m') . ' você chega lá, e cada matéria passa a valer ' . tsp_rel_reais(TSP_REL_VALOR_META) . '. Dá pra fazer, vamos juntos! 💪');
    }
    if ($f['sequencia'] >= 2) {
        $m[] = array('ok', $f['sequencia'] . ' dias seguidos batendo a meta do dia. Que fase! 🌟');
    }
    return $m;
}

function tsp_rel_painel_css()
{
    return '<style>.tsp-p{font-size:13px}.tsp-p-oi{font-size:18px;font-weight:700;margin:4px 0 8px}.tsp-p h3{margin:14px 0 6px;font-size:14px}.tsp-p-fases{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.tsp-p-fase{border:1px solid #dcdcde;border-radius:8px;padding:8px;text-align:center}.tsp-p-fase small{display:block;color:#777}.tsp-p-fase.is-agora{border-color:#E8862A;box-shadow:0 0 0 1px #E8862A}.tsp-p-fase b{display:block;font-size:22px}.tsp-p-barra{height:6px;background:#eee;border-radius:9px;overflow:hidden;margin-top:6px}.tsp-p-barra span{display:block;height:100%;background:#E8862A}.tsp-p-meta{background:#fff8f0;border:1px solid #f3d3b0;border-radius:8px;padding:8px 10px;margin:8px 0}.tsp-p-kpis{display:grid;grid-template-columns:repeat(2,1fr);gap:6px 12px;margin-top:6px}.tsp-p-kpis div{background:#f6f7f7;border-radius:6px;padding:6px 8px}.tsp-p-kpis b{display:block;font-size:16px}.tsp-p-msg{margin:6px 0;padding:6px 10px;border-left:4px solid;border-radius:4px;background:#f6f7f7}.tsp-p-msg.ok{border-color:#1a7f37}.tsp-p-msg.aviso{border-color:#E8862A}.tsp-p-msg.erro{border-color:#b32d2e}.tsp-p table{width:100%}.tsp-p td.n,.tsp-p th.n{text-align:right}</style>';
}

function tsp_rel_barra($v, $max)
{
    return '<div class="tsp-p-barra"><span style="width:' . (int) min(100, $max ? 100 * $v / $max : 0) . '%"></span></div>';
}

function tsp_rel_painel_redator($autor)
{
    $k = tsp_rel_kpis($autor);
    $f = $k['fech'];
    $u = get_userdata($autor);
    echo tsp_rel_painel_css() . '<div class="tsp-p"><p class="tsp-p-oi">' . esc_html(tsp_rel_saudacao($u ? $u->display_name : '')) . '</p>';
    echo function_exists('tsp_corr_avisos_html') && (int) $autor === get_current_user_id() ? tsp_corr_avisos_html($autor) : ''; // phpcs:ignore
    foreach (tsp_rel_mensagens($k) as $m) {
        echo '<div class="tsp-p-msg ' . esc_attr($m[0]) . '">' . esc_html($m[1]) . '</div>';
    }
    echo function_exists('tsp_notas_painel_html') ? tsp_notas_painel_html($autor) : ''; // phpcs:ignore -- HTML montado com escape
    echo '<h3>Hoje · ' . (int) $k['hoje'] . ' matérias · meta ' . TSP_REL_META_DIA . ' (até ' . (3 * TSP_REL_POR_FASE) . ' com o incentivo extra)</h3>' . tsp_rel_barra($k['hoje'], TSP_REL_META_DIA) . '<div class="tsp-p-fases" style="margin-top:8px">';
    foreach ($k['fases'] as $chave => $x) {
        $j = tsp_rel_fases()[$chave];
        echo '<div class="tsp-p-fase' . ($x['agora'] ? ' is-agora' : '') . '">' . esc_html($x['nome']) . '<small>' . esc_html(str_replace(':', 'h', substr($j[1], 0, 5)) . '–' . str_replace(':', 'h', substr($j[2], 0, 5))) . '</small><b>' . (int) min($x['cota'], 99) . '/' . TSP_REL_POR_FASE . '</b>' . tsp_rel_barra($x['cota'], TSP_REL_POR_FASE) . '</div>';
    }
    echo '</div><p>Agendadas para as próximas 24h: <strong>' . (int) $k['agendadas'] . ' de ' . TSP_REL_AGENDA_MAX . '</strong>' . tsp_rel_barra($k['agendadas'], TSP_REL_AGENDA_MAX) . '</p>';
    echo tsp_rel_pautas_html($autor); // phpcs:ignore -- HTML montado com escape
    echo '<h3>Fechamento ' . esc_html($f['ini']->format('d/m') . ' a ' . $f['fim']->format('d/m')) . ' · pagamento ' . esc_html($f['pag']->format('d/m')) . '</h3>';
    echo '<div class="tsp-p-meta"><strong>Meta mínima: ' . TSP_REL_META_MATERIAS . ' matérias.</strong> Com ' . TSP_REL_META_MATERIAS . ' ou mais, todas valem ' . esc_html(tsp_rel_reais(TSP_REL_VALOR_META)) . '. Abaixo disso, ' . esc_html(tsp_rel_reais(TSP_REL_VALOR_BASE)) . ' cada.';
    echo '<br>Você está em <strong>' . (int) $f['n'] . ' de ' . TSP_REL_META_MATERIAS . '</strong>' . tsp_rel_barra($f['n'], TSP_REL_META_MATERIAS) . '</div>';
    echo '<div class="tsp-p-kpis">';
    $kp = array(
        'Matérias no fechamento' => number_format_i18n($f['n']),
        'A receber até agora' => tsp_rel_reais($f['bruto']),
        'Valor por matéria agora' => tsp_rel_reais($f['valor']),
        'Faltam para a meta' => $f['n'] >= TSP_REL_META_MATERIAS ? 'Meta batida ✓' : (TSP_REL_META_MATERIAS - $f['n']) . ' matérias',
        'Projeção até ' . $f['fim']->format('d/m') => number_format_i18n($f['projecao']) . ' matérias · ' . tsp_rel_reais($f['projecao_valor']),
        'Média de caracteres' => number_format_i18n($f['media']),
        'Dias com a meta do dia (' . TSP_REL_META_DIA . ')' => $f['dias_meta'] . ' de ' . $f['dias_passados'],
        'Sequência batendo a meta do dia' => $f['sequencia'] . ' dia(s)',
    );
    foreach ($kp as $r => $v) {
        echo '<div>' . esc_html($r) . '<b>' . esc_html($v) . '</b></div>';
    }
    echo '</div>';
    $dv = tsp_rel_devolutivas($autor);
    if ($dv) {
        echo '<h3>Ajustes sugeridos pela coordenação (' . count($dv) . ')</h3>';
        foreach ($dv as $p) {
            list($a, $obs) = tsp_rel_aval($p->ID);
            echo '<div class="tsp-p-msg ' . ($a === 'recusada' ? 'erro' : 'aviso') . '"><strong>' . esc_html($a === 'recusada' ? 'Esta não entrou no fechamento' : 'Vale um ajuste') . ':</strong> <a href="' . esc_url(get_edit_post_link($p->ID, 'url')) . '">' . esc_html(get_the_title($p)) . '</a>' . ($obs ? '<br>' . esc_html($obs) : '') . '</div>';
        }
    }
    echo '<p><a href="' . esc_url(admin_url('admin.php?page=tsp-relatorio')) . '">Ver relatório completo →</a></p></div>';
}

function tsp_rel_redatores()
{
    return get_users(array('role__in' => array('author', 'editor', 'contributor', 'tsp_coordenador'), 'orderby' => 'display_name'));
}

function tsp_rel_painel_geral()
{
    $tz = tsp_rel_tz();
    $hoje = new DateTimeImmutable('today', $tz);
    list($ini, $fim, $pag) = tsp_rel_fechamento(0);
    $eu = wp_get_current_user();
    echo tsp_rel_painel_css() . '<div class="tsp-p"><p class="tsp-p-oi">' . esc_html(tsp_rel_saudacao($eu->display_name)) . '</p>' . (function_exists('tsp_corr_avisos_html') ? tsp_corr_avisos_html($eu->ID) : '') . '<p>Fechamento <strong>' . esc_html($ini->format('d/m') . ' a ' . $fim->format('d/m')) . '</strong> · pagamento <strong>' . esc_html($pag->format('d/m')) . '</strong> · meta ' . TSP_REL_META_MATERIAS . ' matérias</p>';
    $din = current_user_can('manage_options'); // valores em R$ só para o administrador
    echo '<table class="widefat striped"><thead><tr><th>Redator</th><th class="n">Hoje</th><th class="n">Agend.</th><th class="n">Fech.</th>' . ($din ? '<th class="n">Valor</th><th class="n">A pagar</th><th>MEI</th>' : '') . '</tr></thead><tbody>';
    $soma = 0;
    foreach (tsp_rel_redatores() as $u) {
        $n = tsp_rel_contar_autor($u->ID, $ini, $fim, 'publish', tsp_rel_meta_valida());
        $h = tsp_rel_contar_autor($u->ID, $hoje, $hoje->setTime(23, 59, 59));
        $ag = tsp_rel_contar_autor($u->ID, new DateTimeImmutable('now', $tz), new DateTimeImmutable('+24 hours', $tz), 'future');
        $v = tsp_rel_valor_materia($u->ID, $n);
        $p = tsp_rel_pagamento($n, $v);
        $soma += $p['total'];
        echo '<tr><td>' . esc_html($u->display_name) . '</td><td class="n">' . (int) $h . '/' . TSP_REL_META_DIA . '</td><td class="n">' . (int) $ag . '</td><td class="n">' . (int) $n . '/' . TSP_REL_META_MATERIAS . '</td>' . ($din ? '<td class="n">' . esc_html(tsp_rel_reais($v)) . '</td><td class="n">' . esc_html(tsp_rel_reais($p['total'])) . '</td><td>' . ($p['mei'] ? '✓' : '—') . '</td>' : '') . '</tr>';
    }
    echo '</tbody>' . ($din ? '<tfoot><tr><th colspan="5">Total a pagar até agora (com MEI)</th><th class="n">' . esc_html(tsp_rel_reais($soma)) . '</th><th></th></tr></tfoot>' : '') . '</table>';
    echo function_exists('tsp_rel_carentes_admin_html') ? tsp_rel_carentes_admin_html() : ''; // phpcs:ignore
    echo '<p><a href="' . esc_url(admin_url('admin.php?page=tsp-relatorio')) . '">' . ($din ? 'Relatório completo e pagamento →' : 'Relatório completo da equipe →') . '</a></p></div>';
}

add_action('wp_dashboard_setup', function () {
    if (!current_user_can('edit_posts')) {
        return;
    }
    if (current_user_can('manage_options')) {
        wp_add_dashboard_widget('tsp_rel_geral', 'Redação TSP · visão geral', 'tsp_rel_painel_geral');
    } else {
        if (tsp_rel_coord()) {
            wp_add_dashboard_widget('tsp_rel_geral', 'Redação TSP · equipe (coordenação)', 'tsp_rel_painel_geral');
        }
        wp_add_dashboard_widget('tsp_rel_meu', 'Meu progresso na redação', function () {
            tsp_rel_painel_redator(get_current_user_id());
        });
    }
    global $wp_meta_boxes;
    $d = &$wp_meta_boxes['dashboard']['normal']['core'];
    foreach (array('tsp_rel_meu', 'tsp_rel_geral') as $id) {
        if (isset($d[$id])) {
            $d = array($id => $d[$id]) + $d;
        }
    }
});
