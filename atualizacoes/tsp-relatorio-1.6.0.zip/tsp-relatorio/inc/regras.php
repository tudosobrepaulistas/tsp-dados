<?php
/**
 * Regras da redação.
 *  - Ciclos do dia: Manhã 07h00–12h00, Tarde 12h01–18h00, Noite 18h01–23h59. Cada ciclo tem cota de 4 matérias (até 12 por dia).
 *  - Meta do dia: 8 matérias; as 4 a mais (até 12) são incentivo extra.
 *  - Cota do ciclo cheia: a matéria é agendada sozinha para o próximo ciclo com vaga (manhã → tarde 12h01 → noite 18h01 →
 *    manhã seguinte 07h00), e o redator recebe o aviso.
 *  - Madrugada (00h00–06h59): não publica na hora; a matéria vai sozinha para o ciclo da manhã (07h00), ou o redator agenda.
 *  - Agendamento feito pelo redator: até 20 matérias nas próximas 24 horas (e nunca para depois de 24 horas).
 *  - Administradores não têm limite.
 *  - Pagamento por matéria publicada no fechamento: R$ 5,00; com 200 matérias ou mais, todas passam a R$ 5,45.
 *    Quem passa de R$ 1.000,00 recebe também o MEI (R$ 85,00) — só aparece para o administrador.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_REL_POR_FASE = 4;
const TSP_REL_META_DIA = 8;
const TSP_REL_AGENDA_MAX = 20;
const TSP_REL_VALOR_BASE = 5.00;
const TSP_REL_VALOR_META = 5.45;
const TSP_REL_META_MATERIAS = 200;
const TSP_REL_MEI = 85.00;
const TSP_REL_MEI_MINIMO = 1000.00;

function tsp_rel_tz()
{
    return new DateTimeZone('America/Sao_Paulo');
}

function tsp_rel_fases()
{
    return array(
        'manha' => array('Manhã', '07:00:00', '12:00:59'),
        'tarde' => array('Tarde', '12:01:00', '18:00:59'),
        'noite' => array('Noite', '18:01:00', '23:59:59'),
    );
}

function tsp_rel_fase_de(DateTimeInterface $d)
{
    $h = $d->format('H:i:s');
    foreach (tsp_rel_fases() as $k => $f) {
        if ($h >= $f[1] && $h <= $f[2]) {
            return $k;
        }
    }
    return 'madrugada';
}

function tsp_rel_janela_fase($fase, DateTimeImmutable $dia)
{
    $f = tsp_rel_fases()[$fase];
    return array(new DateTimeImmutable($dia->format('Y-m-d') . ' ' . $f[1], tsp_rel_tz()), new DateTimeImmutable($dia->format('Y-m-d') . ' ' . $f[2], tsp_rel_tz()));
}

function tsp_rel_ciclo_txt($fase)
{
    $f = tsp_rel_fases()[$fase];
    return 'ciclo da ' . mb_strtolower($f[0]) . ' (' . str_replace(':', 'h', substr($f[1], 0, 5)) . ' às ' . str_replace(':', 'h', substr($f[2], 0, 5)) . ')';
}

function tsp_rel_isento($user_id)
{
    return user_can($user_id, 'manage_options');
}

// Valor por matéria: fixo do redator (se o administrador definiu) ou R$ 5,00 / R$ 5,45 com 200 matérias ou mais
function tsp_rel_valor_materia($user_id, $n = 0)
{
    $v = get_user_meta($user_id, 'tsp_valor_materia', true);
    if ($v !== '' && $v !== false) {
        return (float) $v;
    }
    return $n >= TSP_REL_META_MATERIAS ? TSP_REL_VALOR_META : TSP_REL_VALOR_BASE;
}

function tsp_rel_contar_autor($autor, DateTimeImmutable $de, DateTimeImmutable $ate, $status = 'publish', $meta = null)
{
    $site = wp_timezone();
    $args = array(
        'post_type'      => tsp_rel_tipos(),
        'post_status'    => $status,
        'author'         => (int) $autor,
        'fields'         => 'ids',
        'posts_per_page' => -1,
        'no_found_rows'  => true,
        'date_query'     => array(array('after' => $de->setTimezone($site)->format('Y-m-d H:i:s'), 'before' => $ate->setTimezone($site)->format('Y-m-d H:i:s'), 'inclusive' => true)),
    );
    if ($meta) {
        $args['meta_query'] = array($meta);
    }
    return count(get_posts($args));
}

// Quantas matérias ocupam a cota de um ciclo (publicadas + agendadas automáticas; não conta agendamento feito pelo redator)
function tsp_rel_ocupacao($autor, $fase, DateTimeImmutable $dia, $ignorar = 0)
{
    list($de, $ate) = tsp_rel_janela_fase($fase, $dia);
    $n = tsp_rel_contar_autor($autor, $de, $ate, array('publish', 'future'), array('key' => 'tsp_agenda_manual', 'compare' => 'NOT EXISTS'));
    if ($ignorar && get_post_field('post_author', $ignorar) == $autor && in_array(get_post_status($ignorar), array('publish', 'future'), true)) {
        $d = get_post_datetime($ignorar);
        if ($d && $d >= $de && $d <= $ate && !get_post_meta($ignorar, 'tsp_agenda_manual', true)) {
            $n--;
        }
    }
    return $n;
}

// Próximo ciclo com vaga depois de $agora: devolve array(data, fase, dia) ou null
function tsp_rel_proxima_vaga($autor, DateTimeImmutable $agora, $incluir_atual = false)
{
    $ordem = array_keys(tsp_rel_fases());
    $dia = $agora->setTime(0, 0);
    for ($i = 0; $i < 9; $i++) {
        $fase = $ordem[$i % 3];
        $d = $dia->modify('+' . intdiv($i, 3) . ' day');
        list($de, $ate) = tsp_rel_janela_fase($fase, $d);
        if ($ate < $agora || (!$incluir_atual && $de <= $agora)) {
            continue;
        }
        $ocup = tsp_rel_ocupacao($autor, $fase, $d);
        if ($ocup < TSP_REL_POR_FASE) {
            $quando = $de->modify('+' . ($ocup * 15) . ' minutes'); // espaça 15 minutos entre as matérias do ciclo
            return array($quando > $agora ? $quando : $agora->modify('+1 minute'), $fase, $d);
        }
    }
    return null;
}

/**
 * Decide o que fazer com uma matéria que o redator mandou publicar ou agendar.
 * Devolve array('ok') | array('agendar', DateTimeImmutable, mensagem) | array('erro', mensagem).
 */
function tsp_rel_decidir($autor, $status, DateTimeImmutable $quando, $post_id = 0)
{
    if (tsp_rel_isento($autor)) {
        return array('ok');
    }
    $agora = new DateTimeImmutable('now', tsp_rel_tz());
    $agendadas = tsp_rel_contar_autor($autor, $agora, $agora->modify('+24 hours'), 'future');
    if ($post_id && get_post_status($post_id) === 'future') {
        $agendadas--;
    }
    if ($status === 'future' && $quando > $agora->modify('+2 minutes')) {
        if ($quando > $agora->modify('+24 hours')) {
            return array('erro', 'Quase lá! O agendamento vale para as próximas 24 horas (até ' . $agora->modify('+24 hours')->format('d/m \à\s H\hi') . ').');
        }
        if ($agendadas >= TSP_REL_AGENDA_MAX) {
            return array('erro', 'Que produção! Você já tem ' . TSP_REL_AGENDA_MAX . ' matérias agendadas para as próximas 24 horas, o máximo da agenda. Guarde esta como rascunho e agende quando abrir vaga.');
        }
        return array('ok');
    }
    // Publicar agora
    $fase = tsp_rel_fase_de($agora);
    if ($fase !== 'madrugada' && tsp_rel_ocupacao($autor, $fase, $agora, $post_id) < TSP_REL_POR_FASE) {
        return array('ok');
    }
    if ($agendadas >= TSP_REL_AGENDA_MAX) {
        return array('erro', 'Que produção! A cota deste ciclo está completa e sua agenda já tem ' . TSP_REL_AGENDA_MAX . ' matérias. Guarde esta como rascunho e publique no próximo ciclo.');
    }
    $vaga = tsp_rel_proxima_vaga($autor, $agora);
    if (!$vaga) {
        return array('erro', 'Os próximos ciclos já estão cheios, que ritmo! Guarde esta como rascunho e fale com a coordenação.');
    }
    list($data, $fase_nova) = $vaga;
    $dia = $data->format('d/m') === $agora->format('d/m') ? 'hoje' : 'amanhã';
    if ($fase === 'madrugada') {
        $msg = 'Trabalhando de madrugada, hein! 🌙 Nesse horário (0h às 6h59) a matéria entra por agendamento, então já deixamos ela no ' . tsp_rel_ciclo_txt($fase_nova) . ', ' . $dia . ' às ' . $data->format('H\hi') . '.';
    } else {
        $msg = 'Cota da ' . mb_strtolower(tsp_rel_fases()[$fase][0]) . ' completa, mandou bem! 🏆 Esta matéria já ficou agendada para o ' . tsp_rel_ciclo_txt($fase_nova) . ', ' . $dia . ' às ' . $data->format('H\hi') . '. Se quiser outro horário, é só mudar o agendamento.';
    }
    return array('agendar', $data, $msg);
}

/* ---------- Editor de blocos (Gutenberg) ---------- */

foreach (array('materia', 'post') as $tsp_tipo) {
    add_filter('rest_pre_insert_' . $tsp_tipo, function ($prep, $req) {
        if (is_wp_error($prep)) {
            return $prep;
        }
        $status = $prep->post_status ?? '';
        $id = (int) ($prep->ID ?? 0);
        $antes = $id ? get_post_status($id) : '';
        if (!in_array($status, array('publish', 'future'), true) || $antes === 'publish' || ($antes === 'future' && $status === 'publish')) {
            return $prep;
        }
        $autor = (int) ($prep->post_author ?? ($id ? get_post_field('post_author', $id) : get_current_user_id()));
        $quando = !empty($prep->post_date) ? new DateTimeImmutable($prep->post_date, wp_timezone()) : new DateTimeImmutable('now', tsp_rel_tz());
        if ($status === 'publish' && $quando > new DateTimeImmutable('+2 minutes', tsp_rel_tz())) {
            $status = 'future'; // o editor manda "publish" com data futura: é agendamento
        }
        $r = tsp_rel_decidir($autor, $status, $quando->setTimezone(tsp_rel_tz()), $id);
        if ($r[0] === 'erro') {
            return new WP_Error('tsp_limite', $r[1], array('status' => 403));
        }
        if ($r[0] === 'agendar') {
            $prep->post_status = 'future';
            $prep->post_date = $r[1]->setTimezone(wp_timezone())->format('Y-m-d H:i:s');
            $prep->post_date_gmt = $r[1]->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            $prep->edit_date = true;
            $GLOBALS['tsp_rel_auto'] = $r[2];
        } elseif ($status === 'future') {
            $GLOBALS['tsp_rel_manual'] = true;
        }
        return $prep;
    }, 10, 2);
}

/* ---------- Editor clássico, edição rápida e outros caminhos ---------- */

add_filter('wp_insert_post_data', function ($data, $postarr) {
    if ((defined('REST_REQUEST') && REST_REQUEST) || wp_doing_cron() || !in_array($data['post_type'], tsp_rel_tipos(), true)) {
        return $data;
    }
    $novo = $data['post_status'];
    $id = (int) ($postarr['ID'] ?? 0);
    $antes = $id ? get_post_status($id) : '';
    if (!in_array($novo, array('publish', 'future'), true) || $antes === 'publish' || ($antes === 'future' && $novo === 'publish')) {
        return $data;
    }
    $quando = new DateTimeImmutable($data['post_date'], wp_timezone());
    $r = tsp_rel_decidir((int) $data['post_author'], $novo, $quando->setTimezone(tsp_rel_tz()), $id);
    if ($r[0] === 'erro') {
        $data['post_status'] = 'draft';
        set_transient('tsp_rel_aviso_' . get_current_user_id(), $r[1] . ' Sua matéria ficou guardada como rascunho.', 120);
    } elseif ($r[0] === 'agendar') {
        $data['post_status'] = 'future';
        $data['post_date'] = $r[1]->setTimezone(wp_timezone())->format('Y-m-d H:i:s');
        $data['post_date_gmt'] = $r[1]->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        $GLOBALS['tsp_rel_auto'] = $r[2];
        set_transient('tsp_rel_aviso_' . get_current_user_id(), $r[2], 120);
    } elseif ($novo === 'future') {
        $GLOBALS['tsp_rel_manual'] = true;
    }
    return $data;
}, 20, 2);

// Marca o tipo de agendamento e guarda o aviso para o editor mostrar
add_action('transition_post_status', function ($novo, $antigo, $post) {
    if (!in_array($post->post_type, tsp_rel_tipos(), true)) {
        return;
    }
    if ($novo === 'future') {
        if (!empty($GLOBALS['tsp_rel_auto'])) {
            delete_post_meta($post->ID, 'tsp_agenda_manual');
            update_post_meta($post->ID, 'tsp_aviso_limite', $GLOBALS['tsp_rel_auto']);
            unset($GLOBALS['tsp_rel_auto']);
        } elseif (!empty($GLOBALS['tsp_rel_manual'])) {
            update_post_meta($post->ID, 'tsp_agenda_manual', 1);
            delete_post_meta($post->ID, 'tsp_aviso_limite');
            unset($GLOBALS['tsp_rel_manual']);
        }
    }
    if ($novo === 'publish' && $antigo !== 'future') {
        delete_post_meta($post->ID, 'tsp_agenda_manual');
    }
}, 10, 3);

add_action('admin_notices', function () {
    $m = get_transient('tsp_rel_aviso_' . get_current_user_id());
    if ($m) {
        delete_transient('tsp_rel_aviso_' . get_current_user_id());
        echo '<div class="notice notice-info is-dismissible"><p><strong>Redação TSP:</strong> ' . esc_html($m) . '</p></div>';
    }
});

// Aviso dentro do editor de blocos depois de salvar
add_action('init', function () {
    foreach (tsp_rel_tipos() as $t) {
        register_post_meta($t, 'tsp_aviso_limite', array('type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => function () {
            return current_user_can('edit_posts');
        }));
    }
});
add_action('enqueue_block_editor_assets', function () {
    $js = "(function(){var d=wp.data,ult='';d.subscribe(function(){var e=d.select('core/editor');if(!e||e.isSavingPost())return;var m=(e.getCurrentPostAttribute('meta')||{}).tsp_aviso_limite||'';var s=e.getCurrentPostAttribute('status');if(m&&s==='future'&&m!==ult){ult=m;d.dispatch('core/notices').createNotice('success',m,{id:'tsp-cota',isDismissible:true});}});})();";
    wp_add_inline_script('wp-editor', $js);
});

/* ---------- Valor fixo por redator (opcional; só administrador) ---------- */

function tsp_rel_campo_valor($u)
{
    if (!current_user_can('manage_options') || !user_can($u, 'edit_posts')) {
        return;
    }
    $v = get_user_meta($u->ID, 'tsp_valor_materia', true);
    echo '<h2>Redação TSP</h2><table class="form-table"><tr><th><label for="tsp_valor_materia">Valor fixo por matéria (R$)</label></th><td>';
    echo '<input type="text" id="tsp_valor_materia" name="tsp_valor_materia" value="' . esc_attr($v === '' ? '' : number_format((float) $v, 2, ',', '')) . '" class="small-text">';
    echo '<p class="description">Deixe vazio para a regra padrão: R$ 5,00 por matéria; com ' . TSP_REL_META_MATERIAS . ' matérias ou mais no fechamento, todas passam a R$ 5,45.</p></td></tr></table>';
}
add_action('show_user_profile', 'tsp_rel_campo_valor');
add_action('edit_user_profile', 'tsp_rel_campo_valor');

function tsp_rel_salvar_valor($id)
{
    if (!current_user_can('manage_options') || !isset($_POST['tsp_valor_materia'])) {
        return;
    }
    $v = trim(sanitize_text_field(wp_unslash($_POST['tsp_valor_materia'])));
    if ($v === '') {
        delete_user_meta($id, 'tsp_valor_materia');
    } else {
        update_user_meta($id, 'tsp_valor_materia', round((float) str_replace(array('.', ','), array('', '.'), $v), 2));
    }
}
add_action('personal_options_update', 'tsp_rel_salvar_valor');
add_action('edit_user_profile_update', 'tsp_rel_salvar_valor');

/* ---------- Pagamento ---------- */

function tsp_rel_pagamento($n, $valor)
{
    $bruto = round($n * $valor, 2);
    $mei = $bruto >= TSP_REL_MEI_MINIMO ? TSP_REL_MEI : 0;
    return array('bruto' => $bruto, 'mei' => $mei, 'total' => $bruto + $mei);
}

function tsp_rel_reais($v)
{
    return 'R$ ' . number_format((float) $v, 2, ',', '.');
}
