<?php
/**
 * Clubes carentes: clubes das divisões de baixo (Paulistão A2, A3, A4 e "Outros clubes") que estão há mais de 7 dias
 * sem matéria publicada. Ao entrar no painel, cada redator recebe um recado com um clube diferente para pautar
 * (primeiro os que ele cobre; depois um rodízio entre os redatores, para ninguém receber o mesmo clube).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_REL_DIAS_CARENTE = 7;

// Clubes das divisões de baixo, com o nome da divisão
function tsp_rel_clubes_inferiores()
{
    $out = array();
    if (function_exists('tsp_grupos')) {
        $g = tsp_grupos();
        foreach (array('d2', 'd3', 'd4') as $k) {
            foreach (array_keys((array) ($g[$k]['divisao'] ?? array())) as $s) {
                $out[$s] = $g[$k]['titulo'];
            }
        }
        $nac = function_exists('tsp_slugs_nacionais') ? tsp_slugs_nacionais() : array();
        $out = array_diff_key($out, array_flip($nac));
        if (function_exists('tsp_outros_clubes')) {
            foreach (array_keys(tsp_outros_clubes()) as $s) {
                $out[$s] = $out[$s] ?? 'Outros clubes paulistas';
            }
        }
        return $out;
    }
    foreach ((array) get_terms(array('taxonomy' => 'times', 'hide_empty' => false, 'number' => 0)) as $t) {
        if (is_object($t) && !preg_match('~(sub-?\d+|feminin)~i', $t->slug)) {
            $out[$t->slug] = 'Clubes paulistas';
        }
    }
    return $out;
}

// Lista dos carentes: [slug, nome, dias sem matéria, divisão], do mais esquecido para o menos
function tsp_rel_carentes()
{
    $c = get_transient('tsp_rel_carentes');
    if (is_array($c)) {
        return $c;
    }
    $agora = time();
    $c = array();
    foreach (tsp_rel_clubes_inferiores() as $slug => $div) {
        $t = get_term_by('slug', $slug, 'times');
        if (!$t) {
            continue;
        }
        $ult = get_posts(array('post_type' => tsp_rel_tipos(), 'post_status' => 'publish', 'numberposts' => 1, 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids', 'no_found_rows' => true,
            'tax_query' => array(array('taxonomy' => 'times', 'field' => 'term_id', 'terms' => $t->term_id, 'include_children' => false))));
        $dias = $ult ? (int) floor(($agora - get_post_time('U', true, $ult[0])) / DAY_IN_SECONDS) : 999;
        if ($dias > TSP_REL_DIAS_CARENTE) {
            $c[] = array($slug, $t->name, $dias, $div, (int) $t->term_id);
        }
    }
    usort($c, function ($a, $b) {
        return $b[2] <=> $a[2];
    });
    set_transient('tsp_rel_carentes', $c, 3 * HOUR_IN_SECONDS);
    return $c;
}

// Matéria nova publicada: recalcula na próxima vez
add_action('transition_post_status', function ($novo, $antigo, $post) {
    if ($novo === 'publish' && $antigo !== 'publish' && in_array($post->post_type, tsp_rel_tipos(), true)) {
        delete_transient('tsp_rel_carentes');
    }
}, 10, 3);

// Até 2 clubes sugeridos para um redator hoje
function tsp_rel_carentes_do_redator($autor)
{
    $c = tsp_rel_carentes();
    if (!$c) {
        return array();
    }
    $meus = function_exists('tsp_rel_times_cobre') ? tsp_rel_times_cobre($autor) : array();
    $sug = array_values(array_filter($c, function ($x) use ($meus) {
        return in_array($x[4], $meus, true);
    }));
    if (count($sug) < 2) {
        // Rodízio: cada redator fica com uma "fatia" diferente da lista, que gira a cada dia
        $ids = wp_list_pluck(function_exists('tsp_rel_redatores') ? tsp_rel_redatores() : array(), 'ID');
        sort($ids);
        $n = max(1, count($ids));
        $pos = array_search((int) $autor, array_map('intval', $ids), true);
        $pos = $pos === false ? 0 : $pos;
        $dia = (int) wp_date('z');
        foreach ($c as $i => $x) {
            if ((($i + $dia) % $n) === $pos && !in_array($x, $sug, true)) {
                $sug[] = $x;
            }
            if (count($sug) >= 2) {
                break;
            }
        }
    }
    return array_slice($sug, 0, 2);
}

function tsp_rel_recado_carentes($autor)
{
    $sug = tsp_rel_carentes_do_redator($autor);
    if (!$sug) {
        return '';
    }
    $u = get_userdata($autor);
    $nome = $u ? trim(strtok($u->display_name, ' ')) : '';
    $dias = function ($d) {
        return $d >= 999 ? 'ainda não tem nenhuma matéria' : 'está há ' . $d . ' dias sem matéria';
    };
    $link = function ($x) {
        $t = get_term($x[4], 'times');
        return ($t && !is_wp_error($t)) ? '<a href="' . esc_url(get_term_link($t)) . '" target="_blank">' . esc_html($x[1]) . '</a>' : esc_html($x[1]);
    };
    $art = function ($x) {
        $t = get_term($x[4], 'times');
        return ($t && !is_wp_error($t) && function_exists('tsp_o') && strpos(tsp_o($t), 'a ') === 0) ? 'a ' : 'o ';
    };
    $h = 'Oi' . ($nome ? ', ' . esc_html($nome) : '') . '! 👋 Observamos que ' . $art($sug[0]) . $link($sug[0]) . ' (' . esc_html($sug[0][3]) . ') ' . esc_html($dias($sug[0][2])) . '. Que tal uma pauta desse clube para deixar o site equilibrado? Toda divisão conta! ⚽';
    if (!empty($sug[1])) {
        $h .= ' Se der tempo, ' . $art($sug[1]) . $link($sug[1]) . ' (' . esc_html($sug[1][3]) . ') também ' . esc_html($dias($sug[1][2])) . '.';
    }
    return $h;
}

// Recado logo ao entrar no painel
add_action('admin_notices', function () {
    $tela = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$tela || $tela->id !== 'dashboard' || current_user_can('manage_options') || !current_user_can('edit_posts')) {
        return;
    }
    $r = tsp_rel_recado_carentes(get_current_user_id());
    if ($r) {
        echo '<div class="notice notice-info is-dismissible" style="border-left-color:#E8862A;font-size:14px"><p>' . wp_kses_post($r) . '</p></div>';
    }
});

// Para o administrador: lista dos esquecidos
function tsp_rel_carentes_admin_html()
{
    $c = tsp_rel_carentes();
    if (!$c) {
        return '<h3>Divisões de baixo</h3><p>Todos os clubes tiveram matéria nos últimos ' . TSP_REL_DIAS_CARENTE . ' dias. 👏</p>';
    }
    $h = '<h3>Clubes há mais de ' . TSP_REL_DIAS_CARENTE . ' dias sem matéria (' . count($c) . ')</h3><table class="widefat striped"><tbody>';
    foreach (array_slice($c, 0, 12) as $x) {
        $h .= '<tr><td>' . esc_html($x[1]) . '</td><td>' . esc_html($x[3]) . '</td><td class="n">' . ($x[2] >= 999 ? 'nunca' : (int) $x[2] . ' dias') . '</td></tr>';
    }
    $h .= '</tbody></table>' . (count($c) > 12 ? '<p class="description">E mais ' . (count($c) - 12) . '. Cada redator recebe sugestões diferentes ao entrar no painel.</p>' : '');
    return $h;
}
