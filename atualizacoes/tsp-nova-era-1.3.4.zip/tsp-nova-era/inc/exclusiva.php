<?php
/**
 * TSP Exclusiva (19/11/2026, pedido do Thiago): entrevistas exclusivas do canal do TSP no YouTube.
 *  - Home: bloco entre o Paulistão A1 e o A2 com os 3 últimos episódios; o mais novo em destaque, com o escudo do clube.
 *  - Página /tsp-exclusiva/: todos os episódios catalogados por número e data, com busca.
 *  - Dados: dados/exclusiva.json no tsp-dados (catálogo e destaque) + RSS do canal (episódios novos entram sozinhos).
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_EXCL_JSON', 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/dados/exclusiva.json');

function tsp_exclusiva_dados()
{
    static $memo = null;
    if ($memo !== null) {
        return $memo;
    }
    $d = get_transient('tsp_excl_dados');
    if (!is_array($d)) {
        $d = get_option('tsp_excl_ultimo', array());
        $r = wp_remote_get(TSP_EXCL_JSON, array('timeout' => 8));
        if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
            $j = json_decode(wp_remote_retrieve_body($r), true);
            if (!empty($j['episodios'])) {
                $d = $j;
                update_option('tsp_excl_ultimo', $d, false);
            }
        }
        set_transient('tsp_excl_dados', $d, 6 * HOUR_IN_SECONDS);
    }
    $eps = array();
    foreach ((array) ($d['episodios'] ?? array()) as $e) {
        if (!empty($e['id']) && !empty($e['n'])) {
            $eps[(int) $e['n']] = $e;
        }
    }
    // Episódios novos pelo RSS do canal (título com "Exclusiva" e "#número")
    foreach (tsp_exclusiva_rss($d['canal'] ?? '') as $e) {
        if (!isset($eps[$e['n']])) {
            $eps[$e['n']] = $e;
        }
    }
    krsort($eps);
    $memo = array('eps' => array_values($eps), 'destaque' => $d['destaque'] ?? array(), 'canal_url' => $d['canal_url'] ?? 'https://www.youtube.com/@TudoSobrePaulista');
    return $memo;
}

function tsp_exclusiva_rss($canal)
{
    if (!$canal) {
        return array();
    }
    $c = get_transient('tsp_excl_rss');
    if (is_array($c)) {
        return $c;
    }
    $c = array();
    $r = wp_remote_get('https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode($canal), array('timeout' => 8));
    if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
        $xml = wp_remote_retrieve_body($r);
        if (preg_match_all('#<entry>(.*?)</entry>#s', $xml, $m)) {
            foreach ($m[1] as $ent) {
                if (!preg_match('#<yt:videoId>([\w-]{11})</yt:videoId>#', $ent, $id) || !preg_match('#<title>(.*?)</title>#s', $ent, $ti)) {
                    continue;
                }
                $t = html_entity_decode($ti[1], ENT_QUOTES, 'UTF-8');
                if (stripos($t, 'exclusiva') === false || !preg_match('/#\s*0*(\d+)/', $t, $n)) {
                    continue;
                }
                preg_match('#<published>(\d{4}-\d{2}-\d{2})#', $ent, $p);
                $c[] = array('n' => (int) $n[1], 'id' => $id[1], 'data' => $p[1] ?? '', 'titulo' => tsp_exclusiva_limpa($t));
            }
        }
    }
    set_transient('tsp_excl_rss', $c, 3 * HOUR_IN_SECONDS);
    return $c;
}

// "TSP EXCLUSIVA | Episódio #173 – Fulano..." / "#172 - FULANO - TSP EXCLUSIVA #tag" → "Fulano..."
function tsp_exclusiva_limpa($t)
{
    $t = preg_replace('/#[^\s\d][^\s]*/u', '', $t);
    $t = preg_replace('/^\s*TSP EXCLUSIVA\s*\|\s*Epis[oó]dio\s*#?\s*\d+\s*[–-]\s*/iu', '', $t);
    $t = preg_replace('/^\s*#?\s*\d+\s*[-–]?\s*/u', '', $t);
    $t = preg_replace('/[-|–]?\s*(TSP EXCLUSIVA|EXCLUSIVA TSP)\s*$/iu', '', trim($t));
    $t = trim(preg_replace('/\s+/u', ' ', $t), " -|–_");
    if (mb_strtoupper($t) === $t) {
        $t = mb_convert_case(mb_strtolower($t), MB_CASE_TITLE, 'UTF-8');
    }
    return preg_replace('/\s+-\s+/u', ' – ', $t);
}

function tsp_exclusiva_thumb($id, $tam = 'hqdefault')
{
    return 'https://i.ytimg.com/vi/' . rawurlencode($id) . '/' . $tam . '.jpg';
}

function tsp_exclusiva_link($id)
{
    return 'https://www.youtube.com/watch?v=' . rawurlencode($id);
}

function tsp_exclusiva_data($ymd)
{
    $t = strtotime($ymd . ' 12:00');
    return $t ? date_i18n('d/m/Y', $t) : '';
}

function tsp_exclusiva_url()
{
    return home_url('/tsp-exclusiva/');
}

// Selo "TSP Exclusiva"
function tsp_exclusiva_selo()
{
    return '<span class="tsp-excl__selo"><b>TSP</b> Exclusiva</span>';
}

/* ---------- Bloco da home ---------- */
function tsp_bloco_exclusiva()
{
    $d = tsp_exclusiva_dados();
    $eps = array_slice($d['eps'], 0, 3);
    if (!$eps) {
        return;
    }
    $dest = $d['destaque'];
    echo '<section class="tsp-secao tsp-excl" id="tsp-exclusiva" aria-labelledby="h-excl">';
    echo '<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="h-excl">TSP Exclusiva</h2><span class="tsp-secao__sub">Entrevistas exclusivas do TSP</span></div>';
    echo '<span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(tsp_exclusiva_url()) . '">Todos os episódios →</a></span></div>';
    echo '<div class="tsp-excl__grade">';
    foreach ($eps as $i => $e) {
        $novo = $i === 0;
        $esc = '';
        $sub = '';
        if ($novo && !empty($dest['n']) && (int) $dest['n'] === (int) $e['n']) {
            $t = !empty($dest['clube']) ? get_term_by('slug', $dest['clube'], 'times') : null;
            if ($t && function_exists('tsp_escudo')) {
                $esc = '<a class="tsp-excl__escudo" href="' . esc_url(get_term_link($t)) . '" title="' . esc_attr($t->name) . '">' . tsp_escudo($t, 64) . '</a>';
            }
            $sub = trim(($dest['nome'] ?? '') . (!empty($dest['papel']) ? ' · ' . $dest['papel'] : ''));
        }
        echo '<article class="tsp-excl__ep' . ($novo ? ' tsp-excl__ep--novo' : '') . '">';
        echo '<a class="tsp-excl__foto" href="' . esc_url(tsp_exclusiva_link($e['id'])) . '" target="_blank" rel="noopener">';
        echo '<img src="' . esc_url(tsp_exclusiva_thumb($e['id'], $novo ? 'maxresdefault' : 'hqdefault')) . '" alt="' . esc_attr('TSP Exclusiva #' . $e['n'] . ': ' . $e['titulo']) . '" width="' . ($novo ? 1280 : 480) . '" height="' . ($novo ? 720 : 360) . '" loading="lazy" decoding="async"' . ($novo ? ' onerror="this.onerror=null;this.src=\'' . esc_url(tsp_exclusiva_thumb($e['id'])) . '\'"' : '') . '>';
        echo '<span class="tsp-play" aria-hidden="true"></span>';
        echo '</a><div class="tsp-excl__txt">';
        if ($novo) {
            echo $esc . '<div>'; // phpcs:ignore
        }
        echo '<span class="tsp-excl__meta">' . ($novo ? '<span class="tsp-excl__novo">Novo</span>' : '') . tsp_exclusiva_selo() . ' <b class="tsp-excl__n">Ep. #' . (int) $e['n'] . '</b> · <time datetime="' . esc_attr($e['data']) . '">' . esc_html(tsp_exclusiva_data($e['data'])) . '</time></span>';
        echo '<h3 class="tsp-excl__tit"><a href="' . esc_url(tsp_exclusiva_link($e['id'])) . '" target="_blank" rel="noopener">' . esc_html($e['titulo']) . '</a></h3>';
        if ($sub) {
            echo '<span class="tsp-excl__quem">' . esc_html($sub) . '</span>';
        }
        if ($novo) {
            echo '</div>';
        }
        echo '</div></article>';
    }
    echo '</div></section>';
}

/* ---------- Página do catálogo ---------- */

// Cria a página /tsp-exclusiva/ uma vez (o tema usa page-tsp-exclusiva.php)
add_action('admin_init', function () {
    if (get_option('tsp_excl_pagina')) {
        return;
    }
    $p = get_page_by_path('tsp-exclusiva');
    if (!$p) {
        $id = wp_insert_post(array(
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => 'TSP Exclusiva',
            'post_name'    => 'tsp-exclusiva',
            'post_content' => '',
            'post_excerpt' => 'Todas as entrevistas exclusivas do TSP com jogadores, técnicos e dirigentes do futebol paulista, por episódio e data.',
        ));
        if ($id && !is_wp_error($id)) {
            update_option('tsp_excl_pagina', $id, false);
        }
    } else {
        update_option('tsp_excl_pagina', $p->ID, false);
    }
});

add_filter('wpseo_title', function ($t) {
    return is_page('tsp-exclusiva') ? 'TSP Exclusiva: todas as entrevistas do futebol paulista | TSP' : $t;
});
add_filter('wpseo_metadesc', function ($t) {
    if (!is_page('tsp-exclusiva')) {
        return $t;
    }
    $d = tsp_exclusiva_dados();
    return 'Todos os ' . count($d['eps']) . ' episódios do TSP Exclusiva: entrevistas com jogadores, técnicos e dirigentes dos clubes paulistas, por número e data.';
});

// Menu: "TSP Exclusiva" no menu principal; sem Série B fora de temporada
add_filter('wp_nav_menu_items', function ($itens, $args) {
    if (($args->theme_location ?? '') !== 'principal') {
        return $itens;
    }
    if (function_exists('tsp_serie_b_ativa') && !tsp_serie_b_ativa()) {
        $itens = preg_replace('#<li[^>]*>\s*<a[^>]*>\s*S[ée]rie B\s*</a>.*?</li>#isu', '', $itens);
    }
    if (strpos($itens, 'tsp-exclusiva') === false) {
        $itens .= '<li class="menu-item tsp-nav__excl' . (is_page('tsp-exclusiva') ? ' current-menu-item' : '') . '"><a href="' . esc_url(tsp_exclusiva_url()) . '">TSP Exclusiva</a></li>';
    }
    return $itens;
}, 10, 2);

function tsp_exclusiva_catalogo()
{
    $d = tsp_exclusiva_dados();
    $eps = $d['eps'];
    if (!$eps) {
        echo '<p>Os episódios aparecem aqui em instantes.</p>';
        return;
    }
    $anos = array();
    foreach ($eps as $e) {
        $anos[substr($e['data'], 0, 4) ?: '—'][] = $e;
    }
    echo '<div class="tsp-excl-cat">';
    echo '<label class="tsp-sr" for="tsp-excl-busca">Buscar episódio</label><input id="tsp-excl-busca" class="tsp-excl-cat__busca" type="search" placeholder="Buscar por nome, clube ou número do episódio">';
    echo '<nav class="tsp-excl-cat__anos" aria-label="Anos">';
    foreach ($anos as $a => $l) {
        echo '<a href="#ano-' . esc_attr($a) . '">' . esc_html($a) . ' <small>(' . count($l) . ')</small></a>';
    }
    echo '</nav>';
    $lista = array();
    $pos = 1;
    foreach ($anos as $a => $l) {
        echo '<h2 class="tsp-excl-cat__ano" id="ano-' . esc_attr($a) . '">' . esc_html($a) . '</h2><ol class="tsp-excl-cat__lista" reversed>';
        foreach ($l as $e) {
            $busca = mb_strtolower('#' . $e['n'] . ' ' . $e['titulo']);
            echo '<li class="tsp-excl-cat__item" data-b="' . esc_attr(remove_accents($busca)) . '"><a href="' . esc_url(tsp_exclusiva_link($e['id'])) . '" target="_blank" rel="noopener">';
            echo '<img src="' . esc_url(tsp_exclusiva_thumb($e['id'], 'mqdefault')) . '" alt="" width="320" height="180" loading="lazy" decoding="async">';
            echo '<span class="tsp-excl-cat__txt"><span class="tsp-excl-cat__n">Episódio #' . (int) $e['n'] . ' · <time datetime="' . esc_attr($e['data']) . '">' . esc_html(tsp_exclusiva_data($e['data'])) . '</time></span>';
            echo '<span class="tsp-excl-cat__t">' . esc_html($e['titulo']) . '</span></span></a></li>';
            $lista[] = array('@type' => 'ListItem', 'position' => $pos++, 'url' => tsp_exclusiva_link($e['id']), 'name' => 'TSP Exclusiva #' . $e['n'] . ': ' . $e['titulo']);
        }
        echo '</ol>';
    }
    echo '<p class="tsp-excl-cat__nada" hidden>Nenhum episódio encontrado.</p></div>';
    echo '<script>(function(){var c=document.getElementById("tsp-excl-busca");if(!c)return;var it=document.querySelectorAll(".tsp-excl-cat__item"),n=document.querySelector(".tsp-excl-cat__nada");c.addEventListener("input",function(){var q=c.value.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").trim(),v=0;it.forEach(function(li){var ok=!q||li.getAttribute("data-b").indexOf(q)>-1;li.hidden=!ok;if(ok)v++;});n.hidden=v>0;});})();</script>';
    echo '<script type="application/ld+json">' . wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'TSP Exclusiva', 'numberOfItems' => count($lista), 'itemListElement' => $lista), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
}
