<?php
/* Página TSP Exclusiva: catálogo de todos os episódios (inc/exclusiva.php) */
get_header();
$tsp_ex = tsp_exclusiva_dados();
?>
<main class="tsp-container tsp-pagina tsp-excl-pag">
	<div class="tsp-excl-pag__in">
		<?php tsp_breadcrumbs(); ?>
		<header class="tsp-excl-pag__cab">
			<?php echo tsp_exclusiva_selo(); // phpcs:ignore ?>
			<h1 class="tsp-materia__titulo">TSP Exclusiva: todas as entrevistas</h1>
			<p>Jogadores, técnicos e dirigentes do futebol paulista em conversas exclusivas com o TSP. São <?php echo (int) count($tsp_ex['eps']); ?> episódios, do mais novo ao primeiro.
			<a href="<?php echo esc_url($tsp_ex['canal_url']); ?>" target="_blank" rel="noopener">Inscreva-se no canal do TSP no YouTube</a>.</p>
		</header>
		<?php tsp_bloco_exclusiva(); ?>
		<?php tsp_exclusiva_catalogo(); ?>
		<?php while (have_posts()) { the_post(); if (trim(get_the_content())) { echo '<div class="tsp-corpo">'; the_content(); echo '</div>'; } } ?>
	</div>
</main>
<?php
get_footer();
