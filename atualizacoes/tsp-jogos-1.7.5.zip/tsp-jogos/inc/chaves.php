<?php
/**
 * Chaveamento (mata-mata) das copas e painel do futebol feminino, vindos da base de jogos do TSP.
 * tsp_jogos_chave_html('copa_do_brasil') · tsp_jogos_painel_fem_html()
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_chaves()
{
    $c = get_option('tsp_jogos_chaves', array());
    return is_array($c) ? $c : array();
}

function tsp_jogos_chave_css()
{
    static $feito = false;
    if ($feito) {
        return '';
    }
    $feito = true;
    return '<style>
.tsp-chv{background:#fff;border:1px solid #e7e1d8;border-radius:12px;padding:6px 16px 16px}
.tsp-chv__nav{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #e7e1d8;margin-bottom:14px}
.tsp-chv__nav button{background:none;border:0;font-size:30px;line-height:1;color:#E8862A;cursor:pointer;padding:8px 10px}
.tsp-chv__nav button[disabled]{color:#ccc;cursor:default}
.tsp-chv__nav strong{font-size:20px;letter-spacing:.04em;text-transform:uppercase}
.tsp-chv__fase[hidden]{display:none}
.tsp-chv__conf{display:grid;grid-template-columns:1fr 1fr;border:1px solid #e7e1d8;border-radius:8px;margin:0 0 14px;position:relative}
.tsp-chv__conf--unico{grid-template-columns:1fr}
.tsp-chv__pill{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);background:#fff;border:1px solid #e7e1d8;border-radius:999px;padding:2px 12px;font-size:12px;color:#888;white-space:nowrap}
.tsp-chv__conf--unico .tsp-chv__pill{top:0}
.tsp-chv__jogo{padding:14px 10px 12px;text-align:center}
.tsp-chv__jogo+.tsp-chv__jogo{border-left:1px solid #e7e1d8}
.tsp-chv__info{font-size:13px;color:#555;margin-bottom:8px}
.tsp-chv__info b{color:#222}
.tsp-chv__placar{display:grid;grid-template-columns:1fr auto auto auto auto auto 1fr;align-items:center;gap:8px;font-size:17px}
.tsp-chv__placar .c{text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tsp-chv__placar .f{text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tsp-chv__placar img,.tsp-chv__esc{width:30px;height:30px;object-fit:contain}
.tsp-chv__esc{display:inline-grid;place-items:center;border-radius:50%;background:#eee;font-size:10px;font-weight:800;font-style:normal;color:#666}
.tsp-chv__placar b{font-size:24px;min-width:16px}
.tsp-chv__placar i.x{font-style:normal;color:#aaa}
.tsp-chv__placar .venc{font-weight:800}
.tsp-chv__link{display:inline-block;margin-top:8px;font-size:13px;font-weight:800;color:#b45f06!important;text-decoration:none;text-transform:uppercase}
.tsp-chv__agr{grid-column:1/-1;border-top:1px dashed #e7e1d8;font-size:12.5px;color:#555;padding:6px 10px;text-align:center}
.tsp-chv__agr strong{color:#1a7f37}
.tsp-chv__conf.is-hoje{border-color:#E8862A;box-shadow:0 3px 12px rgba(232,134,42,.15)}
@media (max-width:760px){.tsp-chv__conf{grid-template-columns:1fr}.tsp-chv__jogo+.tsp-chv__jogo{border-left:0;border-top:1px solid #e7e1d8}.tsp-chv__pill{top:0}.tsp-chv__placar{font-size:15px;gap:5px}.tsp-chv__placar img,.tsp-chv__esc{width:24px;height:24px}}
.tsp-painel-fem{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
.tsp-painel-fem table{width:100%;border-collapse:collapse;font-size:14px}
.tsp-painel-fem td,.tsp-painel-fem th{padding:6px 4px;border-top:1px solid #f0ebe3;text-align:left}
.tsp-painel-fem td:last-child,.tsp-painel-fem th:last-child{text-align:right;font-weight:800}
.tsp-chave__conf{background:#fff;border:1px solid #e7e1d8;border-radius:12px;padding:12px 14px;margin-top:10px}
.tsp-chave__time{display:flex;align-items:center;gap:8px;padding:4px 0;font-weight:600}
.tsp-chave__info{font-size:12.5px;color:#555;margin-top:6px}
.tsp-chave-tit{margin:0 0 14px!important}
.tsp-chf--lista .tsp-chf__grade{display:block!important}
.tsp-chf--lista .tsp-chf__col{height:auto;margin-bottom:12px;gap:6px}
.tsp-chf--lista .tsp-chf__fase{text-align:left}
.tsp-chf--lista .tsp-chf__jogos{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}
.tsp-chf__conf--placar{background:#fff!important;padding:8px 12px!important;border-radius:10px!important}
.tsp-chf__cab{display:grid;grid-template-columns:1fr 24px 24px 44px;gap:4px;font-size:10px;font-weight:800;color:#999;text-transform:uppercase;letter-spacing:.04em;text-align:center}
.tsp-chf__conf--placar .tsp-chf__time{display:grid!important;grid-template-columns:24px minmax(0,1fr) 24px 24px 44px;gap:4px 6px;align-items:center;padding:5px 0;font-size:15px}
.tsp-chf__nome{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tsp-chf__g{text-align:center;font-weight:700;color:#555;font-variant-numeric:tabular-nums}
.tsp-chf__g--agr{font-size:17px;font-weight:800;color:#111}
.tsp-chf__g small{font-size:11px;color:#777}
.tsp-chf__time--fora{color:#9a9a9a}
.tsp-chf__time--fora .tsp-chf__g--agr{color:#9a9a9a}
.tsp-chf__time--venc .tsp-chf__nome{font-weight:800}
.tsp-chf__conf--placar .tsp-chf__cab span:first-child{grid-column:1}
</style>';
}

function tsp_jogos_chave_escudo($id, $nome)
{
    $u = ($id > 0 && function_exists('tsp_sim_escudo')) ? tsp_sim_escudo($id) : '';
    if ($u) {
        return '<img src="' . esc_url($u) . '" alt="" loading="lazy" width="30" height="30">';
    }
    return '<i class="tsp-chv__esc" aria-hidden="true">' . esc_html($id > 0 ? mb_strtoupper(mb_substr($nome, 0, 2)) : '?') . '</i>';
}

// Uma partida no estilo "estádio · data · dia · hora / mandante escudo placar × placar escudo visitante / link"
function tsp_jogos_chave_jogo($j, $nomes, $tz, $info = array())
{
    $hoje = new DateTimeImmutable('today', $tz);
    $sem = array('Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado');
    $dt = !empty($j['data']) ? date_create_immutable((string) $j['data'], $tz) : (!empty($info['data']) ? date_create_immutable($info['data'], $tz) : null);
    $dia = '';
    if ($dt) {
        $d0 = $dt->setTime(0, 0);
        $dif = (int) round(($d0->getTimestamp() - $hoje->getTimestamp()) / DAY_IN_SECONDS);
        $dia = $dif === 0 ? 'Hoje' : ($dif === -1 ? 'Ontem' : ($dif === 1 ? 'Amanhã' : $sem[(int) $dt->format('w')]));
    }
    $hora = (!empty($j['data']) && $dt) ? $dt->format('H:i') : '';
    $est = $j['estadio'] ?? ($info['estadio'] ?? '');
    $h = '<div class="tsp-chv__jogo"><div class="tsp-chv__info">' . esc_html($est) . ($dt ? ' &nbsp; <b>' . esc_html($dt->format('d/m') . ' • ' . $dia . ($hora ? ' • ' . $hora : '')) . '</b>' : '') . '</div>';
    $c = (int) ($j['casa'] ?? 0);
    $f = (int) ($j['fora'] ?? 0);
    $nc = $nomes[$c] ?? ($j['nome_casa'] ?? 'A definir');
    $nf = $nomes[$f] ?? ($j['nome_fora'] ?? 'A definir');
    $fim = ($j['status'] ?? '') === 'encerrado';
    $gc = $fim ? (int) $j['gc'] : '';
    $gf = $fim ? (int) $j['gf'] : '';
    $vc = $fim && ($gc > $gf) ? ' venc' : '';
    $vf = $fim && ($gf > $gc) ? ' venc' : '';
    $h .= '<div class="tsp-chv__placar"><span class="c' . $vc . '">' . esc_html($nc) . '</span>' . tsp_jogos_chave_escudo($c, $nc) . '<b>' . esc_html((string) $gc) . '</b><i class="x">×</i><b>' . esc_html((string) $gf) . '</b>' . tsp_jogos_chave_escudo($f, $nf) . '<span class="f' . $vf . '">' . esc_html($nf) . '</span></div>';
    if ($fim && !empty($j['pen'])) {
        $h .= '<div class="tsp-chv__info" style="margin:6px 0 0">Pênaltis: ' . esc_html($j['pen']) . '</div>';
    }
    $link = (!empty($j['id']) && (int) $j['id'] > 0 && function_exists('tsp_jogos_link_jogo')) ? tsp_jogos_link_jogo((int) $j['id']) : '';
    if ($link) {
        $h .= '<a class="tsp-chv__link" href="' . esc_url($link) . '">' . ($fim ? 'Saiba como foi' : 'Fique por dentro') . '</a>';
    }
    return $h . '</div>';
}

// Mata-mata em andamento com pelo menos um clube paulista ainda vivo (10/11/2026)
function tsp_jogos_chave_tem_paulista_vivo($liga)
{
    $ch = tsp_jogos_chaves();
    if (empty($ch[$liga]['fases'])) {
        return false;
    }
    $aberta = false;
    foreach ((array) $ch[$liga]['fases'] as $f) {
        foreach ((array) $f['confrontos'] as $c) {
            if (!empty($c['vencedor'])) {
                continue;
            }
            $aberta = true;
            foreach ((array) ($c['times'] ?? array()) as $tid) {
                if ($tid && tsp_jogos_slug_do_time((int) $tid)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function tsp_jogos_chave_html($liga, $titulo = '')
{
    $ch = tsp_jogos_chaves();
    if (empty($ch[$liga]['fases'])) {
        return '';
    }
    $tz = new DateTimeZone('America/Sao_Paulo');
    $fases = array_values($ch[$liga]['fases']);
    // Abre na fase em andamento (primeira com confronto sem vencedor e com jogos), senão na última
    $atual = count($fases) - 1;
    foreach ($fases as $i => $f) {
        foreach ((array) $f['confrontos'] as $c) {
            if (empty($c['vencedor']) && !empty($c['jogos'])) {
                $atual = $i;
                break 2;
            }
        }
    }
    $uid = 'tspchv' . wp_rand(1000, 99999);
    $h = tsp_jogos_chave_css() . '<div class="tsp-chv" id="' . esc_attr($uid) . '"><div class="tsp-chv__nav"><button type="button" data-ir="-1" aria-label="Fase anterior">‹</button><strong></strong><button type="button" data-ir="1" aria-label="Próxima fase">›</button></div>';
    $hoje = wp_date('Y-m-d', null, $tz);
    foreach ($fases as $i => $f) {
        $h .= '<div class="tsp-chv__fase" data-nome="' . esc_attr($f['nome']) . '"' . ($i === $atual ? '' : ' hidden') . '>';
        $confs = array_values((array) $f['confrontos']);
        foreach ($confs as $k => $c) {
            $nomes = array();
            foreach (array(0, 1) as $x) {
                $id = (int) ($c['times'][$x] ?? 0);
                $nm = (string) ($c['nomes'][$x] ?? '');
                if ($id && function_exists('tsp_jogos_nome_time')) {
                    $nm = tsp_jogos_nome_time($id, $nm);
                }
                if (!$id) {
                    // Vaga ainda aberta: "Venc. Semifinal 1" (a posição corresponde ao confronto da fase anterior)
                    $ant = $fases[$i - 1] ?? null;
                    $nm = $ant ? 'Venc. ' . $ant['nome'] . (count((array) $ant['confrontos']) > 1 ? ' ' . ($x + 1) : '') : 'A definir';
                }
                $nomes[$id ?: -1 - $x] = $nm;
            }
            $jogos = (array) ($c['jogos'] ?? array());
            $e_hoje = (bool) array_filter($jogos, function ($j) use ($hoje) {
                return substr((string) $j['data'], 0, 10) === $hoje;
            });
            $unico = count($jogos) <= 1;
            $pill = mb_strtolower($f['nome']) . (count($confs) > 1 ? ' ' . ($k + 1) : '');
            $h .= '<div class="tsp-chv__conf' . ($unico ? ' tsp-chv__conf--unico' : '') . ($e_hoje ? ' is-hoje' : '') . '"><span class="tsp-chv__pill">' . esc_html($pill) . '</span>';
            if ($jogos) {
                foreach ($jogos as $j) {
                    $h .= tsp_jogos_chave_jogo($j, $nomes, $tz);
                }
            } else {
                $ids = array_keys($nomes);
                $h .= tsp_jogos_chave_jogo(array('casa' => $ids[0], 'fora' => $ids[1], 'status' => 'agendado'), $nomes, $tz, (array) ($f['info'] ?? array()));
            }
            if (!$unico && !empty($c['vencedor']) && $c['agregado'] !== null) {
                $vn = $nomes[(int) $c['vencedor']] ?? '';
                $v1 = (int) $c['vencedor'] === (int) ($c['times'][1] ?? 0); // placar com o classificado primeiro
                $ag = $v1 ? array($c['agregado'][1], $c['agregado'][0]) : $c['agregado'];
                $pn = !empty($c['penaltis']) ? ($v1 ? array($c['penaltis'][1], $c['penaltis'][0]) : $c['penaltis']) : null;
                $h .= '<div class="tsp-chv__agr"><strong>' . esc_html($vn) . ' classificado</strong> · agregado ' . (int) $ag[0] . ' x ' . (int) $ag[1] . ($pn ? ' (pênaltis ' . (int) $pn[0] . ' x ' . (int) $pn[1] . ')' : '') . '</div>';
            } elseif (!$unico && $c['agregado'] !== null && empty($c['vencedor'])) {
                $h .= '<div class="tsp-chv__agr">Agregado: ' . esc_html(reset($nomes)) . ' ' . (int) $c['agregado'][0] . ' x ' . (int) $c['agregado'][1] . ' ' . esc_html(end($nomes)) . '</div>';
            }
            if (!$jogos && !empty($f['info']['obs'])) {
                $h .= '<div class="tsp-chv__agr">' . esc_html($f['info']['obs']) . '</div>';
            }
            $h .= '</div>';
        }
        $h .= '</div>';
    }
    $h .= '</div>';
    $h .= "<script>(function(){var r=document.getElementById(" . wp_json_encode($uid) . ");if(!r)return;var fs=[].slice.call(r.querySelectorAll('.tsp-chv__fase')),t=r.querySelector('.tsp-chv__nav strong'),b=r.querySelectorAll('.tsp-chv__nav button'),i=fs.findIndex(function(f){return !f.hidden});function v(){fs.forEach(function(f,k){f.hidden=k!==i});t.textContent=fs[i].dataset.nome;b[0].disabled=i<=0;b[1].disabled=i>=fs.length-1}r.querySelector('.tsp-chv__nav').addEventListener('click',function(e){var x=e.target.closest('[data-ir]');if(!x||x.disabled)return;i=Math.max(0,Math.min(fs.length-1,i+(+x.dataset.ir)));v()});v()})();</script>";
    return $h;
}

function tsp_jogos_painel_fem_conf($x, $esc)
{
    // Placar: ida e volta {"j1": [c, f], "j2": [c, f], "penaltis": [c, f]} ou jogo único {"j": [c, f], "penaltis": [c, f]} (ordem casa/fora)
    $pl = is_array($x['placar'] ?? null) ? $x['placar'] : array();
    $unico = isset($pl['j'][0], $pl['j'][1]) && $pl['j'][0] !== null;
    $j1 = $unico ? array((int) $pl['j'][0], (int) $pl['j'][1]) : (isset($pl['j1'][0], $pl['j1'][1]) && $pl['j1'][0] !== null ? array((int) $pl['j1'][0], (int) $pl['j1'][1]) : null);
    $j2 = !$unico && isset($pl['j2'][0], $pl['j2'][1]) && $pl['j2'][0] !== null ? array((int) $pl['j2'][0], (int) $pl['j2'][1]) : null;
    $pen = isset($pl['penaltis'][0], $pl['penaltis'][1]) ? array((int) $pl['penaltis'][0], (int) $pl['penaltis'][1]) : null;
    $tem = $j1 || $j2;
    $agr = $tem ? array(($j1[0] ?? 0) + ($j2[0] ?? 0), ($j1[1] ?? 0) + ($j2[1] ?? 0)) : null;
    $fim = $unico ? (bool) $j1 : ($j1 && $j2);
    $venc = -1;
    if ($fim) {
        $venc = $agr[0] > $agr[1] ? 0 : ($agr[1] > $agr[0] ? 1 : ($pen ? ($pen[0] > $pen[1] ? 0 : 1) : -1));
    }
    $h = '<div class="tsp-chf__conf' . ($tem ? ' tsp-chf__conf--placar' : '') . ($unico ? ' tsp-chf__conf--unico' : '') . '">';
    if ($tem) {
        $h .= $unico ? '<div class="tsp-chf__cab tsp-chf__cab--unico"><span></span><span>Placar</span></div>' : '<div class="tsp-chf__cab"><span></span><span>J1</span><span>J2</span><span>Agr.</span></div>';
    }
    foreach (array($x['casa'] ?? '', $x['fora'] ?? '') as $k => $nome) {
        $nome = trim($nome) !== '' ? $nome : 'A definir';
        $def = (bool) preg_match('~defin|vencedor~iu', $nome);
        $cls = 'tsp-chf__time' . ($def ? ' tsp-chf__time--def' : '') . ($venc === 1 - $k ? ' tsp-chf__time--fora' : '') . ($venc === $k ? ' tsp-chf__time--venc' : '');
        $h .= '<div class="' . $cls . '">' . ($def ? '<span class="tsp-ge__esc tsp-ge__esc--vazio"></span>' : $esc($nome)) . '<span class="tsp-chf__nome">' . esc_html($nome) . '</span>';
        if ($tem && $unico) {
            $h .= '<b class="tsp-chf__g tsp-chf__g--agr">' . $j1[$k] . ($pen ? ' <small>(' . $pen[$k] . ')</small>' : '') . '</b>';
        } elseif ($tem) {
            $h .= '<b class="tsp-chf__g">' . ($j1 ? $j1[$k] : '–') . '</b><b class="tsp-chf__g">' . ($j2 ? $j2[$k] : '–') . '</b><b class="tsp-chf__g tsp-chf__g--agr">' . $agr[$k] . ($pen && $fim ? ' <small>(' . $pen[$k] . ')</small>' : '') . '</b>';
        }
        $h .= '</div>';
    }
    $h .= '<div class="tsp-chf__quando">' . esc_html($x['quando'] ?? '') . (!empty($x['obs']) ? ' · ' . esc_html($x['obs']) : '') . '</div></div>';
    return array($h, $fim);
}

// 27/11/2026 (1.9.4, Thiago: "traga os possíveis campeonatos femininos e mostre a tabela de forma harmônica e responsiva"):
// um campeonato por aba (a 1ª da lista abre; abas só com CSS), classificação e mata-mata lado a lado sem sobrar espaço:
// fases já decididas ficam recolhidas embaixo da tabela; sem tabela, o mata-mata ocupa a largura toda (uma coluna por fase);
// fase de grupos ("grupos": [{"nome", "sede", "clubes": [...]}]) em cartões.
function tsp_jogos_painel_fem_html()
{
    $p = get_option('tsp_jogos_painel_fem', array());
    if (!is_array($p) || !$p) {
        return '';
    }
    $comps = array();
    foreach ($p as $c) {
        if (is_array($c) && !preg_match('~encerrad|campe[aã]~iu', (string) ($c['fase'] ?? ''))) {
            $comps[] = $c; // só competições em andamento
        }
    }
    if (!$comps) {
        return '';
    }
    $esc = function ($nome) {
        return function_exists('tsp_ge_escudo') ? tsp_ge_escudo(0, $nome, 24) : '';
    };
    $n = count($comps);
    $h = tsp_jogos_chave_css() . '<style>'
        . '.tsp-pf{position:relative}.tsp-pf>input{position:absolute;opacity:0;pointer-events:none}'
        . '.tsp-pf__abas{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;margin:0 0 14px;padding-bottom:2px}.tsp-pf__abas::-webkit-scrollbar{display:none}'
        . '.tsp-pf__abas label{flex:0 0 auto;cursor:pointer;padding:8px 14px;border-radius:999px;border:1px solid #e2dccf;background:#fff;font-weight:700;font-size:14px;color:#444;white-space:nowrap}'
        . '.tsp-pf__abas label small{font-weight:600;color:#999;margin-left:4px}'
        . '.tsp-pf__painel{display:none}'
        . '.tsp-pf__cab{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 10px;margin:0 0 12px}.tsp-pf__cab h3{margin:0!important;font-size:20px}.tsp-pf__cab span{color:#777;font-weight:600;font-size:14px}'
        . '.tsp-pf__grade{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:16px;align-items:start}'
        . '.tsp-pf__grade>*{min-width:0}.tsp-pf__grade .tsp-caixa{margin:0}'
        . '.tsp-pf__antes{margin-top:12px;border:1px solid #e7e1d8;border-radius:12px;background:#fff;padding:0 14px}'
        . '.tsp-pf__antes summary{cursor:pointer;padding:11px 0;font-weight:700;font-size:14px;color:#444;list-style:none}.tsp-pf__antes summary::-webkit-details-marker{display:none}.tsp-pf__antes summary:after{content:" +";color:#999}.tsp-pf__antes[open] summary:after{content:" −"}'
        . '.tsp-pf__antes .tsp-chf__jogos{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px;padding-bottom:12px}'
        . '.tsp-pf__chave{display:grid;grid-template-columns:repeat(var(--fases,3),minmax(0,1fr));gap:14px;align-items:center}'
        . '.tsp-pf__chave .tsp-chf__col{display:flex;flex-direction:column;gap:10px}'
        . '.tsp-pf__fases .tsp-chf__col{margin-bottom:12px}.tsp-pf__fases .tsp-chf__jogos{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}'
        . '.tsp-chf__fase{display:block;font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#777;margin-bottom:6px}'
        . '.tsp-pf__grupos{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}'
        . '.tsp-pf__grupo{background:#fff;border:1px solid #e7e1d8;border-radius:12px;padding:10px 12px}.tsp-pf__grupo strong{display:block;font-size:14px}.tsp-pf__grupo small{display:block;color:#888;font-size:12px;margin-bottom:6px}'
        . '.tsp-pf__grupo li{display:flex;align-items:center;gap:6px;padding:3px 0;font-size:14px;list-style:none}.tsp-pf__grupo ul{margin:0;padding:0}'
        . '.tsp-pf__nota{font-size:12.5px;color:#666;margin-top:10px}'
        . '.tsp-pf__gj{margin-top:8px;border-top:1px dashed #e7e1d8;padding-top:6px;display:flex;flex-direction:column;gap:4px}.tsp-pf__gjl{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);grid-template-areas:"q q q" "c p f";gap:0 6px;font-size:12.5px;align-items:center}.tsp-pf__gjq{grid-area:q;color:#999;font-size:11px}.tsp-pf__gjc{grid-area:c;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.tsp-pf__gjl b{grid-area:p;font-variant-numeric:tabular-nums}.tsp-pf__gjf{grid-area:f;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
        . '.tsp-chf__cab--unico{grid-template-columns:1fr 54px}.tsp-chf__conf--unico.tsp-chf__conf--placar .tsp-chf__time{grid-template-columns:24px minmax(0,1fr) 54px}'
        . '@media (max-width:900px){.tsp-pf__grade{grid-template-columns:1fr}.tsp-pf__chave{grid-template-columns:1fr}}';
    for ($i = 0; $i < $n; $i++) {
        $h .= '#tsp-pf-' . $i . ':checked~.tsp-pf__paineis>.tsp-pf__painel:nth-child(' . ($i + 1) . '){display:block}'
            . '#tsp-pf-' . $i . ':checked~.tsp-pf__abas label[for=tsp-pf-' . $i . ']{background:#111;border-color:#111;color:#fff}'
            . '#tsp-pf-' . $i . ':checked~.tsp-pf__abas label[for=tsp-pf-' . $i . '] small{color:#bbb}'
            . '#tsp-pf-' . $i . ':focus-visible~.tsp-pf__abas label[for=tsp-pf-' . $i . ']{outline:2px solid #E8862A}';
    }
    $h .= '</style><div class="tsp-pf">';
    foreach ($comps as $i => $c) {
        $h .= '<input type="radio" name="tsp-pf" id="tsp-pf-' . $i . '"' . ($i === 0 ? ' checked' : '') . '>';
    }
    if ($n > 1) {
        $h .= '<div class="tsp-pf__abas" role="tablist">';
        foreach ($comps as $i => $c) {
            $h .= '<label for="tsp-pf-' . $i . '">' . esc_html($c['aba'] ?? ($c['nome'] ?? '')) . (!empty($c['selo']) ? '<small>' . esc_html($c['selo']) . '</small>' : '') . '</label>';
        }
        $h .= '</div>';
    }
    $h .= '<div class="tsp-pf__paineis">';
    foreach ($comps as $c) {
        $h .= '<div class="tsp-pf__painel"><div class="tsp-pf__cab"><h3>' . esc_html($c['nome'] ?? '') . '</h3>' . (!empty($c['fase']) ? '<span>' . esc_html($c['fase']) . '</span>' : '') . '</div>';
        // classificação
        $tab = '';
        if (!empty($c['classificacao'][0]) && count($c['classificacao'][0]) >= 8 && function_exists('tsp_tabela_html')) {
            $tab = '<div class="tsp-caixa">' . (function_exists('tsp_tabela_ge_tabela') ? tsp_tabela_ge_tabela('fem_paulista', '') : tsp_tabela_html('fem_paulista', 8, '', 0, false) . (function_exists('tsp_legenda') ? tsp_legenda('fem_paulista') : '')) . '</div>';
        } elseif (!empty($c['classificacao'])) {
            $tab = '<div class="tsp-chave__conf"><strong>' . esc_html($c['classificacao_titulo'] ?? 'Classificação') . '</strong><table><thead><tr><th>#</th><th>Time</th><th>P</th></tr></thead><tbody>';
            foreach ($c['classificacao'] as $r) {
                $tab .= '<tr><td>' . esc_html($r[0]) . '</td><td>' . esc_html($r[1]) . '</td><td>' . esc_html($r[2]) . '</td></tr>';
            }
            $tab .= '</tbody></table>' . (!empty($c['nota_classificacao']) ? '<div class="tsp-chave__info">' . esc_html($c['nota_classificacao']) . '</div>' : '') . '</div>';
        }
        // mata-mata: fases decididas x fases em aberto
        $antes = $agora = array();
        $fases = array();
        foreach ((array) ($c['confrontos'] ?? array()) as $x) {
            $fases[$x['fase'] ?? ''][] = $x;
        }
        foreach ($fases as $fase => $lista) {
            $htmls = array();
            $todas_fim = true;
            foreach ($lista as $x) {
                list($hh, $fim) = tsp_jogos_painel_fem_conf($x, $esc);
                $htmls[] = $hh;
                $todas_fim = $todas_fim && $fim;
            }
            $col = '<div class="tsp-chf__col"><span class="tsp-chf__fase">' . esc_html($fase) . '</span><div class="tsp-chf__jogos">' . implode('', $htmls) . '</div></div>';
            if ($todas_fim && $tab) {
                $antes[$fase] = $col;
            } else {
                $agora[$fase] = $col;
            }
        }
        $grupos = '';
        if (!empty($c['grupos'])) {
            $grupos = '<div class="tsp-pf__grupos">';
            foreach ((array) $c['grupos'] as $g) {
                $grupos .= '<div class="tsp-pf__grupo"><strong>' . esc_html($g['nome'] ?? '') . '</strong>' . (!empty($g['sede']) ? '<small>' . esc_html($g['sede']) . '</small>' : '') . '<ul>';
                foreach ((array) ($g['clubes'] ?? array()) as $cl) {
                    $grupos .= '<li>' . $esc($cl) . '<span>' . esc_html($cl) . '</span></li>';
                }
                $grupos .= '</ul>';
                // 28/11/2026: jogos do grupo [{"quando","casa","fora","placar":[c,f]}] (placar só com 2 fontes)
                if (!empty($g['jogos'])) {
                    $grupos .= '<div class="tsp-pf__gj">';
                    foreach ((array) $g['jogos'] as $j) {
                        $pl = isset($j['placar'][0], $j['placar'][1]) ? array((int) $j['placar'][0], (int) $j['placar'][1]) : null;
                        $grupos .= '<div class="tsp-pf__gjl"><span class="tsp-pf__gjq">' . esc_html($j['quando'] ?? '') . '</span><span class="tsp-pf__gjc">' . esc_html($j['casa'] ?? '') . '</span><b>' . ($pl ? $pl[0] . ' x ' . $pl[1] : 'x') . '</b><span class="tsp-pf__gjf">' . esc_html($j['fora'] ?? '') . '</span></div>';
                    }
                    $grupos .= '</div>';
                }
                $grupos .= '</div>';
            }
            $grupos .= '</div>';
        }
        if ($tab) {
            $esq = $tab . ($antes ? '<details class="tsp-pf__antes"><summary>Fases anteriores · ' . esc_html(implode(', ', array_keys($antes))) . '</summary><div class="tsp-chf tsp-chf--lista">' . implode('', $antes) . '</div></details>' : '');
            $dir = $agora ? '<div class="tsp-chf tsp-chf--lista tsp-pf__fases"><strong class="tsp-chf__tit">Mata-mata</strong>' . implode('', $agora) . '</div>' : '';
            $h .= $dir ? '<div class="tsp-pf__grade"><div>' . $esq . '</div>' . $dir . '</div>' : $esq;
        } elseif ($agora) {
            $h .= '<div class="tsp-chf tsp-pf__chave" style="--fases:' . count($agora) . '">' . implode('', $agora) . '</div>';
        }
        $h .= $grupos;
        if (!empty($c['nota'])) {
            $h .= '<p class="tsp-pf__nota">' . esc_html($c['nota']) . '</p>';
        }
        $h .= '</div>';
    }
    $h .= '</div></div>';
    return $h;
}


// Classificação do Paulistão Feminino no mesmo formato das tabelas da Série A e B (tema: tsp_tabela_html)
add_filter('tsp_dado', function ($v, $chave) {
    if ($chave !== 'tabelas') {
        return $v;
    }
    foreach ((array) get_option('tsp_jogos_painel_fem', array()) as $c) {
        if (!empty($c['classificacao'][0]) && count($c['classificacao'][0]) >= 8) {
            $v = is_array($v) ? $v : array();
            $v['fem_paulista'] = array('titulo' => $c['classificacao_titulo'] ?? 'Classificação', 'linhas' => $c['classificacao'], 'nota' => $c['nota_classificacao'] ?? '');
            break;
        }
    }
    return $v;
}, 30, 2);
