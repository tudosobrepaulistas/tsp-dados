<?php
/**
 * Futebol internacional (27-28/11/2026, pedido do Thiago): menu "Internacional" por continente.
 * Cada continente mostra as 7 principais ligas e a 8ª opção "Outras ligas" (página com as demais).
 * As outras ligas entram aos poucos: quando um jogador que passou pelo futebol paulista passa a atuar nela,
 * marque "ativa" => true na lista abaixo (o termo e a página nascem sozinhos).
 * As matérias NÃO aparecem na home: só no menu e nas páginas /campeonato/<liga>/.
 * Ao salvar uma matéria com uma liga, ela ganha também o termo do continente e "futebol-internacional".
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_INT_GERAL = 'futebol-internacional';

// continente => [nome, slug, bandeira/ícone, descrição, principais [slug => [menu, página, bandeira, descrição]], outras [slug => [menu, página, bandeira, ativa]]]
function tsp_int_continentes()
{
    return array(
        'europa' => array(
            'nome' => 'Europa', 'slug' => 'futebol-europeu', 'icone' => '🇪🇺',
            'desc' => 'Notícias do futebol europeu: Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Liga Portugal, Eredivisie e os paulistas na Europa.',
            'principais' => array(
                'campeonato-ingles'    => array('Inglês', 'Campeonato Inglês (Premier League)', '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Notícias da Premier League: Manchester City, Arsenal, Liverpool, Chelsea, United e os brasileiros na Inglaterra.'),
                'campeonato-espanhol'  => array('Espanhol', 'Campeonato Espanhol (LaLiga)', '🇪🇸', 'Notícias de LaLiga: Real Madrid, Barcelona, Atlético de Madrid e os brasileiros na Espanha.'),
                'campeonato-italiano'  => array('Italiano', 'Campeonato Italiano (Serie A)', '🇮🇹', 'Notícias do Campeonato Italiano: Inter, Milan, Juventus, Napoli, Roma e os brasileiros na Serie A.'),
                'campeonato-alemao'    => array('Alemão', 'Campeonato Alemão (Bundesliga)', '🇩🇪', 'Notícias da Bundesliga: Bayern de Munique, Borussia Dortmund, Bayer Leverkusen e os brasileiros na Alemanha.'),
                'campeonato-frances'   => array('Francês', 'Campeonato Francês (Ligue 1)', '🇫🇷', 'Notícias da Ligue 1: PSG, Olympique de Marselha, Lyon, Monaco e os brasileiros na França.'),
                'campeonato-portugues' => array('Português', 'Campeonato Português (Liga Portugal)', '🇵🇹', 'Notícias da Liga Portugal: Benfica, Porto, Sporting, Braga e os brasileiros em Portugal.'),
                'campeonato-holandes'  => array('Holandês', 'Campeonato Holandês (Eredivisie)', '🇳🇱', 'Notícias da Eredivisie: Ajax, PSV, Feyenoord e os brasileiros na Holanda.'),
            ),
            'outras' => array(
                'campeonato-turco' => array('Turco', 'Campeonato Turco', '🇹🇷', false),
                'campeonato-belga' => array('Belga', 'Campeonato Belga', '🇧🇪', false),
                'campeonato-escoces' => array('Escocês', 'Campeonato Escocês', '🏴󠁧󠁢󠁳󠁣󠁴󠁿', false),
                'campeonato-grego' => array('Grego', 'Campeonato Grego', '🇬🇷', false),
                'campeonato-russo' => array('Russo', 'Campeonato Russo', '🇷🇺', false),
                'campeonato-ucraniano' => array('Ucraniano', 'Campeonato Ucraniano', '🇺🇦', false),
                'campeonato-suico' => array('Suíço', 'Campeonato Suíço', '🇨🇭', false),
                'campeonato-austriaco' => array('Austríaco', 'Campeonato Austríaco', '🇦🇹', false),
                'campeonato-bulgaro' => array('Búlgaro', 'Campeonato Búlgaro', '🇧🇬', false),
                'campeonato-romeno' => array('Romeno', 'Campeonato Romeno', '🇷🇴', false),
                'campeonato-polones' => array('Polonês', 'Campeonato Polonês', '🇵🇱', false),
                'campeonato-croata' => array('Croata', 'Campeonato Croata', '🇭🇷', false),
                'campeonato-servio' => array('Sérvio', 'Campeonato Sérvio', '🇷🇸', false),
                'campeonato-dinamarques' => array('Dinamarquês', 'Campeonato Dinamarquês', '🇩🇰', false),
                'campeonato-sueco' => array('Sueco', 'Campeonato Sueco', '🇸🇪', false),
                'campeonato-noruegues' => array('Norueguês', 'Campeonato Norueguês', '🇳🇴', false),
                'campeonato-tcheco' => array('Tcheco', 'Campeonato Tcheco', '🇨🇿', false),
                'campeonato-cipriota' => array('Cipriota', 'Campeonato Cipriota', '🇨🇾', false),
            ),
        ),
        'america-do-sul' => array(
            'nome' => 'América do Sul', 'slug' => 'futebol-sul-americano', 'icone' => '🌎',
            'desc' => 'Notícias dos campeonatos da América do Sul: Argentina, Uruguai, Chile, Colômbia, Paraguai, Equador, Peru, Bolívia e Venezuela.',
            'principais' => array(
                'campeonato-argentino'   => array('Argentino', 'Campeonato Argentino', '🇦🇷', 'Notícias do Campeonato Argentino: Boca Juniors, River Plate, Racing, Independiente, Estudiantes e San Lorenzo.'),
                'campeonato-uruguaio'    => array('Uruguaio', 'Campeonato Uruguaio', '🇺🇾', 'Notícias do Campeonato Uruguaio: Peñarol, Nacional e os outros clubes do Uruguai.'),
                'campeonato-chileno'     => array('Chileno', 'Campeonato Chileno', '🇨🇱', 'Notícias do Campeonato Chileno: Colo-Colo, Universidad de Chile, Universidad Católica e mais.'),
                'campeonato-colombiano'  => array('Colombiano', 'Campeonato Colombiano', '🇨🇴', 'Notícias do Campeonato Colombiano: Atlético Nacional, Millonarios, América de Cali, Junior e mais.'),
                'campeonato-paraguaio'   => array('Paraguaio', 'Campeonato Paraguaio', '🇵🇾', 'Notícias do Campeonato Paraguaio: Olimpia, Cerro Porteño, Libertad e mais.'),
                'campeonato-equatoriano' => array('Equatoriano', 'Campeonato Equatoriano', '🇪🇨', 'Notícias do Campeonato Equatoriano: LDU, Barcelona de Guayaquil, Independiente del Valle, Emelec e mais.'),
                'campeonato-peruano'     => array('Peruano', 'Campeonato Peruano', '🇵🇪', 'Notícias do Campeonato Peruano: Alianza Lima, Universitario, Sporting Cristal e mais.'),
            ),
            'outras' => array(
                'campeonato-boliviano'   => array('Boliviano', 'Campeonato Boliviano', '🇧🇴', true),
                'campeonato-venezuelano' => array('Venezuelano', 'Campeonato Venezuelano', '🇻🇪', true),
            ),
        ),
        'america-do-norte' => array(
            'nome' => 'América do Norte e Central', 'slug' => 'futebol-norte-centro-americano', 'icone' => '🌎',
            'desc' => 'Notícias do futebol da América do Norte e Central: Liga MX, MLS e os campeonatos da América Central e do Caribe.',
            'principais' => array(
                'campeonato-mexicano'      => array('Mexicano', 'Campeonato Mexicano (Liga MX)', '🇲🇽', 'Notícias da Liga MX: América, Chivas, Cruz Azul, Tigres, Monterrey e os brasileiros no México.'),
                'mls'                      => array('MLS (EUA)', 'MLS, a liga dos Estados Unidos', '🇺🇸', 'Notícias da MLS: Inter Miami, LA Galaxy, LAFC e os brasileiros nos Estados Unidos.'),
                'campeonato-costarriquenho' => array('Costarriquenho', 'Campeonato Costarriquenho', '🇨🇷', 'Notícias do futebol da Costa Rica: Saprissa, Alajuelense, Herediano e mais.'),
                'campeonato-hondurenho'    => array('Hondurenho', 'Campeonato Hondurenho', '🇭🇳', 'Notícias do futebol de Honduras: Olimpia, Motagua, Real España e mais.'),
                'campeonato-guatemalteco'  => array('Guatemalteco', 'Campeonato Guatemalteco', '🇬🇹', 'Notícias do futebol da Guatemala: Comunicaciones, Municipal e mais.'),
                'campeonato-salvadorenho'  => array('Salvadorenho', 'Campeonato Salvadorenho', '🇸🇻', 'Notícias do futebol de El Salvador: Alianza, FAS, Águila e mais.'),
                'campeonato-panamenho'     => array('Panamenho', 'Campeonato Panamenho', '🇵🇦', 'Notícias do futebol do Panamá.'),
            ),
            'outras' => array(
                'campeonato-canadense'   => array('Canadense', 'Campeonato Canadense', '🇨🇦', false),
                'campeonato-jamaicano'   => array('Jamaicano', 'Campeonato Jamaicano', '🇯🇲', false),
                'campeonato-nicaraguense' => array('Nicaraguense', 'Campeonato Nicaraguense', '🇳🇮', false),
            ),
        ),
        'asia' => array(
            'nome' => 'Ásia', 'slug' => 'futebol-asiatico', 'icone' => '🌏',
            'desc' => 'Notícias do futebol asiático: Arábia Saudita, Japão, Coreia do Sul, China, Catar, Emirados e Tailândia, e os paulistas na Ásia.',
            'principais' => array(
                'campeonato-saudita'      => array('Saudita', 'Campeonato Saudita (Saudi Pro League)', '🇸🇦', 'Notícias da Saudi Pro League: Al-Hilal, Al-Nassr, Al-Ittihad e os brasileiros na Arábia Saudita.'),
                'campeonato-japones'      => array('Japonês', 'Campeonato Japonês (J-League)', '🇯🇵', 'Notícias da J-League e os brasileiros no Japão.'),
                'campeonato-sul-coreano'  => array('Sul-coreano', 'Campeonato Sul-coreano (K League)', '🇰🇷', 'Notícias da K League e os brasileiros na Coreia do Sul.'),
                'campeonato-chines'       => array('Chinês', 'Campeonato Chinês (Super League)', '🇨🇳', 'Notícias da Super League chinesa e os brasileiros na China.'),
                'campeonato-catari'       => array('Catari', 'Campeonato Catari (Stars League)', '🇶🇦', 'Notícias da Stars League e os brasileiros no Catar.'),
                'campeonato-emiradense'   => array('Emirados', 'Campeonato dos Emirados Árabes', '🇦🇪', 'Notícias do futebol dos Emirados Árabes Unidos e os brasileiros por lá.'),
                'campeonato-tailandes'    => array('Tailandês', 'Campeonato Tailandês (Thai League)', '🇹🇭', 'Notícias da Thai League e os brasileiros na Tailândia.'),
            ),
            'outras' => array(
                'campeonato-indiano'    => array('Indiano', 'Campeonato Indiano', '🇮🇳', false),
                'campeonato-iraniano'   => array('Iraniano', 'Campeonato Iraniano', '🇮🇷', false),
                'campeonato-uzbeque'    => array('Uzbeque', 'Campeonato Uzbeque', '🇺🇿', false),
                'campeonato-vietnamita' => array('Vietnamita', 'Campeonato Vietnamita', '🇻🇳', false),
                'campeonato-indonesio'  => array('Indonésio', 'Campeonato Indonésio', '🇮🇩', false),
                'campeonato-malaio'     => array('Malaio', 'Campeonato Malaio', '🇲🇾', false),
                'campeonato-kuwaitiano' => array('Kuwaitiano', 'Campeonato Kuwaitiano', '🇰🇼', false),
            ),
        ),
        'oceania' => array(
            'nome' => 'Oceania', 'slug' => 'futebol-da-oceania', 'icone' => '🌏',
            'desc' => 'Notícias do futebol da Oceania: A-League da Austrália, Nova Zelândia e os paulistas na região.',
            'principais' => array(
                'campeonato-australiano'  => array('Australiano', 'Campeonato Australiano (A-League)', '🇦🇺', 'Notícias da A-League e os brasileiros na Austrália.'),
                'campeonato-neozelandes'  => array('Neozelandês', 'Campeonato Neozelandês', '🇳🇿', 'Notícias do futebol da Nova Zelândia.'),
            ),
            'outras' => array(),
        ),
        'africa' => array(
            'nome' => 'África', 'slug' => 'futebol-africano', 'icone' => '🌍',
            'desc' => 'Notícias do futebol africano: Egito, Marrocos, África do Sul, Tunísia, Argélia, Nigéria e Angola, e os paulistas na África.',
            'principais' => array(
                'campeonato-egipcio'      => array('Egípcio', 'Campeonato Egípcio', '🇪🇬', 'Notícias do futebol do Egito: Al Ahly, Zamalek e mais.'),
                'campeonato-marroquino'   => array('Marroquino', 'Campeonato Marroquino', '🇲🇦', 'Notícias do futebol do Marrocos: Wydad, Raja e mais.'),
                'campeonato-sul-africano' => array('Sul-africano', 'Campeonato Sul-africano', '🇿🇦', 'Notícias do futebol da África do Sul: Mamelodi Sundowns, Kaizer Chiefs, Orlando Pirates e mais.'),
                'campeonato-tunisiano'    => array('Tunisiano', 'Campeonato Tunisiano', '🇹🇳', 'Notícias do futebol da Tunísia: Espérance, Étoile du Sahel e mais.'),
                'campeonato-argelino'     => array('Argelino', 'Campeonato Argelino', '🇩🇿', 'Notícias do futebol da Argélia.'),
                'campeonato-nigeriano'    => array('Nigeriano', 'Campeonato Nigeriano', '🇳🇬', 'Notícias do futebol da Nigéria.'),
                'campeonato-angolano'     => array('Angolano', 'Campeonato Angolano', '🇦🇴', 'Notícias do futebol de Angola: Petro de Luanda, 1º de Agosto e mais.'),
            ),
            'outras' => array(),
        ),
    );
}

function tsp_int_outras_slug($k)
{
    return $k . '-outras-ligas';
}

// Todas as ligas com página: slug => [continente, dados]
function tsp_int_ligas_todas()
{
    static $t = null;
    if ($t !== null) {
        return $t;
    }
    $t = array();
    foreach (tsp_int_continentes() as $k => $c) {
        foreach ($c['principais'] as $s => $l) {
            $t[$s] = array($k, $l[0], $l[1], $l[2], $l[3]);
        }
        foreach ($c['outras'] as $s => $l) {
            if (!empty($l[3])) {
                $t[$s] = array($k, $l[0], $l[1], $l[2], 'Notícias do ' . $l[1] . ' e os jogadores que passaram pelo futebol paulista.');
            }
        }
    }
    return $t;
}

// Cria os termos (geral, continentes, "outras ligas" e ligas ativas); de novo quando a lista muda
add_action('init', function () {
    if (!taxonomy_exists('campeonato')) {
        return;
    }
    $todas = array(TSP_INT_GERAL => array('Futebol internacional', 'Notícias do futebol internacional por continente: Europa, América do Sul, América do Norte e Central, Ásia, Oceania e África, sempre com os paulistas que jogam lá fora.'));
    foreach (tsp_int_continentes() as $k => $c) {
        $todas[$c['slug']] = array('Futebol ' . ($k === 'europa' ? 'europeu' : ($k === 'america-do-sul' ? 'sul-americano' : ($k === 'america-do-norte' ? 'da América do Norte e Central' : ($k === 'asia' ? 'asiático' : ($k === 'oceania' ? 'da Oceania' : 'africano'))))), $c['desc']);
        $todas[tsp_int_outras_slug($k)] = array('Outras ligas · ' . $c['nome'], 'Outras ligas de ' . $c['nome'] . ' acompanhadas pelo TSP: entram aqui quando um jogador que passou pelo futebol paulista vai jogar nelas.');
    }
    foreach (tsp_int_ligas_todas() as $s => $l) {
        $todas[$s] = array($l[2], $l[4]);
    }
    $versao = md5(wp_json_encode(array_keys($todas)));
    if (get_option('tsp_int_termos') === $versao) {
        return;
    }
    foreach ($todas as $slug => $l) {
        $ex = term_exists($slug, 'campeonato');
        if (!$ex) {
            wp_insert_term($l[0], 'campeonato', array('slug' => $slug, 'description' => $l[1]));
        } elseif ($slug === 'futebol-sul-americano' || $slug === TSP_INT_GERAL) {
            wp_update_term((int) (is_array($ex) ? $ex['term_id'] : $ex), 'campeonato', array('name' => $l[0], 'description' => $l[1]));
        }
    }
    update_option('tsp_int_termos', $versao, false);
}, 30);

// Matéria com liga ganha o continente e o termo geral (este tira a matéria da home)
add_action('set_object_terms', function ($post_id, $terms, $tt_ids, $taxonomy) {
    static $rodando = false;
    if ($rodando || $taxonomy !== 'campeonato') {
        return;
    }
    $slugs = wp_get_object_terms($post_id, 'campeonato', array('fields' => 'slugs'));
    if (is_wp_error($slugs)) {
        return;
    }
    $ligas = tsp_int_ligas_todas();
    $conts = tsp_int_continentes();
    $add = array();
    foreach ($slugs as $s) {
        if (isset($ligas[$s])) {
            $add[] = TSP_INT_GERAL;
            $add[] = $conts[$ligas[$s][0]]['slug'];
        }
        foreach ($conts as $k => $c) {
            if ($s === $c['slug'] || $s === tsp_int_outras_slug($k)) {
                $add[] = TSP_INT_GERAL;
                $add[] = $c['slug'];
            }
        }
    }
    $add = array_values(array_diff(array_unique($add), $slugs));
    if ($add) {
        $rodando = true;
        wp_set_object_terms($post_id, $add, 'campeonato', true);
        $rodando = false;
    }
}, 10, 4);

// Todos os slugs internacionais (para tirar da home)
function tsp_int_slugs()
{
    $s = array(TSP_INT_GERAL);
    foreach (tsp_int_continentes() as $k => $c) {
        $s[] = $c['slug'];
        $s[] = tsp_int_outras_slug($k);
    }
    return array_merge($s, array_keys(tsp_int_ligas_todas()));
}

function tsp_int_tax_fora()
{
    return array('taxonomy' => 'campeonato', 'field' => 'slug', 'terms' => tsp_int_slugs(), 'operator' => 'NOT IN');
}

function tsp_int_url($slug)
{
    return home_url('/campeonato/' . $slug . '/');
}

// Item do menu principal: um grupo por continente (7 ligas + "Outras ligas")
function tsp_int_menu_item()
{
    echo '<li class="tsp-nav__item tem-sub tsp-nav__int"><a href="' . esc_url(tsp_int_url(TSP_INT_GERAL)) . '">Internacional</a>';
    echo '<button type="button" class="tsp-nav__abre" aria-expanded="false" aria-controls="tsp-sub-internacional" aria-label="Futebol internacional por continente"><span aria-hidden="true">▾</span></button>';
    echo '<div class="tsp-nav__painel tsp-int-mega" id="tsp-sub-internacional"><a class="tsp-nav__painel-tit" href="' . esc_url(tsp_int_url(TSP_INT_GERAL)) . '">Futebol internacional →</a><div class="tsp-int-mega__grade">';
    foreach (tsp_int_continentes() as $k => $c) {
        echo '<div class="tsp-int-mega__cont"><a class="tsp-int-mega__nome" href="' . esc_url(tsp_int_url($c['slug'])) . '">' . esc_html($c['nome']) . '</a><ul>';
        foreach (array_slice($c['principais'], 0, 7, true) as $s => $l) {
            echo '<li><a href="' . esc_url(tsp_int_url($s)) . '"><span class="tsp-int-band" aria-hidden="true">' . $l[2] . '</span><span>' . esc_html($l[0]) . '</span></a></li>';
        }
        echo '<li><a class="tsp-int-mega__outras" href="' . esc_url(tsp_int_url(tsp_int_outras_slug($k))) . '">Outras ligas →</a></li>';
        echo '</ul></div>';
    }
    echo '</div></div></li>';
}

// Atalhos no topo das páginas internacionais
function tsp_int_chips()
{
    if (!is_tax('campeonato')) {
        return;
    }
    $atual = get_queried_object()->slug ?? '';
    $conts = tsp_int_continentes();
    $ligas = tsp_int_ligas_todas();
    $k = null;
    $itens = array();
    if ($atual === TSP_INT_GERAL) {
        foreach ($conts as $c) {
            $itens[$c['slug']] = $c['icone'] . ' ' . $c['nome'];
        }
    } else {
        foreach ($conts as $kk => $c) {
            if ($atual === $c['slug'] || $atual === tsp_int_outras_slug($kk) || (isset($ligas[$atual]) && $ligas[$atual][0] === $kk)) {
                $k = $kk;
            }
        }
        if ($k === null) {
            return;
        }
        $c = $conts[$k];
        $itens[TSP_INT_GERAL] = '← Internacional';
        $itens[$c['slug']] = $c['icone'] . ' ' . $c['nome'];
        $ehoutra = $atual === tsp_int_outras_slug($k) || (isset($ligas[$atual]) && !isset($c['principais'][$atual]));
        if ($ehoutra) {
            foreach ($c['outras'] as $s => $l) {
                if (!empty($l[3])) {
                    $itens[$s] = $l[2] . ' ' . $l[0];
                }
            }
        } else {
            foreach ($c['principais'] as $s => $l) {
                $itens[$s] = $l[2] . ' ' . $l[0];
            }
        }
        $itens[tsp_int_outras_slug($k)] = 'Outras ligas';
    }
    echo '<nav class="tsp-int-chips" aria-label="Campeonatos">';
    foreach ($itens as $s => $rot) {
        echo '<a href="' . esc_url(tsp_int_url($s)) . '"' . ($atual === $s ? ' aria-current="page"' : '') . '>' . esc_html($rot) . '</a>';
    }
    echo '</nav>';
    if ($k !== null && $atual === tsp_int_outras_slug($k)) {
        $ativas = array_filter($conts[$k]['outras'], function ($l) {
            return !empty($l[3]);
        });
        if (!$ativas) {
            echo '<p class="tsp-int-nota">As outras ligas de ' . esc_html($conts[$k]['nome']) . ' entram aqui quando um jogador que passou pelo futebol paulista for jogar nelas.</p>';
        }
    }
}
