<?php
/**
 * Cobertura especial da home (27-28/11/2026, pedido do Thiago: final da Libertadores Palmeiras x Estudiantes).
 * Ligada pelo arquivo api/especial.json do repositório (baixado como o manchete.json), entre "de" e "ate":
 * {"de", "ate", "titulo", "sub", "clube": "palmeiras", "rival": "Estudiantes", "rival_slug": "estudiantes", "liga": "libertadores"}
 *  - 6 notícias: 2 grandes em cima e 4 menores embaixo, alternando clube e rival (3 de cada).
 *    Depois do jogo, as 6 mais novas são a repercussão; as mais antigas voltam para o bloco normal do clube.
 *  - Embaixo, só o jogo da fase em andamento da competição (a final), sem o chaveamento inteiro.
 * Matéria do rival = marcada com o clube do rival OU com o nome do rival no título antes do nome do clube.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Clubes de fora de SP que o TSP acompanha (página /times/<slug>/ própria, fora dos blocos paulistas)
function tsp_clubes_fora()
{
    return array(
        'estudiantes' => array(
            'nome'   => 'Estudiantes',
            'busca'  => array('estudiantes', 'pincharrata', 'pincharratas'),
            'escudo' => 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/escudos/estudiantes.png',
            'desc'   => 'Notícias do Estudiantes de La Plata, clube argentino tetracampeão da Libertadores e adversário do Palmeiras na final de 2026.',
        ),
    );
}

// Cria a página (termo) de cada clube de fora acompanhado
add_action('init', function () {
    if (!taxonomy_exists('times')) {
        return;
    }
    $v = md5(wp_json_encode(array_keys(tsp_clubes_fora())));
    if (get_option('tsp_clubes_fora_v') === $v) {
        return;
    }
    foreach (tsp_clubes_fora() as $slug => $c) {
        if (!term_exists($slug, 'times')) {
            wp_insert_term($c['nome'], 'times', array('slug' => $slug, 'description' => $c['desc']));
        }
    }
    update_option('tsp_clubes_fora_v', $v, false);
}, 31);

// Matéria com o nome do clube de fora no título ganha a marcação dele (alimenta a página do clube)
add_action('save_post', function ($post_id, $post) {
    if (wp_is_post_revision($post_id) || !in_array($post->post_type, (array) tsp_tipos(), true) || !taxonomy_exists('times')) {
        return;
    }
    $tit = mb_strtolower(html_entity_decode($post->post_title, ENT_QUOTES, 'UTF-8'));
    foreach (tsp_clubes_fora() as $slug => $c) {
        foreach ($c['busca'] as $w) {
            if (preg_match('/(^|[^\p{L}])' . preg_quote($w, '/') . '([^\p{L}]|$)/u', $tit)) {
                if (!has_term($slug, 'times', $post_id)) {
                    wp_set_object_terms($post_id, $slug, 'times', true);
                }
                break;
            }
        }
    }
}, 20, 2);

function tsp_especial_ativa()
{
    static $e = false;
    if ($e !== false) {
        return $e;
    }
    $e = null;
    if (!function_exists('tsp_mc_arquivo')) {
        return $e;
    }
    $d = tsp_mc_arquivo('especial.json');
    if (empty($d['clube']) || empty($d['de']) || empty($d['ate'])) {
        return $e;
    }
    $agora = time();
    if ($agora >= strtotime($d['de']) && $agora < strtotime($d['ate'])) {
        $e = $d;
    }
    return $e;
}

function tsp_especial_e_rival($pid, $clube_nome, $rival, $rival_slug)
{
    if ($rival_slug && has_term($rival_slug, 'times', $pid) && !preg_match('~^\s*' . preg_quote($clube_nome, '~') . '~iu', html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8'))) {
        return true;
    }
    $t = mb_strtolower(html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8'));
    $pr = mb_strpos($t, mb_strtolower($rival));
    if ($pr === false) {
        return false;
    }
    $pc = mb_strpos($t, mb_strtolower($clube_nome));
    return $pc === false || $pr < $pc;
}

// 6 matérias alternadas: clube, rival, clube, rival, clube, rival
function tsp_especial_ids($e, &$vistos)
{
    $clube = (string) $e['clube'];
    $t = get_term_by('slug', $clube, 'times');
    $nome = $t ? $t->name : ucfirst($clube);
    $rival = (string) ($e['rival'] ?? '');
    $rs = (string) ($e['rival_slug'] ?? '');
    $n = max(2, (int) ($e['n'] ?? 6));
    $slugs = $rs && term_exists($rs, 'times') ? array($clube, $rs) : array($clube);
    $do_clube = $do_rival = array();
    foreach (tsp_consulta(array('posts_per_page' => 40, 'tax_query' => tsp_tax_times($slugs)), $vistos) as $p) {
        if ($rival && tsp_especial_e_rival($p->ID, $nome, $rival, $rs)) {
            $do_rival[] = $p->ID;
        } else {
            $do_clube[] = $p->ID;
        }
    }
    if ($rival) {
        $ja = array_merge($vistos, $do_clube, $do_rival);
        foreach (tsp_consulta(array('posts_per_page' => 10, 's' => $rival, 'date_query' => array(array('after' => '5 days ago'))), $ja) as $p) {
            if (tsp_especial_e_rival($p->ID, $nome, $rival, $rs)) {
                $do_rival[] = $p->ID;
            }
        }
        $do_rival = array_values(array_unique($do_rival));
        usort($do_rival, function ($a, $b) {
            return strcmp(get_post_field('post_date', $b), get_post_field('post_date', $a));
        });
    }
    $ids = array();
    for ($i = 0; $i < $n; $i++) {
        $quer_rival = ($i % 2 === 1);
        if ($quer_rival && $do_rival) {
            $ids[] = array_shift($do_rival);
        } elseif (!$quer_rival && $do_clube) {
            $ids[] = array_shift($do_clube);
        } elseif ($do_rival) {
            $ids[] = array_shift($do_rival);
        } elseif ($do_clube) {
            $ids[] = array_shift($do_clube);
        }
    }
    $vistos = array_merge($vistos, $ids); // o resto volta para o bloco normal do clube
    return array($ids, $nome);
}

function tsp_bloco_especial($e, $ids, $nome)
{
    if (!$ids) {
        return;
    }
    $cab = array((string) $e['clube'] => $nome);
    $rs = (string) ($e['rival_slug'] ?? '');
    if ($rs && term_exists($rs, 'times')) {
        $cab[$rs] = (string) ($e['rival'] ?? $rs);
    }
    echo '<section class="tsp-secao tsp-secao--caixa tsp-secao--especial" id="especial" aria-labelledby="h-especial">';
    tsp_secao_cab((string) ($e['titulo'] ?? 'Cobertura especial'), '', $cab, (string) ($e['sub'] ?? 'Cobertura especial do TSP'), 'h-especial', true);
    echo '<div class="tsp-esp__duas">';
    foreach (array_slice($ids, 0, 2) as $i => $id) {
        tsp_card($id, 'grande', $i === 0);
    }
    echo '</div>';
    $resto = array_slice($ids, 2);
    if ($resto) {
        echo '<div class="tsp-grade tsp-grade--4 tsp-esp__quatro">';
        foreach ($resto as $id) {
            tsp_card($id, 'grade');
        }
        echo '</div>';
    }
    // Só o jogo da fase em andamento (a final), sem o chaveamento inteiro
    if (!empty($e['liga']) && function_exists('tsp_jogos_chave_html')) {
        $ch = tsp_jogos_chave_html((string) $e['liga']);
        if ($ch) {
            echo '<div class="tsp-esp__jogo">' . $ch . '</div>'; // phpcs:ignore -- HTML montado com escape no plugin
        }
    }
    if (function_exists('tsp_wg_faixa')) {
        tsp_wg_faixa(array((string) $e['clube']));
    }
    echo '</section>';
}
