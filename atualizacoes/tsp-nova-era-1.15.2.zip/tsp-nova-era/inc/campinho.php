<?php
/**
 * Campinho da página do clube (1.15.0, 28/11/2026, pedido do Thiago: padrão Sofascore com foto dos jogadores).
 *  - "Time base": os jogadores com MAIS MINUTOS nos jogos com escalação confirmada na base do TSP, no esquema mais usado.
 *    Interativo: o leitor troca o esquema (o time base se refaz sozinho pela minutagem daquele esquema), arrasta jogadores
 *    da lista de opções para o campo (no celular: toca no jogador do campo e depois no que vai entrar) e compartilha
 *    o "meu time ideal" (imagem + link).
 *  - "Última escalação": os 11 que começaram o jogo mais recente com escalação confirmada.
 *  - Antes de qualquer jogo: time base com o elenco anunciado (quem já é da casa primeiro, depois os mais experientes).
 * Tudo é recorte dos jogos registrados (regra 16): o aviso diz quantos jogos e de quando a quando.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_CP_DESDE = '2026-01-01 00:00:00'; // por enquanto: os jogos de 2026 registrados (a temporada 2027 entra por cima)

function tsp_cp_idade($x)
{
    if (!empty($x['nascimento'])) {
        return (int) floor((time() - strtotime($x['nascimento'])) / (365.25 * DAY_IN_SECONDS));
    }
    return (int) ($x['ficha']['idade'] ?? 0);
}

function tsp_cp_n($n)
{
    return sanitize_title(remove_accents((string) $n));
}

function tsp_cp_setor_pos($pos)
{
    $p = mb_strtolower((string) $pos);
    if (strpos($p, 'goleiro') !== false) {
        return 'G';
    }
    if (strpos($p, 'zagueiro') !== false || strpos($p, 'lateral') !== false || strpos($p, 'ala') === 0) {
        return 'D';
    }
    if (strpos($p, 'atacante') !== false || strpos($p, 'ponta') !== false || strpos($p, 'centroavante') !== false) {
        return 'A';
    }
    return 'M';
}

// Setor de cada linha da escalação: 0 = goleiro, 1 = defesa, última = ataque, o resto = meio
function tsp_cp_setor_linha($li, $total)
{
    return $li === 0 ? 'G' : ($li === 1 ? 'D' : ($li === $total - 1 ? 'A' : 'M'));
}

function tsp_cp_minuto2($m)
{
    return preg_match('~^\s*(\d+)~', (string) $m, $x) ? min(120, (int) $x[1]) : 0;
}

/**
 * Jogos com escalação confirmada (11 titulares em linhas) do clube, do mais novo ao mais antigo.
 * @return array [['j' => obj, 'linhas' => [[nomes]], 'entraram' => [], 'tecnico' => '', 'lado' => 'casa'|'fora']]
 */
function tsp_cp_jogos($api_id, $max = 10)
{
    if (!$api_id || !function_exists('tsp_jogos_buscar') || !function_exists('tsp_jogos_detalhes')) {
        return array();
    }
    $js = tsp_jogos_buscar("(casa_id = %d OR fora_id = %d) AND status IN ('FT','AET','PEN') AND inicio >= %d", array($api_id, $api_id, strtotime(TSP_CP_DESDE)), 'inicio DESC', 60);
    $out = array();
    foreach ((array) $js as $j) {
        if (strpos((string) $j->liga, 'fem_') === 0) {
            continue;
        }
        $d = tsp_jogos_detalhes($j->id);
        $lado = (int) $j->casa_id === (int) $api_id ? 'casa' : 'fora';
        $esc = (array) ($d['esc_tsp'][$lado] ?? array());
        if (empty($esc['time'])) {
            continue;
        }
        $linhas = array();
        foreach (explode(';', (string) $esc['time']) as $parte) {
            $nomes = array_values(array_filter(array_map('trim', explode(',', $parte))));
            if ($nomes) {
                $linhas[] = $nomes;
            }
        }
        if (count($linhas) < 3 || array_sum(array_map('count', $linhas)) !== 11 || count($linhas[0]) !== 1) {
            continue;
        }
        $out[] = array('j' => $j, 'linhas' => $linhas, 'entraram' => (array) ($esc['entraram'] ?? array()), 'tecnico' => $esc['tecnico'] ?? '', 'lado' => $lado);
        if (count($out) >= $max) {
            break;
        }
    }
    return $out;
}

// Dados do campinho para o navegador (jogadores com minutos e setor, último jogo, esquema mais usado)
function tsp_cp_dados($termo, $slug, $el)
{
    $elenco = array_values(array_filter((array) ($el['jogadores'] ?? array()), function ($x) {
        return !tsp_mc_e_comissao_pos($x['posicao'] ?? '');
    }));
    $por_nome = array();
    foreach ($elenco as $x) {
        $por_nome[tsp_cp_n($x['nome'])] = $x;
    }
    $acha = function ($nome) use ($por_nome) {
        $k = tsp_cp_n($nome);
        if (isset($por_nome[$k])) {
            return $por_nome[$k];
        }
        foreach ($por_nome as $kk => $x) { // "Gabriel Girotto" x "Girotto"
            if (strlen($k) > 3 && (strpos($kk, $k) !== false || strpos($k, $kk) !== false)) {
                return $x;
            }
        }
        return null;
    };
    $tid = function_exists('tsp_jogos_api_do_slug') ? (int) tsp_jogos_api_do_slug($slug) : 0;
    $jogos = tsp_cp_jogos($tid);
    $u = array();
    $add = function ($nome) use (&$u, $acha, $slug) {
        $k = tsp_cp_n($nome);
        if (!isset($u[$k])) {
            $x = $acha($nome);
            $u[$k] = array('id' => $k, 'nome' => $x['nome'] ?? $nome, 'foto' => $x['foto']['url'] ?? '', 'url' => $x ? tsp_mc_jog_url($x['nome'], $slug) : '',
                'pos' => $x['posicao'] ?? '', 'min' => 0, 'jogos' => 0, 'tit' => 0, 'setores' => array(), 'ordem' => 0);
        }
        return $k;
    };
    $conta = array();
    foreach ($jogos as $gi => $g) {
        $saiu = array();
        foreach ($g['entraram'] as $s) {
            if (!empty($s['saiu'])) {
                $saiu[tsp_cp_n($s['saiu'])] = tsp_cp_minuto2($s['minuto'] ?? 0) ?: 90;
            }
        }
        $n = count($g['linhas']);
        foreach ($g['linhas'] as $li => $nomes) {
            foreach ($nomes as $nm) {
                $k = $add($nm);
                $se = tsp_cp_setor_linha($li, $n);
                $u[$k]['min'] += $saiu[$k] ?? 90;
                $u[$k]['tit']++;
                $u[$k]['jogos']++;
                $u[$k]['setores'][$se] = ($u[$k]['setores'][$se] ?? 0) + 1;
            }
        }
        foreach ($g['entraram'] as $s) {
            if (empty($s['jogador'])) {
                continue;
            }
            $k = $add($s['jogador']);
            $u[$k]['min'] += max(0, 90 - (tsp_cp_minuto2($s['minuto'] ?? 0) ?: 90));
            $u[$k]['jogos']++;
            $sk = tsp_cp_n($s['saiu'] ?? '');
            if ($sk && !empty($u[$sk]['setores'])) { // entrou no lugar de quem saiu: mesmo setor
                arsort($u[$sk]['setores']);
                $se = key($u[$sk]['setores']);
                $u[$k]['setores'][$se] = ($u[$k]['setores'][$se] ?? 0) + 0.5;
            }
        }
        if ($gi < 5) {
            $f = implode('-', array_slice(array_map('count', $g['linhas']), 1));
            $conta[$f] = ($conta[$f] ?? 0) + 1;
        }
    }
    $formacao = '4-4-2';
    if ($jogos) {
        $formacao = implode('-', array_slice(array_map('count', $jogos[0]['linhas']), 1));
        foreach ($conta as $f => $q) {
            if ($q > ($conta[$formacao] ?? 0)) {
                $formacao = $f;
            }
        }
    }
    // Elenco anunciado entra como opção (sem minutos), com o setor da posição
    foreach ($elenco as $i => $x) {
        $k = tsp_cp_n($x['nome']);
        $ja = false;
        foreach ($u as $uk => $y) {
            if ($y['nome'] === $x['nome']) {
                $ja = true;
                break;
            }
        }
        if (!$ja) {
            $u[$k] = array('id' => $k, 'nome' => $x['nome'], 'foto' => $x['foto']['url'] ?? '', 'url' => tsp_mc_jog_url($x['nome'], $slug), 'pos' => $x['posicao'] ?? '',
                'min' => 0, 'jogos' => 0, 'tit' => 0, 'setores' => array(tsp_cp_setor_pos($x['posicao'] ?? '') => 1),
                'ordem' => (empty($x['novo']) ? 1000 : 0) + tsp_cp_idade($x)); // antes dos jogos: da casa primeiro, depois os mais experientes
        }
    }
    foreach ($u as $k => $x) {
        if (empty($x['setores']) && $x['pos']) {
            $u[$k]['setores'] = array(tsp_cp_setor_pos($x['pos']) => 1);
        }
        arsort($u[$k]['setores']);
        $u[$k]['setor'] = $u[$k]['setores'] ? (string) key($u[$k]['setores']) : 'M';
        unset($u[$k]['setores']);
    }
    $lista = array_values($u);
    usort($lista, function ($a, $b) {
        return $b['min'] <=> $a['min'] ?: $b['ordem'] <=> $a['ordem'];
    });
    $ult = null;
    if ($jogos) {
        $g = $jogos[0];
        $j = $g['j'];
        $adv = $g['lado'] === 'casa' ? $j->fora : $j->casa;
        $placar = isset($j->gols_casa) && $j->gols_casa !== null ? ($g['lado'] === 'casa' ? $j->gols_casa . ' x ' . $j->gols_fora : $j->gols_fora . ' x ' . $j->gols_casa) : '';
        $ult = array('adv' => (string) $adv, 'data' => wp_date('d/m/Y', (int) $j->inicio), 'placar' => $placar, 'mando' => $g['lado'] === 'casa' ? 'em casa' : 'fora',
            'formacao' => implode('-', array_slice(array_map('count', $g['linhas']), 1)), 'tecnico' => (string) $g['tecnico'],
            'linhas' => array_map(function ($l) {
                return array_map('tsp_cp_n', $l);
            }, $g['linhas']));
    }
    return array('clube' => $termo->name, 'de' => tsp_de($termo), 'formacao' => $formacao, 'jogadores' => $lista, 'ultima' => $ult,
        'n' => count($jogos), 'periodo' => $jogos ? wp_date('d/m', (int) end($jogos)['j']->inicio) . ' a ' . wp_date('d/m/Y', (int) $jogos[0]['j']->inicio) : '',
        'escudo' => function_exists('tsp_escudo_url') ? tsp_escudo_url($termo) : '', 'url' => get_term_link($termo));
}

function tsp_el_campinho($termo, $slug, $el)
{
    $d = tsp_cp_dados($termo, $slug, $el);
    if (count($d['jogadores']) < 6) {
        return '';
    }
    $GLOBALS['tsp_cp_usado'] = true;
    $id = 'cp-' . sanitize_html_class($slug);
    if ($d['n']) {
        $aviso = function_exists('tsp_recorte_aviso') ? tsp_recorte_aviso($d['n'], 0, 0, '') : '';
        $nota = 'Recorte dos últimos ' . $d['n'] . ' jogos com escalação confirmada registrados pelo TSP (' . $d['periodo'] . '). Time base = esquema mais usado e, em cada setor, quem tem mais minutos.';
    } else {
        $nota = 'Antes dos jogos: montagem do TSP com o elenco anunciado (em cada setor, primeiro quem já é da casa, depois os mais experientes). Não é escalação oficial. Com a bola rolando, o time base passa a ser o dos que têm mais minutos.';
    }
    $esquemas = array('4-4-2', '4-3-3', '4-2-3-1', '4-1-4-1', '4-5-1', '3-5-2', '3-4-3', '5-3-2', '5-4-1');
    if (!in_array($d['formacao'], $esquemas, true)) {
        array_unshift($esquemas, $d['formacao']);
    }
    $h = '<div class="tsp-cp2" id="' . esc_attr($id) . '">';
    $h .= '<div class="tsp-cp2__abas" role="tablist"><button type="button" role="tab" aria-selected="true" data-cp-aba="base">Time base · mais minutos</button>';
    if ($d['ultima']) {
        $h .= '<button type="button" role="tab" aria-selected="false" data-cp-aba="ultima">Última escalação</button>';
    }
    $h .= '</div>';
    $h .= '<p class="tsp-cp__nota">' . esc_html($nota) . '</p>';
    // Time base interativo
    $h .= '<div class="tsp-cp2__painel" data-cp-painel="base"><div class="tsp-cp2__barra"><label>Esquema <select data-cp-esquema>';
    foreach ($esquemas as $e) {
        $h .= '<option value="' . esc_attr($e) . '"' . selected($e, $d['formacao'], false) . '>' . esc_html($e) . ($e === $d['formacao'] && $d['n'] ? ' (mais usado)' : '') . '</option>';
    }
    $h .= '</select></label><button type="button" class="tsp-cp2__btn tsp-cp2__btn--claro" data-cp-refazer>Voltar ao time base</button>';
    $h .= '<button type="button" class="tsp-cp2__btn" data-cp-compartilhar><span aria-hidden="true">↗</span> Compartilhar meu time</button></div>';
    $h .= '<div class="tsp-cp2__campo" data-cp-campo aria-label="Campinho do time base ' . esc_attr($d['de']) . '"></div>';
    $h .= '<p class="tsp-cp2__dica">Monte o seu time ideal: arraste um jogador das opções para o campo (no celular, toque no jogador do campo e depois em quem vai entrar). Trocando o esquema, o time base se refaz pela minutagem.</p>';
    $h .= '<div class="tsp-cp2__opcoes"><h3>Opções' . ($d['n'] ? ' · por minutos jogados' : '') . '</h3><div class="tsp-cp2__lista" data-cp-lista></div></div></div>';
    if ($d['ultima']) {
        $u = $d['ultima'];
        $h .= '<div class="tsp-cp2__painel" data-cp-painel="ultima" hidden><p class="tsp-cp2__jogo"><strong>' . esc_html($d['clube'] . ($u['placar'] ? ' ' . $u['placar'] . ' ' : ' x ') . $u['adv']) . '</strong> · ' . esc_html($u['data'] . ' · ' . $u['mando'] . ' · ' . $u['formacao'] . ($u['tecnico'] ? ' · técnico ' . $u['tecnico'] : '')) . '</p>';
        $h .= '<div class="tsp-cp2__campo tsp-cp2__campo--fixo" data-cp-ultima></div></div>';
    }
    $h .= '<script type="application/json" data-cp-dados>' . wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script></div>';
    return $h;
}

add_action('wp_footer', function () {
    if (empty($GLOBALS['tsp_cp_usado'])) {
        return;
    }
    $js = file_get_contents(get_template_directory() . '/assets/campinho.js');
    echo '<script>' . $js . '</script>'; // phpcs:ignore
}, 40);
