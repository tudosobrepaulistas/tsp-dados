<?php
/**
 * Radar TSP "Paulistas pelo mundo" (1.14.0, 28/11/2026; layout aprovado pelo Thiago em 4 telas).
 * Quem saiu de um clube paulista (base ou profissional) e joga fora do Brasil.
 * Dados: base própria no GitHub (api/pelo_mundo.json e api/jogos_mundo.json), feitos por ferramentas/pelo_mundo.py.
 *  - /paulistas-pelo-mundo/          Radar: números, filtros e todos os jogadores por país
 *  - /paulistas-pelo-mundo/<id>/     Ficha do jogador
 *  - Home: faixa "Paulistas pelo mundo" depois da tabela da Série A (com "Jogos de hoje no mundo")
 *  - /campeonato/futebol-internacional/: "Jogos de hoje" (hoje e amanhã) e os paulistas lá fora
 *  - Matérias internacionais que citam um jogador do radar no título: selo "Paulista pelo mundo · ex-<clube>"
 * Nada inventado: o que a base não tem aparece como "Em atualização".
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ---------- Dados ---------- */

add_action('tsp_mc_atualizar', function () {
    tsp_mc_baixar('pelo_mundo.json');
    tsp_mc_baixar('jogos_mundo.json');
});
add_action('tsp_mc_atualizar_hora', function () {
    tsp_mc_baixar('pelo_mundo.json');
    tsp_mc_baixar('jogos_mundo.json');
});

function tsp_pm_dados()
{
    return function_exists('tsp_mc_arquivo') ? tsp_mc_arquivo('pelo_mundo.json') : array();
}

function tsp_pm_jogadores()
{
    $d = tsp_pm_dados();
    return isset($d['jogadores']) && is_array($d['jogadores']) ? $d['jogadores'] : array();
}

function tsp_pm_jogador($id)
{
    foreach (tsp_pm_jogadores() as $j) {
        if (($j['id'] ?? '') === $id) {
            return $j;
        }
    }
    return null;
}

function tsp_pm_url($id = '')
{
    return home_url('/paulistas-pelo-mundo/' . ($id ? $id . '/' : ''));
}

function tsp_pm_jogos_dia($dia)
{
    $d = function_exists('tsp_mc_arquivo') ? tsp_mc_arquivo('jogos_mundo.json') : array();
    return isset($d['dias'][$dia]) && is_array($d['dias'][$dia]) ? $d['dias'][$dia] : array();
}

// Ligas com paulista do radar: entram sozinhas no menu Internacional ("outras ligas" ativas)
function tsp_pm_ligas_ativas()
{
    $d = tsp_pm_dados();
    return isset($d['ligas_ativas']) ? (array) $d['ligas_ativas'] : array();
}

/* ---------- Peças ---------- */

function tsp_pm_origem($j)
{
    return $j['origem'][0] ?? array();
}

function tsp_pm_ex($j)
{
    $o = tsp_pm_origem($j);
    return 'Ex-' . ($o['clube'] ?? '');
}

function tsp_pm_div_txt($a)
{
    $d = (int) ($a['divisao'] ?? 0);
    return $d ? $d . 'ª divisão' : '';
}

function tsp_pm_foto($j, $tam = 72)
{
    $nome = (string) ($j['nome'] ?? '');
    if (!empty($j['foto']['url'])) {
        return '<img class="tsp-pm__foto" src="' . esc_url($j['foto']['url']) . '" alt="' . esc_attr($nome) . '" width="' . (int) $tam . '" height="' . (int) $tam . '" loading="lazy" decoding="async" referrerpolicy="no-referrer">';
    }
    return '<span class="tsp-pm__foto tsp-pm__foto--ini" style="width:' . (int) $tam . 'px;height:' . (int) $tam . 'px" aria-hidden="true">' . esc_html(mb_strtoupper(mb_substr($nome, 0, 1))) . '</span>';
}

function tsp_pm_link_clube($o)
{
    $t = !empty($o['slug']) ? get_term_by('slug', $o['slug'], 'times') : null;
    $nome = esc_html($o['clube'] ?? ($t ? $t->name : ''));
    return $t ? '<a href="' . esc_url(get_term_link($t)) . '">' . $nome . '</a>' : $nome;
}

// Card do radar (lista por país e "também revelados")
function tsp_pm_card($j)
{
    $a = $j['atual'] ?? array();
    $o = tsp_pm_origem($j);
    $div = (int) ($a['divisao'] ?? 0);
    $attrs = ' data-origem="' . esc_attr(implode(' ', array_map(function ($x) {
        return $x['slug'] ?? '';
    }, (array) ($j['origem'] ?? array())))) . '" data-pais="' . esc_attr($a['pais'] ?? '') . '" data-div="' . ($div >= 2 ? '2' : '1') . '" data-tipo="' . esc_attr(implode(' ', array_unique(array_map(function ($x) {
        return $x['tipo'] ?? '';
    }, (array) ($j['origem'] ?? array()))))) . '" data-nome="' . esc_attr(remove_accents(mb_strtolower($j['nome'] ?? ''))) . '"';
    $h = '<a class="tsp-pm__card" href="' . esc_url(tsp_pm_url($j['id'])) . '"' . $attrs . '>' . tsp_pm_foto($j, 52);
    $h .= '<span class="tsp-pm__card-txt"><strong>' . esc_html($j['nome'] ?? '') . '</strong>';
    $h .= '<span>' . esc_html(($a['clube'] ?? '') . ($div ? ' · ' . tsp_pm_div_txt($a) : '')) . '</span>';
    $h .= '<span class="tsp-pm__ex">' . esc_html(tsp_pm_ex($j) . (($o['tipo'] ?? '') === 'base' ? ' · base' : '')) . '</span>';
    $rn = tsp_pm_resumo_num($j);
    if ($rn) {
        $h .= '<span class="tsp-pm__card-num">' . esc_html($rn) . '</span>';
    }
    $h .= '</span></a>';
    return $h;
}

// Números da temporada (oGol, lidos página por página) e carreira temporada a temporada
function tsp_pm_resumo_num($j)
{
    $n = $j['numeros'] ?? null;
    if (empty($n['total'])) {
        return '';
    }
    $t = $n['total'];
    return 'Temporada ' . $n['temporada'] . ': ' . (int) $t['jogos'] . ' J · ' . (int) $t['gols'] . ' G · ' . (int) $t['assistencias'] . ' A';
}

function tsp_pm_numeros_html($j)
{
    $n = $j['numeros'] ?? null;
    $car = (array) ($j['carreira'] ?? array());
    if (!$n && !$car) {
        return '';
    }
    $h = '';
    if ($n) {
        $ate = !empty($n['ate']) ? ' (até ' . wp_date('d/m/Y', strtotime($n['ate'] . ' 12:00')) . ')' : '';
        $h .= '<section class="tsp-caixa tsp-pm__num"><h2>Números na temporada ' . esc_html($n['temporada']) . $ate . '</h2>';
        $h .= '<table class="tsp-tabela-simples"><thead><tr><th>Competição</th><th>Jogos</th><th>Minutos</th><th>Gols</th><th>Assist.</th></tr></thead><tbody>';
        foreach ((array) ($n['competicoes'] ?? array()) as $c) {
            $h .= '<tr><td>' . esc_html($c['nome']) . '</td><td>' . (int) $c['jogos'] . '</td><td>' . (int) $c['minutos'] . '</td><td>' . (int) $c['gols'] . '</td><td>' . (int) $c['assistencias'] . '</td></tr>';
        }
        if (!empty($n['total'])) {
            $t = $n['total'];
            $h .= '<tr class="is-total"><td><strong>Total</strong></td><td><strong>' . (int) $t['jogos'] . '</strong></td><td><strong>' . (int) $t['minutos'] . '</strong></td><td><strong>' . (int) $t['gols'] . '</strong></td><td><strong>' . (int) $t['assistencias'] . '</strong></td></tr>';
        }
        $h .= '</tbody></table></section>';
    }
    if ($car) {
        $h .= '<section class="tsp-caixa tsp-pm__num"><h2>Carreira temporada a temporada</h2>';
        $h .= '<table class="tsp-tabela-simples is-car"><thead><tr><th>Temporada</th><th>Clube</th><th>Jogos</th><th>Gols</th><th>Assist.</th></tr></thead><tbody>';
        foreach ($car as $c) {
            $h .= '<tr><td>' . esc_html((string) $c['temporada']) . '</td><td>' . esc_html($c['clube']) . (!empty($c['emprestimo']) ? ' <small>(emprestado)</small>' : '') . '</td><td>' . (int) $c['jogos'] . '</td><td>' . (int) $c['gols'] . '</td><td>' . (int) $c['assistencias'] . '</td></tr>';
        }
        $h .= '</tbody></table></section>';
    }
    $f = $n['fonte'] ?? ($j['carreira_fonte'] ?? '');
    if ($f) {
        $h .= '<p class="tsp-nota">Números: <a href="' . esc_url($f) . '" rel="nofollow noopener" target="_blank">oGol</a>' . (!empty($n['ate']) ? ', consultado em ' . esc_html(wp_date('d/m/Y', strtotime($n['ate'] . ' 12:00'))) : '') . '.</p>';
    }
    return $h;
}

// Selo da matéria: "Paulista pelo mundo · ex-<clube>" quando o título cita um jogador do radar
function tsp_pm_do_post($post_id)
{
    static $cache = array();
    if (isset($cache[$post_id])) {
        return $cache[$post_id];
    }
    $tit = remove_accents(mb_strtolower(html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8')));
    foreach (tsp_pm_jogadores() as $j) {
        $n = remove_accents(mb_strtolower((string) ($j['nome'] ?? '')));
        if ($n && preg_match('~(^|[^a-z0-9])' . preg_quote($n, '~') . '([^a-z0-9]|$)~u', $tit)) {
            return $cache[$post_id] = $j;
        }
    }
    return $cache[$post_id] = null;
}

function tsp_pm_selo_texto($post_id)
{
    $j = tsp_pm_do_post($post_id);
    return $j ? tsp_pm_ex($j) . ' · ' . ($j['atual']['clube'] ?? '') : '';
}

function tsp_pm_selo_html($post_id)
{
    $j = tsp_pm_do_post($post_id);
    if (!$j) {
        return '';
    }
    return '<a class="tsp-pm__selo" href="' . esc_url(tsp_pm_url($j['id'])) . '"><span aria-hidden="true">🌍</span> Paulista pelo mundo · ' . esc_html('ex-' . (tsp_pm_origem($j)['clube'] ?? '')) . '</a>';
}

/* ---------- Jogos de hoje no mundo ---------- */

function tsp_pm_liga_nome($slug)
{
    if (function_exists('tsp_int_ligas_todas')) {
        $l = tsp_int_ligas_todas();
        if (isset($l[$slug])) {
            return preg_replace('~\s*\(.*\)$~', '', $l[$slug][2]);
        }
    }
    return ucwords(str_replace('-', ' ', $slug));
}

function tsp_pm_jogo_li($g, $com_liga = true)
{
    $ps = array();
    foreach ((array) ($g['paulistas'] ?? array()) as $id) {
        $j = tsp_pm_jogador($id);
        if ($j) {
            $ps[] = '<a href="' . esc_url(tsp_pm_url($id)) . '">' . esc_html($j['nome']) . ' (' . esc_html('ex-' . (tsp_pm_origem($j)['clube'] ?? '')) . ')</a>';
        }
    }
    $h = '<li class="tsp-pm__jogo"><span class="tsp-pm__hora">' . esc_html(str_replace(':', 'h', $g['hora'] ?? '')) . '</span><span class="tsp-pm__jogo-txt"><strong>' . esc_html(($g['casa'] ?? '') . ' x ' . ($g['fora'] ?? '')) . '</strong>';
    $info = array();
    if ($com_liga) {
        $info[] = tsp_pm_liga_nome($g['liga'] ?? '');
    }
    if (!empty($g['tv'])) {
        $info[] = $g['tv'];
    }
    $h .= $info ? '<small>' . esc_html(implode(' · ', $info)) . '</small>' : '';
    $h .= $ps ? '<span class="tsp-pm__em-campo">Paulista em campo: ' . implode(', ', $ps) . '</span>' : '';
    return $h . '</span></li>';
}

// Ordem: jogos com paulista primeiro, depois por horário
function tsp_pm_ordena_jogos($lista)
{
    usort($lista, function ($a, $b) {
        $pa = empty($a['paulistas']) ? 1 : 0;
        $pb = empty($b['paulistas']) ? 1 : 0;
        return $pa === $pb ? strcmp($a['hora'] ?? '', $b['hora'] ?? '') : $pa - $pb;
    });
    return $lista;
}

/* ---------- Home: faixa "Paulistas pelo mundo" ---------- */

function tsp_bloco_pelo_mundo()
{
    $jog = tsp_pm_jogadores();
    if (!$jog) {
        return;
    }
    $q = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true,
        'tax_query' => array(array('taxonomy' => 'campeonato', 'field' => 'slug', 'terms' => array('futebol-internacional')))));
    $hoje = wp_date('Y-m-d');
    $jogos = tsp_pm_ordena_jogos(tsp_pm_jogos_dia($hoje));
    echo '<section class="tsp-secao tsp-pm-home" id="paulistas-pelo-mundo">';
    echo '<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Paulistas pelo mundo</h2><span class="tsp-secao__sub">Quem saiu do futebol paulista e brilha lá fora</span></div>';
    echo '<span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/campeonato/futebol-internacional/')) . '">Futebol internacional →</a></span></div>';
    echo '<div class="tsp-pm-home__grade"><div class="tsp-pm-home__cards">';
    if ($q->have_posts()) {
        foreach ($q->posts as $p) {
            tsp_card($p->ID, 'grade');
        }
    } else {
        // Sem matéria internacional ainda: os jogadores do radar
        foreach (array_slice($jog, 0, 6) as $j) {
            echo tsp_pm_card($j); // phpcs:ignore
        }
    }
    echo '</div><aside class="tsp-pm-home__jogos" aria-labelledby="pm-jogos-hoje"><div class="tsp-pm-home__jogos-cab"><h3 id="pm-jogos-hoje">Jogos de hoje no mundo</h3><span>Brasília</span></div>';
    if ($jogos) {
        echo '<ul class="tsp-pm__jogos">' . implode('', array_map('tsp_pm_jogo_li', array_slice($jogos, 0, 6))) . '</ul>'; // phpcs:ignore
        echo '<a class="tsp-vertudo" href="' . esc_url(home_url('/campeonato/futebol-internacional/#jogos-de-hoje')) . '">Todos os jogos do dia →</a>';
    } else {
        echo '<p class="tsp-vazio">Os jogos do dia nas ligas do mundo entram aqui toda manhã.</p>';
    }
    echo '<a class="tsp-pm-home__radar" href="' . esc_url(tsp_pm_url()) . '"><strong>Radar TSP</strong> ' . (int) count($jog) . ' paulistas em ' . (int) (tsp_pm_dados()['numeros']['paises'] ?? 0) . ' países →</a>';
    echo '</aside></div></section>';
}

/* ---------- Página Futebol internacional: jogos de hoje + paulistas ---------- */

function tsp_pm_hub()
{
    if (!is_tax('campeonato', 'futebol-internacional') || is_paged()) {
        return;
    }
    $dias = array('hoje' => wp_date('Y-m-d'), 'amanha' => wp_date('Y-m-d', time() + DAY_IN_SECONDS));
    echo '<div class="tsp-pm-hub"><section class="tsp-caixa tsp-pm-hub__jogos" id="jogos-de-hoje"><div class="tsp-pm-hub__cab"><h2>Jogos de hoje</h2>';
    echo '<div class="tsp-pm-hub__abas" role="tablist"><button type="button" role="tab" aria-selected="true" data-pm-dia="hoje">Hoje</button><button type="button" role="tab" aria-selected="false" data-pm-dia="amanha">Amanhã</button></div></div>';
    foreach ($dias as $k => $dia) {
        $porliga = array();
        foreach (tsp_pm_ordena_jogos(tsp_pm_jogos_dia($dia)) as $g) {
            $porliga[$g['liga'] ?? ''][] = $g;
        }
        echo '<div class="tsp-pm-hub__dia" data-pm-painel="' . esc_attr($k) . '"' . ($k === 'hoje' ? '' : ' hidden') . '>';
        if (!$porliga) {
            echo '<p class="tsp-vazio">' . ($k === 'hoje' ? 'Os jogos de hoje entram aqui toda manhã.' : 'Os jogos de amanhã entram aqui assim que a agenda for confirmada.') . '</p>';
        }
        foreach ($porliga as $liga => $lista) {
            echo '<h3><a href="' . esc_url(home_url('/campeonato/' . $liga . '/')) . '">' . esc_html(tsp_pm_liga_nome($liga)) . '</a></h3><ul class="tsp-pm__jogos">' . implode('', array_map(function ($g) {
                return tsp_pm_jogo_li($g, false);
            }, $lista)) . '</ul>'; // phpcs:ignore
        }
        echo '</div>';
    }
    echo '<p class="tsp-nota">Horário de Brasília. Atualizado todo dia de manhã, a partir das agendas da imprensa e das ligas.</p></section>';
    $jog = tsp_pm_jogadores();
    if ($jog) {
        echo '<aside class="tsp-caixa tsp-pm-hub__lado"><h2>Paulistas pelo mundo</h2><div class="tsp-pm__lista">' . implode('', array_map('tsp_pm_card', array_slice($jog, 0, 5))) . '</div>'; // phpcs:ignore
        echo '<a class="tsp-vertudo" href="' . esc_url(tsp_pm_url()) . '">Ver todos no Radar TSP →</a></aside>';
    }
    echo '</div><h2 class="tsp-pm-hub__not">Notícias</h2>';
}

/* ---------- Endereços ---------- */

add_action('init', function () {
    add_rewrite_rule('^paulistas-pelo-mundo/?$', 'index.php?tsp_pm=radar', 'top');
    add_rewrite_rule('^paulistas-pelo-mundo/([a-z0-9-]+)/?$', 'index.php?tsp_pm=$matches[1]', 'top');
    add_rewrite_rule('^tsp-mapa-pelo-mundo\.xml$', 'index.php?tsp_pm=mapa', 'top');
    if (get_option('tsp_pm_regras') !== '1') {
        flush_rewrite_rules(false);
        update_option('tsp_pm_regras', '1', true);
    }
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_pm';
    return $v;
});

function tsp_pm_seo($titulo, $desc, $url)
{
    foreach (array('pre_get_document_title', 'wpseo_title') as $f) {
        add_filter($f, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($desc) {
        return mb_substr($desc, 0, 155);
    }, 99);
    foreach (array('wpseo_canonical', 'wpseo_opengraph_url') as $f) {
        add_filter($f, function () use ($url) {
            return $url;
        }, 99);
    }
    add_filter('wpseo_robots', function () {
        return 'index, follow, max-image-preview:large';
    }, 99);
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
}

add_action('template_redirect', function () {
    $v = get_query_var('tsp_pm');
    if (!$v) {
        return;
    }
    if ($v === 'mapa') {
        tsp_pm_mapa();
        exit;
    }
    if ($v === 'radar') {
        tsp_pm_pagina_radar();
        exit;
    }
    $j = tsp_pm_jogador($v);
    if (!$j) {
        if (function_exists('tsp_404_real')) {
            tsp_404_real();
        }
        return;
    }
    tsp_pm_pagina_ficha($j);
    exit;
});

/* ---------- Página do Radar ---------- */

function tsp_pm_pagina_radar()
{
    $d = tsp_pm_dados();
    $jog = tsp_pm_jogadores();
    $n = $d['numeros'] ?? array();
    $titulo = 'Paulistas pelo mundo: os jogadores do futebol paulista que atuam no exterior';
    $resp = 'O Radar TSP acompanha ' . (int) ($n['jogadores'] ?? 0) . ' jogadores que saíram de clubes paulistas, da base ou do profissional, e hoje atuam em ' . (int) ($n['paises'] ?? 0) . ' países, de ' . (int) ($n['clubes_origem'] ?? 0) . ' clubes de origem. Cada clube atual é conferido em duas fontes e a lista é atualizada toda semana.';
    tsp_pm_seo($titulo, $resp, tsp_pm_url());
    add_action('wp_head', function () use ($jog) {
        $itens = array();
        foreach ($jog as $i => $j) {
            $itens[] = array('@type' => 'ListItem', 'position' => $i + 1, 'url' => tsp_pm_url($j['id']), 'name' => $j['nome']);
        }
        echo '<script type="application/ld+json">' . wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'Paulistas pelo mundo', 'itemListElement' => $itens), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    });
    get_header();
    echo '<main class="tsp-container tsp-pm">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <a href="' . esc_url(home_url('/campeonato/futebol-internacional/')) . '">Futebol internacional</a> › <span>Paulistas pelo mundo</span></nav>';
    echo '<header class="tsp-pm__topo"><div><span class="tsp-pm__kicker">Radar TSP</span><h1>Paulistas pelo mundo</h1>';
    echo '<p class="tsp-pm__intro">Quem saiu de um clube de São Paulo, da base ao profissional, do Real Madrid à segunda divisão da Coreia. Atualizado toda semana, sempre com fonte.</p></div>';
    echo '<dl class="tsp-pm__numeros">';
    foreach (array(array($n['jogadores'] ?? 0, 'jogadores no radar'), array($n['paises'] ?? 0, 'países'), array($n['clubes_origem'] ?? 0, 'clubes paulistas de origem'), array($n['titulos_ano'] ?? 0, 'títulos lá fora em ' . ($n['ano'] ?? wp_date('Y')))) as $x) {
        echo '<div><dt>' . esc_html($x[1]) . '</dt><dd>' . (int) $x[0] . '</dd></div>';
    }
    echo '</dl></header>';
    echo '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div>';

    // Filtros
    $origens = array();
    $paises = array();
    foreach ($jog as $j) {
        foreach ((array) $j['origem'] as $o) {
            $origens[$o['slug']] = $o['clube'] ?? $o['slug'];
        }
        $paises[$j['atual']['pais']] = ($j['atual']['bandeira'] ?? '') . ' ' . $j['atual']['pais'];
    }
    asort($origens);
    ksort($paises);
    echo '<form class="tsp-pm__filtros" onsubmit="return false" aria-label="Filtrar o radar">';
    echo '<label>Clube paulista de origem<select data-pm-f="origem"><option value="">Todos</option>';
    foreach ($origens as $s => $nome) {
        echo '<option value="' . esc_attr($s) . '">' . esc_html($nome) . '</option>';
    }
    echo '</select></label><label>País<select data-pm-f="pais"><option value="">Todos</option>';
    foreach ($paises as $p => $rot) {
        echo '<option value="' . esc_attr($p) . '">' . esc_html(trim($rot)) . '</option>';
    }
    echo '</select></label><label>Divisão<select data-pm-f="div"><option value="">Todas</option><option value="1">1ª divisão</option><option value="2">2ª divisão ou abaixo</option></select></label>';
    echo '<label>Saiu da<select data-pm-f="tipo"><option value="">Base ou profissional</option><option value="base">Base</option><option value="profissional">Profissional</option></select></label>';
    echo '<label class="tsp-pm__busca">Buscar jogador<input type="search" data-pm-f="nome" placeholder="Nome do jogador" autocomplete="off"></label></form>';

    // Destaques
    $dest = (array) ($d['destaques'] ?? array());
    $tipos = (array) ($d['tipos_destaque'] ?? array());
    echo '<section class="tsp-secao" aria-labelledby="pm-dest"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="pm-dest">Destaques da semana</h2></div></div>';
    if ($dest) {
        echo '<div class="tsp-pm__destaques">';
        foreach (array_slice($dest, 0, 6) as $x) {
            $j = tsp_pm_jogador($x['jogador'] ?? '');
            echo '<article class="tsp-pm__dest"><span class="tsp-pm__dest-tipo">' . esc_html($tipos[$x['tipo']] ?? $x['tipo']) . '</span><p>' . ($j ? '<a href="' . esc_url(tsp_pm_url($j['id'])) . '">' . esc_html($x['texto']) . '</a>' : esc_html($x['texto'])) . '</p>';
            echo '<small>Fontes: ' . implode(' e ', array_map(function ($u) {
                return '<a href="' . esc_url($u) . '" rel="nofollow noopener" target="_blank">' . esc_html(preg_replace('~^www\.~', '', (string) wp_parse_url($u, PHP_URL_HOST))) . '</a>';
            }, array_slice((array) $x['fontes'], 0, 2))) . ' · ' . esc_html(wp_date('d/m', strtotime($x['data'] . ' 12:00'))) . '</small></article>';
        }
        echo '</div>';
    } else {
        echo '<p class="tsp-vazio">Gols, títulos e transferências dos paulistas lá fora entram aqui, sempre com duas fontes.</p>';
    }
    echo '</section>';

    // Todos por país
    $por = array();
    foreach ($jog as $j) {
        $por[$j['atual']['pais']][] = $j;
    }
    ksort($por);
    echo '<section class="tsp-secao" aria-labelledby="pm-todos"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2 id="pm-todos">Todos no radar · por país</h2></div></div>';
    foreach ($por as $pais => $lista) {
        $b = $lista[0]['atual']['bandeira'] ?? '';
        echo '<div class="tsp-pm__pais" data-pm-pais="' . esc_attr($pais) . '"><h3><span aria-hidden="true">' . $b . '</span> ' . esc_html($pais) . ' <small>' . count($lista) . '</small></h3><div class="tsp-pm__lista">' . implode('', array_map('tsp_pm_card', $lista)) . '</div></div>'; // phpcs:ignore
    }
    echo '<p class="tsp-vazio tsp-pm__nada" hidden>Nenhum jogador com esses filtros ainda.</p></section>';
    echo '<aside class="tsp-pm__avise"><p><strong>Conhece um paulista jogando lá fora que não está aqui?</strong> Mande o nome, o clube e um link de notícia para a redação.</p><a class="tsp-pm__botao" href="mailto:contato@tudosobrepaulista.com.br?subject=' . rawurlencode('Radar Paulistas pelo mundo') . '">Avise a redação</a></aside>';
    echo '<p class="tsp-nota">Como apuramos: o clube atual de cada jogador é conferido em duas fontes (imprensa e anúncio oficial do clube). Entram jogadores que passaram pela base ou pelo time profissional de um clube paulista. Quem volta ao Brasil sai do radar.</p>';
    echo '</main>';
    get_footer();
}

/* ---------- Ficha do jogador ---------- */

function tsp_pm_resposta($j)
{
    $a = $j['atual'];
    $o = tsp_pm_origem($j);
    $r = $j['nome'] . (!empty($j['posicao']) ? ', ' . mb_strtolower($j['posicao']) . ',' : '') . ' ' . (($o['tipo'] ?? '') === 'base' ? 'foi revelado pelo ' : 'jogou no ') . ($o['clube'] ?? '') . (!empty($o['ate']) ? ', de onde saiu em ' . (int) $o['ate'] . ',' : '') . ' e hoje joga no ' . $a['clube'] . ', ' . (!empty($a['liga']) ? 'da ' . $a['liga'] . ' (' . $a['pais'] . ')' : 'do futebol de ' . $a['pais']) . '.';
    $ano = (string) wp_date('Y');
    foreach ((array) ($j['titulos'] ?? array()) as $t) {
        if ((string) ($t['ano'] ?? '') === $ano) {
            $r .= ' Em ' . $ano . ': ' . $t['titulo'] . '.';
            break;
        }
    }
    return $r;
}

function tsp_pm_proximo_jogo($j)
{
    $agora = wp_date('Y-m-d H:i');
    for ($i = 0; $i < 3; $i++) {
        $dia = wp_date('Y-m-d', time() + $i * DAY_IN_SECONDS);
        foreach (tsp_pm_jogos_dia($dia) as $g) {
            if (in_array($j['id'], (array) ($g['paulistas'] ?? array()), true) && $dia . ' ' . ($g['hora'] ?? '00:00') >= $agora) {
                return array($dia, $g);
            }
        }
    }
    return null;
}

function tsp_pm_pagina_ficha($j)
{
    $a = $j['atual'];
    $o = tsp_pm_origem($j);
    $titulo = $j['nome'] . ' (' . tsp_pm_ex($j) . '): clube atual, trajetória e números no exterior';
    $resp = tsp_pm_resposta($j);
    tsp_pm_seo($titulo, $resp, tsp_pm_url($j['id']));
    add_action('wp_head', function () use ($j, $a) {
        $p = array('@context' => 'https://schema.org', '@type' => 'Person', 'name' => $j['nome'], 'url' => tsp_pm_url($j['id']), 'jobTitle' => 'Jogador de futebol',
            'memberOf' => array('@type' => 'SportsTeam', 'name' => $a['clube']), 'nationality' => 'Brasil');
        if (!empty($j['nome_completo'])) {
            $p['alternateName'] = $j['nome_completo'];
        }
        if (!empty($j['nascimento'])) {
            $p['birthDate'] = $j['nascimento'];
        }
        if (!empty($j['foto']['url'])) {
            $p['image'] = $j['foto']['url'];
        }
        echo '<script type="application/ld+json">' . wp_json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    });
    get_header();
    echo '<main class="tsp-container tsp-pm tsp-pm--ficha">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <a href="' . esc_url(tsp_pm_url()) . '">Paulistas pelo mundo</a> › <span>' . esc_html($j['nome']) . '</span></nav>';
    echo '<header class="tsp-pm__ficha-cab"><figure class="tsp-pm__ficha-foto">' . tsp_pm_foto($j, 220);
    if (!empty($j['foto']['credito'])) {
        echo '<figcaption>Foto: ' . esc_html($j['foto']['credito']) . '</figcaption>';
    }
    echo '</figure><div><span class="tsp-pm__kicker">' . (($o['tipo'] ?? '') === 'base' ? 'Revelado pelo ' : 'Ex-jogador do ') . tsp_pm_link_clube($o) . (!empty($o['ate']) ? ' · saiu em ' . (int) $o['ate'] : '') . '</span>';
    echo '<h1>' . esc_html($j['nome']) . '</h1>';
    echo '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div>';
    $titulos_fora = count((array) ($j['titulos'] ?? array()));
    echo '<dl class="tsp-pm__ficha">';
    foreach (array(
        array('Posição', $j['posicao'] ?? ''),
        array('Clube atual', $a['clube'] ?? ''),
        array('País · divisão', trim(($a['bandeira'] ?? '') . ' ' . ($a['pais'] ?? '')) . (tsp_pm_div_txt($a) ? ' · ' . tsp_pm_div_txt($a) : '')),
        array('Títulos lá fora', (string) $titulos_fora),
        array('Na temporada', !empty($j['numeros']['total']) ? sprintf('%d jogos · %d gols · %d assistências', $j['numeros']['total']['jogos'], $j['numeros']['total']['gols'], $j['numeros']['total']['assistencias']) : ''),
    ) as $f) {
        echo '<div><dt>' . esc_html($f[0]) . '</dt><dd>' . esc_html($f[1] !== '' ? $f[1] : 'Em atualização') . '</dd></div>';
    }
    echo '</dl></div></header>';

    echo '<div class="tsp-pm__ficha-grade"><div class="tsp-pm__col"><section class="tsp-caixa"><h2>Trajetória: de São Paulo para o mundo</h2>';
    $traj = (array) ($j['trajetoria'] ?? array());
    if ($traj) {
        echo '<ol class="tsp-pm__traj">';
        foreach ($traj as $t) {
            $sp = ($t['pais'] ?? '') === 'Brasil';
            echo '<li class="' . ($sp ? 'is-br' : 'is-fora') . '"><span class="tsp-pm__traj-ano">' . esc_html($t['ano'] ?? '') . '</span><div><strong>' . esc_html($t['clube'] ?? '') . ($sp ? '' : ' · ' . esc_html($t['pais'] ?? '')) . '</strong>' . (!empty($t['obs']) ? '<span>' . esc_html($t['obs']) . '</span>' : '') . '</div></li>';
        }
        echo '</ol>';
    } else {
        echo '<p class="tsp-vazio">Em atualização.</p>';
    }
    if (!empty($j['titulos'])) {
        echo '<h3>Títulos lá fora</h3><ul class="tsp-pm__tit">';
        foreach ($j['titulos'] as $t) {
            echo '<li><strong>' . esc_html((string) $t['ano']) . '</strong> ' . esc_html($t['titulo']) . '</li>';
        }
        echo '</ul>';
    }
    echo '<p class="tsp-nota">Cada etapa tem fonte, listada no fim da página.</p></section>';
    echo tsp_pm_numeros_html($j);
    echo '</div><aside class="tsp-pm__ficha-lado">';

    $px = tsp_pm_proximo_jogo($j);
    echo '<section class="tsp-caixa"><h2>Próximo jogo</h2>';
    if ($px) {
        echo '<p class="tsp-pm__px"><strong>' . esc_html($px[1]['casa'] . ' x ' . $px[1]['fora']) . '</strong><span>' . esc_html(ucfirst(wp_date('l, d/m', strtotime($px[0] . ' 12:00'))) . ', ' . str_replace(':', 'h', $px[1]['hora']) . ' de Brasília · ' . tsp_pm_liga_nome($px[1]['liga'])) . '</span>' . (!empty($px[1]['tv']) ? '<small>Onde assistir: ' . esc_html($px[1]['tv']) . '</small>' : '') . '</p>';
    } else {
        echo '<p class="tsp-vazio">Em atualização.</p>';
    }
    echo '</section>';

    $q = new WP_Query(array('post_type' => 'post', 's' => $j['nome'], 'posts_per_page' => 4, 'no_found_rows' => true, 'ignore_sticky_posts' => true));
    $nots = array_filter($q->posts, function ($p) use ($j) {
        $a = tsp_pm_do_post($p->ID);
        return $a && $a['id'] === $j['id'];
    });
    echo '<section class="tsp-caixa"><h2>Notícias dele no TSP</h2>';
    if ($nots) {
        echo '<ul class="tsp-pm__nots">';
        foreach ($nots as $p) {
            echo '<li><a href="' . esc_url(get_permalink($p)) . '">' . esc_html(get_the_title($p)) . '</a> <small>' . esc_html(tsp_data_rel($p->ID)) . '</small></li>';
        }
        echo '</ul>';
    } else {
        echo '<p class="tsp-vazio">As matérias sobre ele aparecem aqui.</p>';
    }
    echo '</section>';

    $irmaos = array_values(array_filter(tsp_pm_jogadores(), function ($x) use ($j, $o) {
        return $x['id'] !== $j['id'] && in_array($o['slug'] ?? '', array_column((array) $x['origem'], 'slug'), true);
    }));
    if ($irmaos) {
        echo '<section class="tsp-caixa"><h2>Também saíram do ' . esc_html($o['clube'] ?? '') . '</h2><div class="tsp-pm__lista">' . implode('', array_map('tsp_pm_card', array_slice($irmaos, 0, 4))) . '</div></section>'; // phpcs:ignore
    }
    echo '</aside></div>';

    $fontes = array_unique(array_merge((array) ($j['fontes'] ?? array()), array_filter(array_column($traj, 'fonte')), array_filter(array_column((array) ($j['titulos'] ?? array()), 'fonte'))));
    echo '<section class="tsp-pm__fontes"><h2>Fontes</h2><ol>';
    foreach ($fontes as $u) {
        echo '<li><a href="' . esc_url($u) . '" rel="nofollow noopener" target="_blank">' . esc_html(preg_replace('~^www\.~', '', (string) wp_parse_url($u, PHP_URL_HOST))) . '</a></li>';
    }
    echo '</ol><p class="tsp-nota">Conferido em ' . esc_html(wp_date('d/m/Y', strtotime(($j['conferido'] ?? 'today') . ' 12:00'))) . '. Achou um erro? Escreva para contato@tudosobrepaulista.com.br.</p></section>';
    echo '</main>';
    get_footer();
}

/* ---------- Mapa do site ---------- */

function tsp_pm_mapa()
{
    header('Content-Type: application/xml; charset=UTF-8');
    echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>' . esc_url(tsp_pm_url()) . '</loc></url>';
    foreach (tsp_pm_jogadores() as $j) {
        echo '<url><loc>' . esc_url(tsp_pm_url($j['id'])) . '</loc>' . (!empty($j['conferido']) ? '<lastmod>' . esc_html($j['conferido']) . '</lastmod>' : '') . '</url>';
    }
    echo '</urlset>';
}
add_filter('wpseo_sitemap_index', function ($x) {
    return $x . '<sitemap><loc>' . esc_url(home_url('/tsp-mapa-pelo-mundo.xml')) . '</loc><lastmod>' . esc_html(gmdate('c')) . '</lastmod></sitemap>';
});

/* ---------- Comportamento: filtros do radar e abas Hoje/Amanhã ---------- */

add_action('wp_footer', function () {
    if (get_query_var('tsp_pm') !== 'radar' && !is_tax('campeonato', 'futebol-internacional')) {
        return;
    }
    echo "<script>(function(){var q=function(s,c){return [].slice.call((c||document).querySelectorAll(s))};"
        . "q('[data-pm-dia]').forEach(function(b){b.addEventListener('click',function(){q('[data-pm-dia]').forEach(function(x){x.setAttribute('aria-selected',x===b?'true':'false')});q('[data-pm-painel]').forEach(function(p){p.hidden=p.dataset.pmPainel!==b.dataset.pmDia})})});"
        . "var f=q('[data-pm-f]');if(!f.length)return;function sem(t){return (t||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase()}"
        . "function ap(){var v={};f.forEach(function(e){v[e.dataset.pmF]=e.value});var tot=0;q('.tsp-pm__pais').forEach(function(p){var n=0;q('.tsp-pm__card',p).forEach(function(c){var ok=(!v.origem||(' '+c.dataset.origem+' ').indexOf(' '+v.origem+' ')>-1)&&(!v.pais||c.dataset.pais===v.pais)&&(!v.div||c.dataset.div===v.div)&&(!v.tipo||(' '+c.dataset.tipo+' ').indexOf(' '+v.tipo+' ')>-1)&&(!v.nome||c.dataset.nome.indexOf(sem(v.nome))>-1);c.hidden=!ok;if(ok)n++});p.hidden=!n;tot+=n});var z=document.querySelector('.tsp-pm__nada');if(z)z.hidden=!!tot}"
        . "f.forEach(function(e){e.addEventListener(e.tagName==='INPUT'?'input':'change',ap)})})();</script>";
}, 30);
