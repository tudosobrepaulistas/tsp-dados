/* Campinho interativo do TSP (1.15.0): time base por minutagem, troca de esquema, arrastar/tocar para trocar e compartilhar. */
(function () {
  var ESQ = { // linhas de baixo (defesa) para cima (ataque), sem o goleiro
    '4-4-2': [4, 4, 2], '4-3-3': [4, 3, 3], '4-2-3-1': [4, 2, 3, 1], '4-1-4-1': [4, 1, 4, 1], '4-5-1': [4, 5, 1],
    '3-5-2': [3, 5, 2], '3-4-3': [3, 4, 3], '5-3-2': [5, 3, 2], '5-4-1': [5, 4, 1], '4-3-1-2': [4, 3, 1, 2], '3-4-1-2': [3, 4, 1, 2], '4-4-1-1': [4, 4, 1, 1]
  };
  function linhasDe(f) {
    if (ESQ[f]) return ESQ[f];
    var p = String(f).split('-').map(Number).filter(function (n) { return n > 0; });
    return p.length >= 2 ? p : ESQ['4-4-2'];
  }
  function setorDaLinha(i, total) { return i === 0 ? 'D' : (i === total - 1 ? 'A' : 'M'); }
  function ini(n) { var p = String(n).trim().split(/\s+/); return (p[0].charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : '')).toUpperCase(); }
  function curto(n) { var p = String(n).trim().split(/\s+/); return p.length > 2 ? p[0].charAt(0) + '. ' + p[p.length - 1] : n; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function iniciar(raiz) {
    var D = JSON.parse(raiz.querySelector('[data-cp-dados]').textContent);
    var J = {}; D.jogadores.forEach(function (j) { J[j.id] = j; });
    var lista = D.jogadores.slice();
    var campo = raiz.querySelector('[data-cp-campo]'), caixa = raiz.querySelector('[data-cp-lista]'), sel = raiz.querySelector('[data-cp-esquema]');
    var esquema = D.formacao, time = [], escolhido = null;

    // Time base: goleiro + cada setor com quem tem mais minutos ali; faltou, quem mais jogou e ainda está livre
    function timeBase(f) {
      var ls = linhasDe(f), usados = {}, out = [];
      function pega(setor, q) {
        var r = [];
        lista.forEach(function (j) { if (r.length < q && !usados[j.id] && j.setor === setor) { r.push(j.id); usados[j.id] = 1; } });
        return r;
      }
      var g = pega('G', 1);
      var por = { D: 0, M: 0, A: 0 }; ls.forEach(function (q, i) { por[setorDaLinha(i, ls.length)] += q; });
      var bolsa = { D: pega('D', por.D), M: pega('M', por.M), A: pega('A', por.A) };
      ['D', 'M', 'A'].forEach(function (s) {
        lista.forEach(function (j) { if (bolsa[s].length < por[s] && !usados[j.id] && j.setor !== 'G') { bolsa[s].push(j.id); usados[j.id] = 1; } });
      });
      if (!g.length) lista.forEach(function (j) { if (!g.length && !usados[j.id]) { g.push(j.id); usados[j.id] = 1; } });
      out.push(g.slice(0, 1));
      ls.forEach(function (q, i) { var s = setorDaLinha(i, ls.length); out.push(bolsa[s].splice(0, q)); });
      return out;
    }

    function cartao(id, ond) {
      var j = J[id];
      if (!j) return '<div class="tsp-cp2__jog tsp-cp2__jog--vazio" ' + ond + '><span class="tsp-cp2__foto">+</span><span class="tsp-cp2__nome">a definir</span></div>';
      var foto = j.foto ? '<img src="' + esc(j.foto) + '" alt="" loading="lazy" referrerpolicy="no-referrer" crossorigin="anonymous">' : esc(ini(j.nome));
      return '<div class="tsp-cp2__jog" draggable="true" ' + ond + ' data-id="' + esc(id) + '"><span class="tsp-cp2__foto">' + foto + '</span>'
        + (j.min ? '<span class="tsp-cp2__min">' + j.min + "'</span>" : '')
        + '<span class="tsp-cp2__nome">' + esc(curto(j.nome)) + '</span></div>';
    }

    function desenha() {
      var h = '';
      for (var li = time.length - 1; li >= 0; li--) {
        h += '<div class="tsp-cp2__linha">';
        time[li].forEach(function (id, ci) { h += cartao(id, 'data-li="' + li + '" data-ci="' + ci + '" tabindex="0" role="button" aria-label="Posição: ' + esc(J[id] ? J[id].nome : 'vazia') + '"'); });
        h += '</div>';
      }
      campo.innerHTML = h;
      var no = {}; time.forEach(function (l) { l.forEach(function (id) { no[id] = 1; }); });
      caixa.innerHTML = lista.filter(function (j) { return !no[j.id]; }).map(function (j) {
        var foto = j.foto ? '<img src="' + esc(j.foto) + '" alt="" loading="lazy" referrerpolicy="no-referrer">' : esc(ini(j.nome));
        return '<button type="button" class="tsp-cp2__op" draggable="true" data-op="' + esc(j.id) + '"><span class="tsp-cp2__foto">' + foto + '</span><span><strong>' + esc(j.nome) + '</strong><small>'
          + ({ G: 'Goleiro', D: 'Defesa', M: 'Meio', A: 'Ataque' }[j.setor] || '') + (j.min ? ' · ' + j.min + ' min' + (j.jogos ? ' em ' + j.jogos + ' j' : '') : '') + '</small></span></button>';
      }).join('');
      if (escolhido) { var e = campo.querySelector('[data-li="' + escolhido[0] + '"][data-ci="' + escolhido[1] + '"]'); if (e) e.classList.add('is-sel'); }
    }

    function troca(a, b) { // a e b: {li,ci} no campo ou {op:id}
      var ida = a.op || time[a.li][a.ci], idb = b.op || time[b.li][b.ci];
      if (!a.op) time[a.li][a.ci] = idb; if (!b.op) time[b.li][b.ci] = ida;
      escolhido = null; desenha();
    }
    function pos(el) { var c = el.closest('[data-li]'); if (c) return { li: +c.dataset.li, ci: +c.dataset.ci }; var o = el.closest('[data-op]'); return o ? { op: o.dataset.op } : null; }

    // Arrastar (computador)
    var origem = null;
    raiz.addEventListener('dragstart', function (e) { origem = pos(e.target); if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'cp'); } });
    raiz.addEventListener('dragover', function (e) { if (origem && e.target.closest('[data-li]')) { e.preventDefault(); } });
    raiz.addEventListener('drop', function (e) { var d = pos(e.target); if (origem && d && d.li !== undefined) { e.preventDefault(); if (!(origem.li === d.li && origem.ci === d.ci)) troca(origem, d); } origem = null; });
    // Tocar (celular e teclado): escolhe uma posição do campo e depois quem entra
    raiz.addEventListener('click', function (e) {
      var p = pos(e.target);
      if (!p) return;
      if (p.op) { if (escolhido) troca({ li: escolhido[0], ci: escolhido[1] }, p); else { var c = campo.querySelector('.tsp-cp2__jog--vazio'); if (c) troca({ li: +c.dataset.li, ci: +c.dataset.ci }, p); else aviso('Toque primeiro no jogador do campo que vai sair.'); } return; }
      if (escolhido) { if (escolhido[0] === p.li && escolhido[1] === p.ci) { escolhido = null; desenha(); } else troca({ li: escolhido[0], ci: escolhido[1] }, p); }
      else { escolhido = [p.li, p.ci]; desenha(); aviso('Agora toque em quem entra (no campo ou nas opções).'); }
    });
    raiz.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target.closest('[data-li]')) { e.preventDefault(); e.target.click(); } });
    var dica = raiz.querySelector('.tsp-cp2__dica'), dicaTxt = dica ? dica.textContent : '';
    function aviso(t) { if (dica) { dica.textContent = t; dica.classList.add('is-on'); clearTimeout(aviso.t); aviso.t = setTimeout(function () { dica.textContent = dicaTxt; dica.classList.remove('is-on'); }, 4000); } }

    function monta(f) { esquema = f; time = timeBase(f); escolhido = null; desenha(); }
    sel.addEventListener('change', function () { monta(sel.value); });
    raiz.querySelector('[data-cp-refazer]').addEventListener('click', function () { monta(esquema); });

    // Abas
    raiz.querySelectorAll('[data-cp-aba]').forEach(function (b) {
      b.addEventListener('click', function () {
        raiz.querySelectorAll('[data-cp-aba]').forEach(function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
        raiz.querySelectorAll('[data-cp-painel]').forEach(function (p) { p.hidden = p.dataset.cpPainel !== b.dataset.cpAba; });
      });
    });

    // Última escalação (fixa)
    var ult = raiz.querySelector('[data-cp-ultima]');
    if (ult && D.ultima) {
      var h = '';
      for (var li = D.ultima.linhas.length - 1; li >= 0; li--) {
        h += '<div class="tsp-cp2__linha">' + D.ultima.linhas[li].map(function (id) { return cartao(id, ''); }).join('').replace(/ draggable="true"/g, '') + '</div>';
      }
      ult.innerHTML = h;
    }

    // Link com o time montado (?meutime=esquema.id1.id2...) abre o time de quem compartilhou
    function codigo() { return esquema + '.' + time.map(function (l) { return l.join('.'); }).join('.'); }
    var m = location.search.match(/[?&]meutime=([^&]+)/);
    if (m) {
      var p = decodeURIComponent(m[1]).split('.'), f = p.shift(), ls = [1].concat(linhasDe(f)), ok = p.length === 11 && p.every(function (id) { return J[id]; });
      if (ok) { esquema = f; time = ls.map(function (q) { return p.splice(0, q); }); if (![].some.call(sel.options, function (o) { return o.value === f; })) sel.add(new Option(f, f)); sel.value = f; desenha(); raiz.scrollIntoView(); } else monta(esquema);
    } else monta(esquema);

    // Compartilhar: imagem do time + link
    raiz.querySelector('[data-cp-compartilhar]').addEventListener('click', function () {
      var url = (D.url || location.href.split('?')[0]).split('#')[0] + '?meutime=' + encodeURIComponent(codigo()) + '#elenco';
      var txt = 'Meu time ideal ' + D.de + ' (' + esquema + '): monte o seu no TSP';
      imagem(function (blob) {
        var arq = blob ? new File([blob], 'meu-time-tsp.png', { type: 'image/png' }) : null;
        if (navigator.share && arq && navigator.canShare && navigator.canShare({ files: [arq] })) {
          navigator.share({ files: [arq], title: txt, text: txt + ' ' + url }).catch(function () {});
        } else if (navigator.share) {
          navigator.share({ title: txt, text: txt, url: url }).catch(function () {});
        } else {
          if (blob) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'meu-time-tsp.png'; document.body.appendChild(a); a.click(); a.remove(); }
          if (navigator.clipboard) navigator.clipboard.writeText(txt + ' ' + url);
          aviso('Imagem baixada e link copiado: é só colar no WhatsApp.');
        }
      });
    });

    function imagem(fim) {
      var W = 1080, H = 1350, c = document.createElement('canvas'); c.width = W; c.height = H;
      var x = c.getContext('2d');
      if (!x) return fim(null);
      x.fillStyle = '#0B0B0B'; x.fillRect(0, 0, W, H);
      x.fillStyle = '#E18330'; x.fillRect(0, 0, W, 10);
      x.fillStyle = '#fff'; x.font = '800 54px "Barlow Condensed", Arial Narrow, sans-serif'; x.textAlign = 'center';
      x.fillText(('Meu time ideal ' + D.de).toUpperCase(), W / 2, 86);
      x.font = '600 30px Arial, sans-serif'; x.fillStyle = '#E18330'; x.fillText(esquema, W / 2, 128);
      var top = 160, ph = 1060;
      for (var i = 0; i < 10; i++) { x.fillStyle = i % 2 ? '#3E7B40' : '#468546'; x.fillRect(40, top + i * ph / 10, W - 80, ph / 10); }
      x.strokeStyle = 'rgba(255,255,255,.55)'; x.lineWidth = 4; x.strokeRect(40, top, W - 80, ph);
      x.beginPath(); x.moveTo(40, top + ph / 2); x.lineTo(W - 40, top + ph / 2); x.stroke();
      x.beginPath(); x.arc(W / 2, top + ph / 2, 110, 0, 7); x.stroke();
      x.strokeRect(W / 2 - 220, top + ph - 170, 440, 170); x.strokeRect(W / 2 - 220, top, 440, 170);
      var pontos = [], n = time.length;
      time.forEach(function (l, li) {
        var y = top + ph - 90 - li * (ph - 180) / (n - 1);
        l.forEach(function (id, ci) { pontos.push({ id: id, x: 40 + (W - 80) * (ci + 1) / (l.length + 1), y: y }); });
      });
      var falta = pontos.length;
      function desenhaUm(p, img) {
        var r = 52;
        x.save(); x.beginPath(); x.arc(p.x, p.y, r, 0, 7); x.closePath(); x.fillStyle = '#fff'; x.fill(); x.clip();
        if (img) { try { x.drawImage(img, p.x - r, p.y - r, 2 * r, 2 * r); } catch (e) { img = null; } }
        x.restore();
        if (!img) { x.fillStyle = '#1F2A44'; x.font = '800 34px Arial, sans-serif'; x.fillText(ini(J[p.id] ? J[p.id].nome : '?'), p.x, p.y + 12); }
        x.strokeStyle = '#fff'; x.lineWidth = 4; x.beginPath(); x.arc(p.x, p.y, r, 0, 7); x.stroke();
        x.fillStyle = '#fff'; x.font = '700 28px Arial, sans-serif'; x.shadowColor = 'rgba(0,0,0,.7)'; x.shadowBlur = 6;
        x.fillText(J[p.id] ? curto(J[p.id].nome) : '', p.x, p.y + r + 36); x.shadowBlur = 0;
        if (--falta === 0) {
          x.fillStyle = '#fff'; x.font = '700 30px Arial, sans-serif'; x.fillText('tudosobrepaulista.com.br · monte o seu', W / 2, H - 50);
          try { c.toBlob(function (b) { fim(b); }, 'image/png'); } catch (e) { fim(null); }
        }
      }
      pontos.forEach(function (p) {
        var j = J[p.id];
        if (!j || !j.foto) return desenhaUm(p, null);
        var im = new Image(); im.crossOrigin = 'anonymous';
        var feito = false, t = setTimeout(function () { if (!feito) { feito = true; desenhaUm(p, null); } }, 3500);
        im.onload = function () { if (!feito) { feito = true; clearTimeout(t); desenhaUm(p, im); } };
        im.onerror = function () { if (!feito) { feito = true; clearTimeout(t); desenhaUm(p, null); } };
        im.src = j.foto;
      });
    }
  }
  [].forEach.call(document.querySelectorAll('.tsp-cp2'), function (r) { try { iniciar(r); } catch (e) { if (window.console) console.warn('campinho', e); } });
})();
