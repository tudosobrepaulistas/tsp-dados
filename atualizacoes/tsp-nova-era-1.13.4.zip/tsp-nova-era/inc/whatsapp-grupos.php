<?php
/**
 * Grupos de WhatsApp do TSP por clube (22/11/2026, pedido do Thiago).
 * Toda matéria do clube (marcada no clube, no feminino/sub-20 dele, ou com o nome no título) ganha 3 pontos de contato:
 *   1) caixa depois do 1º parágrafo;  2) caixa no fim da matéria;  3) barra fixa no rodapé da tela (pode fechar).
 * A página do clube usa o link do grupo no bloco "Notícias do X no WhatsApp" e ganha a barra fixa também.
 * Para incluir um clube: acrescente o slug e o link em tsp_wg_grupos().
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_wg_grupos()
{
    return array(
        // 4 grandes: grupos abertos de resenha (26/11/2026). Antigos de notícias: palmeiras JUV2B6cKSbsDyFgOt2TWVA, santos GgL8y6IpsUPJokr9Rhjq62, corinthians B6AZGDML59K2Rp62TbP1OO, saopaulo ECVzGioROp7ExxOJ17b6Rl
        'palmeiras'   => array('url' => 'https://chat.whatsapp.com/EzSGMaz13cJIADauR9CKGC', 'tipo' => 'resenha', 'grupo' => 'TSP Resenha do Verdão', 'nome' => 'Palmeiras', 'de' => 'do', 'apelido' => 'Verdão', 'cor' => '#006437', 'titulo' => array('palmeiras', 'verdão', 'verdao')),
        'santos'      => array('url' => 'https://chat.whatsapp.com/ItHHqLXyFylCv9ZeUfJG3Z', 'tipo' => 'resenha', 'grupo' => 'TSP Resenha do Peixe', 'nome' => 'Santos', 'de' => 'do', 'apelido' => 'Peixe', 'cor' => '#111111', 'titulo' => array('santos', 'peixe')),
        'corinthians' => array('url' => 'https://chat.whatsapp.com/BiuKWexirktBsbB7xjxAnR', 'tipo' => 'resenha', 'grupo' => 'TSP Resenha do Timão', 'nome' => 'Corinthians', 'de' => 'do', 'apelido' => 'Timão', 'cor' => '#111111', 'titulo' => array('corinthians', 'timão', 'timao')),
        'saopaulo'    => array('url' => 'https://chat.whatsapp.com/FY9baz6ddvLKmjl1ieTJwy', 'tipo' => 'resenha', 'grupo' => 'TSP Resenha do Tricolor', 'nome' => 'São Paulo', 'de' => 'do', 'apelido' => 'Tricolor', 'cor' => '#C8102E', 'titulo' => array('são paulo', 'sao paulo', 'spfc')),
        // Grupos abertos de resenha (25/11/2026): Série A1 sem os 4 grandes
        'botafogosp' => array('url' => 'https://chat.whatsapp.com/KTQCicXO7b52czceB3lTYU', 'nome' => 'Botafogo-SP', 'de' => 'do', 'apelido' => 'Pantera', 'tipo' => 'resenha', 'titulo' => array('botafogo-sp', 'botafogo sp', 'pantera')),
        'capivariano' => array('url' => 'https://chat.whatsapp.com/K8cflTXma3fEqlnAGABYQZ', 'nome' => 'Capivariano', 'de' => 'do', 'apelido' => 'Leão da Sorocabana', 'tipo' => 'resenha', 'titulo' => array('capivariano')),
        'ferroviaria' => array('url' => 'https://chat.whatsapp.com/HRZkhhijoHKLAGaz3JTgDA', 'nome' => 'Ferroviária', 'de' => 'da', 'apelido' => 'Ferrinha', 'tipo' => 'resenha', 'titulo' => array('ferroviária', 'ferroviaria', 'ferrinha')),
        'guarani' => array('url' => 'https://chat.whatsapp.com/FwNoKCzCqgS5s4GOGrvv1y', 'nome' => 'Guarani', 'de' => 'do', 'apelido' => 'Bugre', 'tipo' => 'resenha', 'titulo' => array('guarani', 'bugre')),
        'juventus' => array('url' => 'https://chat.whatsapp.com/KJ7Vbt7LioQ899QSGo79UC', 'nome' => 'Juventus', 'de' => 'do', 'apelido' => 'Moleque Travesso', 'tipo' => 'resenha', 'titulo' => array('moleque travesso')),
        'mirassol' => array('url' => 'https://chat.whatsapp.com/G8WRSCNkxGcLo2hWdrQ7XG', 'nome' => 'Mirassol', 'de' => 'do', 'apelido' => 'Leão', 'tipo' => 'resenha', 'titulo' => array('mirassol')),
        'noroeste' => array('url' => 'https://chat.whatsapp.com/DlLhdzBwu23HyMMupKlmF7', 'nome' => 'Noroeste', 'de' => 'do', 'apelido' => 'Norusca', 'tipo' => 'resenha', 'titulo' => array('norusca')),
        'novorizontino' => array('url' => 'https://chat.whatsapp.com/FfvfZ4ftT5h41FDFDuy6Ll', 'nome' => 'Novorizontino', 'de' => 'do', 'apelido' => 'Tigre', 'tipo' => 'resenha', 'titulo' => array('novorizontino')),
        'portuguesa' => array('url' => 'https://chat.whatsapp.com/Bi4Z6jX5npoEJRdEFn9rkU', 'nome' => 'Portuguesa', 'de' => 'da', 'apelido' => 'Lusa', 'tipo' => 'resenha', 'titulo' => array('portuguesa', 'lusa'), 'nao' => array('santista')),
        'primavera' => array('url' => 'https://chat.whatsapp.com/IdLNDVreTnkEPeSdKPWmyd', 'nome' => 'Primavera', 'de' => 'do', 'apelido' => 'Primavera', 'tipo' => 'resenha', 'titulo' => array()),
        'bragantino' => array('url' => 'https://chat.whatsapp.com/KjcL30DQptEKcAtC5P5nCn', 'nome' => 'Red Bull Bragantino', 'de' => 'do', 'apelido' => 'Massa Bruta', 'tipo' => 'resenha', 'titulo' => array('bragantino', 'massa bruta')),
        'saobernardo' => array('url' => 'https://chat.whatsapp.com/EHApD4em8v17QHZFSGwcs6', 'nome' => 'São Bernardo', 'de' => 'do', 'apelido' => 'Tigre do ABC', 'tipo' => 'resenha', 'titulo' => array('são bernardo', 'sao bernardo'), 'nao' => array('ec são bernardo', 'e.c. são bernardo', 'esporte clube são bernardo')),
        // Série A2 2027 (25/11/2026)
        'aguasanta' => array('url' => 'https://chat.whatsapp.com/EQpwiaELCMtDiigvd1Gu7B', 'nome' => 'Água Santa', 'de' => 'do', 'apelido' => 'Netuno', 'tipo' => 'resenha', 'titulo' => array('água santa', 'agua santa')),
        'interdelimeira' => array('url' => 'https://chat.whatsapp.com/J7gFRK3tEcsCexwjqi0H5e', 'nome' => 'Inter de Limeira', 'de' => 'da', 'apelido' => 'Leão da Paulista', 'tipo' => 'resenha', 'titulo' => array('inter de limeira')),
        'ituano' => array('url' => 'https://chat.whatsapp.com/IliLM1l9jd1FFgQbgy8upS', 'nome' => 'Ituano', 'de' => 'do', 'apelido' => 'Galo de Itu', 'tipo' => 'resenha', 'titulo' => array('ituano')),
        'linense' => array('url' => 'https://chat.whatsapp.com/EhaIncXylao6zFWBLVnBTx', 'nome' => 'Linense', 'de' => 'do', 'apelido' => 'Elefante', 'tipo' => 'resenha', 'titulo' => array('linense')),
        'marilia' => array('url' => 'https://chat.whatsapp.com/IFUhJhZBMJcES2JvzgWsib', 'nome' => 'Marília', 'de' => 'do', 'apelido' => 'MAC', 'tipo' => 'resenha', 'titulo' => array('marília', 'marilia')),
        'monteazul' => array('url' => 'https://chat.whatsapp.com/KfQz2c8GZnT75khjpQ8WEp', 'nome' => 'Monte Azul', 'de' => 'do', 'apelido' => 'Azulão', 'tipo' => 'resenha', 'titulo' => array('monte azul')),
        'osasco-sporting' => array('url' => 'https://chat.whatsapp.com/Eax82uIh0OpDgH78AyUq3W', 'nome' => 'Osasco Sporting', 'de' => 'do', 'apelido' => 'Osasco Sporting', 'tipo' => 'resenha', 'titulo' => array('osasco sporting')),
        'pontepreta' => array('url' => 'https://chat.whatsapp.com/HLIZRP91eFvCpz2d4xyIXn', 'nome' => 'Ponte Preta', 'de' => 'da', 'apelido' => 'Macaca', 'tipo' => 'resenha', 'titulo' => array('ponte preta', 'macaca')),
        'portuguesasantista' => array('url' => 'https://chat.whatsapp.com/HWO2FcishRf8PqitApu4FS', 'nome' => 'Portuguesa Santista', 'de' => 'da', 'apelido' => 'Briosa', 'tipo' => 'resenha', 'titulo' => array('portuguesa santista', 'briosa')),
        'santoandre' => array('url' => 'https://chat.whatsapp.com/EjKyA8UVVY10EgJJ6D3cyp', 'nome' => 'Santo André', 'de' => 'do', 'apelido' => 'Ramalhão', 'tipo' => 'resenha', 'titulo' => array('santo andré', 'santo andre', 'ramalhão')),
        'saojose' => array('url' => 'https://chat.whatsapp.com/EbZXwksj3yc08fSrlWzUmA', 'nome' => 'São José', 'de' => 'do', 'apelido' => 'Águia do Vale', 'tipo' => 'resenha', 'titulo' => array('são josé', 'sao jose'), 'nao' => array('são josé-rs', 'são josé dos pinhais', 'são josé-sc')),
        'sertaozinho' => array('url' => 'https://chat.whatsapp.com/FjGDBzYnGlm0Jyvs4Y9hD4', 'nome' => 'Sertãozinho', 'de' => 'do', 'apelido' => 'Touro dos Canaviais', 'tipo' => 'resenha', 'titulo' => array('sertãozinho', 'sertaozinho')),
        'taubate' => array('url' => 'https://chat.whatsapp.com/CLbyPlhtMb0GH7uomiRNeu', 'nome' => 'Taubaté', 'de' => 'do', 'apelido' => 'Burro da Central', 'tipo' => 'resenha', 'titulo' => array('taubaté', 'taubate')),
        'veloclube' => array('url' => 'https://chat.whatsapp.com/JJnU5NIxLDKFBxzr2HdR3c', 'nome' => 'Velo Clube', 'de' => 'do', 'apelido' => 'Rubro-Verde', 'tipo' => 'resenha', 'titulo' => array('velo clube')),
        'votuporanguense' => array('url' => 'https://chat.whatsapp.com/CjGPOWgfaLWF8lt9q7SfGL', 'nome' => 'Votuporanguense', 'de' => 'do', 'apelido' => 'CAV', 'tipo' => 'resenha', 'titulo' => array('votuporanguense')),
        'xvdepiracicaba' => array('url' => 'https://chat.whatsapp.com/J1mrnD2NaOiKy9X71a4XUw', 'nome' => 'XV de Piracicaba', 'de' => 'do', 'apelido' => 'Nhô Quim', 'tipo' => 'resenha', 'titulo' => array('xv de piracicaba', 'nhô quim')),
    );
}

// Feminino e Sub-20 levam ao grupo do clube principal
function tsp_wg_do_slug($slug)
{
    $g = tsp_wg_grupos();
    $base = preg_replace('/-(feminino|sub-\d+|b|ii)$/', '', (string) $slug);
    $apel = array('sao-paulo' => 'saopaulo', 'red-bull-bragantino' => 'bragantino', 'sao-bernardo' => 'saobernardo', 'botafogo-sp' => 'botafogosp');
    $base = isset($apel[$base]) ? $apel[$base] : $base;
    if (!isset($g[$base])) {
        // sub-20 com hífen (xv-de-piracicaba-sub-20 -> xvdepiracicaba)
        $sem = str_replace(array('-', 'piracaba'), array('', 'piracicaba'), $base);
        foreach (array_keys($g) as $k) {
            if (str_replace('-', '', $k) === $sem) {
                $base = $k;
                break;
            }
        }
    }
    return isset($g[$base]) ? array_merge($g[$base], array('slug' => $base)) : null;
}

// Grupos da matéria: clubes marcados primeiro; se nenhum, nome do clube no título
function tsp_wg_do_post($post_id)
{
    static $cache = array();
    if (isset($cache[$post_id])) {
        return $cache[$post_id];
    }
    $achou = array();
    $termos = taxonomy_exists('times') ? wp_get_post_terms($post_id, 'times') : array();
    if (!is_wp_error($termos)) {
        foreach ($termos as $t) {
            $g = tsp_wg_do_slug($t->slug);
            if ($g) {
                $achou[$g['slug']] = $g;
            }
        }
    }
    if (!$achou) {
        $tit = mb_strtolower(get_the_title($post_id));
        foreach (tsp_wg_grupos() as $slug => $g) {
            if (!empty($g['nao'])) {
                foreach ($g['nao'] as $n) {
                    if (mb_strpos($tit, $n) !== false) {
                        continue 2;
                    }
                }
            }
            foreach ($g['titulo'] as $w) {
                if (preg_match('/(^|[^\p{L}])' . preg_quote($w, '/') . '([^\p{L}]|$)/u', $tit)) {
                    $achou[$slug] = array_merge($g, array('slug' => $slug));
                    break;
                }
            }
        }
    }
    return $cache[$post_id] = array_values($achou);
}

// Nome do grupo sem o "TSP " (ex.: "Resenha do Timão", "Guarani - Resenha")
function tsp_wg_nome_curto($g)
{
    if (!empty($g['grupo'])) {
        return preg_replace('/^TSP\s+/', '', $g['grupo']);
    }
    return 'grupo ' . $g['de'] . ' ' . $g['nome'];
}

// Grupo do clube da página que está aberta (matéria ou página do clube)
function tsp_wg_atual()
{
    static $g = false;
    if ($g !== false) {
        return $g;
    }
    $g = null;
    if (is_singular(tsp_tipos())) {
        $gs = tsp_wg_do_post(get_queried_object_id());
        $g = $gs ? $gs[0] : null;
    } elseif (is_tax('times')) {
        $g = tsp_wg_do_slug(get_queried_object()->slug);
    }
    return $g;
}

// Chamada curta logo abaixo do título da matéria (aparece na primeira tela do celular)
function tsp_wg_pilula($post_id)
{
    $gs = tsp_wg_do_post($post_id);
    if (!$gs) {
        return '';
    }
    $g = $gs[0];
    $nome = !empty($g['grupo']) ? tsp_wg_nome_curto($g) : 'grupo aberto ' . $g['de'] . ' ' . $g['nome'];
    return '<a class="tsp-wg-pilula" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug'] . '-pilula') . '">'
        . '<span class="tsp-wg__ico">' . tsp_wg_ico(18) . '</span><span>Torcedor ' . esc_html($g['de'] . ' ' . $g['nome']) . '? Entre na <b>' . esc_html($nome) . '</b> no WhatsApp</span><span class="tsp-wg-pilula__bt">Entrar</span></a>';
}

function tsp_wg_ico($tam = 26)
{
    return '<svg viewBox="0 0 24 24" width="' . (int) $tam . '" height="' . (int) $tam . '" aria-hidden="true"><path fill="currentColor" d="M17.5 14.4c-.3-.1-1.8-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.1-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.4-.5c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3zM12 21.8c-1.8 0-3.5-.5-5-1.4l-.4-.2-3.7 1 1-3.6-.2-.4c-1-1.6-1.5-3.4-1.5-5.2C2.2 6.6 6.6 2.2 12 2.2c2.6 0 5.1 1 6.9 2.9 1.9 1.9 2.9 4.3 2.9 6.9 0 5.4-4.4 9.8-9.8 9.8zm8.4-18.2C18.2 1.3 15.2 0 12 0 5.5 0 .1 5.3.1 11.9c0 2.1.5 4.1 1.6 5.9L0 24l6.3-1.7c1.7.9 3.7 1.4 5.7 1.4 6.6 0 11.9-5.3 11.9-11.9 0-3.2-1.2-6.2-3.5-8.2z"/></svg>';
}

// Caixa (lugar: topo | fim | clube)
function tsp_wg_caixa($g, $lugar = 'topo')
{
    $quem = $g['de'] . ' ' . $g['nome'];
    if (!empty($g['tipo']) && $g['tipo'] === 'resenha') {
        // Grupo aberto: a torcida conversa entre si (25/11/2026)
        $nomeg = !empty($g['grupo']) ? tsp_wg_nome_curto($g) : 'grupo aberto ' . $quem;
        $na = !empty($g['grupo']) ? 'na ' : 'no ';
        if ($lugar === 'fim') {
            $tit = 'Entre ' . $na . $nomeg . ' no WhatsApp';
            $sub = 'Resenha da torcida ' . $quem . ' organizada pelo TSP: jogo, escalação, mercado e opinião. Grátis e com regras de respeito.';
        } elseif ($lugar === 'clube') {
            $tit = ucfirst($nomeg) . ' no WhatsApp';
            $sub = 'Converse com outros torcedores ' . $quem . ' sobre jogo, escalação e mercado. Grátis, organizado pelo TSP.';
        } else {
            $tit = 'Torcedor ' . $quem . ': entre ' . $na . $nomeg;
            $sub = 'Grupo grátis no WhatsApp, organizado pelo Tudo Sobre Paulista, para a torcida ' . $quem . ' conversar sobre o time.';
        }
        return '<aside class="tsp-wg tsp-wg--' . esc_attr($lugar) . '" aria-label="Grupo aberto ' . esc_attr($quem) . ' no WhatsApp">'
            . '<span class="tsp-wg__ico">' . tsp_wg_ico() . '</span>'
            . '<div class="tsp-wg__txt"><strong>' . esc_html($tit) . '</strong><span>' . esc_html($sub) . '</span></div>'
            . '<a class="tsp-wg__bt" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug'] . '-' . $lugar) . '">Entrar no grupo aberto</a></aside>';
    }
    if ($lugar === 'fim') {
        $tit = 'Torcedor ' . $quem . ': receba as notícias em primeira mão';
        $sub = 'Entre grátis no grupo do TSP no WhatsApp. Escalação, bastidores, mercado e resultado do ' . $g['apelido'] . ' direto no seu celular.';
    } elseif ($lugar === 'clube') {
        $tit = 'Grupo ' . $quem . ' no WhatsApp: grátis';
        $sub = 'Receba em primeira mão as matérias do ' . $g['apelido'] . ': escalação, bastidores, mercado e coletivas.';
    } else {
        $tit = 'Notícias ' . $quem . ' em primeira mão no WhatsApp';
        $sub = 'Grupo gratuito do Tudo Sobre Paulista. Entre e receba as matérias do seu time do coração.';
    }
    return '<aside class="tsp-wg tsp-wg--' . esc_attr($lugar) . '" aria-label="Grupo ' . esc_attr($quem) . ' no WhatsApp">'
        . '<span class="tsp-wg__ico">' . tsp_wg_ico() . '</span>'
        . '<div class="tsp-wg__txt"><strong>' . esc_html($tit) . '</strong><span>' . esc_html($sub) . '</span></div>'
        . '<a class="tsp-wg__bt" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug'] . '-' . $lugar) . '">Entrar grátis no grupo</a></aside>';
}

// Pontos 1 e 2: depois do 1º parágrafo e no fim da matéria
add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $html;
    }
    $gs = tsp_wg_do_post(get_the_ID());
    if (!$gs) {
        return $html;
    }
    $p = stripos($html, '</p>');
    $topo = tsp_wg_caixa($gs[0], 'topo');
    $html = $p !== false ? substr($html, 0, $p + 4) . $topo . substr($html, $p + 4) : $topo . $html;
    foreach ($gs as $g) {
        $html .= tsp_wg_caixa($g, 'fim');
    }
    return $html;
}, 12);

// Ponto 3: barra fixa (matéria e página do clube). Aparece logo no começo da leitura, fica acima do aviso de
// cookies, some por 1 dia se a pessoa fechar e por 30 dias depois que ela toca em "Entrar" em qualquer chamada.
add_action('wp_footer', function () {
    $g = tsp_wg_atual();
    if (!$g) {
        return;
    }
    $rot = !empty($g['grupo']) ? '<b>' . esc_html(tsp_wg_nome_curto($g)) . '</b> no WhatsApp' : '<b>Grupo aberto ' . esc_html($g['de'] . ' ' . $g['nome']) . '</b> no WhatsApp';
    echo '<div class="tsp-wg-barra" id="tsp-wg-barra" hidden><a href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug']) . '-barra">'
        . '<span class="tsp-wg__ico">' . tsp_wg_ico(22) . '</span><span>' . $rot . ' · grátis</span><span class="tsp-wg-barra__bt">Entrar</span></a>' // phpcs:ignore
        . '<button type="button" class="tsp-wg-barra__x" aria-label="Fechar">×</button></div>';
    echo "<script>(function(){var b=document.getElementById('tsp-wg-barra');if(!b)return;var ls=window.localStorage,agora=Date.now();"
        . "function ok(k){try{return +(ls.getItem(k)||0)>agora}catch(e){return false}}function por(k,d){try{ls.setItem(k,agora+d*864e5)}catch(e){}}"
        . "if(ok('tsp_wg_entrou')||ok('tsp_wg_x'))return;"
        . "function sobe(){var c=document.querySelector('#cookie-notice.cookie-notice-visible,#cookie-notice:not(.cookie-notice-hidden)');var h=0;if(c&&c.offsetHeight&&getComputedStyle(c).display!=='none'&&getComputedStyle(c).visibility!=='hidden')h=c.offsetHeight;b.style.bottom=(h+12)+'px'}"
        . "var s=function(){if(window.scrollY>250){b.hidden=false;sobe();window.removeEventListener('scroll',s)}};window.addEventListener('scroll',s,{passive:true});setInterval(function(){if(!b.hidden)sobe()},1500);"
        . "b.querySelector('.tsp-wg-barra__x').addEventListener('click',function(){b.hidden=true;por('tsp_wg_x',1)});"
        . "document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-tsp-wg]');if(a){por('tsp_wg_entrou',30);b.hidden=true}});})();</script>";
}, 20);

// Medição no Analytics e no Google Ads (conversão "Entrada no grupo WhatsApp (clique)", 26/11/2026): clique em grupo de WhatsApp (clube + posição) e clique em produto de afiliado (loja + clube)
add_action('wp_footer', function () {
    $g = function_exists('tsp_wg_atual') ? tsp_wg_atual() : null;
    $clube = $g ? $g['slug'] : '';
    echo "<script>(function(){var c=" . wp_json_encode($clube) . ";document.addEventListener('click',function(e){if(!window.gtag||!e.target.closest)return;"
        . "var a=e.target.closest('[data-tsp-wg]');if(a){var d=a.getAttribute('data-tsp-wg'),i=d.lastIndexOf('-');gtag('event','whatsapp_grupo',{clube:i>0?d.slice(0,i):d,posicao:i>0?d.slice(i+1):'',link_url:a.href});gtag('event','conversion',{send_to:'AW-11427933986/hgj5CMTG2b8dEKLeockq',value:1.0,currency:'BRL'});return}"
        . "var o=e.target.closest('a[href*=\"shopee\"],a[href*=\"meli.la\"],a[href*=\"mercadolivre\"],a[href*=\"amzn\"],a[href*=\"amazon.com\"]');"
        . "if(o){var box=o.closest('[class*=tsp-ofertas--]');var pos=box?(box.className.match(/tsp-ofertas--([a-z]+)/)||[])[1]||'':'';var loja=/shopee/.test(o.href)?'shopee':/meli|mercadolivre/.test(o.href)?'mercadolivre':'amazon';"
        . "gtag('event','clique_oferta',{loja:loja,clube:c,posicao:pos,link_url:o.href})}},true)})();</script>";
}, 21);

// 27/11/2026 (Thiago: "botões de grupos de WhatsApp abertos dos clubes, de forma sutil"): faixa discreta no pé dos blocos da home.
// Recebe slugs da taxonomia "times"; mostra só os clubes que têm grupo.
function tsp_wg_faixa($slugs, $rotulo = 'Grupos abertos no WhatsApp')
{
    $itens = array();
    foreach ((array) $slugs as $s) {
        $g = tsp_wg_do_slug($s);
        if (!$g || isset($itens[$g['slug']])) {
            continue;
        }
        $t = get_term_by('slug', $s, 'times');
        $esc = ($t && function_exists('tsp_escudo')) ? tsp_escudo($t, 18) : '';
        $itens[$g['slug']] = '<a class="tsp-wg-chip" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug'] . '-home') . '" title="' . esc_attr('Entrar no grupo ' . $g['de'] . ' ' . $g['nome'] . ' no WhatsApp') . '">' . $esc . '<span>' . esc_html($g['apelido'] ?? $g['nome']) . '</span></a>';
    }
    if (!$itens) {
        return;
    }
    echo '<div class="tsp-wg-faixa"><span class="tsp-wg-faixa__rot">' . tsp_wg_ico(14) . ' ' . esc_html($rotulo) . '</span>' . implode('', $itens) . '</div>';
}
