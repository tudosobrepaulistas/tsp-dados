<?php
/**
 * Cobertura especial da home (27/11/2026, pedido do Thiago: final da Libertadores Palmeiras x Estudiantes, 28/11).
 * Ligada pelo arquivo api/especial.json do repositório (baixado como o manchete.json), entre "de" e "ate":
 * {"de": "2026-11-28T00:00:00-03:00", "ate": "2026-11-29T06:00:00-03:00",
 *  "titulo": "Final da Libertadores · Palmeiras x Estudiantes", "sub": "Cobertura especial do TSP",
 *  "clube": "palmeiras", "rival": "Estudiantes", "extra": 8}
 *  - Topo: 4 notícias alternando clube e rival (clube, rival, clube, rival).
 *  - Embaixo: todas as outras notícias recentes do clube (masculino), até "extra".
 *  - Enquanto está ativa, o clube sai do bloco do Brasileirão e das coletivas da Série A (tudo dele fica aqui).
 * Matéria do rival = título com o nome do rival antes do nome do clube (ou sem o clube).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_especial_ativa()
{
    static $e = false;
    if ($e !== false) {
        return $e;
    }
    $e = null;
    if (!function_exists('tsp_mc_arquivo')) {
        return $e;
    }
    $d = tsp_mc_arquivo('especial.json');
    if (empty($d['clube']) || empty($d['de']) || empty($d['ate'])) {
        return $e;
    }
    $agora = time();
    if ($agora >= strtotime($d['de']) && $agora < strtotime($d['ate'])) {
        $e = $d;
    }
    return $e;
}

function tsp_especial_e_rival($pid, $clube_nome, $rival)
{
    $t = mb_strtolower(html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8'));
    $pr = mb_strpos($t, mb_strtolower($rival));
    if ($pr === false) {
        return false;
    }
    $pc = mb_strpos($t, mb_strtolower($clube_nome));
    return $pc === false || $pr < $pc;
}

// Separa as matérias: [topo alternado, resto do clube]
function tsp_especial_ids($e, &$vistos)
{
    $clube = (string) $e['clube'];
    $t = get_term_by('slug', $clube, 'times');
    $nome = $t ? $t->name : ucfirst($clube);
    $rival = (string) ($e['rival'] ?? '');
    $extra = max(0, (int) ($e['extra'] ?? 8));
    $do_clube = $do_rival = array();
    foreach (tsp_consulta(array('posts_per_page' => 40, 'tax_query' => tsp_tax_times(array($clube))), $vistos) as $p) {
        if ($rival && tsp_especial_e_rival($p->ID, $nome, $rival)) {
            $do_rival[] = $p->ID;
        } else {
            $do_clube[] = $p->ID;
        }
    }
    if ($rival) {
        // matérias do rival que não estão marcadas no clube
        $ja = array_merge($vistos, $do_clube, $do_rival);
        foreach (tsp_consulta(array('posts_per_page' => 10, 's' => $rival, 'date_query' => array(array('after' => '5 days ago'))), $ja) as $p) {
            if (tsp_especial_e_rival($p->ID, $nome, $rival)) {
                $do_rival[] = $p->ID;
            }
        }
        $do_rival = array_values(array_unique($do_rival));
        usort($do_rival, function ($a, $b) {
            return strcmp(get_post_field('post_date', $b), get_post_field('post_date', $a));
        });
    }
    // Topo: clube, rival, clube, rival (se faltar um lado, completa com o outro)
    $topo = array();
    $c = $do_clube;
    $r = $do_rival;
    for ($i = 0; $i < 4; $i++) {
        $quer_rival = ($i % 2 === 1);
        if ($quer_rival && $r) {
            $topo[] = array_shift($r);
        } elseif (!$quer_rival && $c) {
            $topo[] = array_shift($c);
        } elseif ($r) {
            $topo[] = array_shift($r);
        } elseif ($c) {
            $topo[] = array_shift($c);
        }
    }
    $resto = array_slice(array_merge($c, $r), 0, $extra);
    usort($resto, function ($a, $b) {
        return strcmp(get_post_field('post_date', $b), get_post_field('post_date', $a));
    });
    $vistos = array_merge($vistos, $topo, $resto);
    return array($topo, $resto, $nome);
}

function tsp_bloco_especial($e, $topo, $resto, $nome)
{
    if (!$topo) {
        return;
    }
    echo '<section class="tsp-secao tsp-secao--caixa tsp-secao--especial" id="especial" aria-labelledby="h-especial">';
    tsp_secao_cab((string) ($e['titulo'] ?? 'Cobertura especial'), '', array((string) $e['clube'] => $nome), (string) ($e['sub'] ?? 'Cobertura especial do TSP'), 'h-especial', true);
    tsp_layout_b($topo); // 1 grande (clube) + 3 ao lado (rival, clube, rival)
    if ($resto) {
        echo '<div class="tsp-grade tsp-grade--5">';
        foreach ($resto as $id) {
            tsp_card($id, 'grade');
        }
        echo '</div>';
    }
    if (function_exists('tsp_wg_faixa')) {
        tsp_wg_faixa(array((string) $e['clube']));
    }
    echo '</section>';
}
