<?php
/**
 * Futebol internacional (27/11/2026, pedido do Thiago): menu "Internacional" com as principais ligas, para atrair quem
 * acompanha esses campeonatos. As matérias NÃO aparecem na home: só no menu e nas páginas /campeonato/<liga>/.
 * Cada liga é um termo da classificação "Campeonatos" (criado sozinho). Ao salvar uma matéria com uma liga,
 * ela ganha também "futebol-internacional" (e "futebol-sul-americano" nas ligas da América do Sul),
 * que é o termo usado para tirá-la da home.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_INT_GERAL = 'futebol-internacional';
const TSP_INT_SUL = 'futebol-sul-americano';

// slug => [menu, nome da página, bandeira, descrição]
function tsp_int_ligas()
{
    return array(
        'campeonato-italiano'   => array('Italiano', 'Campeonato Italiano (Serie A)', '🇮🇹', 'Notícias do Campeonato Italiano: Inter, Milan, Juventus, Napoli, Roma e os brasileiros na Serie A.'),
        'campeonato-ingles'     => array('Inglês', 'Campeonato Inglês (Premier League)', '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'Notícias da Premier League: Manchester City, Arsenal, Liverpool, Chelsea, United e os brasileiros na Inglaterra.'),
        'campeonato-espanhol'   => array('Espanhol', 'Campeonato Espanhol (LaLiga)', '🇪🇸', 'Notícias de LaLiga: Real Madrid, Barcelona, Atlético de Madrid e os brasileiros na Espanha.'),
        'campeonato-frances'    => array('Francês', 'Campeonato Francês (Ligue 1)', '🇫🇷', 'Notícias da Ligue 1: PSG, Olympique de Marselha, Lyon, Monaco e os brasileiros na França.'),
        'campeonato-portugues'  => array('Português', 'Campeonato Português (Liga Portugal)', '🇵🇹', 'Notícias da Liga Portugal: Benfica, Porto, Sporting, Braga e os brasileiros em Portugal.'),
        'campeonato-holandes'   => array('Holandês', 'Campeonato Holandês (Eredivisie)', '🇳🇱', 'Notícias da Eredivisie: Ajax, PSV, Feyenoord e os brasileiros na Holanda.'),
        TSP_INT_SUL             => array('América do Sul', 'Futebol sul-americano', '🌎', 'Notícias dos campeonatos da América do Sul: Argentina, Uruguai, Chile, Colômbia, Paraguai, Peru, Equador, Bolívia e Venezuela.'),
        'campeonato-mexicano'   => array('Mexicano', 'Campeonato Mexicano (Liga MX)', '🇲🇽', 'Notícias da Liga MX: América, Chivas, Cruz Azul, Tigres, Monterrey e os brasileiros no México.'),
    );
}

function tsp_int_sul()
{
    return array(
        'campeonato-argentino'   => array('Argentina', 'Campeonato Argentino', '🇦🇷', 'Notícias do Campeonato Argentino: Boca Juniors, River Plate, Racing, Independiente, Estudiantes e San Lorenzo.'),
        'campeonato-uruguaio'    => array('Uruguai', 'Campeonato Uruguaio', '🇺🇾', 'Notícias do Campeonato Uruguaio: Peñarol, Nacional e os outros clubes do Uruguai.'),
        'campeonato-chileno'     => array('Chile', 'Campeonato Chileno', '🇨🇱', 'Notícias do Campeonato Chileno: Colo-Colo, Universidad de Chile, Universidad Católica e mais.'),
        'campeonato-colombiano'  => array('Colômbia', 'Campeonato Colombiano', '🇨🇴', 'Notícias do Campeonato Colombiano: Atlético Nacional, Millonarios, América de Cali, Junior e mais.'),
        'campeonato-paraguaio'   => array('Paraguai', 'Campeonato Paraguaio', '🇵🇾', 'Notícias do Campeonato Paraguaio: Olimpia, Cerro Porteño, Libertad e mais.'),
        'campeonato-peruano'     => array('Peru', 'Campeonato Peruano', '🇵🇪', 'Notícias do Campeonato Peruano: Alianza Lima, Universitario, Sporting Cristal e mais.'),
        'campeonato-equatoriano' => array('Equador', 'Campeonato Equatoriano', '🇪🇨', 'Notícias do Campeonato Equatoriano: LDU, Barcelona de Guayaquil, Independiente del Valle, Emelec e mais.'),
        'campeonato-boliviano'   => array('Bolívia', 'Campeonato Boliviano', '🇧🇴', 'Notícias do Campeonato Boliviano: Bolívar, The Strongest e mais.'),
        'campeonato-venezuelano' => array('Venezuela', 'Campeonato Venezuelano', '🇻🇪', 'Notícias do Campeonato Venezuelano.'),
    );
}

// Cria os termos uma vez (e de novo se a lista mudar)
add_action('init', function () {
    if (!taxonomy_exists('campeonato')) {
        return;
    }
    $todas = array(TSP_INT_GERAL => array('Internacional', 'Futebol internacional', '🌍', 'Notícias do futebol internacional: Campeonato Italiano, Inglês, Espanhol, Francês, Português, Holandês, Mexicano e os campeonatos da América do Sul.')) + tsp_int_ligas() + tsp_int_sul();
    $versao = md5(wp_json_encode(array_keys($todas)));
    if (get_option('tsp_int_termos') === $versao) {
        return;
    }
    foreach ($todas as $slug => $l) {
        if (!term_exists($slug, 'campeonato')) {
            wp_insert_term($l[1], 'campeonato', array('slug' => $slug, 'description' => $l[3]));
        }
    }
    update_option('tsp_int_termos', $versao, false);
}, 30);

// Matéria com liga ganha o termo geral (e o sul-americano), usado para tirar da home
add_action('set_object_terms', function ($post_id, $terms, $tt_ids, $taxonomy) {
    static $rodando = false;
    if ($rodando || $taxonomy !== 'campeonato') {
        return;
    }
    $slugs = wp_get_object_terms($post_id, 'campeonato', array('fields' => 'slugs'));
    if (is_wp_error($slugs)) {
        return;
    }
    $ligas = array_keys(tsp_int_ligas() + tsp_int_sul());
    $add = array();
    if (array_intersect($slugs, $ligas) && !in_array(TSP_INT_GERAL, $slugs, true)) {
        $add[] = TSP_INT_GERAL;
    }
    if (array_intersect($slugs, array_keys(tsp_int_sul())) && !in_array(TSP_INT_SUL, $slugs, true)) {
        $add[] = TSP_INT_SUL;
    }
    if ($add) {
        $rodando = true;
        wp_set_object_terms($post_id, $add, 'campeonato', true);
        $rodando = false;
    }
}, 10, 4);

function tsp_int_e_internacional($post_id)
{
    return has_term(array_merge(array(TSP_INT_GERAL), array_keys(tsp_int_ligas() + tsp_int_sul())), 'campeonato', $post_id);
}

// Tax query que tira o internacional (usada na home)
function tsp_int_tax_fora()
{
    return array('taxonomy' => 'campeonato', 'field' => 'slug', 'terms' => array_merge(array(TSP_INT_GERAL), array_keys(tsp_int_ligas() + tsp_int_sul())), 'operator' => 'NOT IN');
}

// Item do menu principal
function tsp_int_menu_item()
{
    $geral = home_url('/campeonato/' . TSP_INT_GERAL . '/');
    echo '<li class="tsp-nav__item tem-sub tsp-nav__int"><a href="' . esc_url($geral) . '">Internacional</a>';
    echo '<button type="button" class="tsp-nav__abre" aria-expanded="false" aria-controls="tsp-sub-internacional" aria-label="Campeonatos internacionais"><span aria-hidden="true">▾</span></button>';
    echo '<div class="tsp-nav__painel" id="tsp-sub-internacional"><a class="tsp-nav__painel-tit" href="' . esc_url($geral) . '">Futebol internacional →</a><ul class="tsp-nav__clubes tsp-nav__ligas">';
    foreach (tsp_int_ligas() as $slug => $l) {
        echo '<li><a href="' . esc_url(home_url('/campeonato/' . $slug . '/')) . '"><span class="tsp-int-band" aria-hidden="true">' . $l[2] . '</span><span>' . esc_html($l[0]) . '</span></a></li>';
    }
    echo '</ul></div></li>';
}

// Atalhos no topo das páginas internacionais
function tsp_int_chips()
{
    if (!is_tax('campeonato')) {
        return;
    }
    $atual = get_queried_object()->slug ?? '';
    $ligas = tsp_int_ligas();
    $sul = tsp_int_sul();
    if ($atual !== TSP_INT_GERAL && !isset($ligas[$atual]) && !isset($sul[$atual])) {
        return;
    }
    $lista = ($atual === TSP_INT_SUL || isset($sul[$atual])) ? $sul : $ligas;
    echo '<nav class="tsp-int-chips" aria-label="Campeonatos">';
    if ($lista === $sul) {
        echo '<a href="' . esc_url(home_url('/campeonato/' . TSP_INT_SUL . '/')) . '"' . ($atual === TSP_INT_SUL ? ' aria-current="page"' : '') . '>🌎 Toda a América do Sul</a>';
    } else {
        echo '<a href="' . esc_url(home_url('/campeonato/' . TSP_INT_GERAL . '/')) . '"' . ($atual === TSP_INT_GERAL ? ' aria-current="page"' : '') . '>🌍 Tudo</a>';
    }
    foreach ($lista as $slug => $l) {
        echo '<a href="' . esc_url(home_url('/campeonato/' . $slug . '/')) . '"' . ($atual === $slug ? ' aria-current="page"' : '') . '><span aria-hidden="true">' . $l[2] . '</span> ' . esc_html($l[0]) . '</a>';
    }
    echo '</nav>';
}
