<?php
/**
 * Matéria (SEO/GEO/AEO): título, linha fina, assinatura com datas, foto com crédito, resumo em tópicos,
 * corpo, fontes consultadas, nota de transparência, autor e "Mais do clube".
 * Campos opcionais da matéria (preenchidos pela redação ou pela Máquina de Notícias):
 *   tsp_resumo  → um tópico por linha
 *   tsp_fontes  → uma fonte por linha, no formato "Nome da fonte | https://endereco"
 *   tsp_ia      → "1" quando o texto teve apoio de IA (sempre com revisão humana)
 *   tsp_revisor → nome de quem revisou
 */
get_header();

while (have_posts()) :
	the_post();
	$tsp_id = get_the_ID();
	$tsp_time = tsp_time_do_post($tsp_id);
	$tsp_serie = tsp_serie_do_post($tsp_id);
	$tsp_resumo = array_filter(array_map('trim', explode("\n", (string) get_post_meta($tsp_id, 'tsp_resumo', true))));
	$tsp_fontes = array_filter(array_map('trim', explode("\n", (string) get_post_meta($tsp_id, 'tsp_fontes', true))));
	$tsp_ia = get_post_meta($tsp_id, 'tsp_ia', true) === '1';
	$tsp_revisor = get_post_meta($tsp_id, 'tsp_revisor', true);
	$tsp_autor = get_the_author_meta('ID');
	// Lateral: as últimas do MESMO clube da matéria (sem clube: as últimas do site)
	$tsp_lat_vistos = array($tsp_id);
	$tsp_lat = $tsp_time ? wp_list_pluck(tsp_consulta(array('posts_per_page' => 6, 'tax_query' => tsp_tax_times($tsp_time->slug)), $tsp_lat_vistos), 'ID') : array();
	?>
<main class="tsp-container tsp-com-lateral">
	<article class="tsp-materia" id="post-<?php the_ID(); ?>">
		<header class="tsp-materia__cab">
			<?php tsp_breadcrumbs(); ?>
			<?php if ($tsp_time) : ?><a class="tsp-selo" href="<?php echo esc_url(get_term_link($tsp_time)); ?>"><?php echo esc_html($tsp_time->name); ?></a><?php endif; ?>
			<h1 class="tsp-materia__titulo"><?php the_title(); ?></h1>
			<?php $tsp_sub = tsp_subtitulo($tsp_id); if ($tsp_sub) : ?><p class="tsp-materia__fina"><?php echo esc_html($tsp_sub); ?></p><?php endif; ?>
			<div class="tsp-materia__meta">
				<span>Por <a href="<?php echo esc_url(get_author_posts_url($tsp_autor)); ?>" rel="author"><strong><?php echo esc_html(get_the_author()); ?></strong></a></span>
				<span>Publicado em <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date('d/m/Y \à\s H\hi')); ?></time></span>
				<?php if (get_the_modified_time('U') - get_the_time('U') > 600) : ?>
					<span>Atualizado em <time datetime="<?php echo esc_attr(get_the_modified_date('c')); ?>"><?php echo esc_html(get_the_modified_date('d/m/Y \à\s H\hi')); ?></time></span>
				<?php endif; ?>
				<span><?php echo (int) tsp_tempo_leitura($tsp_id); ?> min de leitura</span>
			</div>
			<?php
			$tsp_url = rawurlencode(get_permalink());
			$tsp_tit = rawurlencode(get_the_title());
			?>
			<div class="tsp-compartilhar" aria-label="Compartilhar">
				<a href="https://api.whatsapp.com/send?text=<?php echo $tsp_tit . '%20' . $tsp_url; ?>" target="_blank" rel="noopener">WhatsApp</a>
				<a href="https://twitter.com/intent/tweet?url=<?php echo $tsp_url; ?>&amp;text=<?php echo $tsp_tit; ?>" target="_blank" rel="noopener">X</a>
				<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $tsp_url; ?>" target="_blank" rel="noopener">Facebook</a>
				<button type="button" data-copiar="<?php echo esc_url(get_permalink()); ?>">Copiar link</button>
			</div>
		</header>

		<?php if (has_post_thumbnail()) :
			$tsp_leg = wp_get_attachment_caption(get_post_thumbnail_id()); ?>
			<figure class="tsp-materia__foto">
				<?php $tsp_alt = trim((string) get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true)); the_post_thumbnail('large', array('loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'alt' => $tsp_alt !== '' ? $tsp_alt : get_the_title())); ?>
				<?php if ($tsp_leg) : ?><figcaption><?php echo esc_html($tsp_leg); ?></figcaption><?php endif; ?>
			</figure>
		<?php endif; ?>

		<?php if ($tsp_resumo) : ?>
			<aside class="tsp-resumo" aria-label="Resumo">
				<strong>Resumo</strong>
				<ul><?php foreach ($tsp_resumo as $tsp_r) : ?><li><?php echo esc_html($tsp_r); ?></li><?php endforeach; ?></ul>
			</aside>
		<?php endif; ?>

		<div class="tsp-corpo">
			<?php the_content(); ?>
		</div>

		<?php $tsp_faq = tsp_faq_da_materia($tsp_id); if ($tsp_faq) : ?>
			<section class="tsp-faq tsp-materia__faq" aria-labelledby="tsp-faq-tit">
				<h2 id="tsp-faq-tit">Perguntas frequentes</h2>
				<?php foreach ($tsp_faq as $tsp_f) : ?>
					<details><summary><?php echo esc_html($tsp_f[0]); ?></summary><p><?php echo esc_html($tsp_f[1]); ?></p></details>
				<?php endforeach; ?>
			</section>
		<?php endif; ?>

		<?php if ($tsp_fontes || $tsp_ia) : ?>
			<section class="tsp-fontes" aria-labelledby="tsp-fontes-tit">
				<h2 id="tsp-fontes-tit">Fontes e transparência</h2>
				<?php if ($tsp_fontes) : ?>
					<ul>
						<?php foreach ($tsp_fontes as $tsp_f) :
							$tsp_p = array_map('trim', explode('|', $tsp_f, 2));
							$tsp_link = isset($tsp_p[1]) ? esc_url($tsp_p[1]) : '';
							?>
							<li><?php echo $tsp_link ? '<a href="' . $tsp_link . '" target="_blank" rel="noopener nofollow">' . esc_html($tsp_p[0]) . '</a>' : esc_html($tsp_p[0]); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php if ($tsp_ia && get_post_meta($tsp_id, 'tsp_ia_origem', true) === 'audio') : ?>
					<p>Esta matéria foi escrita com apoio de inteligência artificial a partir do áudio original<?php echo get_post_meta($tsp_id, 'tsp_fontes', true) ? ' (link acima)' : ''; ?>, gravado ou enviado por <?php echo esc_html(get_the_author()); ?>, da redação do TSP. As falas entre aspas seguem a transcrição automática do áudio. Viu algum erro? <a href="<?php echo esc_url(home_url('/politica-editorial/')); ?>">Fale com a redação</a>.</p>
				<?php elseif ($tsp_ia && get_post_meta($tsp_id, 'tsp_ia_origem', true) === 'maquina') : ?>
					<p>Esta matéria foi produzida pela Máquina de Notícias do TSP, com apoio de inteligência artificial, a partir das fontes acima (sempre que é notícia, cruzamos pelo menos duas fontes, priorizando o site oficial do clube e a imprensa da cidade). O texto é próprio do TSP e as informações foram conferidas nas fontes citadas. Viu algum erro? <a href="<?php echo esc_url(home_url('/politica-editorial/')); ?>">Fale com a redação</a>.</p>
				<?php elseif ($tsp_ia) : ?>
					<p>Esta matéria foi produzida com apoio de ferramentas de inteligência artificial a partir das fontes acima e revisada pela redação<?php echo $tsp_revisor ? ' (' . esc_html($tsp_revisor) . ')' : ''; ?> antes da publicação. <a href="<?php echo esc_url(home_url('/politica-editorial/')); ?>">Conheça nossa política editorial</a>.</p>
				<?php endif; ?>
			</section>
		<?php endif; ?>

		<?php $tsp_tags = get_the_tags(); if ($tsp_tags) : ?>
			<p class="tsp-materia__tags"><?php foreach ($tsp_tags as $tsp_tag) : ?><a href="<?php echo esc_url(get_tag_link($tsp_tag)); ?>">#<?php echo esc_html($tsp_tag->name); ?></a><?php endforeach; ?></p>
		<?php endif; ?>

		<section class="tsp-autor" aria-label="Sobre o autor">
			<?php echo get_avatar($tsp_autor, 72, '', '', array('loading' => 'lazy')); ?>
			<div>
				<strong><a href="<?php echo esc_url(get_author_posts_url($tsp_autor)); ?>"><?php echo esc_html(get_the_author()); ?></a></strong>
				<p><?php echo esc_html(get_the_author_meta('description') ? get_the_author_meta('description') : 'Redação do Tudo Sobre Paulista, cobrindo o futebol do estado de São Paulo.'); ?></p>
			</div>
		</section>

		<?php tsp_cta_whatsapp(); ?>
		<?php tsp_relacionadas($tsp_id, 6, $tsp_lat); ?>
	</article>

	<aside class="tsp-lateral" aria-label="Mais do TSP">
		<?php tsp_banner('tsp-banner-materia'); ?>
		<?php
		if ($tsp_lat) {
			tsp_lista_ultimas(6, array(), 'Últimas ' . tsp_de($tsp_time), '', $tsp_lat);
		} else {
			tsp_lista_ultimas(6, array($tsp_id));
		}
		?>
		<?php if ($tsp_serie && ($tsp_tab = tsp_tabela_html($tsp_serie))) : ?>
			<div class="tsp-caixa"><?php echo $tsp_tab; ?></div>
		<?php endif; ?>
	</aside>
</main>
	<?php
endwhile;

get_footer();
