<?php
/*
Plugin Name: TSP Estruturas
Description: Tipos de conteúdo (Matérias, Apostas, Banners, Onde Assistir), classificações (Times, Série, Campeonato) e campos ACF do Tudo Sobre Paulista, independentes do tema. Também impede que as regras de endereço sejam refeitas a cada visita, oferece a prévia do tema novo só para administradores e guarda os dados de tabelas do tema novo e esconde toda propaganda de apostas (MP 1.394).
Version: 1.4.0
Author: TSP
Requires at least: 6.3
Requires PHP: 7.4
Text Domain: tsp-estruturas
*/

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_EST_DIR', plugin_dir_path(__FILE__));

require_once TSP_EST_DIR . 'inc/previa.php';
require_once TSP_EST_DIR . 'inc/dados.php';
require_once TSP_EST_DIR . 'inc/sem-apostas.php';

/**
 * Enquanto o tema filho antigo (Divi Child) estiver ativo, ele mesmo registra as
 * estruturas. Este plugin só assume quando outro tema está ativo ou em pré-visualização,
 * para nunca registrar nada em dobro.
 */
function tsp_est_tema_antigo_ativo()
{
    return get_stylesheet() === 'Divi-child';
}

add_action('after_setup_theme', function () {
    // O tema antigo chamava flush_rules() em todo 'init', ou seja, a cada visita.
    remove_action('init', 'custom_taxonomy_flush_rewrite');

    if (tsp_est_tema_antigo_ativo()) {
        return;
    }

    $arquivos = array(
        'posttype/materia',
        'posttype/aposta',
        'posttype/banner',
        'posttype/onde-assistir',
        'taxonomy/time',
        'taxonomy/serie',
        'taxonomy/campeonato',
        'taxonomy/campeonato-onde-assistir',
        'page-options',
        'acf-fields/acf-fields',
    );
    foreach ($arquivos as $arquivo) {
        require_once TSP_EST_DIR . 'inc/' . $arquivo . '.php';
    }

    add_image_size('home-370x270', 370, 270, true);
    add_image_size('home-765x570', 765, 570, true);
}, 20);

// Regras de endereço: refeitas só na ativação e na troca de tema.
register_activation_hook(__FILE__, function () {
    update_option('tsp_est_refazer_enderecos', 1);
});
add_action('after_switch_theme', function () {
    update_option('tsp_est_refazer_enderecos', 1);
});
add_action('init', function () {
    if (get_option('tsp_est_refazer_enderecos')) {
        flush_rewrite_rules(false);
        delete_option('tsp_est_refazer_enderecos');
    }
}, 99);


// Atualização automática pelo GitHub do TSP (Painel → Atualizações)
require_once __DIR__ . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('plugin', 'tsp-estruturas', plugin_basename(__FILE__), get_file_data(__FILE__, array('v' => 'Version'))['v']);
