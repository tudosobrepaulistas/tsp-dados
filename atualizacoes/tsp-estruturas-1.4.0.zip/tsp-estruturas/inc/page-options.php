<?php

add_action('acf/init', function () {
    acf_add_options_page(array(
        'page_title' => 'Blocos da Home',
        'menu_slug' => 'blocos-home',
        'position' => 8,
        'redirect' => false,
        'menu_icon' => array(
            'type' => 'dashicons',
            'value' => 'dashicons-layout',
        ),
        'icon_url' => 'dashicons-layout',
    ));

    acf_add_options_page(array(
        'page_title' => 'Blocos de Apostas',
        'menu_slug' => 'blocos-de-apostas',
        'position' => 8,
        'redirect' => false,
        'menu_icon' => array(
            'type' => 'dashicons',
            'value' => 'dashicons-layout',
        ),
        'icon_url' => 'dashicons-layout',
    ));

    acf_add_options_page(array(
        'page_title' => 'Campeonatos',
        'menu_slug' => 'campeonatos',
        'position' => 7,
        'redirect' => false,
    ));

    acf_add_options_page(array(
        'page_title' => 'Config Site',
        'menu_slug' => 'config-site',
        'position' => 9,
        'redirect' => false,
        'menu_icon' => array(
            'type' => 'dashicons',
            'value' => 'dashicons-admin-generic',
        ),
        'icon_url' => 'dashicons-admin-generic',
    ));
});
