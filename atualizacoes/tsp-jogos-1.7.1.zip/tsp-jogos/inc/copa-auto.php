<?php
/**
 * Dia de Copa do Brasil / Libertadores (com clube paulista): a competição abre a home sozinha no dia do jogo.
 * No dia seguinte some e o Brasileirão volta para o topo. Nada para cadastrar: vem da base de jogos do TSP.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_copa_hoje()
{
    $c = wp_cache_get('tsp_copa_hoje', 'tsp');
    if ($c !== false) {
        return $c;
    }
    global $wpdb;
    $tz = new DateTimeZone('America/Sao_Paulo');
    $ini = (new DateTimeImmutable('today', $tz))->getTimestamp();
    $fim = $ini + DAY_IN_SECONDS;
    $nomes = array('libertadores' => 'Libertadores', 'copa_do_brasil' => 'Copa do Brasil');
    $c = null;
    foreach ($nomes as $liga => $nome) {
        $hoje = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . tsp_jogos_tabela() . ' WHERE liga = %s AND inicio >= %d AND inicio < %d ORDER BY inicio', $liga, $ini, $fim));
        $clubes = array();
        foreach ((array) $hoje as $j) {
            foreach (array($j->casa_id, $j->fora_id) as $t) {
                $s = tsp_jogos_slug_do_time($t);
                if ($s) {
                    $clubes[] = $s;
                }
            }
        }
        if (!$clubes) {
            continue;
        }
        $fase = trim((string) $hoje[0]->rodada);
        $prox = array();
        $res = array();
        foreach ($hoje as $j) {
            $fim_j = in_array($j->status, array('FT', 'AET', 'PEN'), true);
            if ($fim_j) {
                $res[] = array('Hoje', $j->casa, $j->gols_casa . ' x ' . $j->gols_fora, $j->fora);
            } else {
                $prox[] = array(wp_date('H\hi', $j->inicio, $tz), $j->casa, $j->fora);
            }
        }
        // Jogo de ida (até 10 dias antes) entre os mesmos clubes, para o leitor lembrar o placar
        $ida = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . tsp_jogos_tabela() . " WHERE liga = %s AND inicio >= %d AND inicio < %d AND status IN ('FT','AET','PEN') ORDER BY inicio DESC LIMIT 4", $liga, $ini - 10 * DAY_IN_SECONDS, $ini));
        foreach ((array) $ida as $j) {
            $res[] = array(wp_date('d/m', $j->inicio, $tz), $j->casa, $j->gols_casa . ' x ' . $j->gols_fora, $j->fora);
        }
        $fase = trim(preg_replace('~\s*-\s*(ida|volta|jogo \d)$~i', '', $fase));
        $c = array('liga' => $liga, 'nome' => $nome . ($fase && !preg_match('~^\d+$~', $fase) ? ' · ' . $fase : ''), 'de' => wp_date('Y-m-d', null, $tz), 'ate' => wp_date('Y-m-d', null, $tz),
            'clubes' => array_values(array_unique($clubes)),
            'proximos' => array('titulo' => 'Hoje', 'lista' => $prox),
            'resultados' => array('titulo' => 'Resultados', 'lista' => $res));
        break;
    }
    wp_cache_set('tsp_copa_hoje', $c, 'tsp', 300);
    return $c;
}

// A lista "copas" do tema (manual, em Ferramentas → TSP · Dados do tema) continua valendo; a automática entra na frente
add_filter('tsp_dado', function ($v, $chave) {
    if ($chave !== 'copas') {
        return $v;
    }
    $auto = tsp_jogos_copa_hoje();
    if (!$auto) {
        return $v;
    }
    return array_merge(array($auto), is_array($v) ? $v : array());
}, 20, 2);
