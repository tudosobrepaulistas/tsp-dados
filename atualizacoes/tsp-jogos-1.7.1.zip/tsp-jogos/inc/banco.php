<?php
/**
 * Tabela própria com os jogos (uma linha por partida) e opções com classificações e vínculos de times.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_tabela()
{
    global $wpdb;
    return $wpdb->prefix . 'tsp_jogos';
}

function tsp_jogos_criar_tabela()
{
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $t = tsp_jogos_tabela();
    $c = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE $t (
        id bigint(20) unsigned NOT NULL,
        liga varchar(40) NOT NULL DEFAULT '',
        temporada smallint(5) unsigned NOT NULL DEFAULT 0,
        rodada varchar(80) NOT NULL DEFAULT '',
        inicio int(10) unsigned NOT NULL DEFAULT 0,
        status varchar(8) NOT NULL DEFAULT '',
        minuto smallint(5) unsigned NOT NULL DEFAULT 0,
        casa_id int(10) unsigned NOT NULL DEFAULT 0,
        fora_id int(10) unsigned NOT NULL DEFAULT 0,
        casa varchar(80) NOT NULL DEFAULT '',
        fora varchar(80) NOT NULL DEFAULT '',
        gols_casa tinyint(3) unsigned NULL,
        gols_fora tinyint(3) unsigned NULL,
        estadio varchar(120) NOT NULL DEFAULT '',
        cidade varchar(80) NOT NULL DEFAULT '',
        arbitro varchar(120) NOT NULL DEFAULT '',
        sp tinyint(1) unsigned NOT NULL DEFAULT 0,
        detalhes longtext NULL,
        detalhes_em int(10) unsigned NOT NULL DEFAULT 0,
        atualizado int(10) unsigned NOT NULL DEFAULT 0,
        PRIMARY KEY  (id),
        KEY liga_inicio (liga, inicio),
        KEY casa_id (casa_id),
        KEY fora_id (fora_id),
        KEY sp_inicio (sp, inicio)
    ) $c;");
}

// Competições acompanhadas: chave interna => id da API (descoberto no teste de conexão)
function tsp_jogos_ligas()
{
    $l = get_option('tsp_jogos_ligas', array());
    return is_array($l) ? $l : array();
}

function tsp_jogos_nome_liga($chave)
{
    $nomes = array(
        'serie_a' => 'Brasileirão Série A', 'serie_b' => 'Brasileirão Série B', 'copa_do_brasil' => 'Copa do Brasil',
        'libertadores' => 'Libertadores', 'sul_americana' => 'Sul-Americana',
        'fem_brasileiro_a1' => 'Brasileirão Feminino A1', 'fem_paulistao' => 'Paulistão Feminino', 'fem_copa_do_brasil' => 'Copa do Brasil Feminina', 'fem_libertadores' => 'Libertadores Feminina',
        'paulistao_a1' => 'Paulistão A1', 'paulistao_a2' => 'Paulistão A2', 'paulistao_a3' => 'Paulistão A3', 'paulistao_a4' => 'Paulistão A4',
    );
    if (!isset($nomes[$chave]) && (strpos($chave, 'base_') === 0 || strpos($chave, 'paulista_') === 0)) {
        $l = get_option('tsp_jogos_ligas', array());
        return isset($l[$chave]['nome_api']) ? $l[$chave]['nome_api'] : 'Base';
    }
    return $nomes[$chave] ?? $chave;
}

// Vínculo time da API => slug do time no site
function tsp_jogos_vinculos()
{
    $v = get_option('tsp_jogos_times', array());
    return is_array($v) ? $v : array();
}

function tsp_jogos_slug_do_time($api_id)
{
    $v = tsp_jogos_vinculos();
    return $v[(int) $api_id] ?? '';
}

function tsp_jogos_api_do_slug($slug)
{
    $v = array_flip(tsp_jogos_vinculos());
    return isset($v[$slug]) ? (int) $v[$slug] : 0;
}

// Nome exibido: para clubes paulistas, o nome do site (com acento); para os outros, o da API
function tsp_jogos_nome_time($api_id, $nome_api)
{
    static $cache = array();
    if (isset($cache[$api_id])) {
        return $cache[$api_id];
    }
    $slug = tsp_jogos_slug_do_time($api_id);
    $t = $slug ? get_term_by('slug', $slug, 'times') : null;
    return $cache[$api_id] = $t ? $t->name : $nome_api;
}

function tsp_jogos_buscar($where, $args = array(), $ordem = 'inicio ASC', $limite = 50)
{
    global $wpdb;
    $t = tsp_jogos_tabela();
    $sql = "SELECT * FROM $t WHERE $where ORDER BY $ordem LIMIT " . (int) $limite;
    return $wpdb->get_results($args ? $wpdb->prepare($sql, $args) : $sql);
}

function tsp_jogos_do_time($api_id, $tipo, $n = 2, $liga = '')
{
    $agora = time();
    $base = '(casa_id = %d OR fora_id = %d)' . ($liga ? ' AND liga = %s' : '');
    $args = $liga ? array($api_id, $api_id, $liga) : array($api_id, $api_id);
    if ($tipo === 'ultimos') {
        return tsp_jogos_buscar($base . " AND status IN ('FT','AET','PEN')", $args, 'inicio DESC', $n);
    }
    $args[] = $agora - 3 * HOUR_IN_SECONDS;
    return tsp_jogos_buscar($base . " AND status NOT IN ('FT','AET','PEN','PST','CANC','ABD','AWD','WO') AND inicio >= %d", $args, 'inicio ASC', $n);
}

function tsp_jogos_classificacao($liga)
{
    $c = get_option('tsp_jogos_class_' . sanitize_key($liga), array());
    return is_array($c) ? $c : array();
}
