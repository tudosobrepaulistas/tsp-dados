<?php
/**
 * Escudo oficial de todos os clubes das competições (inclusive os de fora de SP).
 * O site busca na Wikipédia em português a imagem principal da página do clube (escudo hospedado no
 * Wikimedia Commons), baixa uma vez para uploads/tsp-escudos/ e usa nas páginas de jogo.
 * Clube paulista com escudo cadastrado no site continua usando o do site.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_escudos()
{
    $e = get_option('tsp_jogos_escudos', array());
    return is_array($e) ? $e : array();
}

// Busca até 8 escudos que faltam (roda depois de cada leitura da base)
add_action('tsp_jogos_base', 'tsp_jogos_escudos_buscar', 30);
function tsp_jogos_escudos_buscar($max = 20)
{
    $max = (int) $max ?: 20;
    $esc = tsp_jogos_escudos();
    $feitos = 0;
    $up = wp_upload_dir();
    $dir = trailingslashit($up['basedir']) . 'tsp-escudos';
    wp_mkdir_p($dir);
    foreach (tsp_jogos_base_times() as $id => $t) {
        if ($feitos >= $max) {
            break;
        }
        $wiki = $t['wiki'] ?? '';
        $atual = $esc[$id] ?? null;
        if (!$wiki || (is_array($atual) && (!empty($atual['url']) || !empty($atual['manual']) || ($atual['tentou'] ?? 0) > time() - 12 * HOUR_IN_SECONDS))) {
            continue;
        }
        $feitos++;
        $r = tsp_jogos_escudo_baixar($wiki, ($t['chave'] ?? '') ?: (string) $id, $dir, $up['baseurl']);
        $esc[$id] = $r;
    }
    update_option('tsp_jogos_escudos', $esc, false);
    return $feitos;
}

// Tenta, em ordem: imagem principal da Wikipédia (tamanho padrão 250 px), logotipo do Wikidata (P154),
// e o arquivo original do Commons. A Wikimedia recusa tamanhos fora do padrão e downloads sem identificação.
function tsp_jogos_escudo_baixar($wiki, $chave, $dir, $baseurl)
{
    $ua = array('User-Agent' => 'TSP-Jogos/1.7 (https://tudosobrepaulista.com.br; contato@tudosobrepaulista.com.br) WordPress');
    $cands = array();
    $qid = '';
    $api = add_query_arg(array('action' => 'query', 'format' => 'json', 'redirects' => 1, 'prop' => 'pageimages|pageprops', 'piprop' => 'thumbnail|name|original', 'pithumbsize' => 250, 'ppprop' => 'wikibase_item', 'titles' => $wiki), 'https://pt.wikipedia.org/w/api.php');
    $r = wp_remote_get($api, array('timeout' => 15, 'headers' => $ua));
    $erros = array();
    if (is_wp_error($r)) {
        $erros[] = 'wikipedia: ' . $r->get_error_message();
    } else {
        $d = json_decode(wp_remote_retrieve_body($r), true);
        foreach ((array) ($d['query']['pages'] ?? array()) as $pg) {
            if (!empty($pg['thumbnail']['source'])) {
                $cands[] = $pg['thumbnail']['source'];
            }
            if (!empty($pg['pageimage'])) {
                $cands[] = 'https://commons.wikimedia.org/w/index.php?title=Special:FilePath/' . rawurlencode($pg['pageimage']) . '&width=250';
            }
            if (!empty($pg['original']['source']) && !preg_match('~\.svg$~i', $pg['original']['source'])) {
                $cands[] = $pg['original']['source'];
            }
            $qid = $pg['pageprops']['wikibase_item'] ?? '';
        }
    }
    if (preg_match('~^Q\d+$~', $qid)) {
        $w = wp_remote_get('https://www.wikidata.org/wiki/Special:EntityData/' . $qid . '.json', array('timeout' => 15, 'headers' => $ua));
        $wd = is_wp_error($w) ? array() : json_decode(wp_remote_retrieve_body($w), true);
        foreach ((array) ($wd['entities'][$qid]['claims']['P154'] ?? array()) as $c) {
            $logo = $c['mainsnak']['datavalue']['value'] ?? '';
            if ($logo) {
                $cands[] = 'https://commons.wikimedia.org/w/index.php?title=Special:FilePath/' . rawurlencode(str_replace(' ', '_', $logo)) . '&width=250';
            }
        }
    }
    $cands = array_values(array_unique($cands));
    if (!$cands) {
        return array('tentou' => time(), 'erro' => $erros ? implode('; ', $erros) : 'sem imagem na Wikipédia/Wikidata');
    }
    foreach (array_slice($cands, 0, 4) as $src) {
        if (strpos($src, 'https://upload.wikimedia.org/') !== 0 && strpos($src, 'https://commons.wikimedia.org/') !== 0) {
            continue;
        }
        $img = wp_remote_get($src, array('timeout' => 20, 'headers' => $ua, 'redirection' => 5));
        $code = is_wp_error($img) ? 0 : (int) wp_remote_retrieve_response_code($img);
        $corpo = $code === 200 ? wp_remote_retrieve_body($img) : '';
        if (!$corpo) {
            $erros[] = is_wp_error($img) ? $img->get_error_message() : 'http ' . $code;
            continue;
        }
        $tipo = (string) wp_remote_retrieve_header($img, 'content-type');
        $ext = strpos($tipo, 'jpeg') !== false ? 'jpg' : (strpos($tipo, 'webp') !== false ? 'webp' : (strpos($tipo, 'gif') !== false ? 'gif' : 'png'));
        $nome = sanitize_file_name($chave . '.' . $ext);
        @file_put_contents("$dir/$nome", $corpo);
        if (file_exists("$dir/$nome") && @getimagesize("$dir/$nome")) {
            return array('url' => trailingslashit($baseurl) . 'tsp-escudos/' . $nome . '?v=' . time());
        }
        @unlink("$dir/$nome");
        $erros[] = 'arquivo inválido';
    }
    return array('tentou' => time(), 'erro' => implode('; ', array_slice($erros, 0, 3)));
}

function tsp_jogos_escudo_url($api_id)
{
    $e = tsp_jogos_escudos()[(int) $api_id] ?? array();
    return $e['url'] ?? '';
}

/* ---------- Tela "Ferramentas → Escudos dos clubes" (só administrador) ---------- */
add_action('admin_menu', function () {
    add_management_page('Escudos dos clubes', 'Escudos dos clubes', 'manage_options', 'tsp-escudos', 'tsp_jogos_escudos_tela');
});

add_action('admin_post_tsp_escudos_buscar', function () {
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão');
    }
    check_admin_referer('tsp_escudos');
    @set_time_limit(300);
    $esc = tsp_jogos_escudos();
    foreach ($esc as $id => $e) {
        if (empty($e['url'])) {
            unset($esc[$id]); // tenta de novo agora quem falhou
        }
    }
    update_option('tsp_jogos_escudos', $esc, false);
    $n = tsp_jogos_escudos_buscar(30);
    wp_safe_redirect(admin_url('tools.php?page=tsp-escudos&feitos=' . (int) $n));
    exit;
});

add_action('admin_post_tsp_escudo_manual', function () {
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão');
    }
    check_admin_referer('tsp_escudos');
    $id = (int) ($_POST['time'] ?? 0);
    $anexo = (int) ($_POST['anexo'] ?? 0);
    $esc = tsp_jogos_escudos();
    if ($id && $anexo && wp_attachment_is_image($anexo)) {
        $esc[$id] = array('url' => wp_get_attachment_image_url($anexo, 'thumbnail') ?: wp_get_attachment_url($anexo), 'manual' => 1);
    } elseif ($id && !empty($_POST['remover'])) {
        unset($esc[$id]);
    }
    update_option('tsp_jogos_escudos', $esc, false);
    wp_safe_redirect(admin_url('tools.php?page=tsp-escudos&salvo=1'));
    exit;
});

function tsp_jogos_escudos_tela()
{
    wp_enqueue_media();
    $esc = tsp_jogos_escudos();
    $times = tsp_jogos_base_times();
    $tem = array();
    foreach ($times as $id => $t) {
        $tem[$id] = function_exists('tsp_sim_escudo') ? (tsp_sim_escudo($id) !== '') : (tsp_jogos_escudo_url($id) !== '');
    }
    uksort($times, function ($a, $b) use ($times, $tem) {
        return ($tem[$a] <=> $tem[$b]) ?: strcmp((string) ($times[$a]['nome'] ?? ''), (string) ($times[$b]['nome'] ?? ''));
    });
    $falta = 0;
    foreach ($times as $id => $t) {
        if (empty($esc[$id]['url']) && !(function_exists('tsp_sim_escudo') && tsp_sim_escudo($id))) {
            $falta++;
        }
    }
    echo '<div class="wrap"><h1>Escudos dos clubes</h1>';
    if (isset($_GET['feitos'])) {
        echo '<div class="notice notice-success"><p>Busca feita em ' . (int) $_GET['feitos'] . ' clubes. Veja abaixo o resultado.</p></div>';
    }
    if (isset($_GET['salvo'])) {
        echo '<div class="notice notice-success"><p>Escudo salvo. Ele aparece no simulador e nas páginas de jogo em até 15 minutos (limpe o cache para ver na hora).</p></div>';
    }
    echo '<p>O site busca sozinho o escudo de cada clube na Wikipédia. <strong>Faltam ' . (int) $falta . '.</strong> Se algum não vier, clique em <strong>Escolher escudo</strong> e envie a imagem (PNG de fundo transparente, de preferência quadrada).</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('tsp_escudos');
    echo '<input type="hidden" name="action" value="tsp_escudos_buscar"><p><button class="button button-primary button-hero">🔄 Buscar agora os escudos que faltam</button></p></form>';
    echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th style="width:60px">Escudo</th><th>Clube</th><th>Situação</th><th>Ação</th></tr></thead><tbody>';
    foreach ($times as $id => $t) {
        $u = function_exists('tsp_sim_escudo') ? tsp_sim_escudo($id) : tsp_jogos_escudo_url($id);
        $e = $esc[$id] ?? array();
        if ($u) {
            $sit = !empty($e['manual']) ? '✅ Enviado à mão' : '✅ OK';
        } else {
            $sit = '❌ Falta' . (!empty($e['erro']) ? ' <small style="color:#888">(' . esc_html($e['erro']) . ')</small>' : '');
        }
        echo '<tr><td>' . ($u ? '<img src="' . esc_url($u) . '" style="width:36px;height:36px;object-fit:contain">' : '') . '</td><td><strong>' . esc_html($t['nome'] ?? $id) . '</strong></td><td>' . $sit . '</td><td>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline">';
        wp_nonce_field('tsp_escudos');
        echo '<input type="hidden" name="action" value="tsp_escudo_manual"><input type="hidden" name="time" value="' . (int) $id . '"><input type="hidden" name="anexo" value="">';
        echo '<button type="button" class="button tsp-esc-escolher">Escolher escudo</button>';
        if (!empty($e['manual'])) {
            echo ' <button class="button-link" name="remover" value="1">voltar ao automático</button>';
        }
        echo '</form></td></tr>';
    }
    echo '</tbody></table></div>';
    ?>
<script>
jQuery(function($){$('.tsp-esc-escolher').on('click',function(){var f=$(this).closest('form');var m=wp.media({title:'Escudo do clube',button:{text:'Usar este escudo'},library:{type:'image'},multiple:false});m.on('select',function(){f.find('[name=anexo]').val(m.state().get('selection').first().id);f.trigger('submit')});m.open()})});
</script>
    <?php
}
