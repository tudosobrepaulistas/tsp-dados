<?php
/**
 * Sincronização automática (WP-Cron, sem ninguém mexer):
 * - Diária (madrugada): jogos de todas as competições acompanhadas + classificação + ficha dos jogos encerrados
 *   + pré-jogo (confronto direto e desfalques) dos jogos paulistas dos próximos 3 dias.
 * - A cada 5 minutos: SÓ se houver jogo de clube paulista acontecendo, atualiza placar, lances e escalações.
 *   Sem jogo = nenhuma consulta gasta.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Sem API-Football: nenhum agendamento próprio aqui. A leitura da base fica em base-tsp.php.

const TSP_JOGOS_RESERVA_AO_VIVO = 30;

// 1) Descobre as competições na API (usado no botão "Testar" do painel). Gasta 3 consultas.
function tsp_jogos_descobrir()
{
    $st = tsp_jogos_get('status');
    if (is_wp_error($st)) {
        return $st;
    }
    $achadas = array();
    $listas = array(tsp_jogos_get('leagues', array('country' => 'Brazil')), tsp_jogos_get('leagues', array('id' => 13)), tsp_jogos_get('leagues', array('id' => 11)), tsp_jogos_get('leagues', array('search' => 'Femenina')), tsp_jogos_get('leagues', array('search' => 'Paulista')));
    foreach ($listas as $lista) {
        if (is_wp_error($lista)) {
            continue;
        }
        foreach ($lista as $item) {
            $nome = $item['league']['name'] ?? '';
            $chave = tsp_jogos_chave_da_liga($nome, (int) ($item['league']['id'] ?? 0));
            if (!$chave) {
                continue;
            }
            $temps = $item['seasons'] ?? array();
            usort($temps, function ($a, $b) {
                return ($b['year'] ?? 0) - ($a['year'] ?? 0);
            });
            $t = $temps[0] ?? array();
            foreach ($temps as $x) {
                if (!empty($x['current'])) {
                    $t = $x;
                    break;
                }
            }
            $cob = $t['coverage'] ?? array();
            if (strpos($chave, 'base_') === 0 && (int) ($t['year'] ?? 0) < (int) gmdate('Y')) {
                continue; // base: só competições com temporada atual
            }
            $achadas[$chave] = array(
                'id'         => (int) $item['league']['id'],
                'nome_api'   => sanitize_text_field($nome),
                'temporada'  => (int) ($t['year'] ?? 0),
                'inicio'     => sanitize_text_field($t['start'] ?? ''),
                'fim'        => sanitize_text_field($t['end'] ?? ''),
                'jogos'      => !empty($cob['fixtures']['events']),
                'escalacoes' => !empty($cob['fixtures']['lineups']),
                'estatisticas' => !empty($cob['fixtures']['statistics_fixtures']),
                'tabela'     => !empty($cob['standings']),
                'desfalques' => !empty($cob['injuries']),
            );
        }
    }
    update_option('tsp_jogos_ligas', $achadas, false);
    update_option('tsp_jogos_status', array('quando' => time(), 'plano' => $st['subscription']['plan'] ?? '', 'uso' => $st['requests']['current'] ?? '', 'limite' => $st['requests']['limit_day'] ?? ''), false);
    tsp_jogos_log('Teste de conexão: ' . count($achadas) . ' competições encontradas.');
    return $achadas;
}

function tsp_jogos_chave_da_liga($nome, $id)
{
    $n0 = strtolower(remove_accents($nome));
    // Categorias de base (sub-20, sub-17, sub-15...): chave "base_sub20_nome-da-competicao"
    // Só São Paulo e Brasil: competições de outros estados ficam de fora
    $sp = (bool) preg_match('~paulista|sao paulo|copinha~', $n0);
    $nacional = (bool) preg_match('~^(brasileiro|copa do brasil|serie a|serie b|supercopa)~', $n0);
    if (preg_match('~\\bu-?(11|13|15|17|20|23)\\b|sub-?(11|13|15|17|20|23)|junior|copinha~', $n0, $mb)) {
        if (!$sp && !$nacional) {
            return '';
        }
        $cat = !empty($mb[1]) ? $mb[1] : (!empty($mb[2]) ? $mb[2] : '20');
        return 'base_sub' . $cat . '_' . substr(sanitize_key(str_replace(' ', '-', $n0)), 0, 40);
    }
    if (preg_match('~women|femin|femen|\\bw$~', $n0)) {
        if (!$sp && !$nacional && strpos($n0, 'libertadores') === false) {
            return '';
        }
        if (strpos($n0, 'libertadores') !== false) {
            return 'fem_libertadores';
        }
        if (strpos($n0, 'copa do brasil') !== false) {
            return 'fem_copa_do_brasil';
        }
        if (strpos($n0, 'paulista') !== false) {
            return 'fem_paulistao';
        }
        if (preg_match('~brasileiro|serie a1|^serie a~', $n0) && strpos($n0, 'a2') === false && strpos($n0, 'a3') === false) {
            return 'fem_brasileiro_a1';
        }
        return '';
    }
    if ($id === 13) {
        return 'libertadores';
    }
    if ($id === 11) {
        return 'sul_americana';
    }
    $n = strtolower(remove_accents($nome));
    if ($n === 'serie a') {
        return 'serie_a';
    }
    if ($n === 'serie b') {
        return 'serie_b';
    }
    if ($n === 'copa do brasil') {
        return 'copa_do_brasil';
    }
    if (preg_match('~^paulista\s*-?\s*a\s*([1-4])$~', $n, $m)) {
        return 'paulistao_a' . $m[1];
    }
    // Outras competições paulistas (ex.: Copa Paulista, Segunda Divisão)
    if (strpos($n, 'paulista') !== false) {
        return 'paulista_' . substr(sanitize_key(str_replace(' ', '-', $n)), 0, 40);
    }
    return '';
}

// 2) Grava/atualiza uma partida vinda da API
function tsp_jogos_gravar($chave, $temporada, $f, $com_detalhes = false)
{
    global $wpdb;
    $fx = $f['fixture'] ?? array();
    $id = (int) ($fx['id'] ?? 0);
    if (!$id) {
        return 0;
    }
    $casa = (int) ($f['teams']['home']['id'] ?? 0);
    $fora = (int) ($f['teams']['away']['id'] ?? 0);
    $sp = (tsp_jogos_slug_do_time($casa) || tsp_jogos_slug_do_time($fora)) ? 1 : 0;
    $linha = array(
        'id' => $id, 'liga' => $chave, 'temporada' => (int) $temporada,
        'rodada' => sanitize_text_field($f['league']['round'] ?? ''),
        'inicio' => (int) ($fx['timestamp'] ?? 0),
        'status' => sanitize_text_field($fx['status']['short'] ?? ''),
        'minuto' => (int) ($fx['status']['elapsed'] ?? 0),
        'casa_id' => $casa, 'fora_id' => $fora,
        'casa' => sanitize_text_field($f['teams']['home']['name'] ?? ''),
        'fora' => sanitize_text_field($f['teams']['away']['name'] ?? ''),
        'gols_casa' => isset($f['goals']['home']) ? (int) $f['goals']['home'] : null,
        'gols_fora' => isset($f['goals']['away']) ? (int) $f['goals']['away'] : null,
        'estadio' => sanitize_text_field($fx['venue']['name'] ?? ''),
        'cidade' => sanitize_text_field($fx['venue']['city'] ?? ''),
        'arbitro' => sanitize_text_field($fx['referee'] ?? ''),
        'sp' => $sp, 'atualizado' => time(),
    );
    if ($com_detalhes) {
        $atual = tsp_jogos_detalhes($id);
        $atual['eventos'] = tsp_jogos_limpar_lista($f['events'] ?? array());
        $atual['escalacoes'] = tsp_jogos_limpar_lista($f['lineups'] ?? array());
        $atual['estatisticas'] = tsp_jogos_limpar_lista($f['statistics'] ?? array());
        $linha['detalhes'] = wp_json_encode($atual);
        $linha['detalhes_em'] = time();
    }
    $existe = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . tsp_jogos_tabela() . ' WHERE id = %d', $id));
    if ($existe) {
        $wpdb->update(tsp_jogos_tabela(), $linha, array('id' => $id));
    } else {
        $wpdb->insert(tsp_jogos_tabela(), $linha);
    }
    return $id;
}

// Guarda só texto e números vindos da API
function tsp_jogos_limpar_lista($v)
{
    if (is_array($v)) {
        $s = array();
        foreach ($v as $k => $x) {
            $s[is_int($k) ? $k : sanitize_key($k)] = tsp_jogos_limpar_lista($x);
        }
        return $s;
    }
    if (is_int($v) || is_float($v) || is_bool($v) || $v === null) {
        return $v;
    }
    return sanitize_text_field((string) $v);
}

function tsp_jogos_detalhes($id)
{
    global $wpdb;
    $j = $wpdb->get_var($wpdb->prepare('SELECT detalhes FROM ' . tsp_jogos_tabela() . ' WHERE id = %d', $id));
    $d = $j ? json_decode($j, true) : array();
    return is_array($d) ? $d : array();
}

function tsp_jogos_salvar_detalhe($id, $campo, $valor)
{
    global $wpdb;
    $d = tsp_jogos_detalhes($id);
    $d[$campo] = tsp_jogos_limpar_lista($valor);
    $wpdb->update(tsp_jogos_tabela(), array('detalhes' => wp_json_encode($d)), array('id' => $id));
}

// 3) Vincula os times da API aos 64 clubes paulistas do site (automático; o painel permite corrigir)
function tsp_jogos_vincular_times($times_api)
{
    $v = tsp_jogos_vinculos();
    $indice = array();
    $termos = get_terms(array('taxonomy' => 'times', 'hide_empty' => false, 'number' => 400));
    if (is_wp_error($termos)) {
        return;
    }
    $permitidos = tsp_jogos_slugs_paulistas();
    foreach ($termos as $t) {
        if (!in_array($t->slug, $permitidos, true)) {
            continue;
        }
        $indice[tsp_jogos_normal($t->name)] = $t->slug;
        $indice[tsp_jogos_normal($t->slug)] = $t->slug;
    }
    $apelidos = array(
        'rbbragantino' => 'bragantino', 'redbullbragantino' => 'bragantino', 'botafogosp' => 'botafogosp',
        'saobernardo' => 'saobernardo', 'guaranicampinas' => 'guarani', 'pontepreta' => 'pontepreta',
        'gremionovorizontino' => 'novorizontino', 'portuguesasp' => 'portuguesa', 'juventussp' => 'juventus',
        'interlimeira' => 'interdelimeira', 'internacionallimeira' => 'interdelimeira', 'xvpiracicaba' => 'xvdepiracicaba',
        'saojosesp' => 'saojose', 'saobentosp' => 'saobento', 'aguasantasp' => 'aguasanta', 'portuguesasantista' => 'portuguesasantista',
        'gremioprudente' => 'prudente', 'paulistajundiai' => 'paulista-jundiai', 'riobrancosp' => 'rio-branco', 'riobranco' => 'rio-branco',
        'rioclaro' => 'rioclaro', 'ecsaobernardo' => 'ec-sao-bernardo', 'americasp' => 'america-de-rio-preto', 'americarp' => 'america-de-rio-preto',
        'saocaetano' => 'saocaetano', 'velo' => 'veloclube', 'veloclube' => 'veloclube', 'interbebedouro' => 'inter-de-bebedouro',
    );
    foreach ($times_api as $id => $nome) {
        if (isset($v[$id])) {
            continue;
        }
        $n = tsp_jogos_normal($nome);
        $slug = $apelidos[$n] ?? ($indice[$n] ?? '');
        if ($slug && in_array($slug, $permitidos, true)) {
            $v[(int) $id] = $slug;
        }
    }
    update_option('tsp_jogos_times', $v, false);
}

function tsp_jogos_slugs_paulistas()
{
    // Os 64 clubes do Paulistão 2027 (A1 a A4). Fica no plugin para funcionar com qualquer tema ativo.
    $lista = array('botafogosp', 'capivariano', 'corinthians', 'ferroviaria', 'guarani', 'juventus', 'mirassol', 'noroeste', 'novorizontino', 'palmeiras', 'portuguesa', 'primavera', 'bragantino', 'santos', 'saobernardo', 'saopaulo', 'aguasanta', 'interdelimeira', 'ituano', 'linense', 'marilia', 'monteazul', 'osasco-sporting', 'pontepreta', 'portuguesasantista', 'santoandre', 'saojose', 'sertaozinho', 'taubate', 'veloclube', 'votuporanguense', 'xvdepiracicaba', 'bandeirante', 'catanduva', 'ec-sao-bernardo', 'francana', 'prudente', 'inter-de-bebedouro', 'itapirense', 'paulista-jundiai', 'penapolense', 'rio-branco', 'rioclaro', 'rio-preto', 'saobento', 'uniao-barbarense', 'uniao-sao-joao', 'xv-de-jau', 'america-de-rio-preto', 'barretos', 'colorado-caieiras', 'comercial', 'desportivo-brasil', 'ecus', 'gremio-saocarlense', 'independente', 'jabaquara', 'jacarei', 'lemense', 'saocaetano', 'tanabi', 'taquaritinga', 'uniao-suzano', 'vocem');
    if (function_exists('tsp_grupos')) {
        foreach (tsp_grupos() as $g) {
            $lista = array_merge($lista, array_keys($g['clubes'] ?? $g['divisao']));
        }
    }
    return array_values(array_unique($lista));
}

// Times femininos (ex.: "Corinthians W", "Palmeiras Women") → corinthians-feminino, palmeiras-feminino...
function tsp_jogos_vincular_femininos($times_api)
{
    $mapa = array('corinthians' => 'corinthians-feminino', 'palmeiras' => 'palmeiras-feminino', 'saopaulo' => 'sao-paulo-feminino', 'santos' => 'santos-feminino', 'ferroviaria' => 'ferroviaria-feminino', 'bragantino' => 'red-bull-bragantino-feminino', 'rbbragantino' => 'red-bull-bragantino-feminino', 'redbullbragantino' => 'red-bull-bragantino-feminino', 'mirassol' => 'mirassol-feminino', 'taubate' => 'taubate-feminino');
    $v = tsp_jogos_vinculos();
    foreach ($times_api as $id => $nome) {
        if (isset($v[$id])) {
            continue;
        }
        $n = strtolower(remove_accents((string) $nome));
        $n = preg_replace('~\\b(w|women|feminino|fem|femenino)\\b~', '', $n);
        $n = tsp_jogos_normal($n);
        if (isset($mapa[$n]) && term_exists($mapa[$n], 'times')) {
            $v[(int) $id] = $mapa[$n];
        }
    }
    update_option('tsp_jogos_times', $v, false);
}

// Base: "Palmeiras U20" → palmeiras-sub-20 (só se o time já existir no site com esse endereço)
function tsp_jogos_vincular_base($times_api)
{
    $v = tsp_jogos_vinculos();
    $mapa = array('saopaulo' => 'sao-paulo', 'bragantino' => 'red-bull-bragantino', 'rbbragantino' => 'red-bull-bragantino', 'redbullbragantino' => 'red-bull-bragantino', 'pontepreta' => 'ponte-preta', 'botafogosp' => 'botafogo-sp', 'interdelimeira' => 'inter-de-limeira', 'xvdepiracicaba' => 'xv-de-piracicaba', 'gremioprudente' => 'gremio-prudente', 'aguasanta' => 'agua-santa', 'saojose' => 'sao-jose', 'saobento' => 'sao-bento', 'santoandre' => 'santo-andre', 'portuguesasantista' => 'portuguesa-santista');
    foreach ($times_api as $id => $nome) {
        if (isset($v[$id])) {
            continue;
        }
        $n = strtolower(remove_accents((string) $nome));
        if (!preg_match('~u-?(11|13|15|17|20|23)\\b|sub-?(11|13|15|17|20|23)~', $n, $m)) {
            $m = array('', '20');
        }
        $cat = !empty($m[1]) ? $m[1] : ($m[2] ?? '20');
        $base = tsp_jogos_normal(preg_replace('~\\b(u-?\\d+|sub-?\\d+|w|women)\\b~', '', $n));
        $raiz = $mapa[$base] ?? $base;
        foreach (array($raiz . '-sub-' . $cat, $base . '-sub-' . $cat) as $slug) {
            if (term_exists($slug, 'times')) {
                $v[(int) $id] = $slug;
                break;
            }
        }
    }
    update_option('tsp_jogos_times', $v, false);
}

// 4) Sincronização diária completa
function tsp_jogos_sincronizar_tudo()
{
    if (function_exists('tsp_jogos_base_ativa') && tsp_jogos_base_ativa()) {
        return; // dados vêm da Base TSP (inc/base-tsp.php)
    }
    $st = get_option('tsp_jogos_status', array());
    if (empty($st['quando']) || time() - (int) $st['quando'] > 7 * DAY_IN_SECONDS) {
        tsp_jogos_descobrir(); // uma vez por semana: novas temporadas (ex.: Paulistão 2027) entram sozinhas
    }
    $ligas = tsp_jogos_ligas();
    if (!$ligas) {
        return;
    }
    $times = array();
    $times_fem = array();
    $times_base = array();
    $todos = array();
    foreach ($ligas as $chave => $l) {
        if (empty($l['id']) || empty($l['temporada'])) {
            continue;
        }
        $r = tsp_jogos_get('fixtures', array('league' => $l['id'], 'season' => $l['temporada']), TSP_JOGOS_RESERVA_AO_VIVO);
        if (is_wp_error($r)) {
            tsp_jogos_log(tsp_jogos_nome_liga($chave) . ': ' . $r->get_error_message());
            continue;
        }
        $todos[$chave] = $r;
        foreach ($r as $f) {
            if (strpos($chave, 'base_') === 0) {
                $times_base[(int) ($f['teams']['home']['id'] ?? 0)] = $f['teams']['home']['name'] ?? '';
                $times_base[(int) ($f['teams']['away']['id'] ?? 0)] = $f['teams']['away']['name'] ?? '';
                continue;
            }
            if (strpos($chave, 'fem_') === 0) {
                $times_fem[(int) ($f['teams']['home']['id'] ?? 0)] = $f['teams']['home']['name'] ?? '';
                $times_fem[(int) ($f['teams']['away']['id'] ?? 0)] = $f['teams']['away']['name'] ?? '';
                continue;
            }
            $times[(int) ($f['teams']['home']['id'] ?? 0)] = $f['teams']['home']['name'] ?? '';
            $times[(int) ($f['teams']['away']['id'] ?? 0)] = $f['teams']['away']['name'] ?? '';
        }
    }
    // Brasileirão: só vincula pelos nomes exatos dos clubes paulistas; Paulistão: todos os participantes
    tsp_jogos_vincular_times(array_filter($times));
    tsp_jogos_vincular_femininos(array_filter($times_fem));
    tsp_jogos_vincular_base(array_filter($times_base));
    $n = 0;
    foreach ($todos as $chave => $r) {
        foreach ($r as $f) {
            tsp_jogos_gravar($chave, $ligas[$chave]['temporada'], $f);
            $n++;
        }
        if (!empty($ligas[$chave]['tabela']) && (strpos($chave, 'paulistao') === 0 || in_array($chave, array('serie_a', 'serie_b', 'fem_brasileiro_a1', 'fem_paulistao'), true))) {
            tsp_jogos_atualizar_classificacao($chave);
        }
    }
    tsp_jogos_completar_fichas();
    tsp_jogos_pre_jogo();
    tsp_jogos_criar_paginas();
    tsp_jogos_montar_resumo();
    update_option('tsp_jogos_ultima_sinc', time(), false);
    tsp_jogos_log('Sincronização diária: ' . $n . ' jogos lidos.');
}

function tsp_jogos_atualizar_classificacao($chave)
{
    $l = tsp_jogos_ligas()[$chave] ?? null;
    if (!$l) {
        return;
    }
    $r = tsp_jogos_get('standings', array('league' => $l['id'], 'season' => $l['temporada']), TSP_JOGOS_RESERVA_AO_VIVO / 2);
    if (is_wp_error($r) || empty($r[0]['league']['standings'])) {
        return;
    }
    $grupos = array();
    foreach ($r[0]['league']['standings'] as $g) {
        $linhas = array();
        foreach ($g as $x) {
            $linhas[] = array(
                (int) $x['rank'], (int) ($x['team']['id'] ?? 0), sanitize_text_field($x['team']['name'] ?? ''),
                (int) $x['points'], (int) ($x['all']['played'] ?? 0), (int) ($x['all']['win'] ?? 0), (int) ($x['all']['draw'] ?? 0),
                (int) ($x['all']['lose'] ?? 0), (int) ($x['goalsDiff'] ?? 0), sanitize_text_field($x['group'] ?? ''),
            );
        }
        $grupos[] = $linhas;
    }
    update_option('tsp_jogos_class_' . sanitize_key($chave), array('quando' => time(), 'grupos' => $grupos), false);
}

// Ficha técnica (lances, escalações, estatísticas) dos jogos paulistas encerrados que ainda não têm ficha
function tsp_jogos_completar_fichas()
{
    $ids = wp_list_pluck(tsp_jogos_buscar("sp = 1 AND status IN ('FT','AET','PEN') AND detalhes_em < inicio + 7200 AND inicio > %d", array(time() - 30 * DAY_IN_SECONDS), 'inicio DESC', 20), 'id');
    tsp_jogos_buscar_detalhes($ids);
}

function tsp_jogos_buscar_detalhes($ids)
{
    if (!$ids) {
        return;
    }
    $r = tsp_jogos_get('fixtures', array('ids' => implode('-', array_map('intval', $ids))));
    if (is_wp_error($r)) {
        return;
    }
    foreach ($r as $f) {
        $j = tsp_jogos_buscar('id = %d', array((int) $f['fixture']['id']), 'inicio ASC', 1);
        $chave = $j ? $j[0]->liga : '';
        $temp = $j ? $j[0]->temporada : 0;
        tsp_jogos_gravar($chave, $temp, $f, true);
    }
}

// Pré-jogo dos próximos 3 dias: confronto direto e desfalques (uma consulta por jogo, uma vez só)
function tsp_jogos_pre_jogo()
{
    $jogos = tsp_jogos_buscar("sp = 1 AND status IN ('NS','TBD') AND inicio BETWEEN %d AND %d", array(time(), time() + 3 * DAY_IN_SECONDS), 'inicio ASC', 6);
    foreach ($jogos as $j) {
        $d = tsp_jogos_detalhes($j->id);
        if (empty($d['h2h'])) {
            $h = tsp_jogos_get('fixtures/headtohead', array('h2h' => $j->casa_id . '-' . $j->fora_id, 'last' => 5), TSP_JOGOS_RESERVA_AO_VIVO);
            if (!is_wp_error($h)) {
                $lista = array();
                foreach ($h as $f) {
                    $lista[] = array((int) $f['fixture']['timestamp'], sanitize_text_field($f['teams']['home']['name']), $f['goals']['home'], $f['goals']['away'], sanitize_text_field($f['teams']['away']['name']), sanitize_text_field($f['league']['name'] ?? ''));
                }
                tsp_jogos_salvar_detalhe($j->id, 'h2h', $lista);
            }
        }
        $liga = tsp_jogos_ligas()[$j->liga] ?? array();
        if (!empty($liga['desfalques']) && empty($d['desfalques'])) {
            $i = tsp_jogos_get('injuries', array('fixture' => $j->id), TSP_JOGOS_RESERVA_AO_VIVO);
            if (!is_wp_error($i)) {
                $lista = array();
                foreach ($i as $x) {
                    $lista[] = array((int) ($x['team']['id'] ?? 0), sanitize_text_field($x['player']['name'] ?? ''), sanitize_text_field($x['player']['reason'] ?? ''));
                }
                tsp_jogos_salvar_detalhe($j->id, 'desfalques', $lista);
            }
        }
    }
}

// 5) Placar ao vivo: só gasta consulta se houver jogo paulista em andamento ou começando
function tsp_jogos_atualizar_ao_vivo()
{
    if (function_exists('tsp_jogos_base_ativa') && tsp_jogos_base_ativa()) {
        return;
    }
    $agora = time();
    $jogos = tsp_jogos_buscar("sp = 1 AND liga NOT LIKE 'base\\_%%' AND status NOT IN ('FT','AET','PEN','PST','CANC','ABD','AWD','WO') AND inicio BETWEEN %d AND %d", array($agora - 150 * MINUTE_IN_SECONDS, $agora + 10 * MINUTE_IN_SECONDS), 'inicio ASC', 20);
    if (!$jogos) {
        return;
    }
    $antes = array();
    foreach ($jogos as $j) {
        $antes[$j->id] = $j->liga;
    }
    tsp_jogos_buscar_detalhes(array_keys($antes));
    $acabaram = tsp_jogos_buscar("id IN (" . implode(',', array_map('intval', array_keys($antes))) . ") AND status IN ('FT','AET','PEN')", array(), 'inicio ASC', 20);
    $ligas = array();
    foreach ($acabaram as $j) {
        $ligas[$j->liga] = true;
    }
    foreach (array_keys($ligas) as $l) {
        tsp_jogos_atualizar_classificacao($l);
    }
    tsp_jogos_montar_resumo();
    tsp_jogos_limpar_cache($jogos);
}

// Limpa do cache só as páginas afetadas: home, páginas dos jogos e dos dois clubes
function tsp_jogos_limpar_cache($jogos)
{
    $urls = array(home_url('/'));
    foreach ($jogos as $j) {
        $p = tsp_jogos_post_do_jogo($j->id);
        if ($p) {
            $urls[] = get_permalink($p);
        }
        foreach (array($j->casa_id, $j->fora_id) as $t) {
            $slug = tsp_jogos_slug_do_time($t);
            $termo = $slug ? get_term_by('slug', $slug, 'times') : null;
            if ($termo) {
                $urls[] = get_term_link($termo);
            }
        }
    }
    foreach (array_unique($urls) as $u) {
        if (is_string($u)) {
            do_action('litespeed_purge_url', $u);
        }
    }
}
