<?php
/**
 * Simulador TSP do Brasileirão: o leitor preenche os placares dos jogos que faltam e a tabela é recalculada na hora.
 * Dados: Base TSP (tsp.json → "simulador"): tabela atual + jogos restantes. Jogo encerrado sai sozinho do simulador.
 * Página criada automaticamente: /simulador-brasileirao/ (shortcode [tsp_simulador liga="serie_a"]).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_SIM_PAGINA = 'simulador-brasileirao';

function tsp_sim_dados($liga = 'serie_a')
{
    $s = (array) get_option('tsp_simulador', array());
    return $s[$liga] ?? null;
}

function tsp_sim_url()
{
    $p = get_page_by_path(TSP_SIM_PAGINA);
    return ($p && $p->post_status === 'publish') ? get_permalink($p) : '';
}

// Cria a página do simulador uma vez (se não existir)
add_action('init', function () {
    if (get_option('tsp_sim_pagina_v') === '1' || !tsp_sim_dados()) {
        return;
    }
    update_option('tsp_sim_pagina_v', '1', false);
    if (get_page_by_path(TSP_SIM_PAGINA, OBJECT, 'page')) {
        return;
    }
    $admin = get_users(array('role' => 'administrator', 'number' => 1, 'fields' => 'ID'));
    $id = wp_insert_post(array(
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_title'   => 'Simulador do Brasileirão 2026',
        'post_name'    => TSP_SIM_PAGINA,
        'post_author'  => $admin ? (int) $admin[0] : 1,
        'post_content' => "<!-- wp:paragraph -->\n<p>Preencha os placares dos jogos que faltam e veja na hora como fica a tabela do Brasileirão 2026: quem fica com o título, quem vai para a Libertadores e a Sul-Americana e quem cai para a Série B. Os jogos que já terminaram saem do simulador automaticamente.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[tsp_simulador liga=\"serie_a\"]\n<!-- /wp:shortcode -->",
    ));
    if ($id && !is_wp_error($id)) {
        update_post_meta($id, '_yoast_wpseo_title', 'Simulador do Brasileirão 2026: simule a tabela e veja quem cai | TSP');
        update_post_meta($id, '_yoast_wpseo_metadesc', 'Simulador do Brasileirão Série A 2026: preencha os placares das últimas rodadas e veja quem é campeão, quem vai à Libertadores e quem é rebaixado.');
        update_post_meta($id, '_yoast_wpseo_focuskw', 'simulador do Brasileirão');
    }
}, 30);

// Página do simulador: cache curto (os jogos mudam ao longo do dia)
add_action('template_redirect', function () {
    if (is_page(TSP_SIM_PAGINA)) {
        do_action('litespeed_control_set_ttl', 900);
    }
});

function tsp_sim_escudo($api_id)
{
    $slug = function_exists('tsp_jogos_slug_do_time') ? tsp_jogos_slug_do_time($api_id) : '';
    $t = $slug ? get_term_by('slug', $slug, 'times') : null;
    if ($t && function_exists('tsp_escudo_url')) {
        $u = (string) tsp_escudo_url($t);
        if ($u) {
            return $u;
        }
    }
    return function_exists('tsp_jogos_escudo_url') ? (string) tsp_jogos_escudo_url($api_id) : '';
}

add_shortcode('tsp_simulador', function ($atts) {
    $a = shortcode_atts(array('liga' => 'serie_a'), $atts);
    $d = tsp_sim_dados($a['liga']);
    if (!$d || empty($d['tabela'])) {
        return '<p>O simulador volta em instantes.</p>';
    }
    $times = array();
    foreach ($d['tabela'] as $r) {
        $nome = function_exists('tsp_jogos_nome_time') ? tsp_jogos_nome_time($r['id'], $r['nome']) : $r['nome'];
        $slug = function_exists('tsp_jogos_slug_do_time') ? tsp_jogos_slug_do_time($r['id']) : '';
        $times[$r['id']] = array('nome' => $nome, 'escudo' => tsp_sim_escudo($r['id']), 'sp' => $slug !== '');
    }
    $jogos = array();
    foreach ((array) $d['jogos'] as $j) {
        $dt = date_create_immutable(str_replace('T', ' ', substr($j['data'], 0, 16)), new DateTimeZone('America/Sao_Paulo'));
        $sem = array('dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb');
        $txt = $dt ? ($j['a_confirmar'] || strlen($j['data']) <= 10 ? $dt->format('d/m') . ' · horário a confirmar' : $sem[(int) $dt->format('w')] . ' ' . $dt->format('d/m') . ' · ' . $dt->format('H\hi')) : '';
        $jogos[] = array('id' => (string) $j['id'], 'r' => (string) $j['rodada'], 'c' => (int) $j['casa'], 'f' => (int) $j['fora'], 'd' => $txt);
    }
    $dados = array('tabela' => $d['tabela'], 'jogos' => $jogos, 'times' => $times, 'zonas' => (array) $d['zonas'], 'liga' => $a['liga'], 'url' => get_permalink());
    $json = wp_json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
    ob_start();
    ?>
<div class="tsp-sim" id="tsp-sim" data-pronto="0">
    <div class="tsp-sim__barra">
        <p><strong><?php echo count($jogos); ?> jogos</strong> para simular. Digite os placares: a tabela muda na hora.</p>
        <div class="tsp-sim__acoes">
            <button type="button" class="tsp-sim__btn" data-acao="limpar">Limpar placares</button>
            <button type="button" class="tsp-sim__btn tsp-sim__btn--forte" data-acao="partilhar">Compartilhar minha simulação</button>
        </div>
    </div>
    <div class="tsp-sim__resumo" aria-live="polite"></div>
    <div class="tsp-sim__grade">
        <section class="tsp-sim__jogos" aria-label="Jogos que faltam">
            <h2 class="tsp-sim__jtit">Jogos que faltam</h2><nav class="tsp-sim__nav" aria-label="Ir para a rodada"></nav>
            <div class="tsp-sim__lista"></div>
            <a class="tsp-sim__ir" href="#tsp-sim-tabela">Ver a tabela simulada ↓</a>
        </section>
        <section class="tsp-sim__tabela" id="tsp-sim-tabela" aria-label="Tabela simulada">
            <h2>Classificação simulada</h2>
            <div class="tsp-sim__rolagem"><table><thead><tr><th>#</th><th class="t">Time</th><th>P</th><th>J</th><th class="x">V</th><th class="x">E</th><th class="x">D</th><th>SG</th><th class="x">GP</th></tr></thead><tbody></tbody></table></div>
            <ul class="tsp-sim__legenda"></ul>
            <p class="tsp-sim__nota">Critérios de desempate usados: pontos, vitórias, saldo de gols e gols marcados. A tabela parte da classificação oficial atualizada pelo TSP.</p>
        </section>
    </div>
</div>
<script type="application/json" id="tsp-sim-dados"><?php echo $json; // phpcs:ignore ?></script>
<style>
.tsp-sim{--sim-l:#E8862A;--sim-b:#e3ddd3;margin:18px 0 28px;font-size:15px}
.tsp-sim__barra{display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;align-items:center;background:#111;color:#fff;border-radius:12px;padding:12px 16px}
.tsp-sim__barra p{margin:0}
.tsp-sim__acoes{display:flex;gap:8px;flex-wrap:wrap}
.tsp-sim__btn{border:1px solid #fff3;background:transparent;color:#fff;border-radius:999px;padding:8px 14px;font-weight:700;cursor:pointer}
.tsp-sim__btn--forte{background:var(--sim-l);border-color:var(--sim-l);color:#111}
.tsp-sim__resumo{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:14px 0}
.tsp-sim__resumo div{background:#fff;border:1px solid var(--sim-b);border-left:4px solid var(--c,#111);border-radius:10px;padding:10px 12px}
.tsp-sim__resumo span{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#666}
.tsp-sim__resumo b{font-size:15px}
.tsp-sim__grade{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:18px;align-items:start}
.tsp-sim__jogos,.tsp-sim__tabela{background:#fff;border:1px solid var(--sim-b);border-radius:12px;padding:14px}
.tsp-sim__tabela{position:sticky;top:12px;max-height:calc(100vh - 24px);overflow:auto}
.tsp-sim .tsp-sim__jtit,.tsp-sim .tsp-sim__tabela h2{font-size:20px!important;line-height:1.2!important;margin:0 0 8px;text-align:center}
.tsp-sim__nav{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-bottom:6px}
.tsp-sim__nav a{border:1px solid var(--sim-b);border-radius:999px;padding:4px 10px;font-size:13px;font-weight:700;color:#111;text-decoration:none}
.tsp-sim .tsp-sim__rod{margin:16px 0 0;padding:8px 12px;background:#111;color:#fff;border-radius:8px;font-size:14px!important;line-height:1.3!important;text-transform:uppercase;letter-spacing:.03em;scroll-margin-top:12px}
.tsp-sim__ir{position:sticky;bottom:12px;z-index:5;background:#E8862A;color:#111!important;border-radius:999px;padding:10px 16px;text-align:center;box-shadow:0 4px 14px #0003}
.tsp-sim__jogo{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:8px;padding:10px 0;border-top:1px solid #f0ebe3}
.tsp-sim__jogo small{grid-column:1/-1;text-align:center;color:#777;font-size:12px;margin-bottom:-4px}
.tsp-sim__time{display:flex;align-items:center;gap:6px;min-width:0;font-weight:600}
.tsp-sim__time span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tsp-sim__time--c{justify-content:flex-end;text-align:right}
.tsp-sim__time img,.tsp-sim__esc{width:26px;height:26px;object-fit:contain;flex:none}
.tsp-sim__esc{display:inline-grid;place-items:center;border-radius:50%;background:#eee;font-size:8px;font-weight:800;overflow:hidden}
.tsp-sim__placar{display:flex;align-items:center;gap:4px}
.tsp-sim__placar input{width:44px;height:40px;text-align:center;font-size:18px;font-weight:800;border:2px solid var(--sim-b);border-radius:8px;-moz-appearance:textfield}
.tsp-sim__placar input:focus{border-color:var(--sim-l);outline:none}
.tsp-sim__placar input::-webkit-outer-spin-button,.tsp-sim__placar input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
.tsp-sim__ir{display:none;margin-top:10px;font-weight:700;text-decoration:none}
.tsp-sim__rolagem{overflow-x:auto}
.tsp-sim table{width:100%;border-collapse:collapse;font-size:14px}
.tsp-sim th{font-size:11px;text-transform:uppercase;color:#777;text-align:center;padding:6px 4px}
.tsp-sim td{text-align:center;padding:6px 4px;border-top:1px solid #f0ebe3}
.tsp-sim td:first-child{border-left:4px solid var(--z,transparent);font-weight:800}
.tsp-sim .t{text-align:left}
.tsp-sim td.t{display:flex;align-items:center;gap:6px;font-weight:600}
.tsp-sim td.t img,.tsp-sim td.t .tsp-sim__esc{width:20px;height:20px}
.tsp-sim .mov{font-size:11px;font-weight:800;margin-left:auto}
.tsp-sim .mov.s{color:#1a7f37}.tsp-sim .mov.d{color:#c0392b}
.tsp-sim tr.mud td{background:#fff7ec}
.tsp-sim__legenda{list-style:none;padding:0;margin:10px 0 0;display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12px}
.tsp-sim__legenda li::before{content:"";display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--z);margin-right:5px;vertical-align:-1px}
.tsp-sim__nota{font-size:12px;color:#777;margin:8px 0 0}
.tsp-sim__aviso{position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:#111;color:#fff;padding:10px 16px;border-radius:999px;z-index:99;font-weight:700}
@media (max-width:900px){.tsp-sim__grade{grid-template-columns:1fr}.tsp-sim__tabela{position:static}.tsp-sim__ir{display:block}.tsp-sim .x{display:none}}
@media (max-width:600px){.tsp-sim{font-size:14px}.tsp-sim__barra{padding:10px 12px}.tsp-sim__btn{padding:7px 12px;font-size:13px}
.tsp-sim__resumo{grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}.tsp-sim__resumo div{padding:7px 8px}.tsp-sim__resumo span{font-size:10px}.tsp-sim__resumo b{font-size:12px;line-height:1.3;display:block;overflow-wrap:anywhere}
.tsp-sim__jogos,.tsp-sim__tabela{padding:10px}
.tsp-sim__time,.tsp-sim__time--c{flex-direction:column;justify-content:center;text-align:center;gap:3px;font-size:12px}
.tsp-sim__time--c{flex-direction:column-reverse}.tsp-sim__time span{white-space:normal;line-height:1.2}
.tsp-sim__placar input{width:40px;height:40px}}
</style>
<script>
(function(){
var raiz=document.getElementById('tsp-sim'),D=JSON.parse(document.getElementById('tsp-sim-dados').textContent);
var CH='tsp-sim-'+D.liga,pl={};
try{pl=JSON.parse(localStorage.getItem(CH)||'{}')||{}}catch(e){pl={}}
if(location.hash.indexOf('#s=')===0){try{pl=JSON.parse(decodeURIComponent(escape(atob(location.hash.slice(3)))))||{}}catch(e){}}
var rods=[],porR={};D.jogos.forEach(function(j){if(!porR[j.r]){porR[j.r]=[];rods.push(j.r)}porR[j.r].push(j)});
rods.sort(function(a,b){return (+a)-(+b)});var cheia=rods.filter(function(r){return porR[r].length>=5}).map(Number),ref=cheia.length?Math.min.apply(null,cheia):0;
function atr(r){return (+r)<ref-1}
function titR(r){return atr(r)?'Jogo atrasado · Rodada '+r:'Rodada '+r}
(function(){var a=rods.filter(atr),n=rods.filter(function(r){return !atr(r)});rods=n.length?[n[0]].concat(a,n.slice(1)):a})();
var ri=0,base={};D.tabela.forEach(function(t,i){base[t.id]=i+1});
function esc(id){var t=D.times[id]||{};return t.escudo?'<img src="'+t.escudo+'" alt="" loading="lazy" width="26" height="26">':'<span class="tsp-sim__esc">'+(t.nome||'?').slice(0,2).toUpperCase()+'</span>'}
function nm(id){return (D.times[id]||{}).nome||''}
function h(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function jogoH(j){var p=pl[j.id]||['',''];return '<div class="tsp-sim__jogo"><small>'+h(j.d)+'</small><div class="tsp-sim__time tsp-sim__time--c"><span>'+h(nm(j.c))+'</span>'+esc(j.c)+'</div><div class="tsp-sim__placar"><input inputmode="numeric" type="number" min="0" max="20" aria-label="Gols '+h(nm(j.c))+'" data-j="'+j.id+'" data-l="0" value="'+h(p[0])+'"><b>×</b><input inputmode="numeric" type="number" min="0" max="20" aria-label="Gols '+h(nm(j.f))+'" data-j="'+j.id+'" data-l="1" value="'+h(p[1])+'"></div><div class="tsp-sim__time">'+esc(j.f)+'<span>'+h(nm(j.f))+'</span></div></div>'}
// Todos os jogos de todas as rodadas, um bloco por rodada
function lista(){var x='';rods.forEach(function(r){x+='<h3 class="tsp-sim__rod" id="tsp-sim-r'+h(r)+'">'+h(titR(r))+'</h3>';(porR[r]||[]).forEach(function(j){x+=jogoH(j)})});
 raiz.querySelector('.tsp-sim__lista').innerHTML=x;
 raiz.querySelector('.tsp-sim__nav').innerHTML=rods.map(function(r){return '<a href="#tsp-sim-r'+h(r)+'">'+h(atr(r)?'Atrasado ('+r+')':'R'+r)+'</a>'}).join('');}
function calc(){var T={};D.tabela.forEach(function(t){T[t.id]={id:t.id,p:t.pts,j:t.j,v:t.v,e:t.e,d:t.d,gp:t.gp,gc:t.gc}});
 D.jogos.forEach(function(j){var p=pl[j.id];if(!p||p[0]===''||p[1]===''||p[0]==null||p[1]==null)return;var a=+p[0],b=+p[1],c=T[j.c],f=T[j.f];if(!c||!f)return;
  c.j++;f.j++;c.gp+=a;c.gc+=b;f.gp+=b;f.gc+=a;if(a>b){c.v++;c.p+=3;f.d++}else if(a<b){f.v++;f.p+=3;c.d++}else{c.e++;f.e++;c.p++;f.p++}});
 return Object.keys(T).map(function(k){return T[k]}).sort(function(x,y){return y.p-x.p||y.v-x.v||(y.gp-y.gc)-(x.gp-x.gc)||y.gp-x.gp||nm(x.id).localeCompare(nm(y.id))});}
function zona(pos){for(var i=0;i<D.zonas.length;i++){var z=D.zonas[i];if(pos>=z.de&&pos<=z.ate)return z}return null}
function tabela(){var L=calc(),x='';L.forEach(function(t,i){var pos=i+1,z=zona(pos),dif=base[t.id]-pos,sg=t.gp-t.gc;
 x+='<tr'+(dif?' class="mud"':'')+'><td style="--z:'+(z?z.cor:'transparent')+'">'+pos+'</td><td class="t">'+esc(t.id)+'<span>'+h(nm(t.id))+'</span>'+(dif?'<span class="mov '+(dif>0?'s':'d')+'">'+(dif>0?'▲'+dif:'▼'+(-dif))+'</span>':'')+'</td><td><strong>'+t.p+'</strong></td><td>'+t.j+'</td><td class="x">'+t.v+'</td><td class="x">'+t.e+'</td><td class="x">'+t.d+'</td><td>'+(sg>0?'+':'')+sg+'</td><td class="x">'+t.gp+'</td></tr>'});
 raiz.querySelector('tbody').innerHTML=x;
 var z4=D.zonas.filter(function(z){return z.de>=15})[0],lib=D.zonas[0];
 raiz.querySelector('.tsp-sim__resumo').innerHTML='<div style="--c:#E8862A"><span>Campeão</span><b>'+h(nm(L[0].id))+'</b></div>'+(lib?'<div style="--c:'+lib.cor+'"><span>Libertadores</span><b>'+L.slice(lib.de-1,lib.ate).map(function(t){return h(nm(t.id))}).join(', ')+'</b></div>':'')+(z4?'<div style="--c:'+z4.cor+'"><span>Rebaixados</span><b>'+L.slice(z4.de-1,z4.ate).map(function(t){return h(nm(t.id))}).join(', ')+'</b></div>':'');}
function guardar(){try{localStorage.setItem(CH,JSON.stringify(pl))}catch(e){}}
function aviso(t){var a=document.createElement('div');a.className='tsp-sim__aviso';a.textContent=t;document.body.appendChild(a);setTimeout(function(){a.remove()},2600)}
raiz.addEventListener('input',function(e){var i=e.target;if(!i.dataset||!i.dataset.j)return;var v=i.value.replace(/\D/g,'').slice(0,2);if(v!==i.value)i.value=v;var p=pl[i.dataset.j]||['',''];p[+i.dataset.l]=v;pl[i.dataset.j]=p;guardar();tabela();
 if(v!==''&&i.dataset.l==='0'){var n=i.parentNode.querySelector('[data-l="1"]');if(n)n.focus()}});
raiz.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;
 if(b.dataset.acao==='limpar'){pl={};guardar();lista();tabela();history.replaceState(null,'',location.pathname);return}
 if(b.dataset.acao==='partilhar'){var u=D.url+'#s='+btoa(unescape(encodeURIComponent(JSON.stringify(pl)))),L=calc(),txt='Minha simulação do Brasileirão no TSP: campeão '+nm(L[0].id)+'. Faça a sua:';
  if(navigator.share){navigator.share({title:'Simulador TSP do Brasileirão',text:txt,url:u}).catch(function(){})}else{try{navigator.clipboard.writeText(txt+' '+u);aviso('Link copiado! Cole no WhatsApp.')}catch(e){window.open('https://wa.me/?text='+encodeURIComponent(txt+' '+u),'_blank')}}}});
raiz.querySelector('.tsp-sim__legenda').innerHTML=D.zonas.map(function(z){return '<li style="--z:'+z.cor+'">'+h(z.nome)+' ('+z.de+(z.ate>z.de?'º ao '+z.ate+'º':'º')+')</li>'}).join('');
lista();tabela();raiz.dataset.pronto='1';
})();
</script>
    <?php
    return ob_get_clean();
});

// Botão em destaque para o simulador (usado pelo tema na home e na página da Série A)
function tsp_sim_botao_html($texto = 'Simulador TSP Brasileirão')
{
    $u = tsp_sim_url();
    if (!$u) {
        return '';
    }
    return '<a class="tsp-sim-cta" href="' . esc_url($u) . '"><span class="tsp-sim-cta__ico" aria-hidden="true">🧮</span><span><strong>' . esc_html($texto) . '</strong><small>Simule as últimas rodadas e veja quem é campeão e quem cai</small></span><span class="tsp-sim-cta__seta" aria-hidden="true">→</span></a>'
        . '<style>.tsp-sim-cta{display:flex;align-items:center;gap:12px;background:#111;color:#fff;border-radius:14px;padding:14px 18px;margin:14px 0;text-decoration:none;border-left:6px solid #E8862A}.tsp-sim-cta:hover{background:#222;color:#fff}.tsp-sim-cta strong{display:block;font-size:18px;text-transform:uppercase;letter-spacing:.02em}.tsp-sim-cta small{display:block;opacity:.8}.tsp-sim-cta__ico{font-size:28px}.tsp-sim-cta__seta{margin-left:auto;font-size:24px;color:#E8862A}</style>';
}
