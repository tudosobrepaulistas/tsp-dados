<?php
/**
 * Ofertas do Mercado Livre por clube (listas de afiliado do TSP), lidas de api/ofertas.json da Base TSP.
 * O tema mostra a vitrine nas matérias e na página do clube. O clique leva à lista de afiliado do TSP.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_OFERTAS_URL = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/ofertas.json';

add_action('tsp_jogos_base', function () {
    tsp_ofertas_importar(false);
});

function tsp_ofertas_importar($forcar = false)
{
    $r = wp_remote_get(add_query_arg('v', floor(time() / 900), TSP_OFERTAS_URL), array('timeout' => 20));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return false;
    }
    $corpo = wp_remote_retrieve_body($r);
    if (!$forcar && get_option('tsp_ofertas_hash') === md5($corpo)) {
        return true;
    }
    $d = json_decode($corpo, true);
    if (!is_array($d) || empty($d['clubes'])) {
        return false;
    }
    $limpo = array('gerado' => sanitize_text_field($d['gerado'] ?? ''), 'clubes' => array());
    foreach ($d['clubes'] as $slug => $c) {
        $prods = array();
        foreach (array_slice((array) ($c['produtos'] ?? array()), 0, 20) as $p) {
            $img = esc_url_raw($p['img'] ?? '');
            if (!$img || strpos($img, 'https://http2.mlstatic.com/') !== 0) {
                continue; // só fotos do próprio Mercado Livre
            }
            $prods[] = array('titulo' => sanitize_text_field($p['titulo'] ?? ''), 'preco' => sanitize_text_field($p['preco'] ?? ''), 'antigo' => sanitize_text_field($p['preco_antigo'] ?? ''), 'img' => $img);
        }
        $lista = esc_url_raw($c['lista'] ?? '');
        if ($prods && preg_match('~^https://meli\.la/~', $lista)) {
            $limpo['clubes'][sanitize_title($slug)] = array('lista' => $lista, 'lido' => sanitize_text_field($c['lido_em'] ?? ''), 'produtos' => $prods);
        }
    }
    update_option('tsp_ofertas', $limpo, false);
    update_option('tsp_ofertas_hash', md5($corpo), false);
    return true;
}
