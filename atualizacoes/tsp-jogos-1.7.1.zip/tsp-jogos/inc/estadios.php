<?php
/**
 * Foto do estádio como destaque da página de jogo.
 * O pré-jogo da Base TSP traz "estadio_wiki" (título da página do estádio na Wikipédia em português).
 * O site pega a imagem principal dessa página, confere no Wikimedia Commons se a licença é livre
 * (CC BY, CC BY-SA, CC0 ou domínio público), baixa uma vez para a Biblioteca de mídia com o crédito do autor
 * e usa como imagem de destaque de todos os jogos naquele estádio. Licença não livre: não usa.
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('tsp_jogos_base', 'tsp_jogos_estadios_buscar', 40);

function tsp_jogos_estadio_foto($titulo)
{
    $e = (array) get_option('tsp_jogos_estadios', array());
    $x = $e[$titulo] ?? array();
    return !empty($x['anexo']) && get_post($x['anexo']) ? (int) $x['anexo'] : 0;
}

function tsp_jogos_estadios_buscar($max = 3)
{
    global $wpdb;
    $max = (int) $max ?: 3;
    $e = (array) get_option('tsp_jogos_estadios', array());
    $linhas = $wpdb->get_results('SELECT id, detalhes FROM ' . tsp_jogos_tabela() . " WHERE id BETWEEN 91000000 AND 91999999 AND inicio > " . (time() - 2 * DAY_IN_SECONDS));
    $feitos = 0;
    foreach ($linhas as $l) {
        $d = json_decode((string) $l->detalhes, true);
        $tit = trim((string) ($d['prejogo']['estadio_wiki'] ?? ''));
        if ($tit === '') {
            continue;
        }
        $anexo = tsp_jogos_estadio_foto($tit);
        if (!$anexo && $feitos < $max && (($e[$tit]['tentou'] ?? 0) < time() - 7 * DAY_IN_SECONDS)) {
            $feitos++;
            $anexo = tsp_jogos_estadio_baixar($tit);
            $e[$tit] = $anexo ? array('anexo' => $anexo) : array('tentou' => time());
            update_option('tsp_jogos_estadios', $e, false);
        }
        $post = tsp_jogos_post_do_jogo((int) $l->id);
        if ($anexo && $post && !has_post_thumbnail($post)) {
            set_post_thumbnail($post, $anexo);
        }
    }
}

function tsp_jogos_estadio_baixar($tit)
{
    $ua = array('User-Agent' => 'TSP-Jogos/1.0 (tudosobrepaulista.com.br)');
    $r = wp_remote_get(add_query_arg(array('action' => 'query', 'format' => 'json', 'redirects' => 1, 'prop' => 'pageimages', 'piprop' => 'name', 'titles' => $tit), 'https://pt.wikipedia.org/w/api.php'), array('timeout' => 15, 'headers' => $ua));
    if (is_wp_error($r)) {
        return 0;
    }
    $arq = '';
    foreach ((array) (json_decode(wp_remote_retrieve_body($r), true)['query']['pages'] ?? array()) as $pg) {
        $arq = $pg['pageimage'] ?? '';
    }
    if ($arq === '') {
        return 0;
    }
    $r = wp_remote_get(add_query_arg(array('action' => 'query', 'format' => 'json', 'prop' => 'imageinfo', 'iiprop' => 'url|extmetadata', 'iiurlwidth' => 1600, 'titles' => 'File:' . $arq), 'https://commons.wikimedia.org/w/api.php'), array('timeout' => 15, 'headers' => $ua));
    if (is_wp_error($r)) {
        return 0;
    }
    $info = null;
    foreach ((array) (json_decode(wp_remote_retrieve_body($r), true)['query']['pages'] ?? array()) as $pg) {
        $info = $pg['imageinfo'][0] ?? null;
    }
    if (!$info) {
        return 0; // arquivo só na Wikipédia local (geralmente uso restrito): não usa
    }
    $m = $info['extmetadata'] ?? array();
    $lic = trim(wp_strip_all_tags($m['LicenseShortName']['value'] ?? ''));
    if (!preg_match('~^(CC BY(-SA)?( \d\.\d)?|CC0|Public domain|Domínio público|PD)~i', $lic) || preg_match('~NC|ND~', $lic)) {
        return 0;
    }
    $autor = trim(preg_replace('~\s+~', ' ', wp_strip_all_tags($m['Artist']['value'] ?? '')));
    $autor = $autor !== '' ? mb_substr($autor, 0, 80) : 'autor no Wikimedia Commons';
    $url = $info['thumburl'] ?? ($info['url'] ?? '');
    if (strpos($url, 'https://upload.wikimedia.org/') !== 0) {
        return 0;
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $tmp = download_url($url, 30);
    if (is_wp_error($tmp)) {
        return 0;
    }
    $file = array('name' => sanitize_file_name(sanitize_title($tit) . '.' . (pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg')), 'tmp_name' => $tmp);
    $cred = 'Foto: ' . $autor . ' / Wikimedia Commons (' . $lic . ')';
    $id = media_handle_sideload($file, 0, $tit, array('post_excerpt' => $cred, 'post_content' => 'Fonte: ' . ($info['descriptionurl'] ?? '')));
    if (is_wp_error($id)) {
        @unlink($tmp);
        return 0;
    }
    update_post_meta($id, '_wp_attachment_image_alt', $tit);
    update_post_meta($id, 'tsp_credito', $cred);
    return (int) $id;
}
