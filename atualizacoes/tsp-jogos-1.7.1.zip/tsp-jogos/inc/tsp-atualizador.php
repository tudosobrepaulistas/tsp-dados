<?php
/**
 * Atualizador automático do TSP (plugins e tema próprios).
 *
 * Lê https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/atualizacoes/versoes.json
 * e, quando há versão nova, ela aparece em Painel → Atualizações e é instalada sozinha pela
 * atualização automática do WordPress (2 vezes por dia), ou na hora com "Atualizar agora".
 * Só aceita pacotes do repositório do TSP. O mesmo arquivo vai dentro de cada plugin e do tema;
 * o primeiro a carregar registra os ganchos e os outros só se inscrevem.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('tsp_atualizador_registrar')) {

    define('TSP_ATUALIZADOR_MANIFESTO', 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/atualizacoes/versoes.json');
    define('TSP_ATUALIZADOR_PACOTES', 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/atualizacoes/');

    $GLOBALS['tsp_atualizador_itens'] = array();

    // $tipo: 'plugin' ou 'tema'; $id: pasta (ex.: tsp-jogos); $arquivo: plugin_basename (ex.: tsp-jogos/tsp-jogos.php)
    function tsp_atualizador_registrar($tipo, $id, $arquivo, $versao)
    {
        $GLOBALS['tsp_atualizador_itens'][$id] = array('tipo' => $tipo, 'arquivo' => $arquivo, 'versao' => $versao);
    }

    function tsp_atualizador_manifesto($forcar = false)
    {
        $m = $forcar ? false : get_site_transient('tsp_atualizador_manifesto');
        if (is_array($m)) {
            return $m;
        }
        $r = wp_remote_get(add_query_arg('v', time(), TSP_ATUALIZADOR_MANIFESTO), array('timeout' => 15));
        $m = (!is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) === 200) ? json_decode(wp_remote_retrieve_body($r), true) : null;
        $m = is_array($m) ? $m : array();
        set_site_transient('tsp_atualizador_manifesto', $m, $m ? HOUR_IN_SECONDS : 15 * MINUTE_IN_SECONDS);
        return $m;
    }

    function tsp_atualizador_novo($id)
    {
        $it = $GLOBALS['tsp_atualizador_itens'][$id] ?? null;
        $m = tsp_atualizador_manifesto();
        $n = $m['itens'][$id] ?? null;
        if (!$it || !is_array($n) || empty($n['versao']) || !version_compare($n['versao'], $it['versao'], '>')) {
            return null;
        }
        $zip = basename((string) ($n['zip'] ?? ''));
        if (!preg_match('~^[a-z0-9-]+-\d+(\.\d+)*\.zip$~', $zip)) {
            return null;
        }
        $n['pacote'] = TSP_ATUALIZADOR_PACOTES . $zip;
        return $n;
    }

    add_filter('pre_set_site_transient_update_plugins', function ($t) {
        if (!is_object($t)) {
            return $t;
        }
        foreach ($GLOBALS['tsp_atualizador_itens'] as $id => $it) {
            if ($it['tipo'] !== 'plugin') {
                continue;
            }
            $n = tsp_atualizador_novo($id);
            $obj = (object) array(
                'id' => 'tsp/' . $id, 'slug' => $id, 'plugin' => $it['arquivo'],
                'new_version' => $n ? $n['versao'] : $it['versao'], 'url' => 'https://tudosobrepaulista.com.br/',
                'package' => $n ? $n['pacote'] : '', 'requires_php' => '7.4',
            );
            if ($n) {
                $t->response[$it['arquivo']] = $obj;
                unset($t->no_update[$it['arquivo']]);
            } else {
                $t->no_update[$it['arquivo']] = $obj;
            }
        }
        return $t;
    });

    add_filter('pre_set_site_transient_update_themes', function ($t) {
        if (!is_object($t)) {
            return $t;
        }
        foreach ($GLOBALS['tsp_atualizador_itens'] as $id => $it) {
            if ($it['tipo'] !== 'tema') {
                continue;
            }
            $n = tsp_atualizador_novo($id);
            $obj = array('theme' => $id, 'new_version' => $n ? $n['versao'] : $it['versao'], 'url' => 'https://tudosobrepaulista.com.br/', 'package' => $n ? $n['pacote'] : '');
            if ($n) {
                $t->response[$id] = $obj;
                unset($t->no_update[$id]);
            } else {
                $t->no_update[$id] = $obj;
            }
        }
        return $t;
    });

    // Janela "Ver detalhes" da versão
    add_filter('plugins_api', function ($r, $acao, $args) {
        if ($acao !== 'plugin_information' || empty($args->slug) || empty($GLOBALS['tsp_atualizador_itens'][$args->slug])) {
            return $r;
        }
        $it = $GLOBALS['tsp_atualizador_itens'][$args->slug];
        $n = tsp_atualizador_novo($args->slug);
        return (object) array(
            'name' => $args->slug, 'slug' => $args->slug, 'version' => $n ? $n['versao'] : $it['versao'], 'author' => 'TSP',
            'sections' => array('changelog' => '<p>' . esc_html($n['notas'] ?? 'Sem novidades.') . '</p>'),
            'download_link' => $n ? $n['pacote'] : '',
        );
    }, 10, 3);

    // Atualização automática ligada para os itens do TSP
    add_filter('auto_update_plugin', function ($ligar, $item) {
        foreach ($GLOBALS['tsp_atualizador_itens'] as $it) {
            if ($it['tipo'] === 'plugin' && isset($item->plugin) && $item->plugin === $it['arquivo']) {
                return true;
            }
        }
        return $ligar;
    }, 20, 2);
    add_filter('auto_update_theme', function ($ligar, $item) {
        $id = $item->theme ?? '';
        return (isset($GLOBALS['tsp_atualizador_itens'][$id]) && $GLOBALS['tsp_atualizador_itens'][$id]['tipo'] === 'tema') ? true : $ligar;
    }, 20, 2);

    // Depois de atualizar: limpa o cache do site
    add_action('upgrader_process_complete', function () {
        delete_site_transient('tsp_atualizador_manifesto');
        do_action('litespeed_purge_all');
    });

    // "Painel → Atualizações → Verificar novamente" também relê o manifesto
    add_action('load-update-core.php', function () {
        if (!empty($_GET['force-check'])) {
            delete_site_transient('tsp_atualizador_manifesto');
        }
    });
}
