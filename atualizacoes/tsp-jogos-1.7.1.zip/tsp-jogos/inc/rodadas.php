<?php
/**
 * Rodadas completas (Série A e B): cada jogo com ficha técnica, matéria do TSP (pós-jogo ou onde assistir)
 * e página do confronto. Navegação entre rodadas no tema (‹ ›).
 * Página de estatísticas de qualquer time da base, inclusive de fora de SP: /time/<chave>/.
 * Clube paulista leva para a página de notícias dele (/times/<slug>/).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_JOGOS_LIGAS_RODADAS = array('serie_a', 'serie_b');

function tsp_jogos_base_times()
{
    $t = get_option('tsp_jogos_base_times', array());
    return is_array($t) ? $t : array();
}

function tsp_jogos_time_link($id)
{
    $slug = tsp_jogos_slug_do_time($id);
    if ($slug) {
        $l = get_term_link($slug, 'times');
        if (!is_wp_error($l)) {
            return $l;
        }
    }
    $t = tsp_jogos_base_times()[(int) $id] ?? null;
    return $t ? home_url('/time/' . sanitize_title($t['chave']) . '/') : '';
}

// Matéria do TSP sobre o jogo: pós-jogo (encerrado) ou "onde assistir" (a disputar)
function tsp_jogos_materia_do_jogo($j)
{
    $chave = 'tsp_mat_' . (int) $j->id . '_' . $j->status;
    $c = get_transient($chave);
    if ($c !== false) {
        return $c;
    }
    $slugs = array_filter(array(tsp_jogos_slug_do_time($j->casa_id), tsp_jogos_slug_do_time($j->fora_id)));
    $link = '';
    if ($slugs) {
        $fim = in_array($j->status, array('FT', 'AET', 'PEN'), true);
        $q = new WP_Query(array(
            'post_type' => function_exists('tsp_tipos') ? tsp_tipos() : array('materia', 'post'), 'post_status' => 'publish', 'posts_per_page' => 12, 'no_found_rows' => true,
            'tax_query' => array(array('taxonomy' => 'times', 'field' => 'slug', 'terms' => array_values($slugs))),
            'date_query' => array(array('after' => gmdate('Y-m-d H:i:s', $j->inicio - ($fim ? 0 : 4 * DAY_IN_SECONDS)), 'before' => gmdate('Y-m-d H:i:s', $j->inicio + ($fim ? 3 * DAY_IN_SECONDS : 3 * HOUR_IN_SECONDS)), 'column' => 'post_date_gmt')),
        ));
        $casa = remove_accents(mb_strtolower(tsp_jogos_nome_time($j->casa_id, $j->casa)));
        $fora = remove_accents(mb_strtolower(tsp_jogos_nome_time($j->fora_id, $j->fora)));
        $melhor = 0;
        foreach ($q->posts as $p) {
            $t = remove_accents(mb_strtolower($p->post_title));
            $pts = 0;
            $pts += (strpos($t, strtok($casa, ' ')) !== false) + (strpos($t, strtok($fora, ' ')) !== false);
            if ($fim) {
                $pts += preg_match('~\d+\s*x\s*\d+~', $t) ? 3 : 0;
                $pts -= strpos($t, 'onde assistir') !== false ? 3 : 0;
            } else {
                $pts += strpos($t, 'onde assistir') !== false ? 3 : 0;
            }
            if ($pts > $melhor && $pts >= 3) {
                $melhor = $pts;
                $link = get_permalink($p);
            }
        }
    }
    set_transient($chave, $link, 3 * HOUR_IN_SECONDS);
    return $link;
}

function tsp_jogos_montar_rodadas($liga)
{
    $jogos = tsp_jogos_buscar('liga = %s', array($liga), 'inicio ASC', 500);
    $rod = array();
    foreach ($jogos as $j) {
        $k = $j->rodada !== '' ? $j->rodada : wp_date('d/m', $j->inicio);
        $fim = in_array($j->status, array('FT', 'AET', 'PEN'), true);
        $pag = tsp_jogos_link_jogo($j->id);
        $rod[$k]['titulo'] = tsp_jogos_rodada_curta($k);
        $rod[$k]['inicio'] = min($rod[$k]['inicio'] ?? PHP_INT_MAX, (int) $j->inicio);
        $rod[$k]['aberta'] = ($rod[$k]['aberta'] ?? false) || !$fim;
        $rod[$k]['jogos'][] = array(
            'dia' => tsp_jogos_dia_curto($j->inicio),
            'casa' => tsp_jogos_nome_time($j->casa_id, $j->casa), 'casa_link' => tsp_jogos_time_link($j->casa_id), 'casa_sp' => (bool) tsp_jogos_slug_do_time($j->casa_id),
            'fora' => tsp_jogos_nome_time($j->fora_id, $j->fora), 'fora_link' => tsp_jogos_time_link($j->fora_id), 'fora_sp' => (bool) tsp_jogos_slug_do_time($j->fora_id),
            'placar' => ($j->gols_casa !== null && !in_array($j->status, array('NS', 'TBD'), true)) ? (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : '',
            'status' => $fim ? 'fim' : (in_array($j->status, array('PST', 'SUSP', 'CANC'), true) ? tsp_jogos_rotulo_status($j) : 'vai'),
            'jogo' => $pag, 'materia' => tsp_jogos_materia_do_jogo($j),
            'casa_id' => (int) $j->casa_id, 'fora_id' => (int) $j->fora_id, 'estadio' => $j->estadio,
            'quando' => wp_date('d/m', $j->inicio) . ' • ' . array('Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb')[(int) wp_date('w', $j->inicio)] . ' • ' . wp_date('H:i', $j->inicio),
        );
    }
    uasort($rod, function ($a, $b) {
        return $a['inicio'] - $b['inicio'];
    });
    $rod = array_values($rod);
    $atual = 0;
    foreach ($rod as $i => $r) {
        $atual = $i;
        if ($r['aberta']) {
            break;
        }
    }
    return $rod ? array('atual' => $atual, 'rodadas' => $rod) : array();
}

// Junta ao resumo do tema (chamado no fim de tsp_jogos_montar_resumo)
add_filter('tsp_jogos_resumo', function ($r) {
    foreach (TSP_JOGOS_LIGAS_RODADAS as $liga) {
        $x = tsp_jogos_montar_rodadas($liga);
        if ($x) {
            $r['rodadas'][$liga] = $x;
        }
    }
    $links = array();
    foreach (tsp_jogos_base_times() as $id => $t) {
        $links[tsp_jogos_nome_time($id, $t['nome'])] = tsp_jogos_time_link($id);
    }
    $r['links_times'] = $links;
    return $r;
});

/* ---------- Página de estatísticas do time: /time/<chave>/ ---------- */

add_action('init', function () {
    add_rewrite_rule('^time/([a-z0-9-]+)/?$', 'index.php?tsp_time=$matches[1]', 'top');
});
add_filter('query_vars', function ($v) {
    $v[] = 'tsp_time';
    return $v;
});

function tsp_jogos_time_da_chave($chave)
{
    foreach (tsp_jogos_base_times() as $id => $t) {
        if (sanitize_title($t['chave']) === $chave) {
            return array((int) $id, $t);
        }
    }
    return null;
}

add_action('template_redirect', function () {
    $chave = get_query_var('tsp_time');
    if (!$chave) {
        return;
    }
    $t = tsp_jogos_time_da_chave(sanitize_title($chave));
    if (!$t) {
        return;
    }
    // Clube paulista: a página dele é a de notícias
    $slug = tsp_jogos_slug_do_time($t[0]);
    if ($slug && !is_wp_error(get_term_link($slug, 'times'))) {
        wp_safe_redirect(get_term_link($slug, 'times'), 301);
        exit;
    }
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    $GLOBALS['tsp_time_atual'] = $t;
    add_filter('pre_get_document_title', function () use ($t) {
        return $t[1]['nome'] . ': jogos, elenco, artilheiros e estatísticas | ' . get_bloginfo('name');
    }, 99);
    add_filter('wpseo_title', function () use ($t) {
        return $t[1]['nome'] . ': jogos, elenco, artilheiros e estatísticas | ' . get_bloginfo('name');
    }, 99);
    add_filter('wpseo_canonical', function () use ($chave) {
        return home_url('/time/' . sanitize_title($chave) . '/');
    }, 99);
    add_filter('wpseo_metadesc', function () use ($t) {
        return $t[1]['nome'] . ': números da temporada, últimos e próximos jogos, artilheiros, jogadores mais utilizados e elenco, atualizados pelo Tudo Sobre Paulista.';
    }, 99);
    get_header();
    echo function_exists('tsp_tn_pagina') ? tsp_tn_pagina($t[0], $t[1]) : tsp_jogos_render_time($t[0], $t[1]);
    get_footer();
    exit;
});

function tsp_jogos_render_time($id, $t)
{
    $nome = $t['nome'];
    $todos = tsp_jogos_buscar('(casa_id = %d OR fora_id = %d)', array($id, $id), 'inicio ASC', 200);
    $v = $e = $d = $gp = $gc = 0;
    $ult = $prx = array();
    foreach ($todos as $j) {
        if (in_array($j->status, array('FT', 'AET', 'PEN'), true)) {
            $meu = (int) $j->casa_id === $id ? (int) $j->gols_casa : (int) $j->gols_fora;
            $dele = (int) $j->casa_id === $id ? (int) $j->gols_fora : (int) $j->gols_casa;
            $gp += $meu;
            $gc += $dele;
            $meu > $dele ? $v++ : ($meu === $dele ? $e++ : $d++);
            $ult[] = $j;
        } elseif ((int) $j->inicio > time() - 3 * HOUR_IN_SECONDS) {
            $prx[] = $j;
        }
    }
    $ult = array_slice(array_reverse($ult), 0, 5);
    $prx = array_slice($prx, 0, 3);
    // Posição nas tabelas
    $pos = array();
    foreach (tsp_jogos_ligas() as $liga => $l) {
        foreach ((array) (tsp_jogos_classificacao($liga)['grupos'] ?? array()) as $g) {
            foreach ($g as $x) {
                if ((int) $x[1] === $id) {
                    $pos[] = array(tsp_jogos_nome_liga($liga), $x);
                }
            }
        }
    }
    $li = function ($j) {
        $placar = ($j->gols_casa !== null && $j->status !== 'NS') ? (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : 'x';
        $link = tsp_jogos_link_jogo($j->id);
        $c = '<span class="tsp-jogos__dia">' . esc_html(tsp_jogos_dia_curto($j->inicio)) . '</span><span class="tsp-jogos__casa">' . esc_html(tsp_jogos_nome_time($j->casa_id, $j->casa)) . '</span><span class="tsp-jogos__placar">' . esc_html($placar) . '</span><span class="tsp-jogos__fora">' . esc_html(tsp_jogos_nome_time($j->fora_id, $j->fora)) . '</span>';
        return '<li class="tsp-jogos__item">' . $c . '<span class="tsp-jogos__extra"><span class="tsp-jogos__comp">' . esc_html(tsp_jogos_nome_liga($j->liga)) . '</span>' . ($link ? '<a class="tsp-jogos__link" href="' . esc_url($link) . '">Ficha do jogo →</a>' : '') . '</span></li>';
    };
    $h = '<main class="tsp-container tsp-camp tsp-time"><header class="tsp-camp__cab">';
    if (function_exists('tsp_breadcrumbs')) {
        ob_start();
        tsp_breadcrumbs();
        $h .= ob_get_clean();
    }
    $h .= '<h1>' . esc_html($nome) . ': jogos, resultados e estatísticas</h1>';
    $resp = $pos ? $nome . ' está em ' . (int) $pos[0][1][0] . 'º lugar no ' . $pos[0][0] . ', com ' . (int) $pos[0][1][3] . ' pontos em ' . (int) $pos[0][1][4] . ' jogos (' . (int) $pos[0][1][5] . ' vitórias, ' . (int) $pos[0][1][6] . ' empates e ' . (int) $pos[0][1][7] . ' derrotas).' : '';
    if ($resp) {
        $h .= '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div>';
    }
    $h .= '</header>';
    if ($ult || $prx) {
        $h .= '<section class="tsp-secao"><div class="tsp-painel__linha tsp-painel__linha--2">';
        if ($ult) {
            $h .= '<div class="tsp-jogos"><h2 class="tsp-caixa__tit">Últimos jogos</h2><ul>' . implode('', array_map($li, $ult)) . '</ul></div>';
        }
        if ($prx) {
            $h .= '<div class="tsp-jogos tsp-jogos--escuro"><h2 class="tsp-caixa__tit">Próximos jogos</h2><ul>' . implode('', array_map($li, $prx)) . '</ul></div>';
        }
        $h .= '</div></section>';
    }
    if ($ult) {
        $h .= '<section class="tsp-secao"><h2 class="tsp-caixa__tit">Campanha nos jogos registrados pelo TSP</h2><dl class="tsp-camp__ficha"><div><dt>Vitórias</dt><dd>' . $v . '</dd></div><div><dt>Empates</dt><dd>' . $e . '</dd></div><div><dt>Derrotas</dt><dd>' . $d . '</dd></div><div><dt>Gols marcados</dt><dd>' . $gp . '</dd></div><div><dt>Gols sofridos</dt><dd>' . $gc . '</dd></div></dl></section>';
    }
    return $h . '</main>';
}
