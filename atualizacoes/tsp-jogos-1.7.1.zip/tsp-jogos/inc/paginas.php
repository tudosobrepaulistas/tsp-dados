<?php
/**
 * Página de cada jogo de clube paulista (tipo de conteúdo "jogo", endereço /jogo/time-a-x-time-b-dd-mm-aaaa/).
 * Criada sozinha pela sincronização; o conteúdo é montado na hora a partir dos dados guardados:
 * placar (ao vivo), onde assistir, escalações, lances, estatísticas, últimos 5, casa/fora, confronto direto,
 * desfalques, classificação e matérias do TSP sobre os dois times.
 * Campos opcionais da página (redação ou Máquina): tsp_onde_assistir, tsp_provaveis (texto livre).
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', function () {
    register_post_type('jogo', array(
        'labels'       => array('name' => 'Jogos', 'singular_name' => 'Jogo', 'menu_name' => 'Jogos (automático)'),
        'public'       => true,
        'has_archive'  => 'jogos',
        'rewrite'      => array('slug' => 'jogo', 'with_front' => false),
        'supports'     => array('title', 'excerpt', 'custom-fields'),
        'menu_icon'    => 'dashicons-calendar-alt',
        'show_in_rest' => false,
    ));
});

function tsp_jogos_post_do_jogo($id)
{
    $p = get_posts(array('post_type' => 'jogo', 'post_status' => 'any', 'meta_key' => 'tsp_fixture_id', 'meta_value' => (int) $id, 'numberposts' => 1, 'fields' => 'ids'));
    return $p ? (int) $p[0] : 0;
}

function tsp_jogos_titulo($j)
{
    $c = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $f = tsp_jogos_nome_time($j->fora_id, $j->fora);
    return $c . ' x ' . $f . ': onde assistir, escalações e resultado · ' . tsp_jogos_nome_liga($j->liga) . ' ' . $j->temporada;
}

// Cria/atualiza as páginas dos jogos paulistas entre 60 dias atrás e 45 dias à frente
function tsp_jogos_criar_paginas()
{
    $jogos = tsp_jogos_buscar("(sp = 1 OR liga IN ('serie_a','serie_b')) AND inicio BETWEEN %d AND %d", array(time() - 60 * DAY_IN_SECONDS, time() + 45 * DAY_IN_SECONDS), 'inicio ASC', 400);
    foreach ($jogos as $j) {
        $titulo = tsp_jogos_titulo($j);
        $resumo = tsp_jogos_nome_time($j->casa_id, $j->casa) . ' x ' . tsp_jogos_nome_time($j->fora_id, $j->fora) . ' pelo ' . tsp_jogos_nome_liga($j->liga) . ' (' . tsp_jogos_rodada_curta($j->rodada) . ') em ' . wp_date('d/m/Y \à\s H\hi', $j->inicio) . ($j->estadio ? ', no ' . $j->estadio : '') . '. Veja onde assistir, escalações, placar ao vivo e ficha técnica.';
        $existe = tsp_jogos_post_do_jogo($j->id);
        $dados = array('post_title' => $titulo, 'post_excerpt' => $resumo);
        if ($existe) {
            if (get_the_title($existe) !== $titulo) {
                wp_update_post(array_merge(array('ID' => $existe), $dados));
            }
            continue;
        }
        $slug = sanitize_title(tsp_jogos_nome_time($j->casa_id, $j->casa) . ' x ' . tsp_jogos_nome_time($j->fora_id, $j->fora) . ' ' . wp_date('d-m-Y', $j->inicio));
        $pid = wp_insert_post(array_merge($dados, array('post_type' => 'jogo', 'post_status' => 'publish', 'post_name' => $slug, 'post_content' => '')));
        if ($pid && !is_wp_error($pid)) {
            update_post_meta($pid, 'tsp_fixture_id', (int) $j->id);
            $times = array_filter(array(tsp_jogos_slug_do_time($j->casa_id), tsp_jogos_slug_do_time($j->fora_id)));
            if ($times && taxonomy_exists('times')) {
                register_taxonomy_for_object_type('times', 'jogo');
                wp_set_object_terms($pid, array_values($times), 'times');
            }
        }
    }
}

add_action('init', function () {
    if (taxonomy_exists('times')) {
        register_taxonomy_for_object_type('times', 'jogo');
    }
}, 30);

function tsp_jogos_do_post($post_id)
{
    $id = (int) get_post_meta($post_id, 'tsp_fixture_id', true);
    $r = $id ? tsp_jogos_buscar('id = %d', array($id), 'inicio ASC', 1) : array();
    return $r ? $r[0] : null;
}

function tsp_jogos_rotulo_status($j)
{
    $m = array('NS' => 'A começar', 'TBD' => 'Horário a definir', '1H' => '1º tempo', 'HT' => 'Intervalo', '2H' => '2º tempo', 'ET' => 'Prorrogação', 'BT' => 'Intervalo da prorrogação', 'P' => 'Pênaltis', 'SUSP' => 'Suspenso', 'INT' => 'Interrompido', 'FT' => 'Encerrado', 'AET' => 'Encerrado (prorrogação)', 'PEN' => 'Encerrado (pênaltis)', 'PST' => 'Adiado', 'CANC' => 'Cancelado', 'ABD' => 'Abandonado', 'LIVE' => 'Ao vivo');
    $t = $m[$j->status] ?? $j->status;
    if (in_array($j->status, array('1H', '2H', 'ET', 'LIVE'), true) && $j->minuto) {
        $t .= ' · ' . $j->minuto . "'";
    }
    return $t;
}

function tsp_jogos_ao_vivo($j)
{
    return in_array($j->status, array('1H', 'HT', '2H', 'ET', 'BT', 'P', 'LIVE', 'INT'), true);
}

function tsp_jogos_escudo_html($api_id, $nome)
{
    $slug = tsp_jogos_slug_do_time($api_id);
    $t = $slug ? get_term_by('slug', $slug, 'times') : null;
    $tem_escudo_site = $t && (get_term_meta($t->term_id, 'tsp_escudo_png', true) || get_term_meta($t->term_id, 'imagem', true));
    if ($tem_escudo_site && function_exists('tsp_escudo')) {
        return tsp_escudo($t, 64);
    }
    $url = function_exists('tsp_jogos_escudo_url') ? tsp_jogos_escudo_url($api_id) : '';
    if ($url) {
        return '<img class="tsp-escudo" src="' . esc_url($url) . '" alt="Escudo ' . esc_attr($nome) . '" width="64" height="64" loading="lazy">';
    }
    if ($t && function_exists('tsp_escudo')) {
        return tsp_escudo($t, 64);
    }
    $sig = '';
    foreach (preg_split('~[\s-]+~', remove_accents((string) $nome)) as $p) {
        $sig .= ($p !== '' && strlen($sig) < 3 && !preg_match('~^(de|do|da|fc|ec|sc)$~i', $p)) ? strtoupper($p[0]) : '';
    }
    if (strlen($sig) < 2) {
        $sig = strtoupper(substr(preg_replace('~[^A-Za-z]~', '', remove_accents((string) $nome)), 0, 3));
    }
    return '<span class="tsp-sigla" aria-hidden="true">' . esc_html($sig ?: '?') . '</span>';
}

function tsp_jogos_forma($api_id, $mando = '', $n = 5)
{
    $cond = '(casa_id = %d OR fora_id = %d)';
    $args = array($api_id, $api_id);
    if ($mando === 'casa') {
        $cond = 'casa_id = %d';
        $args = array($api_id);
    } elseif ($mando === 'fora') {
        $cond = 'fora_id = %d';
        $args = array($api_id);
    }
    return tsp_jogos_buscar($cond . " AND status IN ('FT','AET','PEN')", $args, 'inicio DESC', $n);
}

function tsp_jogos_forma_html($api_id, $nome, $mando = '')
{
    $lista = tsp_jogos_forma($api_id, $mando);
    if (!$lista) {
        return '<p class="tsp-nota">Sem jogos registrados ainda.</p>';
    }
    $h = '<ul class="tsp-forma">';
    foreach ($lista as $x) {
        $gp = $x->casa_id == $api_id ? $x->gols_casa : $x->gols_fora;
        $gc = $x->casa_id == $api_id ? $x->gols_fora : $x->gols_casa;
        $r = $gp > $gc ? 'v' : ($gp < $gc ? 'd' : 'e');
        $adv = $x->casa_id == $api_id ? tsp_jogos_nome_time($x->fora_id, $x->fora) : tsp_jogos_nome_time($x->casa_id, $x->casa);
        $h .= '<li class="tsp-forma--' . $r . '"><b>' . strtoupper($r) . '</b><span>' . esc_html(wp_date('d/m', $x->inicio)) . ' · ' . ($x->casa_id == $api_id ? 'x ' : '@ ') . esc_html($adv) . '</span><strong>' . (int) $gp . ' x ' . (int) $gc . '</strong></li>';
    }
    return $h . '</ul>';
}

function tsp_jogos_tabela_html($liga, $destaques = array())
{
    $c = tsp_jogos_classificacao($liga);
    if (empty($c['grupos'])) {
        return '';
    }
    $h = '';
    foreach ($c['grupos'] as $g) {
        $h .= '<div class="tsp-rolagem"><table class="tsp-tabela"><thead><tr><th>#</th><th class="tsp-tabela__time">Time</th><th>P</th><th>J</th><th>V</th><th>E</th><th>D</th><th>SG</th></tr></thead><tbody>';
        foreach ($g as $r) {
            $cl = in_array((int) $r[1], $destaques, true) ? ' class="tsp-clube-atual"' : (tsp_jogos_slug_do_time($r[1]) ? ' class="tsp-sp"' : '');
            $h .= '<tr' . $cl . '><td>' . (int) $r[0] . '</td><td class="tsp-tabela__time">' . esc_html(tsp_jogos_nome_time($r[1], $r[2])) . '</td><td><strong>' . (int) $r[3] . '</strong></td><td>' . (int) $r[4] . '</td><td>' . (int) $r[5] . '</td><td>' . (int) $r[6] . '</td><td>' . (int) $r[7] . '</td><td>' . ((int) $r[8] > 0 ? '+' : '') . (int) $r[8] . '</td></tr>';
        }
        $h .= '</tbody></table></div>';
    }
    return $h;
}

function tsp_jogos_fontes_html($fontes)
{
    $fontes = array_values(array_filter((array) $fontes));
    if (!$fontes) {
        return '';
    }
    $h = '<p class="tsp-jogo__fontes">Fontes: ';
    foreach ($fontes as $i => $u) {
        $host = preg_replace('~^www\\.~', '', (string) wp_parse_url($u, PHP_URL_HOST));
        $h .= ($i ? ' · ' : '') . '<a href="' . esc_url($u) . '" target="_blank" rel="noopener nofollow">' . esc_html($host) . '</a>';
    }
    return $h . '</p>';
}

// Monta a página do jogo
function tsp_jogos_render($j, $post_id)
{
    $d = tsp_jogos_detalhes($j->id);
    $casa = tsp_jogos_nome_time($j->casa_id, $j->casa);
    $fora = tsp_jogos_nome_time($j->fora_id, $j->fora);
    $tem_placar = $j->gols_casa !== null && $j->status !== 'NS';
    ob_start();
    echo '<div class="tsp-jogo" data-jogo="' . (int) $j->id . '" data-ao-vivo="' . (tsp_jogos_ao_vivo($j) ? '1' : '0') . '">';
    $pre = (array) ($d['prejogo'] ?? array());
    // Foto do estádio (licença livre, com crédito)
    if (has_post_thumbnail($post_id)) {
        $tid = get_post_thumbnail_id($post_id);
        $cred = get_post_meta($tid, 'tsp_credito', true) ?: wp_get_attachment_caption($tid);
        echo '<figure class="tsp-jogo__estadio">' . get_the_post_thumbnail($post_id, 'large', array('loading' => 'eager', 'alt' => esc_attr($j->estadio ?: 'Estádio'))) . '<figcaption>' . esc_html(($j->estadio ? $j->estadio . ($j->cidade ? ', ' . $j->cidade : '') . ' · ' : '') . $cred) . '</figcaption></figure>';
    }
    // Placar
    echo '<section class="tsp-placar"><div class="tsp-placar__comp">' . esc_html(tsp_jogos_nome_liga($j->liga) . ' ' . $j->temporada . ' · ' . tsp_jogos_rodada_curta($j->rodada)) . '</div><div class="tsp-placar__linha">';
    echo '<div class="tsp-placar__time">' . tsp_jogos_escudo_html($j->casa_id, $casa) . '<strong>' . esc_html($casa) . '</strong></div>';
    echo '<div class="tsp-placar__centro"><span class="tsp-placar__gols" data-placar>' . ($tem_placar ? (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : 'x') . '</span><span class="tsp-placar__status" data-status>' . esc_html(tsp_jogos_rotulo_status($j)) . '</span></div>';
    echo '<div class="tsp-placar__time">' . tsp_jogos_escudo_html($j->fora_id, $fora) . '<strong>' . esc_html($fora) . '</strong></div></div>';
    echo '<div class="tsp-placar__info">' . esc_html(wp_date('l, d/m/Y \à\s H\hi', $j->inicio)) . ($j->estadio ? ' · ' . esc_html($j->estadio) : '') . ($j->cidade ? ' (' . esc_html($j->cidade) . ')' : '') . ($j->arbitro ? ' · Árbitro: ' . esc_html($j->arbitro) : '') . '</div>';
    if (!empty($d['obs'])) {
        echo '<div class="tsp-placar__aviso">' . esc_html($d['obs']) . '</div>';
    }
    if (!empty($d['penaltis']) && $j->status === 'PEN') {
        echo '<div class="tsp-placar__info">Pênaltis: ' . esc_html($d['penaltis']) . '</div>';
    }
    echo '</section>';

    // Onde assistir
    $onde = get_post_meta($post_id, 'tsp_onde_assistir', true);
    $quando = wp_date('l (d/m), \\à\\s H\\hi', $j->inicio);
    echo '<section class="tsp-jogo__bloco"><h2>Onde assistir ' . esc_html($casa . ' x ' . $fora) . '</h2>';
    $canais = (array) ($pre['onde_assistir']['canais'] ?? array());
    if ($canais) {
        $lista = array();
        foreach ($canais as $c) {
            $lista[] = '<li><strong>' . esc_html($c['nome'] ?? '') . '</strong>' . (!empty($c['tipo']) ? ' <span>' . esc_html($c['tipo']) . '</span>' : '') . '</li>';
        }
        echo '<p>' . esc_html($casa . ' e ' . $fora . ' se enfrentam ' . $quando . ($j->estadio ? ', no ' . $j->estadio : '') . ', pela ' . tsp_jogos_rodada_curta($j->rodada) . ' do ' . tsp_jogos_nome_liga($j->liga) . '. A partida terá transmissão de:') . '</p><ul class="tsp-canais">' . implode('', $lista) . '</ul>';
        echo tsp_jogos_fontes_html((array) ($pre['onde_assistir']['fontes'] ?? array()));
    } else {
        echo $onde ? '<p>' . esc_html($onde) . '</p>' : '<p>' . esc_html($casa . ' e ' . $fora . ' se enfrentam ' . $quando . ($j->estadio ? ', no ' . $j->estadio : '') . '. A transmissão será confirmada aqui assim que for divulgada pelas emissoras.') . '</p>';
    }
    echo '</section>';

    // Escalações
    echo '<section class="tsp-jogo__bloco"><h2>' . (!empty($d['escalacoes']) ? 'Escalações' : 'Prováveis escalações') . '</h2>';
    if (!empty($d['escalacoes'])) {
        echo '<div class="tsp-jogo__duas">';
        foreach ($d['escalacoes'] as $l) {
            echo '<div><h3>' . esc_html(tsp_jogos_nome_time($l['team']['id'] ?? 0, $l['team']['name'] ?? '')) . ($l['formation'] ?? '' ? ' · ' . esc_html($l['formation']) : '') . '</h3><ol class="tsp-escalacao">';
            foreach ((array) ($l['startxi'] ?? array()) as $p) {
                echo '<li><span>' . esc_html($p['player']['number'] ?? '') . '</span>' . esc_html($p['player']['name'] ?? '') . '</li>';
            }
            echo '</ol>';
            if (!empty($l['substitutes'])) {
                echo '<p class="tsp-nota"><strong>Reservas:</strong> ' . esc_html(implode(', ', array_map(function ($p) {
                    return $p['player']['name'] ?? '';
                }, $l['substitutes']))) . '</p>';
            }
            if (!empty($l['coach']['name'])) {
                echo '<p class="tsp-nota"><strong>Técnico:</strong> ' . esc_html($l['coach']['name']) . '</p>';
            }
            echo '</div>';
        }
        echo '</div>';
    } else {
        $pv = (array) ($pre['provaveis'] ?? array());
        $prov = get_post_meta($post_id, 'tsp_provaveis', true);
        if (!empty($pv['casa']['time']) || !empty($pv['fora']['time'])) {
            echo '<div class="tsp-jogo__duas">';
            foreach (array('casa' => array($j->casa_id, $casa), 'fora' => array($j->fora_id, $fora)) as $lado => $tm) {
                $x = (array) ($pv[$lado] ?? array());
                echo '<div class="tsp-provavel"><div class="tsp-provavel__cab">' . tsp_jogos_escudo_html($tm[0], $tm[1]) . '<h3>' . esc_html($tm[1]) . '</h3></div>';
                if (!empty($x['tecnico'])) {
                    echo '<p class="tsp-nota"><strong>Técnico:</strong> ' . esc_html($x['tecnico']) . '</p>';
                }
                echo '<p>' . esc_html($x['time'] ?? 'Ainda sem provável escalação divulgada.') . '</p>';
                if (!empty($x['desfalques'])) {
                    echo '<p class="tsp-nota"><strong>Desfalques:</strong> ' . esc_html($x['desfalques']) . '</p>';
                }
                if (!empty($x['duvidas'])) {
                    echo '<p class="tsp-nota"><strong>Dúvidas:</strong> ' . esc_html($x['duvidas']) . '</p>';
                }
                echo '</div>';
            }
            echo '</div>';
            $at = !empty($pv['atualizado']) ? strtotime($pv['atualizado']) : 0;
            echo '<p class="tsp-nota">Prováveis escalações segundo a imprensa' . ($at ? ', atualizadas em ' . esc_html(wp_date('d/m \\à\\s H\\hi', $at)) : '') . '. As escalações oficiais aparecem aqui quando forem divulgadas.</p>';
            echo tsp_jogos_fontes_html((array) ($pv['fontes'] ?? array()));
        } else {
            echo $prov ? '<p>' . nl2br(esc_html($prov)) . '</p>' : '<p>As prováveis escalações entram aqui cerca de 5 horas antes do jogo, com base no que a imprensa e os clubes divulgarem.</p>';
        }
    }
    echo '</section>';

    // Lances
    if (!empty($d['eventos'])) {
        echo '<section class="tsp-jogo__bloco"><h2>Lance a lance</h2><ul class="tsp-lances">';
        foreach ($d['eventos'] as $e) {
            $tipo = strtolower($e['type'] ?? '');
            $ic = $tipo === 'goal' ? '⚽' : ($tipo === 'card' ? (stripos($e['detail'] ?? '', 'red') !== false ? '🟥' : '🟨') : ($tipo === 'subst' ? '🔁' : '•'));
            $det = $tipo === 'goal' ? 'Gol' : ($tipo === 'card' ? 'Cartão' : ($tipo === 'subst' ? 'Substituição' : ($e['detail'] ?? '')));
            echo '<li><b>' . (int) ($e['time']['elapsed'] ?? 0) . (!empty($e['time']['extra']) ? '+' . (int) $e['time']['extra'] : '') . "'</b><span>" . $ic . '</span>' . esc_html($det . ': ' . ($e['player']['name'] ?? '') . (!empty($e['assist']['name']) && $tipo !== 'subst' ? ' (assistência: ' . $e['assist']['name'] . ')' : '') . ($tipo === 'subst' && !empty($e['assist']['name']) ? ' → ' . $e['assist']['name'] : '') . ' · ' . tsp_jogos_nome_time($e['team']['id'] ?? 0, $e['team']['name'] ?? '')) . '</li>';
        }
        echo '</ul></section>';
    }

    // Estatísticas
    if (count($d['estatisticas'] ?? array()) === 2) {
        $a = $d['estatisticas'][0]['statistics'] ?? array();
        $b = $d['estatisticas'][1]['statistics'] ?? array();
        $nomes = array('ball possession' => 'Posse de bola', 'total shots' => 'Finalizações', 'shots on goal' => 'Chutes no gol', 'corner kicks' => 'Escanteios', 'fouls' => 'Faltas', 'offsides' => 'Impedimentos', 'yellow cards' => 'Cartões amarelos', 'red cards' => 'Cartões vermelhos', 'passes %' => 'Passes certos');
        echo '<section class="tsp-jogo__bloco"><h2>Estatísticas</h2><table class="tsp-stats"><thead><tr><th>' . esc_html($casa) . '</th><th></th><th>' . esc_html($fora) . '</th></tr></thead><tbody>';
        foreach ($a as $i => $s) {
            $k = strtolower($s['type'] ?? '');
            if (!isset($nomes[$k])) {
                continue;
            }
            echo '<tr><td>' . esc_html((string) ($s['value'] ?? 0)) . '</td><th>' . esc_html($nomes[$k]) . '</th><td>' . esc_html((string) ($b[$i]['value'] ?? 0)) . '</td></tr>';
        }
        echo '</tbody></table></section>';
    }

    // Análise e retrospecto (texto do TSP, com fontes)
    if (!empty($pre['analise'])) {
        echo '<section class="tsp-jogo__bloco"><h2>O que está em jogo</h2>';
        foreach ((array) $pre['analise'] as $par) {
            echo '<p>' . esc_html($par) . '</p>';
        }
        echo '</section>';
    }
    if (!empty($pre['retrospecto'])) {
        echo '<section class="tsp-jogo__bloco"><h2>Retrospecto: ' . esc_html($casa . ' x ' . $fora) . '</h2><p>' . esc_html($pre['retrospecto']) . '</p></section>';
    }
    if (!empty($pre['analise']) || !empty($pre['retrospecto'])) {
        echo tsp_jogos_fontes_html((array) ($pre['fontes'] ?? array()));
    }

    // Pré-jogo: forma recente, casa/fora, confronto direto, desfalques
    echo '<section class="tsp-jogo__bloco"><h2>Pré-jogo: momento dos times</h2><div class="tsp-jogo__duas">';
    echo '<div><h3>Últimos 5 · ' . esc_html($casa) . '</h3>' . tsp_jogos_forma_html($j->casa_id, $casa) . '<h3>Últimos em casa</h3>' . tsp_jogos_forma_html($j->casa_id, $casa, 'casa') . '</div>';
    echo '<div><h3>Últimos 5 · ' . esc_html($fora) . '</h3>' . tsp_jogos_forma_html($j->fora_id, $fora) . '<h3>Últimos fora de casa</h3>' . tsp_jogos_forma_html($j->fora_id, $fora, 'fora') . '</div></div>';
    if (!empty($d['h2h'])) {
        echo '<h3>Confronto direto (últimos jogos)</h3><ul class="tsp-forma">';
        foreach ($d['h2h'] as $x) {
            echo '<li><span>' . esc_html(wp_date('d/m/Y', (int) $x[0]) . ' · ' . $x[5]) . '</span><strong>' . esc_html($x[1] . ' ' . (int) $x[2] . ' x ' . (int) $x[3] . ' ' . $x[4]) . '</strong></li>';
        }
        echo '</ul>';
    }
    if (!empty($d['desfalques'])) {
        echo '<h3>Desfalques</h3><ul class="tsp-desfalques">';
        foreach ($d['desfalques'] as $x) {
            echo '<li>' . esc_html($x[1] . ' (' . tsp_jogos_nome_time($x[0], '') . ') · ' . $x[2]) . '</li>';
        }
        echo '</ul>';
    }
    echo '</section>';

    // Classificação
    $tab = tsp_jogos_tabela_html($j->liga, array((int) $j->casa_id, (int) $j->fora_id));
    if ($tab) {
        echo '<section class="tsp-jogo__bloco"><h2>Classificação · ' . esc_html(tsp_jogos_nome_liga($j->liga)) . '</h2>' . $tab . '</section>';
    }

    // Matérias do TSP sobre os dois times (pré-jogo, onde assistir, coletiva)
    $slugs = array_filter(array(tsp_jogos_slug_do_time($j->casa_id), tsp_jogos_slug_do_time($j->fora_id)));
    if ($slugs) {
        $q = new WP_Query(array('post_type' => array('materia', 'post'), 'posts_per_page' => 6, 'no_found_rows' => true, 'ignore_sticky_posts' => true, 'tax_query' => array(array('taxonomy' => 'times', 'field' => 'slug', 'terms' => array_values($slugs))), 'date_query' => array(array('after' => wp_date('Y-m-d', $j->inicio - 5 * DAY_IN_SECONDS)))));
        if ($q->posts) {
            echo '<section class="tsp-jogo__bloco"><h2>Notícias do jogo</h2><ul class="tsp-jogo__noticias">';
            foreach ($q->posts as $p) {
                echo '<li><a href="' . esc_url(get_permalink($p)) . '">' . esc_html(get_the_title($p)) . '</a></li>';
            }
            echo '</ul></section>';
        }
    }
    echo '<p class="tsp-nota">Dados atualizados automaticamente' . ($j->atualizado ? ' em ' . esc_html(wp_date('d/m/Y \à\s H\hi', $j->atualizado)) : '') . '.</p></div>';
    return ob_get_clean();
}

add_filter('the_content', function ($c) {
    if (!is_singular('jogo') || !in_the_loop() || !is_main_query()) {
        return $c;
    }
    $j = tsp_jogos_do_post(get_the_ID());
    return $j ? tsp_jogos_render($j, get_the_ID()) . $c : $c;
}, 20);

// Dados estruturados do jogo (SportsEvent)
add_action('wp_head', function () {
    if (!is_singular('jogo')) {
        return;
    }
    $j = tsp_jogos_do_post(get_queried_object_id());
    if (!$j) {
        return;
    }
    $e = array('@context' => 'https://schema.org', '@type' => 'SportsEvent', 'name' => tsp_jogos_nome_time($j->casa_id, $j->casa) . ' x ' . tsp_jogos_nome_time($j->fora_id, $j->fora), 'startDate' => wp_date('c', $j->inicio), 'sport' => 'Futebol', 'eventStatus' => in_array($j->status, array('PST'), true) ? 'https://schema.org/EventPostponed' : (in_array($j->status, array('CANC', 'ABD'), true) ? 'https://schema.org/EventCancelled' : 'https://schema.org/EventScheduled'),
        'homeTeam' => array('@type' => 'SportsTeam', 'name' => tsp_jogos_nome_time($j->casa_id, $j->casa)), 'awayTeam' => array('@type' => 'SportsTeam', 'name' => tsp_jogos_nome_time($j->fora_id, $j->fora)),
        'location' => array('@type' => 'Place', 'name' => $j->estadio ?: 'A definir', 'address' => $j->cidade ?: 'Brasil'));
    // Campos que o Google pede (out/2026): fim, descrição, organizador e imagem. "offers" fica de fora: não vendemos ingresso.
    $liga = tsp_jogos_nome_liga($j->liga);
    $e['endDate'] = wp_date('c', (int) $j->inicio + 2 * HOUR_IN_SECONDS);
    $e['description'] = $e['name'] . ' pelo ' . $liga . ($j->rodada ? ' (' . $j->rodada . ')' : '') . ', ' . wp_date('d/m/Y \à\s H\hi', $j->inicio) . ($j->estadio ? ', no ' . $j->estadio : '') . '. Placar, gols e ficha técnica no Tudo Sobre Paulista.';
    $e['organizer'] = array('@type' => 'Organization', 'name' => preg_match('~^(Paulist|fem_paulist)~i', $liga . $j->liga) ? 'Federação Paulista de Futebol' : (preg_match('~Libertadores|Sul-Americana~', $liga) ? 'Conmebol' : 'CBF'), 'url' => preg_match('~^(Paulist|fem_paulist)~i', $liga . $j->liga) ? 'https://futebolpaulista.com.br' : (preg_match('~Libertadores|Sul-Americana~', $liga) ? 'https://www.conmebol.com' : 'https://www.cbf.com.br'));
    $img = has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'large') : '';
    if (!$img && function_exists('tsp_og_arte')) {
        $img = tsp_og_arte('home', 'Futebol paulista', 'Todos os times de São Paulo', '#0B0B0B', '#FFFFFF');
    }
    if ($img) {
        $e['image'] = array($img);
    }
    echo '<script type="application/ld+json">' . wp_json_encode($e, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
});

// Placar ao vivo sem recarregar a página: lê do banco do site (não gasta consulta da API)
add_action('rest_api_init', function () {
    register_rest_route('tsp/v1', '/jogo/(?P<id>\d+)', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function ($r) {
        $x = tsp_jogos_buscar('id = %d', array((int) $r['id']), 'inicio ASC', 1);
        if (!$x) {
            return new WP_Error('nao', 'Jogo não encontrado', array('status' => 404));
        }
        $j = $x[0];
        return array('placar' => ($j->gols_casa !== null && $j->status !== 'NS') ? (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : 'x', 'status' => tsp_jogos_rotulo_status($j), 'ao_vivo' => tsp_jogos_ao_vivo($j));
    }));
});

add_action('wp_footer', function () {
    if (!is_singular('jogo')) {
        return;
    }
    $url = esc_url_raw(rest_url('tsp/v1/jogo/'));
    echo "<script>(function(){var b=document.querySelector('.tsp-jogo');if(!b||b.dataset.aoVivo!=='1')return;var u=" . wp_json_encode($url) . "+b.dataset.jogo;setInterval(function(){fetch(u,{cache:'no-store'}).then(function(r){return r.json()}).then(function(d){var p=b.querySelector('[data-placar]'),s=b.querySelector('[data-status]');if(p)p.textContent=d.placar;if(s)s.textContent=d.status;if(!d.ao_vivo)location.reload();}).catch(function(){})},60000);})();</script>";
});

add_action('wp_enqueue_scripts', function () {
    if (!is_singular('jogo') && !is_post_type_archive('jogo')) {
        return;
    }
    wp_register_style('tsp-jogos', false);
    wp_enqueue_style('tsp-jogos');
    wp_add_inline_style('tsp-jogos', '.tsp-jogo{display:flex;flex-direction:column;gap:22px}.tsp-placar{background:#0B0B0B;color:#fff;border-radius:12px;padding:22px;text-align:center}.tsp-placar__comp{margin:0 0 12px;color:#E18330;font-weight:700;text-transform:uppercase;letter-spacing:.05em;font-size:13px}.tsp-placar__linha{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:12px}.tsp-placar__time{display:flex;flex-direction:column;align-items:center;gap:8px;font-size:18px;min-width:0}.tsp-placar__time img,.tsp-placar__time .tsp-escudo{width:64px!important;height:64px!important;object-fit:contain}.tsp-sigla{width:64px;height:64px;border-radius:50%;background:#2A2622;border:2px solid #E18330;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:800;font-size:20px;letter-spacing:.02em}.tsp-forma li{flex-wrap:wrap}.tsp-forma li span{min-width:0}.tsp-jogo{min-width:0;overflow-wrap:anywhere}.tsp-placar__gols{display:block;font-size:46px;font-weight:800;line-height:1}.tsp-placar__status{display:block;margin-top:6px;font-size:13px;color:#BDB9B1}.tsp-placar__info{margin:14px 0 0;font-size:13.5px;color:#BDB9B1}.tsp-jogo__estadio{margin:0;border-radius:12px;overflow:hidden;position:relative}.tsp-jogo__estadio img{display:block;width:100%;height:auto;aspect-ratio:16/9;object-fit:cover}.tsp-jogo__estadio figcaption{font-size:12px;color:#6F6A62;padding:6px 2px 0}.tsp-canais{list-style:none;margin:6px 0 8px;padding:0;display:flex;flex-wrap:wrap;gap:8px}.tsp-canais li{background:#F7F2EA;border:1px solid #E9DFD0;border-radius:999px;padding:6px 14px}.tsp-canais span{color:#6F6A62;font-size:13px}.tsp-provavel{background:#FAF8F4;border:1px solid #EEEBE5;border-radius:10px;padding:12px 14px}.tsp-provavel__cab{display:flex;align-items:center;gap:10px;margin-bottom:6px}.tsp-provavel__cab img,.tsp-provavel__cab .tsp-escudo,.tsp-provavel__cab .tsp-sigla{width:40px!important;height:40px!important;font-size:13px}.tsp-provavel__cab h3{margin:0!important}.tsp-jogo__fontes{font-size:12.5px;color:#6F6A62;margin:-4px 0 0}.tsp-jogo__fontes a{color:#A8520C}.tsp-jogo__bloco h2{font-size:24px;text-transform:uppercase;margin:0 0 10px}.tsp-jogo__bloco h3{font-size:18px;margin:14px 0 6px}.tsp-jogo__duas{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px}.tsp-escalacao{margin:0;padding-left:0;list-style:none}.tsp-escalacao li{display:flex;gap:10px;padding:5px 0;border-top:1px solid #EEEBE5}.tsp-escalacao span{width:24px;font-weight:800;color:#A8520C}.tsp-lances,.tsp-forma,.tsp-desfalques,.tsp-jogo__noticias{list-style:none;margin:0;padding:0}.tsp-lances li,.tsp-forma li,.tsp-desfalques li,.tsp-jogo__noticias li{display:flex;gap:10px;align-items:center;padding:7px 0;border-top:1px solid #EEEBE5;font-size:14.5px}.tsp-lances b{width:40px}.tsp-forma li b{width:22px;height:22px;border-radius:4px;display:inline-flex;align-items:center;justify-content:center;color:#fff;font-size:12px}.tsp-forma--v b{background:#2D7A4F}.tsp-forma--e b{background:#F2B705;color:#111!important}.tsp-forma--d b{background:#C0392B}.tsp-forma li span{flex:1}.tsp-stats{width:100%;border-collapse:collapse}.tsp-stats td,.tsp-stats th{padding:7px;border-top:1px solid #EEEBE5;text-align:center}.tsp-stats td:first-child{text-align:left}.tsp-stats td:last-child{text-align:right}');
});
