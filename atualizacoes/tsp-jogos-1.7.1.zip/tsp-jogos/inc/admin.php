<?php
/**
 * Ferramentas → TSP · Jogos: situação da Base TSP (jogos, classificação, Editor SEO e ofertas), leitura manual e registro.
 * A API-Football foi retirada (27/10/2026): os dados vêm só da base própria do TSP no GitHub.
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', function () {
    add_management_page('TSP · Jogos', 'TSP · Jogos', 'manage_options', 'tsp-jogos', 'tsp_jogos_tela');
});

function tsp_jogos_tela()
{
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão.');
    }
    $aviso = '';
    if (isset($_POST['tsp_jogos_acao'])) {
        check_admin_referer('tsp_jogos');
        if (sanitize_key($_POST['tsp_jogos_acao']) === 'base_ler') {
            $ok = tsp_jogos_base_importar(true);
            if (function_exists('tsp_editor_seo_aplicar')) {
                delete_option('tsp_editor_seo_hash');
                tsp_editor_seo_aplicar();
            }
            if (function_exists('tsp_ofertas_importar')) {
                tsp_ofertas_importar(true);
            }
            $aviso = $ok ? 'Base TSP lida agora. Veja o registro abaixo.' : 'Não consegui ler a base. Veja o registro abaixo.';
        }
    }
    $qb = (int) get_option('tsp_jogos_base_quando', 0);
    $of = get_option('tsp_ofertas', array());
    echo '<div class="wrap"><h1>TSP · Jogos</h1>';
    if ($aviso) {
        echo '<div class="notice notice-info"><p>' . esc_html($aviso) . '</p></div>';
    }
    echo '<p>Jogos, resultados, classificação, Editor SEO e ofertas vêm da <strong>Base TSP</strong> (repositório tudosobrepaulistas/tsp-dados), montada pela Máquina de Resultados e conferida em 2 fontes. O site confere a base a cada 15 minutos.</p>';
    echo '<table class="widefat striped" style="max-width:720px"><tbody>';
    echo '<tr><td>Última leitura com novidade (jogos)</td><td><strong>' . ($qb ? esc_html(wp_date('d/m H\hi', $qb)) : 'ainda não leu') . '</strong></td></tr>';
    echo '<tr><td>Competições na base</td><td>' . (int) count(tsp_jogos_ligas()) . '</td></tr>';
    echo '<tr><td>Ofertas (clubes com vitrine)</td><td>' . (int) count((array) ($of['clubes'] ?? array())) . '</td></tr>';
    echo '</tbody></table><form method="post" style="margin-top:12px">';
    wp_nonce_field('tsp_jogos');
    echo '<input type="hidden" name="tsp_jogos_acao" value="base_ler">';
    submit_button('Ler a base agora', 'primary', 'submit', false);
    echo '</form>';
    $log = array_reverse((array) get_option('tsp_jogos_log', array()));
    if ($log) {
        echo '<h2>Registro</h2><ul style="font-family:monospace;font-size:12px">';
        foreach (array_slice($log, 0, 20) as $l) {
            echo '<li>' . esc_html($l) . '</li>';
        }
        echo '</ul>';
    }
    echo '</div>';
}
