<?php
/**
 * A API-Football foi retirada em 27/10/2026. O site não conversa mais com nenhum serviço de estatística:
 * os dados vêm só da Base TSP (GitHub). Ficam aqui o registro e a normalização de nomes, usados pela base.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_chave()
{
    return '';
}

// Mantida só para compatibilidade: nunca faz chamada externa.
function tsp_jogos_get($caminho, $params = array(), $reserva = 0)
{
    return new WP_Error('sem_api', 'A API-Football foi retirada do TSP.');
}

function tsp_jogos_log($msg)
{
    $l = get_option('tsp_jogos_log', array());
    $l = is_array($l) ? array_slice($l, -29) : array();
    $l[] = wp_date('d/m H:i') . ' · ' . sanitize_text_field($msg);
    update_option('tsp_jogos_log', $l, false);
}

// Nome sem acento, minúsculo, só letras e números (para casar "Sao Paulo" com "São Paulo")
function tsp_jogos_normal($s)
{
    $s = strtolower(remove_accents((string) $s));
    $s = preg_replace('~\b(fc|ec|sc|ac|ca|se|cr|ad|esporte clube|futebol clube|clube|atletico|associacao)\b~', '', $s);
    return preg_replace('~[^a-z0-9]~', '', $s);
}
