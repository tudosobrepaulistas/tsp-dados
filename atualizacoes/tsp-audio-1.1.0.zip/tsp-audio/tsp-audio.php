<?php
/*
Plugin Name: TSP Notícia por Áudio
Description: A redação envia o áudio ou vídeo de uma coletiva (ou grava na hora) e uma foto. O áudio vira texto no próprio aparelho (grátis), o robô do TSP escreve a matéria com título, subtítulo, resumo, perguntas frequentes, tags e meta, e o site publica sozinho.
Version: 1.1.0
Author: TSP
Requires at least: 6.3
Requires PHP: 7.4
Text Domain: tsp-audio
*/

if (!defined('ABSPATH')) {
    exit;
}

define('TSP_AUDIO_VERSAO', '1.1.0');
define('TSP_AUDIO_URL', plugin_dir_url(__FILE__));
const TSP_AUDIO_RESULTADOS = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/audio.json';

function tsp_audio_tipo()
{
    return post_type_exists('materia') ? 'materia' : 'post';
}

/* ---------- Tela "Notícia por áudio" ---------- */

add_action('admin_menu', function () {
    add_menu_page('Notícia por áudio', 'Notícia por áudio', 'edit_posts', 'tsp-audio', 'tsp_audio_tela', 'dashicons-microphone', 4);
});

add_action('admin_enqueue_scripts', function ($tela) {
    if ($tela !== 'toplevel_page_tsp-audio') {
        return;
    }
    wp_enqueue_style('tsp-audio', TSP_AUDIO_URL . 'assets/audio.css', array(), TSP_AUDIO_VERSAO);
    wp_enqueue_script('tsp-audio', TSP_AUDIO_URL . 'assets/audio.js', array(), TSP_AUDIO_VERSAO, true);
    wp_localize_script('tsp-audio', 'TSP_AUDIO', array(
        'ajax'   => admin_url('admin-ajax.php'),
        'nonce'  => wp_create_nonce('tsp_audio'),
        'worker' => TSP_AUDIO_URL . 'assets/worker.js?v=' . TSP_AUDIO_VERSAO,
    ));
});

function tsp_audio_tela()
{
    if (!current_user_can('edit_posts')) {
        wp_die('Sem permissão.');
    }
    if (isset($_GET['buscar']) && check_admin_referer('tsp_audio_buscar')) {
        tsp_audio_aplicar(true);
    }
    $times = get_terms(array('taxonomy' => 'times', 'hide_empty' => false, 'number' => 0));
    ?>
    <div class="wrap tsp-audio">
        <h1>Notícia por áudio</h1>
        <p class="tsp-audio__intro">Envie o áudio ou vídeo da coletiva (ou grave agora) e uma foto. O texto do áudio é feito <strong>aqui no seu aparelho</strong>; depois o robô do TSP escreve a matéria completa e o site publica sozinho (em até 1 hora).</p>

        <form id="tsp-audio-form" class="tsp-audio__form" autocomplete="off">
            <fieldset class="tsp-audio__passo">
                <legend>1. O áudio</legend>
                <div class="tsp-audio__modos" role="tablist">
                    <button type="button" class="is-ativo" data-modo="arquivo">Enviar arquivo (MP3, MP4, M4A, WAV)</button>
                    <button type="button" data-modo="gravar">Gravar agora</button>
                </div>
                <div data-painel="arquivo">
                    <input type="file" id="tsp-audio-arquivo" accept="audio/*,video/mp4,video/quicktime,.mp3,.mp4,.m4a,.wav,.ogg,.webm">
                    <p class="description">Coletiva do YouTube: o robô não baixa vídeos do YouTube. Grave a tela/áudio do computador ou use o arquivo oficial do clube e envie aqui. Cole o link no campo "Link da coletiva" para citar a fonte.</p>
                </div>
                <div data-painel="gravar" hidden>
                    <button type="button" class="button button-hero" id="tsp-audio-gravar">● Começar a gravar</button>
                    <span id="tsp-audio-tempo" class="tsp-audio__tempo">00:00</span>
                    <p class="description">Deixe o celular perto de quem fala. Ao parar, o áudio é transcrito.</p>
                </div>
                <label class="tsp-audio__linha">Qualidade da transcrição
                    <select id="tsp-audio-modelo">
                        <option value="Xenova/whisper-base">Rápida (boa para áudio limpo)</option>
                        <option value="Xenova/whisper-small">Precisa (mais lenta; melhor em coletiva com barulho)</option>
                    </select>
                </label>
                <button type="button" class="button button-primary" id="tsp-audio-transcrever" disabled>Transcrever</button>
                <div class="tsp-audio__progresso" hidden><div class="tsp-audio__barra"><span></span></div><p id="tsp-audio-status"></p></div>
                <label class="tsp-audio__linha">Texto do áudio (confira nomes de jogadores e corrija o que precisar)
                    <textarea id="tsp-audio-texto" name="transcricao" rows="10" required></textarea>
                </label>
            </fieldset>

            <fieldset class="tsp-audio__passo">
                <legend>2. Do que se trata</legend>
                <label class="tsp-audio__linha">Quem fala e em que ocasião *
                    <input type="text" name="contexto" required maxlength="300" placeholder="Ex.: Coletiva do técnico Abel Ferreira depois de Palmeiras 2 x 1 Santos, no Allianz Parque, em 27/10">
                </label>
                <label class="tsp-audio__linha">Clube(s) *
                    <input type="search" id="tsp-audio-filtro" placeholder="Digite para achar o clube (ex.: palm)">
                    <select name="times[]" id="tsp-audio-times" multiple required size="6">
                        <?php foreach ((array) $times as $t) : if (is_object($t)) : ?>
                            <option value="<?php echo (int) $t->term_id; ?>"><?php echo esc_html($t->name); ?></option>
                        <?php endif; endforeach; ?>
                    </select>
                    <span class="description">No computador, segure Ctrl (ou ⌘) para marcar mais de um.</span>
                </label>
                <label class="tsp-audio__linha">Link da coletiva (opcional)
                    <input type="url" name="link" placeholder="https://www.youtube.com/...">
                </label>
                <label class="tsp-audio__linha">Observação para o robô (opcional)
                    <input type="text" name="obs" maxlength="300" placeholder="Ex.: o foco é a lesão do zagueiro">
                </label>
            </fieldset>

            <fieldset class="tsp-audio__passo">
                <legend>3. A foto</legend>
                <label class="tsp-audio__linha">Foto (print da coletiva ou foto do estádio) *
                    <input type="file" name="foto" accept="image/jpeg,image/png,image/webp" required>
                </label>
                <label class="tsp-audio__linha">Crédito da foto *
                    <input type="text" name="credito" required maxlength="120" placeholder="Ex.: Reprodução/YouTube Palmeiras ou Foto: Seu Nome/TSP">
                </label>
            </fieldset>

            <button type="submit" class="button button-primary button-hero" id="tsp-audio-enviar">Enviar para o robô escrever</button>
            <p id="tsp-audio-resposta" class="tsp-audio__resposta" role="status"></p>
        </form>

        <h2>Últimos envios</h2>
        <?php tsp_audio_lista(); ?>
        <p><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=tsp-audio&buscar=1'), 'tsp_audio_buscar')); ?>">Buscar matérias prontas agora</a></p>
    </div>
    <?php
}

function tsp_audio_lista()
{
    $q = get_posts(array('post_type' => tsp_audio_tipo(), 'post_status' => array('draft', 'publish', 'pending'), 'numberposts' => 15, 'meta_key' => 'tsp_audio_status', 'orderby' => 'date', 'order' => 'DESC'));
    if (!$q) {
        echo '<p>Nenhum envio ainda.</p>';
        return;
    }
    $rot = array('fila' => '⏳ Na fila do robô', 'publicada' => '✅ Publicada', 'erro' => '⚠️ Não deu certo');
    echo '<table class="widefat striped"><thead><tr><th>Enviado</th><th>Assunto</th><th>Situação</th></tr></thead><tbody>';
    foreach ($q as $p) {
        $st = get_post_meta($p->ID, 'tsp_audio_status', true);
        $txt = $rot[$st] ?? $st;
        if ($st === 'publicada') {
            $txt .= ' · <a href="' . esc_url(get_permalink($p)) . '" target="_blank">ver</a> · <a href="' . esc_url(get_edit_post_link($p->ID)) . '">editar</a>';
        } elseif ($st === 'erro') {
            $txt .= ': ' . esc_html(get_post_meta($p->ID, 'tsp_audio_erro', true));
        }
        echo '<tr><td>' . esc_html(get_the_date('d/m H\hi', $p)) . '</td><td>' . esc_html($st === 'publicada' ? get_the_title($p) : get_post_meta($p->ID, 'tsp_audio_contexto', true)) . '</td><td>' . wp_kses_post($txt) . '</td></tr>';
    }
    echo '</tbody></table>';
}

/* ---------- Recebe o envio ---------- */

add_action('wp_ajax_tsp_audio_enviar', function () {
    check_ajax_referer('tsp_audio', 'nonce');
    if (!current_user_can('edit_posts') || !current_user_can('upload_files')) {
        wp_send_json_error('Sem permissão para enviar.');
    }
    $texto = sanitize_textarea_field(wp_unslash($_POST['transcricao'] ?? ''));
    $contexto = sanitize_text_field(wp_unslash($_POST['contexto'] ?? ''));
    $credito = sanitize_text_field(wp_unslash($_POST['credito'] ?? ''));
    $times = array_filter(array_map('intval', (array) ($_POST['times'] ?? array())));
    if (mb_strlen($texto) < 200) {
        wp_send_json_error('O texto do áudio está curto demais (mínimo 200 letras).');
    }
    if ($contexto === '' || $credito === '' || !$times || empty($_FILES['foto']['name'])) {
        wp_send_json_error('Preencha quem fala, o clube, a foto e o crédito.');
    }
    $tipo = wp_check_filetype($_FILES['foto']['name']);
    if (!in_array($tipo['type'], array('image/jpeg', 'image/png', 'image/webp'), true)) {
        wp_send_json_error('A foto precisa ser JPG, PNG ou WEBP.');
    }
    $id = wp_insert_post(array(
        'post_type'    => tsp_audio_tipo(),
        'post_status'  => 'draft',
        'post_title'   => 'Áudio: ' . mb_substr($contexto, 0, 120),
        'post_content' => '',
        'post_author'  => get_current_user_id(),
    ), true);
    if (is_wp_error($id)) {
        wp_send_json_error('Não consegui criar a matéria: ' . $id->get_error_message());
    }
    wp_set_object_terms($id, $times, 'times');
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $foto = media_handle_upload('foto', $id, array('post_excerpt' => $credito));
    if (is_wp_error($foto)) {
        wp_delete_post($id, true);
        wp_send_json_error('A foto não subiu: ' . $foto->get_error_message());
    }
    set_post_thumbnail($id, $foto);
    update_post_meta($id, 'tsp_audio_status', 'fila');
    update_post_meta($id, 'tsp_audio_transcricao', $texto);
    update_post_meta($id, 'tsp_audio_contexto', $contexto);
    update_post_meta($id, 'tsp_audio_credito', $credito);
    update_post_meta($id, 'tsp_audio_link', esc_url_raw(wp_unslash($_POST['link'] ?? '')));
    update_post_meta($id, 'tsp_audio_obs', sanitize_text_field(wp_unslash($_POST['obs'] ?? '')));
    tsp_audio_acf($id, array('Crédito da imagem', 'Credito da imagem', 'Crédito da foto'), $credito);
    wp_send_json_success('Enviado! O robô escreve a matéria e o site publica sozinho em até 1 hora. Acompanhe em "Últimos envios".');
});

// Grava num campo ACF achado pelo rótulo (o grupo "Adicional matéria" da redação)
function tsp_audio_acf($post_id, $rotulos, $valor)
{
    if (!function_exists('acf_get_field_groups') || !function_exists('update_field')) {
        return false;
    }
    $alvo = array_map(function ($r) {
        return sanitize_title(remove_accents($r));
    }, $rotulos);
    foreach (acf_get_field_groups() as $g) {
        foreach ((array) acf_get_fields($g) as $f) {
            if (in_array(sanitize_title(remove_accents($f['label'])), $alvo, true)) {
                update_field($f['key'], $valor, $post_id);
                return true;
            }
        }
    }
    return false;
}

/* ---------- Fila para o robô (só leitura: texto do áudio e dados do envio, nada mais) ---------- */

add_action('rest_api_init', function () {
    register_rest_route('tsp/v1', '/fila-audio', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            $q = get_posts(array('post_type' => tsp_audio_tipo(), 'post_status' => 'draft', 'numberposts' => 10, 'meta_key' => 'tsp_audio_status', 'meta_value' => 'fila', 'orderby' => 'date', 'order' => 'ASC'));
            $out = array();
            foreach ($q as $p) {
                $clubes = wp_get_post_terms($p->ID, 'times', array('fields' => 'names'));
                $out[] = array(
                    'id'         => $p->ID,
                    'enviado'    => get_post_time('c', true, $p),
                    'contexto'   => get_post_meta($p->ID, 'tsp_audio_contexto', true),
                    'clubes'     => is_wp_error($clubes) ? array() : $clubes,
                    'link'       => get_post_meta($p->ID, 'tsp_audio_link', true),
                    'obs'        => get_post_meta($p->ID, 'tsp_audio_obs', true),
                    'transcricao' => get_post_meta($p->ID, 'tsp_audio_transcricao', true),
                );
            }
            $r = rest_ensure_response(array('itens' => $out));
            $r->header('X-Robots-Tag', 'noindex');
            $r->header('Cache-Control', 'no-store');
            return $r;
        },
    ));
});

/* ---------- Matérias prontas: aplica e publica ---------- */

// Confere a cada 15 minutos se o robô já devolveu matérias prontas
add_filter('cron_schedules', function ($s) {
    $s['tsp_audio_15'] = array('interval' => 900, 'display' => 'A cada 15 minutos (TSP Áudio)');
    return $s;
});
add_action('init', function () {
    if (!wp_next_scheduled('tsp_audio_buscar')) {
        wp_schedule_event(time() + 120, 'tsp_audio_15', 'tsp_audio_buscar');
    }
});
add_action('tsp_audio_buscar', function () {
    tsp_audio_aplicar(false);
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('tsp_audio_buscar');
});

function tsp_audio_aplicar($forcar = false)
{
    $na_fila = get_posts(array('post_type' => tsp_audio_tipo(), 'post_status' => 'draft', 'numberposts' => 30, 'fields' => 'ids', 'meta_key' => 'tsp_audio_status', 'meta_value' => 'fila'));
    if (!$na_fila) {
        return 0;
    }
    $r = wp_remote_get(add_query_arg('v', time(), TSP_AUDIO_RESULTADOS), array('timeout' => 20));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return 0;
    }
    $corpo = wp_remote_retrieve_body($r);
    if (!$forcar && get_option('tsp_audio_hash') === md5($corpo)) {
        return 0;
    }
    update_option('tsp_audio_hash', md5($corpo), false);
    $d = json_decode($corpo, true);
    $feitos = 0;
    foreach ((array) ($d['itens'] ?? array()) as $it) {
        $id = (int) ($it['id'] ?? 0);
        if (!$id || !in_array($id, $na_fila, true)) {
            continue;
        }
        if (!empty($it['erro'])) {
            update_post_meta($id, 'tsp_audio_status', 'erro');
            update_post_meta($id, 'tsp_audio_erro', sanitize_text_field($it['erro']));
            continue;
        }
        if (tsp_audio_publicar($id, $it)) {
            $feitos++;
        }
    }
    return $feitos;
}

function tsp_audio_publicar($id, $it)
{
    $txt = function ($s, $max = 400) {
        return mb_substr(trim(wp_strip_all_tags((string) $s)), 0, $max);
    };
    $titulo = $txt($it['titulo'] ?? '', 120);
    $blocos = '';
    foreach ((array) ($it['corpo'] ?? array()) as $b) {
        if (!empty($b['h2'])) {
            $blocos .= "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html($txt($b['h2'], 140)) . "</h2>\n<!-- /wp:heading -->\n\n";
        } elseif (!empty($b['citacao'])) {
            $blocos .= "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>" . esc_html($txt($b['citacao'], 900)) . "</p></blockquote>\n<!-- /wp:quote -->\n\n";
        } elseif (!empty($b['p'])) {
            $blocos .= "<!-- wp:paragraph -->\n<p>" . esc_html($txt($b['p'], 2000)) . "</p>\n<!-- /wp:paragraph -->\n\n";
        }
    }
    if ($titulo === '' || substr_count($blocos, '<p>') < 3) {
        update_post_meta($id, 'tsp_audio_status', 'erro');
        update_post_meta($id, 'tsp_audio_erro', 'O robô devolveu um texto incompleto.');
        return false;
    }
    $sub = $txt($it['subtitulo'] ?? '', 220);
    $ok = wp_update_post(array(
        'ID'           => $id,
        'post_title'   => $titulo,
        'post_content' => $blocos,
        'post_excerpt' => $sub,
        'post_status'  => 'publish',
        'post_date'    => current_time('mysql'),
        'post_date_gmt' => current_time('mysql', true),
    ), true);
    if (is_wp_error($ok)) {
        update_post_meta($id, 'tsp_audio_erro', $ok->get_error_message());
        return false;
    }
    if ($sub !== '') {
        tsp_audio_acf($id, array('Subtítulo', 'Subtitulo', 'Linha fina'), $sub);
    }
    if (!empty($it['resumo'])) {
        update_post_meta($id, 'tsp_resumo', implode("\n", array_map(function ($s) use ($txt) {
            return $txt($s, 220);
        }, array_slice((array) $it['resumo'], 0, 5))));
    }
    $faq = array();
    foreach (array_slice((array) ($it['faq'] ?? array()), 0, 5) as $f) {
        if (is_array($f) && !empty($f[0]) && !empty($f[1])) {
            $faq[] = array($txt($f[0], 200), $txt($f[1], 500));
        }
    }
    if ($faq) {
        update_post_meta($id, 'tsp_faq', wp_json_encode($faq, JSON_UNESCAPED_UNICODE));
    }
    foreach (array('meta_title' => array('_yoast_wpseo_title', 70), 'meta_desc' => array('_yoast_wpseo_metadesc', 160), 'foco' => array('_yoast_wpseo_focuskw', 80)) as $k => $m) {
        if (!empty($it[$k])) {
            update_post_meta($id, $m[0], $txt($it[$k], $m[1]));
        }
    }
    if (!empty($it['tags'])) {
        wp_set_post_tags($id, array_map(function ($t) use ($txt) {
            return $txt($t, 60);
        }, array_slice((array) $it['tags'], 0, 6)), false);
    }
    $link = get_post_meta($id, 'tsp_audio_link', true);
    if ($link) {
        update_post_meta($id, 'tsp_fontes', 'Áudio original da coletiva | ' . $link);
    }
    update_post_meta($id, 'tsp_ia', '1');
    update_post_meta($id, 'tsp_ia_origem', 'audio');
    update_post_meta($id, 'tsp_h2_aplicado', 1);
    update_post_meta($id, 'tsp_audio_status', 'publicada');
    return true;
}


// Atualização automática pelo GitHub do TSP (Painel → Atualizações)
require_once __DIR__ . '/inc/tsp-atualizador.php';
tsp_atualizador_registrar('plugin', 'tsp-audio', plugin_basename(__FILE__), get_file_data(__FILE__, array('v' => 'Version'))['v']);
