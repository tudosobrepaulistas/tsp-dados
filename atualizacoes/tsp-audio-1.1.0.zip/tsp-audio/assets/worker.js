/* TSP Notícia por Áudio: transcrição no próprio aparelho (Whisper, via Transformers.js).
   Recebe pedaços de áudio de 16 kHz e devolve o texto de cada pedaço. Nada sai do aparelho. */
import { pipeline, env } from 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.6';

env.allowLocalModels = false;
let asr = null;
let nomeModelo = '';

async function carregar(modelo) {
  if (asr && nomeModelo === modelo) { return; }
  const gpu = typeof navigator !== 'undefined' && navigator.gpu && (await navigator.gpu.requestAdapter().catch(() => null));
  const opcoes = gpu
    ? { device: 'webgpu', dtype: { encoder_model: 'fp32', decoder_model_merged: 'q4' } }
    : { device: 'wasm', dtype: 'q8' };
  opcoes.progress_callback = (p) => {
    if (p.status === 'progress' && p.total) {
      self.postMessage({ tipo: 'baixando', pct: Math.round((p.loaded / p.total) * 100), arquivo: p.file });
    }
  };
  asr = await pipeline('automatic-speech-recognition', modelo, opcoes);
  nomeModelo = modelo;
  self.postMessage({ tipo: 'pronto', gpu: !!gpu });
}

self.onmessage = async (e) => {
  const m = e.data;
  try {
    if (m.tipo === 'carregar') {
      await carregar(m.modelo);
    } else if (m.tipo === 'pedaco') {
      const r = await asr(m.audio, { language: 'portuguese', task: 'transcribe', chunk_length_s: 30 });
      self.postMessage({ tipo: 'texto', i: m.i, texto: (r && r.text ? r.text : '').trim() });
    }
  } catch (err) {
    self.postMessage({ tipo: 'erro', msg: String(err && err.message ? err.message : err) });
  }
};
