/* TSP Notícia por Áudio: escolhe/grava o áudio, transcreve no aparelho e envia para a fila do robô. */
(function () {
  var C = window.TSP_AUDIO;
  var $ = function (s) { return document.querySelector(s); };
  var form = $('#tsp-audio-form');
  if (!form || !C) { return; }
  var arquivo = $('#tsp-audio-arquivo');
  var btnTrans = $('#tsp-audio-transcrever');
  var texto = $('#tsp-audio-texto');
  var status = $('#tsp-audio-status');
  var prog = document.querySelector('.tsp-audio__progresso');
  var barra = document.querySelector('.tsp-audio__barra span');
  var resposta = $('#tsp-audio-resposta');
  var fonte = null; // Blob do áudio escolhido ou gravado
  var PEDACO = 28; // segundos por pedaço

  function avisar(msg, pct) {
    prog.hidden = false;
    status.textContent = msg;
    if (typeof pct === 'number') { barra.style.width = Math.max(2, Math.min(100, pct)) + '%'; }
  }

  // Filtro da lista de clubes
  var filtro = $('#tsp-audio-filtro'), sel = $('#tsp-audio-times');
  var sem = function (t) { return t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); };
  filtro.addEventListener('input', function () {
    var q = sem(filtro.value);
    Array.prototype.forEach.call(sel.options, function (o) { o.hidden = q && !o.selected && sem(o.text).indexOf(q) === -1; });
  });

  // Abas: arquivo x gravar
  document.querySelectorAll('[data-modo]').forEach(function (b) {
    b.addEventListener('click', function () {
      document.querySelectorAll('[data-modo]').forEach(function (x) { x.classList.toggle('is-ativo', x === b); });
      document.querySelectorAll('[data-painel]').forEach(function (p) { p.hidden = p.getAttribute('data-painel') !== b.getAttribute('data-modo'); });
    });
  });

  arquivo.addEventListener('change', function () {
    fonte = arquivo.files[0] || null;
    btnTrans.disabled = !fonte;
    if (fonte && fonte.size > 700 * 1024 * 1024) {
      avisar('Arquivo muito grande (mais de 700 MB). Envie só o áudio ou corte o vídeo.', 0);
      btnTrans.disabled = true;
    }
  });

  // Gravar agora
  var gravador = null, partes = [], inicio = 0, relogio = null;
  var btnGravar = $('#tsp-audio-gravar'), tempo = $('#tsp-audio-tempo');
  btnGravar.addEventListener('click', async function () {
    if (gravador && gravador.state === 'recording') { gravador.stop(); return; }
    try {
      var stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: true } });
      partes = [];
      gravador = new MediaRecorder(stream);
      gravador.ondataavailable = function (e) { if (e.data.size) { partes.push(e.data); } };
      gravador.onstop = function () {
        stream.getTracks().forEach(function (t) { t.stop(); });
        clearInterval(relogio);
        fonte = new Blob(partes, { type: gravador.mimeType || 'audio/webm' });
        btnGravar.textContent = '● Gravar de novo';
        btnTrans.disabled = false;
        transcrever();
      };
      gravador.start(1000);
      inicio = Date.now();
      btnGravar.textContent = '■ Parar e transcrever';
      relogio = setInterval(function () {
        var s = Math.floor((Date.now() - inicio) / 1000);
        tempo.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
      }, 500);
    } catch (err) {
      avisar('Não consegui usar o microfone. Libere o microfone para este site no navegador.', 0);
    }
  });

  // Áudio → 16 kHz mono
  async function prepararAudio(blob) {
    var buf = await blob.arrayBuffer();
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ctx = new Ctx();
    var dec = await ctx.decodeAudioData(buf);
    ctx.close && ctx.close();
    var off = new OfflineAudioContext(1, Math.ceil(dec.duration * 16000), 16000);
    var src = off.createBufferSource();
    src.buffer = dec;
    src.connect(off.destination);
    src.start();
    var r = await off.startRendering();
    return r.getChannelData(0);
  }

  var worker = null;
  function pedir(msg, transfer) {
    return new Promise(function (ok, falha) {
      worker.onmessage = function (e) {
        var d = e.data;
        if (d.tipo === 'baixando') { avisar('Preparando a transcrição (só na 1ª vez neste aparelho): ' + d.pct + '%', d.pct); return; }
        if (d.tipo === 'erro') { falha(new Error(d.msg)); return; }
        ok(d);
      };
      worker.postMessage(msg, transfer || []);
    });
  }

  async function transcrever() {
    if (!fonte) { return; }
    btnTrans.disabled = true;
    try {
      avisar('Lendo o áudio...', 2);
      var audio = await prepararAudio(fonte);
      var total = Math.ceil(audio.length / (16000 * PEDACO));
      if (!worker) { worker = new Worker(C.worker, { type: 'module' }); }
      var pronto = await pedir({ tipo: 'carregar', modelo: $('#tsp-audio-modelo').value });
      var textos = [];
      var t0 = Date.now();
      for (var i = 0; i < total; i++) {
        var pedaco = audio.slice(i * 16000 * PEDACO, (i + 1) * 16000 * PEDACO);
        var r = await pedir({ tipo: 'pedaco', i: i, audio: pedaco }, [pedaco.buffer]);
        textos.push(r.texto);
        texto.value = textos.join(' ');
        var porPedaco = (Date.now() - t0) / (i + 1);
        var falta = Math.round((porPedaco * (total - i - 1)) / 60000);
        avisar('Transcrevendo ' + (i + 1) + ' de ' + total + (falta > 0 ? ' · faltam cerca de ' + falta + ' min' : '') + (pronto.gpu ? '' : ' · dica: no computador fica mais rápido'), ((i + 1) / total) * 100);
      }
      avisar('Pronto! Confira o texto, principalmente nomes, e preencha o resto.', 100);
    } catch (err) {
      avisar('Não consegui transcrever: ' + err.message + '. Tente a qualidade "Rápida" ou use o Chrome.', 0);
    }
    btnTrans.disabled = false;
  }
  btnTrans.addEventListener('click', transcrever);

  // Envia para a fila
  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    var b = $('#tsp-audio-enviar');
    b.disabled = true;
    resposta.textContent = 'Enviando...';
    var fd = new FormData(form);
    fd.append('action', 'tsp_audio_enviar');
    fd.append('nonce', C.nonce);
    try {
      var r = await fetch(C.ajax, { method: 'POST', body: fd, credentials: 'same-origin' });
      var j = await r.json();
      resposta.textContent = j.data || 'Algo deu errado.';
      resposta.className = 'tsp-audio__resposta ' + (j.success ? 'is-ok' : 'is-erro');
      if (j.success) { form.reset(); texto.value = ''; fonte = null; setTimeout(function () { location.reload(); }, 2500); }
    } catch (err) {
      resposta.textContent = 'Falha na conexão. Tente de novo.';
      resposta.className = 'tsp-audio__resposta is-erro';
    }
    b.disabled = false;
  });
})();
