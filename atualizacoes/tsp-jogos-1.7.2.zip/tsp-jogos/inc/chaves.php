<?php
/**
 * Chaveamento (mata-mata) das copas e painel do futebol feminino, vindos da base de jogos do TSP.
 * tsp_jogos_chave_html('copa_do_brasil') · tsp_jogos_painel_fem_html()
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_chaves()
{
    $c = get_option('tsp_jogos_chaves', array());
    return is_array($c) ? $c : array();
}

function tsp_jogos_chave_css()
{
    static $feito = false;
    if ($feito) {
        return '';
    }
    $feito = true;
    return '<style>
.tsp-chave-tit{margin:0 0 14px!important}
.tsp-chave{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(260px,1fr);gap:18px;align-items:center;overflow-x:auto;padding-bottom:4px}
.tsp-chave__fase{display:flex;flex-direction:column;gap:14px;justify-content:space-around;height:100%}
.tsp-chave__fase h3{font-size:13px!important;letter-spacing:.06em;text-transform:uppercase;color:#777;margin:0!important;text-align:center}
.tsp-chave__conf{background:#fff;border:1px solid #e7e1d8;border-radius:12px;padding:12px 14px;position:relative}
.tsp-chave__conf.is-hoje{border:2px solid #E8862A;box-shadow:0 4px 14px rgba(232,134,42,.18)}
.tsp-chave__selo{position:absolute;top:-10px;right:12px;background:#E8862A;color:#111;font-size:11px;font-weight:800;border-radius:999px;padding:2px 9px;text-transform:uppercase}
.tsp-chave__time{display:flex;align-items:center;gap:8px;padding:5px 0;font-weight:600}
.tsp-chave__time img,.tsp-chave__esc{width:24px;height:24px;object-fit:contain;flex:none}
.tsp-chave__esc{display:inline-grid;place-items:center;border-radius:50%;background:#eee;font-size:8px;font-weight:800;font-style:normal}
.tsp-chave__time span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tsp-chave__time b{font-size:18px;min-width:22px;text-align:right}
.tsp-chave__time.is-venc{font-weight:800}.tsp-chave__time.is-venc span::after{content:" ✓";color:#1a7f37}
.tsp-chave__time.is-fora{opacity:.55}
.tsp-chave__jogos{list-style:none;margin:8px 0 0!important;padding:8px 0 0!important;border-top:1px dashed #e7e1d8;font-size:12.5px;color:#555}
.tsp-chave__jogos li{margin:2px 0!important;padding:0!important}
.tsp-chave__jogos li::before{content:none!important}
.tsp-chave__info{font-size:12.5px;color:#555;margin-top:8px}
@media (max-width:700px){.tsp-chave{grid-auto-flow:row;grid-auto-columns:auto}.tsp-chave__fase{height:auto}}
.tsp-painel-fem{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
.tsp-painel-fem table{width:100%;border-collapse:collapse;font-size:14px}
.tsp-painel-fem td,.tsp-painel-fem th{padding:6px 4px;border-top:1px solid #f0ebe3;text-align:left}
.tsp-painel-fem td:last-child,.tsp-painel-fem th:last-child{text-align:right;font-weight:800}
.tsp-painel-fem .tsp-chave__conf{margin-top:10px}
</style>';
}

function tsp_jogos_chave_escudo($id, $nome)
{
    $u = ($id && function_exists('tsp_sim_escudo')) ? tsp_sim_escudo($id) : '';
    if ($u) {
        return '<img src="' . esc_url($u) . '" alt="" loading="lazy" width="24" height="24">';
    }
    return '<i class="tsp-chave__esc" aria-hidden="true">' . esc_html($id ? mb_strtoupper(mb_substr($nome, 0, 2)) : '?') . '</i>';
}

function tsp_jogos_chave_html($liga, $titulo = '')
{
    $ch = tsp_jogos_chaves();
    if (empty($ch[$liga]['fases'])) {
        return '';
    }
    $tz = new DateTimeZone('America/Sao_Paulo');
    $hoje = wp_date('Y-m-d', null, $tz);
    $sem = array('dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb');
    $h = tsp_jogos_chave_css() . '<div class="tsp-chave" aria-label="Chaveamento ' . esc_attr($ch[$liga]['nome'] ?? '') . '">';
    foreach ($ch[$liga]['fases'] as $f) {
        $h .= '<div class="tsp-chave__fase"><h3>' . esc_html($f['nome']) . '</h3>';
        foreach ((array) $f['confrontos'] as $c) {
            $jogos = (array) ($c['jogos'] ?? array());
            $e_hoje = (bool) array_filter($jogos, function ($j) use ($hoje) {
                return substr((string) $j['data'], 0, 10) === $hoje;
            });
            $h .= '<div class="tsp-chave__conf' . ($e_hoje ? ' is-hoje' : '') . '">' . ($e_hoje ? '<span class="tsp-chave__selo">Hoje</span>' : '');
            foreach (array(0, 1) as $i) {
                $id = (int) ($c['times'][$i] ?? 0);
                $nome = (string) ($c['nomes'][$i] ?? 'A definir');
                if (function_exists('tsp_jogos_nome_time') && $id) {
                    $nome = tsp_jogos_nome_time($id, $nome);
                }
                $cl = !empty($c['vencedor']) ? ((int) $c['vencedor'] === $id ? ' is-venc' : ' is-fora') : '';
                $pl = isset($c['agregado'][$i]) && $c['agregado'] !== null ? (string) $c['agregado'][$i] : '';
                if (!empty($c['penaltis'])) {
                    $pl .= ' <small>(' . (int) $c['penaltis'][$i] . ')</small>';
                }
                $h .= '<div class="tsp-chave__time' . $cl . '">' . tsp_jogos_chave_escudo($id, $nome) . '<span>' . esc_html($nome) . '</span><b>' . wp_kses($pl, array('small' => array())) . '</b></div>';
            }
            if ($jogos) {
                $h .= '<ul class="tsp-chave__jogos">';
                $n = count($jogos);
                foreach ($jogos as $k => $j) {
                    $dt = date_create_immutable((string) $j['data'], $tz);
                    $rot = $n > 1 ? ($k === 0 ? 'Ida' : 'Volta') : 'Jogo único';
                    $nm = function ($x) use ($c) {
                        $i = array_search((int) $x, array_map('intval', (array) $c['times']), true);
                        return $i === false ? '' : (string) $c['nomes'][$i];
                    };
                    if ($j['status'] === 'encerrado') {
                        $txt = $rot . ' · ' . ($dt ? $dt->format('d/m') : '') . ' · ' . $nm($j['casa']) . ' ' . (int) $j['gc'] . ' x ' . (int) $j['gf'] . ' ' . $nm($j['fora']) . ($j['pen'] ? ' (pênaltis ' . $j['pen'] . ')' : '');
                    } else {
                        $quando = $dt ? ((substr((string) $j['data'], 0, 10) === $hoje ? 'hoje' : $sem[(int) $dt->format('w')] . ' ' . $dt->format('d/m')) . ' · ' . $dt->format('H\hi')) : '';
                        $txt = $rot . ' · ' . $quando . ' · ' . $nm($j['casa']) . ' x ' . $nm($j['fora']) . ($j['estadio'] ? ' · ' . $j['estadio'] : '');
                    }
                    $link = function_exists('tsp_jogos_link_jogo') ? tsp_jogos_link_jogo((int) $j['id']) : '';
                    $h .= '<li>' . ($link ? '<a href="' . esc_url($link) . '">' . esc_html($txt) . '</a>' : esc_html($txt)) . '</li>';
                }
                $h .= '</ul>';
            } elseif (!empty($f['info'])) {
                $in = $f['info'];
                $d = !empty($in['data']) ? date_create_immutable($in['data'], $tz) : null;
                $partes = array_filter(array(!empty($in['jogo_unico']) ? 'Jogo único' : '', $d ? $sem[(int) $d->format('w')] . ' ' . $d->format('d/m') : '', trim(($in['estadio'] ?? '') . (!empty($in['cidade']) ? ', ' . $in['cidade'] : ''), ', '), $in['obs'] ?? ''));
                $h .= '<div class="tsp-chave__info">' . esc_html(implode(' · ', $partes)) . '</div>';
            }
            $h .= '</div>';
        }
        $h .= '</div>';
    }
    return $h . '</div>';
}

function tsp_jogos_painel_fem_html()
{
    $p = get_option('tsp_jogos_painel_fem', array());
    if (!is_array($p) || !$p) {
        return '';
    }
    $h = tsp_jogos_chave_css();
    foreach ($p as $c) {
        $h .= '<div class="tsp-painel-fem__comp"><h3>' . esc_html($c['nome'] ?? '') . ' <small style="font-weight:600;color:#777">· ' . esc_html($c['fase'] ?? '') . '</small></h3><div class="tsp-painel-fem">';
        if (!empty($c['classificacao'])) {
            $h .= '<div class="tsp-chave__conf"><strong>' . esc_html($c['classificacao_titulo'] ?? 'Classificação') . '</strong><table><thead><tr><th>#</th><th>Time</th><th>P</th></tr></thead><tbody>';
            foreach ($c['classificacao'] as $r) {
                $h .= '<tr><td>' . esc_html($r[0]) . '</td><td>' . esc_html($r[1]) . '</td><td>' . esc_html($r[2]) . '</td></tr>';
            }
            $h .= '</tbody></table>' . (!empty($c['nota_classificacao']) ? '<div class="tsp-chave__info">' . esc_html($c['nota_classificacao']) . '</div>' : '') . '</div>';
        }
        if (!empty($c['confrontos'])) {
            $h .= '<div>';
            foreach ($c['confrontos'] as $x) {
                $h .= '<div class="tsp-chave__conf"><div class="tsp-chave__info" style="margin:0 0 4px;font-weight:800;text-transform:uppercase;font-size:11px;letter-spacing:.06em">' . esc_html($x['fase']) . ' · ' . esc_html($x['quando']) . '</div>'
                    . '<div class="tsp-chave__time"><span>' . esc_html(trim(($x['casa'] ?? '') . ($x['fora'] ? ' x ' . $x['fora'] : '')) ?: 'A definir') . '</span></div>'
                    . (!empty($x['obs']) ? '<div class="tsp-chave__info">' . esc_html($x['obs']) . '</div>' : '') . '</div>';
            }
            $h .= '</div>';
        }
        $h .= '</div></div>';
    }
    return $h;
}
