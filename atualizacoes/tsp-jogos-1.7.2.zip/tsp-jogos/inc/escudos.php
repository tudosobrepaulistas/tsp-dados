<?php
/**
 * Escudo oficial de todos os clubes das competições (inclusive os de fora de SP).
 * O site busca na Wikipédia em português a imagem principal da página do clube (escudo hospedado no
 * Wikimedia Commons), baixa uma vez para uploads/tsp-escudos/ e usa nas páginas de jogo.
 * Clube paulista com escudo cadastrado no site continua usando o do site.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_escudos()
{
    $e = get_option('tsp_jogos_escudos', array());
    return is_array($e) ? $e : array();
}

// Busca até 8 escudos que faltam (roda depois de cada leitura da base)
add_action('tsp_jogos_base', 'tsp_jogos_escudos_buscar', 30);
function tsp_jogos_escudos_buscar($max = 20)
{
    $max = (int) $max ?: 20;
    $esc = tsp_jogos_escudos();
    $feitos = 0;
    $up = wp_upload_dir();
    $dir = trailingslashit($up['basedir']) . 'tsp-escudos';
    wp_mkdir_p($dir);
    foreach (tsp_jogos_base_times() as $id => $t) {
        if ($feitos >= $max) {
            break;
        }
        $wiki = $t['wiki'] ?? '';
        $atual = $esc[$id] ?? null;
        if (!$wiki || (is_array($atual) && (!empty($atual['url']) || ($atual['tentou'] ?? 0) > time() - 7 * DAY_IN_SECONDS))) {
            continue;
        }
        $feitos++;
        $ua = array('User-Agent' => 'TSP-Jogos/1.7 (https://tudosobrepaulista.com.br; contato@tudosobrepaulista.com.br)');
        $api = add_query_arg(array('action' => 'query', 'format' => 'json', 'redirects' => 1, 'prop' => 'pageimages|pageprops', 'piprop' => 'thumbnail|name', 'pithumbsize' => 240, 'ppprop' => 'wikibase_item', 'titles' => $wiki), 'https://pt.wikipedia.org/w/api.php');
        $r = wp_remote_get($api, array('timeout' => 15, 'headers' => $ua));
        $src = '';
        $arq = '';
        $qid = '';
        if (!is_wp_error($r)) {
            $d = json_decode(wp_remote_retrieve_body($r), true);
            foreach ((array) ($d['query']['pages'] ?? array()) as $pg) {
                $src = $pg['thumbnail']['source'] ?? '';
                $arq = $pg['pageimage'] ?? '';
                $qid = $pg['pageprops']['wikibase_item'] ?? '';
            }
        }
        // Sem imagem principal na página: usa o logotipo do clube no Wikidata (propriedade P154), hospedado no Commons
        if ((!$src || strpos($src, 'https://upload.wikimedia.org/') !== 0) && preg_match('~^Q\d+$~', $qid)) {
            $w = wp_remote_get('https://www.wikidata.org/wiki/Special:EntityData/' . $qid . '.json', array('timeout' => 15, 'headers' => $ua));
            $wd = is_wp_error($w) ? array() : json_decode(wp_remote_retrieve_body($w), true);
            $logo = $wd['entities'][$qid]['claims']['P154'][0]['mainsnak']['datavalue']['value'] ?? '';
            if ($logo) {
                $arq = $logo;
                $src = 'https://commons.wikimedia.org/w/index.php?title=Special:FilePath/' . rawurlencode(str_replace(' ', '_', $logo)) . '&width=240';
            }
        }
        if (!$src || (strpos($src, 'https://upload.wikimedia.org/') !== 0 && strpos($src, 'https://commons.wikimedia.org/') !== 0)) {
            $esc[$id] = array('tentou' => time(), 'erro' => 'sem imagem');
            continue;
        }
        // Wikimedia exige identificação do robô (User-Agent); o download padrão do WordPress é recusado
        $img = wp_remote_get($src, array('timeout' => 20, 'headers' => $ua, 'redirection' => 5));
        $corpo = is_wp_error($img) ? '' : wp_remote_retrieve_body($img);
        if (!$corpo || (int) wp_remote_retrieve_response_code($img) !== 200) {
            $esc[$id] = array('tentou' => time(), 'erro' => is_wp_error($img) ? $img->get_error_message() : 'http ' . wp_remote_retrieve_response_code($img));
            continue;
        }
        $tipo = (string) wp_remote_retrieve_header($img, 'content-type');
        $ext = strpos($tipo, 'jpeg') !== false ? 'jpg' : (strpos($tipo, 'webp') !== false ? 'webp' : (strpos($tipo, 'gif') !== false ? 'gif' : 'png'));
        $nome = sanitize_file_name(($t['chave'] ?: $id) . '.' . $ext);
        @file_put_contents("$dir/$nome", $corpo);
        if (file_exists("$dir/$nome") && @getimagesize("$dir/$nome")) {
            $esc[$id] = array('url' => trailingslashit($up['baseurl']) . 'tsp-escudos/' . $nome, 'arquivo' => $arq);
        } else {
            @unlink("$dir/$nome");
            $esc[$id] = array('tentou' => time(), 'erro' => 'arquivo inválido');
        }
    }
    update_option('tsp_jogos_escudos', $esc, false);
    return $feitos;
}

function tsp_jogos_escudo_url($api_id)
{
    $e = tsp_jogos_escudos()[(int) $api_id] ?? array();
    return $e['url'] ?? '';
}
