<?php
/**
 * Vitrine de ofertas do Mercado Livre (listas de afiliado do TSP por clube).
 * Os produtos chegam pelo plugin TSP Jogos (opção tsp_ofertas, lida da Base TSP).
 * Aparece: na página do clube (depois do painel de jogos), no meio da matéria (depois do 3º parágrafo,
 * em matérias com 6 parágrafos ou mais) e no fim da matéria. Só para clubes que têm lista.
 * Todo clique vai para a lista de afiliado do TSP (rel="sponsored"), com aviso de transparência.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_ofertas_do_clube($slug)
{
    $of = get_option('tsp_ofertas', array());
    $clubes = (array) ($of['clubes'] ?? array());
    $chave = function_exists('tsp_clube_slug_pai') ? tsp_clube_slug_pai($slug) : $slug;
    return $clubes[$chave] ?? ($clubes[$slug] ?? null);
}

// Clube da matéria que tem vitrine: SÓ o clube principal da matéria (o do selo no topo).
// Matéria do Bragantino nunca mostra produtos do Santos, mesmo que o Santos seja citado.
function tsp_ofertas_clube_do_post($post_id)
{
    $t = function_exists('tsp_time_do_post') ? tsp_time_do_post($post_id) : null;
    return ($t && tsp_ofertas_do_clube($t->slug)) ? $t : null;
}

function tsp_ofertas_html($termo, $onde = 'clube', $qtd = 10)
{
    if (!$termo) {
        return '';
    }
    $c = tsp_ofertas_do_clube($termo->slug);
    if (!$c || empty($c['produtos'])) {
        return '';
    }
    $prods = $c['produtos'];
    // Gira a ordem por dia e por lugar, para o leitor ver produtos diferentes no meio e no fim
    $semente = crc32(wp_date('Y-m-d') . $onde . get_the_ID());
    usort($prods, function ($a, $b) use ($semente) {
        return crc32($a['img'] . $semente) <=> crc32($b['img'] . $semente);
    });
    $prods = array_slice($prods, 0, $qtd);
    $lista = $c['lista'];
    $nome = preg_replace('~ (Feminino|Sub-\d+)$~i', '', $termo->name);
    $cores = function_exists('tsp_clube_cores') ? tsp_clube_cores($termo) : array('#111111', '#FFFFFF');
    $rel = 'sponsored nofollow noopener';
    $h = '<aside class="tsp-ofertas tsp-ofertas--' . esc_attr($onde) . '" style="--of-cor:' . esc_attr($cores[0]) . ';--of-txt:' . esc_attr($cores[1]) . '" aria-label="Ofertas ' . esc_attr($nome) . ' no Mercado Livre">';
    $h .= '<div class="tsp-ofertas__cab"><p class="tsp-ofertas__tit">Produtos ' . esc_html(function_exists('tsp_de') ? tsp_de($termo) : 'do ' . $nome) . ' <span>no Mercado Livre</span></p>';
    $h .= '<div class="tsp-ofertas__nav"><button type="button" data-of="-1" aria-label="Ofertas anteriores">‹</button><button type="button" data-of="1" aria-label="Mais ofertas">›</button></div></div>';
    $h .= '<ul class="tsp-ofertas__trilho">';
    foreach ($prods as $p) {
        $h .= '<li><a href="' . esc_url($lista) . '" target="_blank" rel="' . $rel . '">';
        $h .= '<span class="tsp-ofertas__img"><img src="' . esc_url($p['img']) . '" alt="" width="160" height="160" loading="lazy" decoding="async" referrerpolicy="no-referrer"></span>';
        $h .= '<span class="tsp-ofertas__nome">' . esc_html($p['titulo']) . '</span>';
        if ($p['antigo'] !== '') {
            $h .= '<s class="tsp-ofertas__antigo">R$ ' . esc_html($p['antigo']) . '</s>';
        }
        if ($p['preco'] !== '') {
            $h .= '<strong class="tsp-ofertas__preco">R$ ' . esc_html($p['preco']) . '</strong>';
        }
        $h .= '</a></li>';
    }
    $h .= '</ul><div class="tsp-ofertas__rod"><a class="tsp-ofertas__todas" href="' . esc_url($lista) . '" target="_blank" rel="' . $rel . '">Ver todas as ofertas →</a>';
    $h .= '<small>Link de afiliado: o TSP pode receber comissão do Mercado Livre, sem custo extra para você. Preços e estoque podem mudar.</small></div></aside>';
    return $h;
}

// Meio e fim da matéria (tipos Matéria e Post; jogos e páginas ficam de fora)
add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $html;
    }
    $t = tsp_ofertas_clube_do_post(get_the_ID());
    if (!$t) {
        return $html;
    }
    $partes = preg_split('~(</p>)~i', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    $n = substr_count(strtolower($html), '</p>');
    if ($n >= 6) {
        $saida = '';
        $contador = 0;
        $feito = false;
        for ($i = 0; $i < count($partes); $i++) {
            $saida .= $partes[$i];
            if (!$feito && strtolower($partes[$i]) === '</p>') {
                $contador++;
                $dentro = substr_count(strtolower($saida), '<blockquote') > substr_count(strtolower($saida), '</blockquote')
                    || substr_count(strtolower($saida), '<li') > substr_count(strtolower($saida), '</li');
                if ($contador >= 3 && !$dentro) {
                    $saida .= tsp_ofertas_html($t, 'meio', 8);
                    $feito = true;
                }
            }
        }
        $html = $saida;
    }
    return $html . tsp_ofertas_html($t, 'fim', 10);
}, 30);
