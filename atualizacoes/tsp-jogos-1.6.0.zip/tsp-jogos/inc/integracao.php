<?php
/**
 * Espelha os dados da API no tema: tabelas, rodadas da Série A/B e os 2 últimos / 2 próximos de cada clube.
 * O resumo é montado a cada sincronização (rápido de ler). O que vier da API substitui o preenchido à mão;
 * o que a API não tiver continua vindo de Ferramentas → TSP · Dados do tema.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_dia_curto($ts)
{
    $dias = array('Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb');
    return $dias[(int) wp_date('w', $ts)] . ' ' . wp_date('d/m', $ts) . ' ' . str_replace('h00', 'h', wp_date('H\hi', $ts));
}

function tsp_jogos_link_jogo($id)
{
    $p = tsp_jogos_post_do_jogo($id);
    return $p ? get_permalink($p) : '';
}

function tsp_jogos_montar_resumo()
{
    $r = array('tabelas' => array(), 'jogos' => array(), 'clubes' => array());
    foreach (array_keys(tsp_jogos_ligas()) as $liga) {
        $c = tsp_jogos_classificacao($liga);
        if (!empty($c['grupos'][0])) {
            $linhas = array();
            foreach ($c['grupos'][0] as $x) {
                // Últimos 5 jogos (do mais antigo para o mais recente): V, E ou D
                $forma = '';
                foreach (array_reverse((array) tsp_jogos_do_time((int) $x[1], 'ultimos', 5, $liga)) as $g) {
                    $pro = (int) $x[1] === (int) $g->casa_id ? (int) $g->gols_casa : (int) $g->gols_fora;
                    $con = (int) $x[1] === (int) $g->casa_id ? (int) $g->gols_fora : (int) $g->gols_casa;
                    $forma .= $pro > $con ? 'V' : ($pro === $con ? 'E' : 'D');
                }
                $linhas[] = array($x[0], tsp_jogos_nome_time($x[1], $x[2]), $x[3], $x[4], $x[5], $x[6], $x[7], $x[8], $forma);
            }
            $r['tabelas'][$liga] = array('titulo' => 'Classificação · ' . tsp_jogos_nome_liga($liga), 'nota' => 'Atualizada automaticamente em ' . wp_date('d/m \à\s H\hi', $c['quando']) . '.', 'linhas' => $linhas);
        }
        // Rodada: última encerrada e próxima
        $ult = tsp_jogos_buscar("liga = %s AND status IN ('FT','AET','PEN')", array($liga), 'inicio DESC', 1);
        $prx = tsp_jogos_buscar("liga = %s AND status IN ('NS','TBD')", array($liga), 'inicio ASC', 1);
        $bloco = array();
        if ($ult) {
            $lista = array();
            foreach (tsp_jogos_buscar('liga = %s AND rodada = %s', array($liga, $ult[0]->rodada), 'inicio ASC', 20) as $j) {
                if ($j->gols_casa !== null) {
                    $lista[] = array(wp_date('d/m', $j->inicio), tsp_jogos_nome_time($j->casa_id, $j->casa), (int) $j->gols_casa . ' x ' . (int) $j->gols_fora, tsp_jogos_nome_time($j->fora_id, $j->fora));
                }
            }
            $bloco['resultados'] = array('titulo' => tsp_jogos_rodada_curta($ult[0]->rodada) . ' · Resultados', 'lista' => $lista);
        }
        if ($prx) {
            $lista = array();
            foreach (tsp_jogos_buscar('liga = %s AND rodada = %s', array($liga, $prx[0]->rodada), 'inicio ASC', 20) as $j) {
                $lista[] = array(tsp_jogos_dia_curto($j->inicio), tsp_jogos_nome_time($j->casa_id, $j->casa), tsp_jogos_nome_time($j->fora_id, $j->fora));
            }
            $bloco['proximos'] = array('titulo' => tsp_jogos_rodada_curta($prx[0]->rodada) . ' · Próximos jogos', 'lista' => $lista);
        }
        if ($bloco) {
            $r['jogos'][$liga] = $bloco;
        }
    }
    // Clubes paulistas: 2 últimos e 2 próximos (todas as competições do profissional masculino)
    foreach (tsp_jogos_vinculos() as $api_id => $slug) {
        $c = array();
        foreach (tsp_jogos_do_time((int) $api_id, 'ultimos', 2) as $j) {
            $c['ultimos'][] = array(wp_date('d/m', $j->inicio), tsp_jogos_nome_time($j->casa_id, $j->casa), (int) $j->gols_casa . ' x ' . (int) $j->gols_fora, tsp_jogos_nome_time($j->fora_id, $j->fora), tsp_jogos_nome_liga($j->liga), tsp_jogos_link_jogo($j->id));
        }
        foreach (tsp_jogos_do_time((int) $api_id, 'proximos', 2) as $j) {
            $c['proximos'][] = array(tsp_jogos_ao_vivo($j) ? 'AO VIVO · ' . tsp_jogos_rotulo_status($j) . ' · ' . (int) $j->gols_casa . ' x ' . (int) $j->gols_fora : tsp_jogos_dia_curto($j->inicio), tsp_jogos_nome_time($j->casa_id, $j->casa), tsp_jogos_nome_time($j->fora_id, $j->fora), tsp_jogos_nome_liga($j->liga), tsp_jogos_link_jogo($j->id));
        }
        if ($c) {
            $r['clubes'][$slug] = $c;
        }
    }
    $r = apply_filters('tsp_jogos_resumo', $r);
    update_option('tsp_jogos_resumo', $r, false);
}

function tsp_jogos_rodada_curta($rodada)
{
    if (preg_match('~(\d+)\s*$~', $rodada, $m)) {
        return $m[1] . 'ª rodada';
    }
    return $rodada;
}

// O tema chama tsp_dado(chave); aqui os dados da API entram por cima dos manuais
add_filter('tsp_dado', function ($valor, $chave) {
    $r = get_option('tsp_jogos_resumo', array());
    if (!is_array($r) || empty($r[$chave])) {
        return $valor;
    }
    $valor = is_array($valor) ? $valor : array();
    if ($chave === 'clubes') {
        foreach ($r['clubes'] as $slug => $c) {
            $valor[$slug] = array_merge(isset($valor[$slug]) && is_array($valor[$slug]) ? $valor[$slug] : array(), $c);
        }
        return $valor;
    }
    return array_merge($valor, $r[$chave]);
}, 10, 2);
