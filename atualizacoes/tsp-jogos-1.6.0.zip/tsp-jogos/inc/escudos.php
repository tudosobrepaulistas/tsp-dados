<?php
/**
 * Escudo oficial de todos os clubes das competições (inclusive os de fora de SP).
 * O site busca na Wikipédia em português a imagem principal da página do clube (escudo hospedado no
 * Wikimedia Commons), baixa uma vez para uploads/tsp-escudos/ e usa nas páginas de jogo.
 * Clube paulista com escudo cadastrado no site continua usando o do site.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_jogos_escudos()
{
    $e = get_option('tsp_jogos_escudos', array());
    return is_array($e) ? $e : array();
}

// Busca até 8 escudos que faltam (roda depois de cada leitura da base)
add_action('tsp_jogos_base', 'tsp_jogos_escudos_buscar', 30);
function tsp_jogos_escudos_buscar($max = 8)
{
    $max = (int) $max ?: 8;
    $esc = tsp_jogos_escudos();
    $feitos = 0;
    $up = wp_upload_dir();
    $dir = trailingslashit($up['basedir']) . 'tsp-escudos';
    wp_mkdir_p($dir);
    foreach (tsp_jogos_base_times() as $id => $t) {
        if ($feitos >= $max) {
            break;
        }
        $wiki = $t['wiki'] ?? '';
        $atual = $esc[$id] ?? null;
        if (!$wiki || (is_array($atual) && (!empty($atual['url']) || ($atual['tentou'] ?? 0) > time() - 7 * DAY_IN_SECONDS))) {
            continue;
        }
        $feitos++;
        $api = add_query_arg(array('action' => 'query', 'format' => 'json', 'redirects' => 1, 'prop' => 'pageimages', 'piprop' => 'thumbnail|name', 'pithumbsize' => 240, 'titles' => $wiki), 'https://pt.wikipedia.org/w/api.php');
        $r = wp_remote_get($api, array('timeout' => 15, 'headers' => array('User-Agent' => 'TSP-Jogos/1.0 (tudosobrepaulista.com.br)')));
        $src = '';
        $arq = '';
        if (!is_wp_error($r)) {
            $d = json_decode(wp_remote_retrieve_body($r), true);
            foreach ((array) ($d['query']['pages'] ?? array()) as $pg) {
                $src = $pg['thumbnail']['source'] ?? '';
                $arq = $pg['pageimage'] ?? '';
            }
        }
        if (!$src || strpos($src, 'https://upload.wikimedia.org/') !== 0) {
            $esc[$id] = array('tentou' => time());
            continue;
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $tmp = download_url($src, 20);
        if (is_wp_error($tmp)) {
            $esc[$id] = array('tentou' => time());
            continue;
        }
        $ext = preg_match('~\.(png|jpe?g|webp|gif)$~i', $src, $m) ? strtolower($m[1]) : 'png';
        $nome = sanitize_file_name(($t['chave'] ?: $id) . '.' . $ext);
        @copy($tmp, "$dir/$nome");
        @unlink($tmp);
        if (file_exists("$dir/$nome") && @getimagesize("$dir/$nome")) {
            $esc[$id] = array('url' => trailingslashit($up['baseurl']) . 'tsp-escudos/' . $nome, 'arquivo' => $arq);
        } else {
            $esc[$id] = array('tentou' => time());
        }
    }
    update_option('tsp_jogos_escudos', $esc, false);
    return $feitos;
}

function tsp_jogos_escudo_url($api_id)
{
    $e = tsp_jogos_escudos()[(int) $api_id] ?? array();
    return $e['url'] ?? '';
}
