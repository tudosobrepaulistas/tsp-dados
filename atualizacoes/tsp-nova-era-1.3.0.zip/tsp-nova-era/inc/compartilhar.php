<?php
/**
 * Imagem de compartilhamento (WhatsApp, Facebook, X): JPG leve de 1200x630.
 * - Matéria: a foto de destaque recortada em 1200x630 (as fotos originais em PNG passam de 400 KB e o
 *   WhatsApp não mostra a prévia de imagem pesada).
 * - Página de clube: arte com a cor do clube, o escudo e o nome. Página de campeonato e home: arte do TSP.
 * Os arquivos ficam em uploads/tsp-og/ e só são gerados uma vez.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_og_pasta()
{
    $u = wp_upload_dir();
    $dir = trailingslashit($u['basedir']) . 'tsp-og';
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
    }
    return array($dir, trailingslashit($u['baseurl']) . 'tsp-og');
}

// Foto de destaque → JPG 1200x630
function tsp_og_da_foto($anexo_id)
{
    $anexo_id = (int) $anexo_id;
    $orig = $anexo_id ? get_attached_file($anexo_id) : '';
    if (!$orig || !file_exists($orig)) {
        return '';
    }
    list($dir, $url) = tsp_og_pasta();
    $nome = 'm-' . $anexo_id . '-' . substr(md5((string) filemtime($orig)), 0, 6) . '.jpg';
    if (!file_exists("$dir/$nome")) {
        $ed = wp_get_image_editor($orig);
        if (is_wp_error($ed)) {
            return '';
        }
        $ed->resize(1200, 630, true);
        $ed->set_quality(82);
        $r = $ed->save("$dir/$nome", 'image/jpeg');
        if (is_wp_error($r)) {
            return '';
        }
    }
    return "$url/$nome";
}

// Arte do clube (ou do TSP): fundo na cor, escudo e nome
function tsp_og_arte($chave, $titulo, $sub, $fundo, $texto, $escudo_arquivo = '')
{
    if (!function_exists('imagecreatetruecolor') || !function_exists('imagettftext')) {
        return '';
    }
    list($dir, $url) = tsp_og_pasta();
    $nome = 'a-' . sanitize_file_name($chave) . '-' . substr(md5($titulo . $sub . $fundo . $texto . $escudo_arquivo . TSP_VERSAO), 0, 6) . '.jpg';
    if (file_exists("$dir/$nome")) {
        return "$url/$nome";
    }
    $fonte = get_template_directory() . '/assets/fonts/BarlowCondensed-ExtraBold.ttf';
    $im = imagecreatetruecolor(1200, 630);
    $cor = function ($hex) use ($im) {
        $h = ltrim($hex, '#');
        return imagecolorallocate($im, hexdec(substr($h, 0, 2)), hexdec(substr($h, 2, 2)), hexdec(substr($h, 4, 2)));
    };
    imagefilledrectangle($im, 0, 0, 1200, 630, $cor($fundo));
    imagefilledrectangle($im, 0, 612, 1200, 630, $cor('#E8862A'));
    $tx = $cor($texto);
    // Logo do TSP no canto
    $logo = get_template_directory() . '/assets/img/logo-136.webp';
    if (function_exists('imagecreatefromwebp') && file_exists($logo)) {
        $l = @imagecreatefromwebp($logo);
        if ($l) {
            imagecopyresampled($im, $l, 60, 50, 0, 0, 157, 96, imagesx($l), imagesy($l));
            imagedestroy($l);
        }
    }
    // Escudo à direita
    $x_texto = 60;
    $info = ($escudo_arquivo && file_exists($escudo_arquivo) && filesize($escudo_arquivo) < 1500000) ? @getimagesize($escudo_arquivo) : false;
    if ($info && $info[0] * $info[1] <= 1600 * 1600 && in_array($info[2], array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF, IMAGETYPE_WEBP), true)) {
        $e = @imagecreatefromstring(file_get_contents($escudo_arquivo));
        if ($e) {
            $w = imagesx($e);
            $h = imagesy($e);
            $lado = 330;
            $esc = min($lado / $w, $lado / $h);
            imagecopyresampled($im, $e, (int) (1200 - 90 - $w * $esc), (int) ((630 - $h * $esc) / 2), 0, 0, (int) ($w * $esc), (int) ($h * $esc), $w, $h);
            imagedestroy($e);
        }
    }
    // Nome (quebra em até 2 linhas) e subtítulo
    $tam = mb_strlen($titulo) > 18 ? 78 : 96;
    $linhas = explode("\n", wordwrap(mb_strtoupper($titulo), mb_strlen($titulo) > 18 ? 18 : 24, "\n", true));
    $y = 360 - (count($linhas) - 1) * 46;
    imagettftext($im, 28, 0, $x_texto, $y - $tam - 34, $tx, $fonte, mb_strtoupper($sub));
    foreach (array_slice($linhas, 0, 2) as $i => $ln) {
        imagettftext($im, $tam, 0, $x_texto, $y + $i * ($tam + 12), $tx, $fonte, $ln);
    }
    imagettftext($im, 26, 0, $x_texto, 560, $tx, $fonte, 'TUDOSOBREPAULISTA.COM.BR');
    imagejpeg($im, "$dir/$nome", 86);
    imagedestroy($im);
    return "$url/$nome";
}

function tsp_og_imagem_da_pagina()
{
    if (is_singular() && has_post_thumbnail()) {
        return tsp_og_da_foto(get_post_thumbnail_id());
    }
    if (is_tax('times')) {
        $t = get_queried_object();
        list($fundo, $texto) = tsp_clube_cores($t);
        $esc = '';
        $png = get_term_meta($t->term_id, 'tsp_escudo_png', true);
        if ($png) {
            $u = wp_upload_dir();
            $esc = str_replace(trailingslashit($u['baseurl']), trailingslashit($u['basedir']), $png);
        }
        if (!$esc || !file_exists($esc)) {
            $id = (int) get_term_meta($t->term_id, 'imagem', true);
            $esc = $id ? (string) get_attached_file($id) : '';
        }
        return tsp_og_arte('t-' . $t->slug, $t->name, 'Notícias ' . substr(tsp_de($t), 0, 3), $fundo, $texto, $esc);
    }
    if (is_tax('campeonato')) {
        $t = get_queried_object();
        $g = function_exists('tsp_campeonato_guia') ? tsp_campeonato_guia($t->slug) : null;
        return tsp_og_arte('c-' . $t->slug, $g ? $g['nome'] . ' ' . $g['temporada'] : $t->name, 'Tabela, jogos e notícias', '#0B0B0B', '#FFFFFF');
    }
    if (is_front_page()) {
        return tsp_og_arte('home', 'Futebol paulista', 'Todos os times de São Paulo', '#0B0B0B', '#FFFFFF');
    }
    return '';
}

// Yoast: troca a imagem de compartilhamento pela versão leve
add_filter('wpseo_frontend_presentation', function ($p) {
    try {
        $img = tsp_og_imagem_da_pagina();
    } catch (\Throwable $e) {
        $img = '';
    }
    if ($img) {
        $p->open_graph_images = array($img => array('url' => $img, 'width' => 1200, 'height' => 630, 'type' => 'image/jpeg'));
        $p->twitter_image = $img;
    }
    return $p;
}, 20);
