<?php
/**
 * Campos da matéria que a redação já usa no editor (grupo ACF "Adicional matéria"): Subtítulo e Crédito da imagem.
 * O tema acha os campos pelo rótulo, sem depender do nome interno que a agência deu.
 * Também: perguntas frequentes (tsp_faq) no fim da matéria, com marcação para Google e IAs.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_acf_por_rotulo($post_id, $rotulos)
{
    if (!function_exists('acf_get_field_groups') || !function_exists('acf_get_fields')) {
        return '';
    }
    static $mapa = null;
    if ($mapa === null) {
        $mapa = array();
        foreach (acf_get_field_groups() as $g) {
            foreach ((array) acf_get_fields($g) as $f) {
                $mapa[sanitize_title(remove_accents($f['label']))] = $f['name'];
            }
        }
    }
    foreach ((array) $rotulos as $r) {
        $k = sanitize_title(remove_accents($r));
        if (!empty($mapa[$k])) {
            $v = get_post_meta($post_id, $mapa[$k], true);
            if (is_string($v) && trim($v) !== '') {
                return trim($v);
            }
        }
    }
    return '';
}

function tsp_subtitulo($post_id)
{
    $s = tsp_acf_por_rotulo($post_id, array('Subtitulo', 'Subtítulo', 'Linha fina'));
    if ($s === '' && has_excerpt($post_id)) {
        $s = get_the_excerpt($post_id);
    }
    return $s;
}

// Crédito da foto: campo "Crédito da imagem" da matéria; se vazio, a legenda da própria foto
function tsp_credito_foto($post_id)
{
    $c = tsp_acf_por_rotulo($post_id, array('Crédito da imagem', 'Credito da imagem', 'Crédito', 'Credito da foto', 'Crédito da foto'));
    if ($c === '') {
        $c = trim((string) wp_get_attachment_caption(get_post_thumbnail_id($post_id)));
    }
    return $c;
}

// Perguntas frequentes: [["pergunta","resposta"], ...] (preenchidas pelo Editor SEO do TSP)
function tsp_faq_da_materia($post_id)
{
    $f = json_decode((string) get_post_meta($post_id, 'tsp_faq', true), true);
    $ok = array();
    foreach ((array) $f as $x) {
        if (is_array($x) && !empty($x[0]) && !empty($x[1])) {
            $ok[] = array(wp_strip_all_tags($x[0]), wp_strip_all_tags($x[1]));
        }
    }
    return array_slice($ok, 0, 6);
}

add_action('wp_head', function () {
    if (!is_singular(tsp_tipos())) {
        return;
    }
    $faq = tsp_faq_da_materia(get_queried_object_id());
    if (!$faq) {
        return;
    }
    $itens = array();
    foreach ($faq as $f) {
        $itens[] = array('@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $f[1]));
    }
    echo '<script type="application/ld+json">' . wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $itens), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}, 31);
