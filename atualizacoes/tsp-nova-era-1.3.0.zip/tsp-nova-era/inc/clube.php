<?php
/**
 * Página do clube (/times/slug/): tarja, destaques, jogos, classificação, elenco, vídeos e notícias.
 * Dados por clube ficam em Ferramentas → TSP · Dados do tema, na chave "clubes":
 *   "clubes": { "mirassol": {
 *       "youtube": "UC...",                                  (ID do canal oficial no YouTube)
 *       "ultimos":  [["20/10", "Mirassol", "2 x 0", "Internacional", "Brasileirão"]],
 *       "proximos": [["Sáb 24/10 16h30", "Mirassol", "São Paulo", "Brasileirão"]],
 *       "elenco":   [["1", "Walter", "Goleiro"], ["10", "Reinaldo", "Lateral"]]
 *   } }
 * Quando não há dado, o bloco simplesmente não aparece.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Nome do clube como aparece nas tabelas
function tsp_clube_nome_tabela($termo)
{
    $alias = array('bragantino' => 'Red Bull Bragantino', 'botafogosp' => 'Botafogo-SP', 'saopaulo' => 'São Paulo', 'pontepreta' => 'Ponte Preta', 'saobernardo' => 'São Bernardo');
    return $alias[$termo->slug] ?? $termo->name;
}

function tsp_clube_serie($slug)
{
    if (in_array($slug, array_merge(tsp_grupo_slugs('a4'), tsp_grupo_slugs('mb')), true)) {
        return 'serie_a';
    }
    if (in_array($slug, tsp_grupo_slugs('sb'), true)) {
        return 'serie_b';
    }
    foreach (array('d1', 'd2', 'd3', 'd4') as $k) {
        $d = tsp_grupos()[$k]['divisao'];
        if (isset($d[$slug])) {
            return 'paulistao_' . strtolower($d[$slug]);
        }
    }
    return '';
}

function tsp_clube_dados($slug)
{
    $c = tsp_dado('clubes');
    return isset($c[$slug]) && is_array($c[$slug]) ? $c[$slug] : array();
}

// 2 últimos e 2 próximos jogos: dados do clube; se não houver, procura nas rodadas da série
function tsp_clube_jogos($termo)
{
    $d = tsp_clube_dados($termo->slug);
    $ult = !empty($d['ultimos']) ? $d['ultimos'] : array();
    $prx = !empty($d['proximos']) ? $d['proximos'] : array();
    $serie = tsp_clube_serie($termo->slug);
    $nome = tsp_clube_nome_tabela($termo);
    $jogos = tsp_dado('jogos');
    if (!$ult && !empty($jogos[$serie]['resultados']['lista'])) {
        foreach ($jogos[$serie]['resultados']['lista'] as $g) {
            if (in_array($nome, array($g[1] ?? '', $g[3] ?? ''), true)) {
                $ult[] = array($g[0], $g[1], $g[2], $g[3], $serie === 'serie_b' ? 'Brasileirão Série B' : 'Brasileirão Série A');
            }
        }
    }
    if (!$prx && !empty($jogos[$serie]['proximos']['lista'])) {
        foreach ($jogos[$serie]['proximos']['lista'] as $g) {
            if (in_array($nome, array($g[1] ?? '', $g[2] ?? ''), true)) {
                $prx[] = array($g[0], $g[1], $g[2], $serie === 'serie_b' ? 'Brasileirão Série B' : 'Brasileirão Série A');
            }
        }
    }
    return array('ultimos' => array_slice($ult, 0, 2), 'proximos' => array_slice($prx, 0, 2));
}

// Últimos vídeos: canal oficial do clube no YouTube (feed público, guardado por 3 horas);
// sem canal cadastrado, usa as matérias do clube que têm vídeo/coletiva.
function tsp_clube_videos($termo, $n = 4)
{
    $d = tsp_clube_dados($termo->slug);
    $canal = isset($d['youtube']) ? preg_replace('~[^A-Za-z0-9_-]~', '', (string) $d['youtube']) : '';
    if ($canal) {
        $chave = 'tsp_yt_' . md5($canal);
        $lista = get_transient($chave);
        if ($lista === false) {
            $lista = array();
            $r = wp_remote_get('https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode($canal), array('timeout' => 5));
            if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200 && function_exists('simplexml_load_string')) {
                $xml = @simplexml_load_string(wp_remote_retrieve_body($r));
                if ($xml) {
                    foreach ($xml->entry as $e) {
                        $yt = $e->children('http://www.youtube.com/xml/schemas/2015');
                        $id = preg_replace('~[^A-Za-z0-9_-]~', '', (string) $yt->videoId);
                        if ($id) {
                            $lista[] = array('tipo' => 'yt', 'id' => $id, 'titulo' => sanitize_text_field((string) $e->title));
                        }
                        if (count($lista) >= 8) {
                            break;
                        }
                    }
                }
            }
            set_transient($chave, $lista, $lista ? 3 * HOUR_IN_SECONDS : 30 * MINUTE_IN_SECONDS);
        }
        if ($lista) {
            return array_slice($lista, 0, $n);
        }
    }
    $vistos = array();
    return array_map(function ($id) {
        return array('tipo' => 'post', 'id' => $id);
    }, tsp_ids_videos(array($termo->slug), $n, $vistos));
}

function tsp_clube_video_html($v)
{
    if ($v['tipo'] === 'yt') {
        $thumb = 'https://i.ytimg.com/vi/' . $v['id'] . '/hqdefault.jpg';
        return '<div class="tsp-video tsp-video--cartao"><button type="button" class="tsp-video__foto tsp-yt" data-video="' . esc_attr($v['id']) . '" aria-label="' . esc_attr('Assistir: ' . $v['titulo']) . '"><img class="tsp-img" src="' . esc_url($thumb) . '" alt="" loading="lazy" decoding="async"><span class="tsp-play" aria-hidden="true"></span></button><span class="tsp-card__titulo">' . esc_html($v['titulo']) . '</span></div>';
    }
    ob_start();
    echo '<div class="tsp-video tsp-video--cartao">';
    echo '<a class="tsp-video__foto" href="' . esc_url(get_permalink($v['id'])) . '">' . tsp_img($v['id'], 'home-370x270') . '<span class="tsp-play" aria-hidden="true"></span></a>';
    echo '<a class="tsp-card__titulo" href="' . esc_url(get_permalink($v['id'])) . '">' . esc_html(get_the_title($v['id'])) . '</a></div>';
    return ob_get_clean();
}

function tsp_clube_whatsapp($termo)
{
    $l = get_term_meta($termo->term_id, 'link_grupo_whatsapp_time', true);
    if ($l) {
        return $l;
    }
    $serie = tsp_clube_serie($termo->slug);
    $w = tsp_dado('whatsapp');
    if ($serie && !empty($w[$serie])) {
        return $w[$serie];
    }
    return tsp_whatsapp_link();
}

// Cores da tarja: definidas a partir do uniforme e do escudo de cada clube.
// Clubes fora da lista: a cor é tirada automaticamente do escudo (e guardada).
function tsp_clube_cores_fixas()
{
    return array(
        'corinthians' => array('#000000', '#FFFFFF'), 'palmeiras' => array('#006437', '#FFFFFF'),
        'santos' => array('#000000', '#FFFFFF'), 'saopaulo' => array('#D7182A', '#FFFFFF'),
        'mirassol' => array('#FFD200', '#00692F'), 'bragantino' => array('#E10600', '#FFFFFF'),
        'botafogosp' => array('#C8102E', '#FFFFFF'), 'pontepreta' => array('#000000', '#FFFFFF'),
        'saobernardo' => array('#FFD100', '#111111'), 'novorizontino' => array('#FFD100', '#111111'),
        'guarani' => array('#00843D', '#FFFFFF'), 'portuguesa' => array('#D2232A', '#FFFFFF'),
        'noroeste' => array('#C8102E', '#FFFFFF'), 'ituano' => array('#C8102E', '#FFFFFF'),
        'ferroviaria' => array('#7A1F2B', '#FFFFFF'), 'xvdepiracicaba' => array('#000000', '#FFFFFF'),
        'interdelimeira' => array('#000000', '#FFFFFF'), 'saojose' => array('#0033A0', '#FFFFFF'),
        'saobento' => array('#0047AB', '#FFFFFF'), 'santoandre' => array('#0055A4', '#FFFFFF'),
        'juventus' => array('#7B1E3A', '#FFFFFF'), 'marilia' => array('#003DA5', '#FFFFFF'),
        'comercial' => array('#000000', '#FFFFFF'), 'rio-branco' => array('#000000', '#FFFFFF'),
        'uniao-sao-joao' => array('#00843D', '#FFFFFF'), 'taubate' => array('#0033A0', '#FFFFFF'),
        'linense' => array('#C8102E', '#FFFFFF'), 'paulista-jundiai' => array('#C8102E', '#FFFFFF'),
        'xv-de-jau' => array('#00843D', '#FFFFFF'), 'rioclaro' => array('#003DA5', '#FFFFFF'),
        'saocaetano' => array('#0033A0', '#FFFFFF'), 'capivariano' => array('#C8102E', '#FFFFFF'),
        'monteazul' => array('#0055A4', '#FFFFFF'), 'votuporanguense' => array('#000000', '#FFFFFF'),
        'ec-sao-bernardo' => array('#000000', '#FFFFFF'), 'francana' => array('#00843D', '#FFFFFF'),
        'rio-preto' => array('#00843D', '#FFFFFF'), 'uniao-barbarense' => array('#000000', '#FFFFFF'),
        'america-de-rio-preto' => array('#C8102E', '#FFFFFF'),
    );
}

// Times femininos e de base usam as cores do clube principal (ex.: corinthians-feminino → corinthians)
function tsp_clube_slug_pai($slug)
{
    $base = preg_replace('~-(feminino|sub-\d+)$~', '', $slug);
    $mapa = array('sao-paulo' => 'saopaulo', 'red-bull-bragantino' => 'bragantino', 'ponte-preta' => 'pontepreta', 'botafogo-sp' => 'botafogosp',
        'inter-de-limeira' => 'interdelimeira', 'xv-de-piracicaba' => 'xvdepiracicaba', 'agua-santa' => 'aguasanta', 'sao-jose' => 'saojose',
        'sao-bento' => 'saobento', 'santo-andre' => 'santoandre', 'portuguesa-santista' => 'portuguesasantista', 'sao-bernardo' => 'saobernardo', 'gremio-prudente' => 'prudente');
    return $mapa[$base] ?? $base;
}

function tsp_cor_texto($hex)
{
    $h = ltrim($hex, '#');
    $r = hexdec(substr($h, 0, 2)) / 255;
    $g = hexdec(substr($h, 2, 2)) / 255;
    $b = hexdec(substr($h, 4, 2)) / 255;
    return (0.299 * $r + 0.587 * $g + 0.114 * $b) > 0.6 ? '#111111' : '#FFFFFF';
}

// Cor predominante do escudo (ignora branco, preto, cinza e transparente)
function tsp_cor_do_escudo($anexo_id)
{
    if (!function_exists('imagecreatefromstring')) {
        return '';
    }
    $arq = get_attached_file($anexo_id);
    if (!$arq || !file_exists($arq) || filesize($arq) > 3 * MB_IN_BYTES) {
        return '';
    }
    $img = @imagecreatefromstring(file_get_contents($arq));
    if (!$img) {
        return '';
    }
    $p = imagecreatetruecolor(40, 40);
    imagealphablending($p, false);
    imagesavealpha($p, true);
    imagecopyresampled($p, $img, 0, 0, 0, 0, 40, 40, imagesx($img), imagesy($img));
    $baldes = array();
    $opacos = 0;
    $escuros = 0;
    for ($x = 0; $x < 40; $x++) {
        for ($y = 0; $y < 40; $y++) {
            $c = imagecolorat($p, $x, $y);
            if ((($c >> 24) & 0x7F) > 60) {
                continue;
            }
            $opacos++;
            $r = ($c >> 16) & 0xFF;
            $g = ($c >> 8) & 0xFF;
            $b = $c & 0xFF;
            $max = max($r, $g, $b);
            $min = min($r, $g, $b);
            if ($max < 50) {
                $escuros++;
                continue;
            }
            if ($max - $min < 45 || ($max > 235 && $min > 200)) {
                continue;
            }
            $hue = 0;
            $d = $max - $min;
            if ($max === $r) {
                $hue = fmod((($g - $b) / $d), 6);
            } elseif ($max === $g) {
                $hue = (($b - $r) / $d) + 2;
            } else {
                $hue = (($r - $g) / $d) + 4;
            }
            $k = (int) floor(fmod(($hue * 60) + 360, 360) / 30);
            if (!isset($baldes[$k])) {
                $baldes[$k] = array(0, 0, 0, 0);
            }
            $baldes[$k][0]++;
            $baldes[$k][1] += $r;
            $baldes[$k][2] += $g;
            $baldes[$k][3] += $b;
        }
    }
    imagedestroy($p);
    imagedestroy($img);
    if (!$opacos) {
        return '';
    }
    uasort($baldes, function ($a, $b) {
        return $b[0] - $a[0];
    });
    $top = reset($baldes);
    if (!$top || $top[0] < $opacos * 0.12) {
        return $escuros > $opacos * 0.15 ? '#000000' : '';
    }
    return sprintf('#%02X%02X%02X', (int) ($top[1] / $top[0]), (int) ($top[2] / $top[0]), (int) ($top[3] / $top[0]));
}

function tsp_clube_cores($termo)
{
    $fixas = tsp_clube_cores_fixas();
    if (isset($fixas[$termo->slug])) {
        return $fixas[$termo->slug];
    }
    $pai = tsp_clube_slug_pai($termo->slug);
    if (isset($fixas[$pai])) {
        return $fixas[$pai];
    }
    // Cor cadastrada no próprio time (campo "Cor do time") vale mais que a tirada do escudo
    $manual = sanitize_hex_color((string) get_term_meta($termo->term_id, 'cor_do_time', true));
    if ($manual) {
        $txt = sanitize_hex_color((string) get_term_meta($termo->term_id, 'cor_do_time_texto', true));
        return array($manual, $txt ? $txt : tsp_cor_texto($manual));
    }
    $anexo = (int) get_term_meta($termo->term_id, 'imagem', true);
    $cache = get_term_meta($termo->term_id, 'tsp_cor_auto', true);
    if (is_array($cache) && isset($cache['anexo']) && (int) $cache['anexo'] === $anexo && !empty($cache['cor'])) {
        return array($cache['cor'], tsp_cor_texto($cache['cor']));
    }
    $cor = $anexo ? tsp_cor_do_escudo($anexo) : '';
    if (!$cor) {
        $manual = sanitize_hex_color((string) get_term_meta($termo->term_id, 'cor_do_time', true));
        $cor = $manual ? $manual : '#0B0B0B';
    }
    if ($anexo) {
        update_term_meta($termo->term_id, 'tsp_cor_auto', array('anexo' => $anexo, 'cor' => $cor));
    }
    return array($cor, tsp_cor_texto($cor));
}

function tsp_clube_tarja($termo)
{
    list($fundo, $texto) = tsp_clube_cores($termo);
    echo '<div class="tsp-tarja' . ($texto !== '#FFFFFF' ? ' tsp-tarja--clara' : '') . '" style="background:' . esc_attr($fundo) . ';color:' . esc_attr($texto) . '"><div class="tsp-container tsp-tarja__in">';
    echo '<a class="tsp-tarja__tsp" href="' . esc_url(home_url('/')) . '"><img src="' . esc_url(get_template_directory_uri() . '/assets/img/logo-tsp.webp?v=' . TSP_VERSAO) . '" alt="Tudo Sobre Paulista" width="65" height="40"></a>';
    echo '<h1 class="tsp-tarja__nome"><small>Notícias ' . esc_html(substr(tsp_de($termo), 0, 3)) . '</small>' . esc_html($termo->name) . '</h1>';
    echo '<span class="tsp-tarja__escudo">' . tsp_escudo($termo, 56) . '</span>';
    echo '</div></div>';
}

function tsp_clube_jogo_li($g, $tipo, $nome)
{
    $nomes = (array) $nome;
    $forte = function ($t) use ($nomes) {
        return in_array($t, $nomes, true) ? ' tsp-forte' : '';
    };
    if ($tipo === 'ultimos') {
        $link = $g[5] ?? '';
        $miolo = '<span class="tsp-jogos__dia">' . esc_html($g[0] ?? '') . '</span><span class="tsp-jogos__casa' . $forte($g[1] ?? '') . '">' . esc_html($g[1] ?? '') . '</span><span class="tsp-jogos__placar">' . esc_html($g[2] ?? '') . '</span><span class="tsp-jogos__fora' . $forte($g[3] ?? '') . '">' . esc_html($g[3] ?? '') . '</span>';
        $rot = 'Ficha técnica →';
    } else {
        $link = $g[4] ?? '';
        $miolo = '<span class="tsp-jogos__dia">' . esc_html($g[0] ?? '') . '</span><span class="tsp-jogos__casa' . $forte($g[1] ?? '') . '">' . esc_html($g[1] ?? '') . '</span><span class="tsp-jogos__placar">x</span><span class="tsp-jogos__fora' . $forte($g[2] ?? '') . '">' . esc_html($g[2] ?? '') . '</span>';
        $rot = 'Pré-jogo, escalações e onde assistir →';
    }
    $comp = $tipo === 'ultimos' ? ($g[4] ?? '') : ($g[3] ?? '');
    $extra = ($comp ? '<span class="tsp-jogos__comp">' . esc_html($comp) . '</span>' : '') . ($link ? '<a class="tsp-jogos__link" href="' . esc_url($link) . '">' . esc_html($rot) . '</a>' : '');
    return '<li class="tsp-jogos__item">' . $miolo . ($extra ? '<span class="tsp-jogos__extra">' . $extra . '</span>' : '') . '</li>';
}

// Painel: [últimos jogos | próximos jogos | elenco] e, embaixo, a classificação em duas metades (1º–10º e 11º–20º)
function tsp_clube_painel($termo)
{
    $nome = array_unique(array(tsp_clube_nome_tabela($termo), $termo->name));
    $j = tsp_clube_jogos($termo);
    $serie = tsp_clube_serie($termo->slug);
    $tabs = tsp_dado('tabelas');
    $linhas = ($serie && !empty($tabs[$serie]['linhas'])) ? count($tabs[$serie]['linhas']) : 0;
    $d = tsp_clube_dados($termo->slug);
    $elenco = !empty($d['elenco']) ? $d['elenco'] : array();
    $sofa = (!$linhas && $serie) ? tsp_sofa_html($serie, 'Classificação') : '';
    if (!$j['ultimos'] && !$j['proximos'] && !$linhas && !$elenco && !$sofa && !tsp_clube_competicoes($termo)) {
        return;
    }
    echo '<section class="tsp-painel" aria-label="' . esc_attr('Jogos e classificação ' . tsp_de($termo)) . '">';
    $cols = array();
    if ($j['ultimos']) {
        $h = '<div class="tsp-jogos"><h2 class="tsp-caixa__tit">Últimos jogos</h2><ul>';
        foreach ($j['ultimos'] as $g) {
            $h .= tsp_clube_jogo_li($g, 'ultimos', $nome);
        }
        $cols[] = $h . '</ul></div>';
    }
    if ($j['proximos']) {
        $h = '<div class="tsp-jogos tsp-jogos--escuro"><h2 class="tsp-caixa__tit">Próximos jogos</h2><ul>';
        foreach ($j['proximos'] as $g) {
            $h .= tsp_clube_jogo_li($g, 'proximos', $nome);
        }
        $cols[] = $h . '</ul></div>';
    }
    if ($elenco) {
        $h = '<div class="tsp-caixa tsp-painel__elenco"><h2 class="tsp-caixa__tit">Elenco</h2><ul class="tsp-elenco">';
        foreach ($elenco as $p) {
            $h .= '<li><span class="tsp-elenco__num">' . esc_html($p[0] ?? '') . '</span><strong>' . esc_html($p[1] ?? '') . '</strong><span>' . esc_html($p[2] ?? '') . '</span></li>';
        }
        $cols[] = $h . '</ul></div>';
    }
    $comps = tsp_clube_competicoes($termo);
    if ($comps) {
        echo '<div class="tsp-painel__comps"><span>Competições em ' . esc_html(wp_date('Y')) . ':</span>' . implode('', array_map(function ($c) {
            return '<strong>' . esc_html($c) . '</strong>';
        }, $comps)) . '</div>';
    }
    if ($cols) {
        echo '<div class="tsp-painel__linha tsp-painel__linha--' . count($cols) . '">' . implode('', $cols) . '</div>';
    }
    if ($linhas) {
        $metade = (int) ceil($linhas / 2);
        echo '<div class="tsp-caixa tsp-painel__tabela"><h2 class="tsp-caixa__tit">' . esc_html($tabs[$serie]['titulo'] ?? 'Classificação') . '</h2>';
        echo '<div class="tsp-painel__metades">' . tsp_tabela_html($serie, $metade, $nome, 0, false) . tsp_tabela_html($serie, $linhas - $metade, $nome, $metade, false) . '</div>';
        echo tsp_legenda($serie) . '</div>';
    } elseif ($sofa) {
        echo '<div class="tsp-caixa tsp-painel__tabela"><h2 class="tsp-caixa__tit">Classificação</h2>' . $sofa . '</div>';
    }
    echo '</section>';
}

// Competições do clube na temporada: as da Base TSP (jogos cadastrados) + as do guia do clube
function tsp_clube_competicoes($termo)
{
    static $cache = array();
    if (isset($cache[$termo->slug])) {
        return $cache[$termo->slug];
    }
    $lista = array();
    if (function_exists('tsp_jogos_api_do_slug') && function_exists('tsp_jogos_buscar')) {
        $v = tsp_jogos_vinculos();
        $ids = array_keys(array_filter($v, function ($s) use ($termo) {
            return $s === $termo->slug;
        }));
        foreach ($ids as $id) {
            foreach (tsp_jogos_buscar('(casa_id = %d OR fora_id = %d) AND inicio > %d', array($id, $id, strtotime(wp_date('Y') . '-01-01')), 'inicio DESC', 200) as $j) {
                $lista[$j->liga] = tsp_jogos_nome_liga($j->liga);
            }
        }
    }
    $g = function_exists('tsp_guia') ? tsp_guia($termo) : array();
    foreach ((array) ($g['campeonatos_' . wp_date('Y')] ?? array()) as $c) {
        if (!in_array($c, $lista, true)) {
            $lista[] = $c;
        }
    }
    return $cache[$termo->slug] = array_values($lista);
}
