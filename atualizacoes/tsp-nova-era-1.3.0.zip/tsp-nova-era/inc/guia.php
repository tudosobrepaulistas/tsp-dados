<?php
/**
 * Guia do clube (fim da página de notícias do clube): responde o que o torcedor procura no Google.
 * Pesquisa de palavras-chave do Palmeiras (out/2025–set/2026): "notícias do X" e "onde assistir X hoje"
 * lideram (500 mil buscas/mês cada), seguidas de "onde vai passar o jogo", "próximo jogo", "X x Y onde assistir"
 * e "X contrata". O guia cobre essas perguntas para cada um dos 64 clubes.
 *
 * Dados em Ferramentas → TSP · Dados do tema → "clubes" → slug → "guia":
 * { "cidade": "São Paulo", "estadio": "Allianz Parque", "capacidade": "43.713", "fundacao": "26/08/1914",
 *   "apelidos": "Verdão, Alviverde", "mascote": "Porco", "cores": "Verde e branco",
 *   "rival": "Corinthians", "classico": "Dérbi Paulista", "tecnico": "...", "presidente": "...",
 *   "titulos": [["Campeonato Brasileiro", "12"], ["Libertadores", "3"]],
 *   "campeonatos_2026": ["Brasileirão Série A", "Libertadores", "Copa do Brasil"],
 *   "campeonatos_2027": ["Paulistão A1", "Brasileirão Série A"],
 *   "transmissao": "Os jogos do Brasileirão passam na Globo, no Premiere e na CazéTV, conforme a rodada.",
 *   "ingressos": "Venda pelo site oficial do clube e pelo programa de sócio-torcedor.", "ingressos_link": "https://...",
 *   "site": "https://...", "instagram": "https://...", "youtube": "https://..." }
 * Campo vazio = pergunta não aparece. Nada é inventado: só entra o que foi conferido.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_guia($termo)
{
    $d = tsp_clube_dados($termo->slug);
    return isset($d['guia']) && is_array($d['guia']) ? $d['guia'] : array();
}

// Perguntas e respostas montadas a partir dos dados (texto puro, sem HTML)
function tsp_guia_perguntas($termo)
{
    $g = tsp_guia($termo);
    $nome = $termo->name;
    $de = tsp_de($termo);
    $o = tsp_o($termo);
    $j = tsp_clube_jogos($termo);
    $faq = array();

    if ($j['proximos']) {
        $p = $j['proximos'][0];
        $comp = $p[3] ?? '';
        $faq[] = array('Qual é o próximo jogo ' . $de . '?', 'O próximo jogo ' . $de . ' é ' . ($p[1] ?? '') . ' x ' . ($p[2] ?? '') . ', ' . ($p[0] ?? '') . ($comp ? ', pelo ' . $comp : '') . '.');
    }
    if (!empty($g['transmissao'])) {
        $faq[] = array('Onde assistir ao jogo ' . $de . ' hoje?', $g['transmissao'] . ' O TSP publica, antes de cada partida, a matéria "Onde assistir" com o canal confirmado.');
    }
    if (!empty($g['ingressos'])) {
        $faq[] = array('Onde comprar ingresso para o jogo ' . $de . '?', $g['ingressos']);
    }
    if (!empty($g['campeonatos_2026'])) {
        $faq[] = array('Quais campeonatos ' . $o . ' disputa em 2026?', implode(', ', (array) $g['campeonatos_2026']) . '.');
    }
    if (!empty($g['campeonatos_2027'])) {
        $faq[] = array('Quais campeonatos ' . $o . ' vai disputar em 2027?', implode(', ', (array) $g['campeonatos_2027']) . '.');
    }
    if (!empty($g['titulos'])) {
        $l = array();
        foreach ((array) $g['titulos'] as $t) {
            $l[] = ($t[0] ?? '') . ' (' . ($t[1] ?? '') . ')';
        }
        $faq[] = array('Quantos títulos tem ' . $o . '?', 'Principais conquistas: ' . implode('; ', $l) . '.');
    }
    if (!empty($g['rival'])) {
        $faq[] = array('Quem é o maior rival ' . $de . '?', 'O maior rival é o ' . $g['rival'] . (!empty($g['classico']) ? ', no clássico conhecido como ' . $g['classico'] : '') . '.');
    }
    if (!empty($g['estadio'])) {
        $faq[] = array('Qual é o estádio ' . $de . '?', ucfirst($o) . ' manda seus jogos no ' . $g['estadio'] . (!empty($g['cidade']) ? ', em ' . $g['cidade'] : '') . (!empty($g['capacidade']) ? ', com capacidade para ' . $g['capacidade'] . ' torcedores' : '') . '.');
    }
    if (!empty($g['tecnico'])) {
        $faq[] = array('Quem é o técnico ' . $de . '?', 'O técnico é ' . $g['tecnico'] . '.');
    }
    return $faq;
}

function tsp_guia_html($termo)
{
    $g = tsp_guia($termo);
    $faq = tsp_guia_perguntas($termo);
    $nome = $termo->name;
    $de = tsp_de($termo);
    $ficha = array(
        'Cidade' => $g['cidade'] ?? '', 'Estádio' => $g['estadio'] ?? '', 'Fundação' => $g['fundacao'] ?? '',
        'Apelidos' => $g['apelidos'] ?? '', 'Mascote' => $g['mascote'] ?? '', 'Cores' => $g['cores'] ?? '',
        'Maior rival' => $g['rival'] ?? '', 'Técnico' => $g['tecnico'] ?? '', 'Presidente' => $g['presidente'] ?? '',
        'Divisão no Paulistão 2027' => tsp_divisao_paulistao($termo->slug),
    );
    $ficha = array_filter($ficha);
    $desc = term_description($termo);
    if (!$faq && count($ficha) <= 1 && !$desc) {
        return;
    }
    echo '<section class="tsp-guia" aria-labelledby="tsp-guia-tit">';
    echo '<h2 id="tsp-guia-tit">Guia ' . esc_html($de) . ': jogos, onde assistir e história</h2>';
    echo '<p class="tsp-guia__intro">Aqui você encontra as últimas notícias ' . esc_html($de) . ' hoje, o próximo jogo, onde assistir, a classificação e a ficha completa do clube, atualizadas pela redação do Tudo Sobre Paulista.</p>';
    if ($ficha) {
        echo '<dl class="tsp-ficha">';
        foreach ($ficha as $k => $v) {
            echo '<div><dt>' . esc_html($k) . '</dt><dd>' . esc_html($v) . '</dd></div>';
        }
        echo '</dl>';
    }
    if ($faq) {
        echo '<div class="tsp-faq">';
        foreach ($faq as $i => $q) {
            echo '<details' . ($i < 2 ? ' open' : '') . '><summary><h3>' . esc_html($q[0]) . '</h3></summary><p>' . esc_html($q[1]) . '</p></details>';
        }
        echo '</div>';
    }
    $links = array_filter(array('Site oficial' => $g['site'] ?? '', 'Instagram oficial' => $g['instagram'] ?? '', 'YouTube oficial' => $g['youtube'] ?? '', 'Ingressos' => $g['ingressos_link'] ?? ''));
    if ($links) {
        echo '<p class="tsp-guia__links">';
        foreach ($links as $k => $u) {
            echo '<a href="' . esc_url($u) . '" target="_blank" rel="noopener nofollow">' . esc_html($k) . ' ↗</a>';
        }
        echo '</p>';
    }
    if ($desc) {
        echo '<div class="tsp-corpo tsp-guia__texto">' . wp_kses_post($desc) . '</div>';
    }
    echo '</section>';

    // Dados estruturados: clube (SportsTeam) + perguntas frequentes (FAQPage)
    $time = array('@context' => 'https://schema.org', '@type' => 'SportsTeam', 'name' => $nome, 'sport' => 'Futebol', 'url' => get_term_link($termo));
    if (!empty($g['cidade'])) {
        $time['location'] = array('@type' => 'Place', 'name' => $g['cidade'] . ', SP');
    }
    if (!empty($g['tecnico'])) {
        $time['coach'] = array('@type' => 'Person', 'name' => $g['tecnico']);
    }
    $same = array_values(array_filter(array($g['site'] ?? '', $g['instagram'] ?? '', $g['youtube'] ?? '')));
    if ($same) {
        $time['sameAs'] = $same;
    }
    echo '<script type="application/ld+json">' . wp_json_encode($time, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    if ($faq) {
        $f = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array());
        foreach ($faq as $q) {
            $f['mainEntity'][] = array('@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $q[1]));
        }
        echo '<script type="application/ld+json">' . wp_json_encode($f, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    }
}

function tsp_divisao_paulistao($slug)
{
    foreach (array('d1', 'd2', 'd3', 'd4') as $k) {
        $d = tsp_grupos()[$k]['divisao'];
        if (isset($d[$slug])) {
            return 'Série ' . $d[$slug];
        }
    }
    return '';
}
