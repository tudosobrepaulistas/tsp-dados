<?php
/**
 * Quem aparece em cada bloco da home.
 * Os endereços (slugs) são os da classificação "Times" que já existe no site.
 * Divisões do Paulistão 2027 (lista de 27/10/2026, 16 clubes por série). Para mudar um clube de divisão, basta mover o slug aqui.
 * Quem escreve cada grupo: "redacao" = jornalistas; "maquina" = TSP Máquina de Notícias (com revisão humana).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_grupos()
{
    return array(
        'a4' => array(
            'titulo'  => 'Série A · Os 4 grandes',
            'quem'    => 'redacao',
            'link'    => '/campeonato/brasileiro-serie-a/',
            'clubes'  => array('corinthians' => 'Corinthians', 'palmeiras' => 'Palmeiras', 'santos' => 'Santos', 'saopaulo' => 'São Paulo'),
        ),
        'mb' => array(
            'titulo'  => 'Série A · Mirassol e Bragantino',
            'quem'    => 'redacao',
            'link'    => '/campeonato/brasileiro-serie-a/',
            'clubes'  => array('mirassol' => 'Mirassol', 'bragantino' => 'Bragantino'),
        ),
        'sb' => array(
            'titulo'  => 'Série B · Os 4 paulistas',
            'quem'    => 'redacao',
            'link'    => '/campeonato/brasileiro-serie-b/',
            'clubes'  => array('botafogosp' => 'Botafogo-SP', 'pontepreta' => 'Ponte Preta', 'saobernardo' => 'São Bernardo', 'novorizontino' => 'Novorizontino'),
        ),
        'fem' => array(
            'titulo'  => 'Futebol Feminino · Clubes paulistas',
            'quem'    => 'redacao',
            'link'    => '/campeonato/brasileirao-feminino/',
            'clubes'  => array(
                'corinthians-feminino' => 'Corinthians', 'palmeiras-feminino' => 'Palmeiras', 'sao-paulo-feminino' => 'São Paulo',
                'santos-feminino' => 'Santos', 'ferroviaria-feminino' => 'Ferroviária', 'red-bull-bragantino-feminino' => 'Bragantino',
                'mirassol-feminino' => 'Mirassol', 'taubate-feminino' => 'Taubaté',
            ),
        ),
        'd1' => array(
            'titulo'  => 'Paulistão A1',
            'sub'     => 'Elite do futebol paulista',
            'quem'    => 'redacao',
            'link'    => '/campeonato/paulistao-a1/',
            'divisao' => array('botafogosp' => 'A1', 'capivariano' => 'A1', 'corinthians' => 'A1', 'ferroviaria' => 'A1', 'guarani' => 'A1', 'juventus' => 'A1', 'mirassol' => 'A1', 'noroeste' => 'A1', 'novorizontino' => 'A1', 'palmeiras' => 'A1', 'portuguesa' => 'A1', 'primavera' => 'A1', 'bragantino' => 'A1', 'santos' => 'A1', 'saobernardo' => 'A1', 'saopaulo' => 'A1'),
        ),
        'd2' => array(
            'titulo'  => 'Paulistão A2',
            'sub'     => 'Segunda divisão do futebol paulista',
            'quem'    => 'redacao',
            'link'    => '/campeonato/paulistao-a2/',
            'divisao' => array('aguasanta' => 'A2', 'interdelimeira' => 'A2', 'ituano' => 'A2', 'linense' => 'A2', 'marilia' => 'A2', 'monteazul' => 'A2', 'osasco-sporting' => 'A2', 'pontepreta' => 'A2', 'portuguesasantista' => 'A2', 'santoandre' => 'A2', 'saojose' => 'A2', 'sertaozinho' => 'A2', 'taubate' => 'A2', 'veloclube' => 'A2', 'votuporanguense' => 'A2', 'xvdepiracicaba' => 'A2'),
        ),
        'd3' => array(
            'titulo'  => 'Paulistão A3',
            'sub'     => 'Terceira divisão do futebol paulista',
            'quem'    => 'maquina',
            'link'    => '/campeonato/paulistao-a3/',
            'divisao' => array('bandeirante' => 'A3', 'catanduva' => 'A3', 'ec-sao-bernardo' => 'A3', 'francana' => 'A3', 'prudente' => 'A3', 'inter-de-bebedouro' => 'A3', 'itapirense' => 'A3', 'paulista-jundiai' => 'A3', 'penapolense' => 'A3', 'rio-branco' => 'A3', 'rioclaro' => 'A3', 'rio-preto' => 'A3', 'saobento' => 'A3', 'uniao-barbarense' => 'A3', 'uniao-sao-joao' => 'A3', 'xv-de-jau' => 'A3'),
        ),
        'd4' => array(
            'titulo'  => 'Paulistão A4',
            'sub'     => 'Quarta divisão do futebol paulista',
            'quem'    => 'maquina',
            'link'    => '/campeonato/paulistao-a4/',
            'divisao' => array('america-de-rio-preto' => 'A4', 'barretos' => 'A4', 'colorado-caieiras' => 'A4', 'comercial' => 'A4', 'desportivo-brasil' => 'A4', 'ecus' => 'A4', 'gremio-saocarlense' => 'A4', 'independente' => 'A4', 'jabaquara' => 'A4', 'jacarei' => 'A4', 'lemense' => 'A4', 'saocaetano' => 'A4', 'tanabi' => 'A4', 'taquaritinga' => 'A4', 'uniao-suzano' => 'A4', 'vocem' => 'A4'),
        ),
    );
}

/**
 * Outros clubes paulistas: todo clube profissional cadastrado em "Times" que não está em nenhuma
 * divisão acima (Segunda Divisão/Bezinha, rebaixados da A4 e clubes sem divisão).
 * Fica de fora: Sub-20/Sub-xx, Feminino, times B/II e quem ainda não tem nenhuma matéria.
 * A lista se monta sozinha: clube novo cadastrado com matéria entra; clube que sobe para a A4 sai.
 */
function tsp_outros_clubes()
{
    static $lista = null;
    if ($lista !== null) {
        return $lista;
    }
    $lista = get_transient('tsp_outros_clubes');
    if (is_array($lista)) {
        return $lista;
    }
    $conhecidos = array();
    foreach (tsp_grupos() as $g) {
        $conhecidos += isset($g['clubes']) ? $g['clubes'] : $g['divisao'];
    }
    $lista = array();
    $termos = get_terms(array('taxonomy' => 'times', 'hide_empty' => true, 'number' => 0));
    if (!is_wp_error($termos)) {
        foreach ($termos as $t) {
            if (isset($conhecidos[$t->slug]) || in_array($t->slug, array('destaques'), true)) {
                continue;
            }
            if (preg_match('~(sub-?\d+|feminin[oa]|-b$|-ii$)~i', $t->slug) || preg_match('~( B| II| Sub-?\d+| Feminin[oa])$~i', $t->name)) {
                continue;
            }
            $lista[$t->slug] = 'Outros';
        }
    }
    set_transient('tsp_outros_clubes', $lista, 6 * HOUR_IN_SECONDS);
    return $lista;
}
add_action('created_times', function () { delete_transient('tsp_outros_clubes'); });
add_action('edited_times', function () { delete_transient('tsp_outros_clubes'); });

function tsp_grupo_slugs($chave)
{
    $g = tsp_grupos();
    if (empty($g[$chave])) {
        return array();
    }
    return array_keys(isset($g[$chave]['clubes']) ? $g[$chave]['clubes'] : $g[$chave]['divisao']);
}

// Nomes (como aparecem nas tabelas) dos clubes paulistas, para destacar com o selo "SP"
function tsp_paulistas_tabela($serie)
{
    if ($serie === 'serie_b') {
        return array('Novorizontino', 'São Bernardo', 'Botafogo-SP', 'Botafogo SP', 'Botafogo', 'Ponte Preta');
    }
    return array('Palmeiras', 'Santos', 'São Paulo', 'Red Bull Bragantino', 'Bragantino', 'Mirassol', 'Corinthians');
}

// "do Corinthians" / "da Ponte Preta": clubes tratados no feminino
function tsp_de($termo)
{
    $fem = array('pontepreta', 'ferroviaria', 'ferroviaria-feminino', 'portuguesa', 'portuguesasantista', 'francana', 'itapirense', 'interdelimeira', 'inter-de-bebedouro', 'matonense', 'aguasanta', 'inter-de-limeira-b');
    return (in_array($termo->slug, $fem, true) ? 'da ' : 'do ') . $termo->name;
}

// Clubes com calendário nacional agora (Série A e Série B): já têm bloco próprio na home
function tsp_slugs_nacionais()
{
    return array_merge(tsp_grupo_slugs('a4'), tsp_grupo_slugs('mb'), tsp_grupo_slugs('sb'));
}

// Clubes de uma divisão que entram no bloco da home (sem os da Série A e B)
function tsp_divisao_home_slugs($k)
{
    return array_values(array_diff(tsp_grupo_slugs($k), tsp_slugs_nacionais()));
}

// "o Corinthians" / "a Ponte Preta"
function tsp_o($termo)
{
    return (strpos(tsp_de($termo), 'da ') === 0 ? 'a ' : 'o ') . $termo->name;
}
