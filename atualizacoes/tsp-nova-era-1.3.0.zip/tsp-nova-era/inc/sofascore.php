<?php
/**
 * Classificações pelos widgets oficiais e gratuitos do Sofascore (iframe com o crédito deles).
 * Usados só quando não há tabela própria (TSP Jogos ou TSP · Dados do tema).
 * Para trocar de temporada (ex.: 2027), cole em TSP · Dados do tema, chave "sofascore",
 * o código do Sofascore: {"sofascore": {"paulistao_a1": "<iframe ...>"}}.
 */

if (!defined('ABSPATH')) {
    exit;
}

// chave => [id do torneio, id da temporada, título, nº de times, link da página no Sofascore]
function tsp_sofa_padroes()
{
    return array(
        'serie_a' => array(83, 87678, 'Brasileirão Série A 2026', 20, 'brazil/brasileirao-serie-a/325'),
        'serie_b' => array(1449, 89840, 'Brasileirão Série B 2026', 20, 'brazil/brasileirao-serie-b/390'),
        'paulistao_a1' => array(57411, 86993, 'Paulistão A1 2026', 16, 'brazil/paulista-serie-a1/372'),
        'paulistao_a2' => array(57420, 87118, 'Paulistão A2 2026', 16, 'brazil/paulista-serie-a2/1234'),
        'paulistao_a3' => array(57422, 87237, 'Paulistão A3 2026', 16, 'brazil/paulista-serie-a3/1614'),
        'paulistao_a4' => array(125513, 87773, 'Paulistão A4 2026', 16, 'brazil/paulista-serie-a4/20058'),
        'fem_brasileiro_a1' => array(47550, 89138, 'Brasileirão Feminino A1 2026', 18, 'brazil/brasileirao-serie-a1-feminino/10257'),
        'fem_paulistao' => array(89490, 93750, 'Paulistão Feminino 2026', 8, 'brazil/paulista-feminino/14448'),
    );
}

// Devolve [src, altura, link] do widget ou null. Só aceita endereços do próprio Sofascore.
function tsp_sofa_widget($chave)
{
    $extra = tsp_dado('sofascore');
    if (is_array($extra) && !empty($extra[$chave]) && is_string($extra[$chave])) {
        $cod = $extra[$chave];
        if (preg_match('~src=["\']?(https://widgets\.sofascore\.com/[^"\'\s>]+)~', $cod, $m)) {
            $alt = preg_match('~height:\s*(\d{3,4})px~', $cod, $h) ? (int) $h[1] : 1123;
            $link = preg_match('~href=["\'](https://www\.sofascore\.com/[^"\']+)~', $cod, $l) ? $l[1] : 'https://www.sofascore.com/pt/';
            return array(html_entity_decode($m[1]), $alt, $link);
        }
    }
    // Padrão desligado: o site usa a classificação própria (Base TSP). Só aparece widget colado à mão em "sofascore".
    $p = array();
    if (empty($p[$chave])) {
        return null;
    }
    list($torneio, $temporada, $titulo, $times, $pagina) = $p[$chave];
    $src = 'https://widgets.sofascore.com/pt-BR/embed/tournament/' . $torneio . '/season/' . $temporada . '/standings/' . rawurlencode($titulo) . '?widgetTitle=' . rawurlencode($titulo) . '&showCompetitionLogo=true';
    return array($src, 183 + 47 * $times, 'https://www.sofascore.com/pt/football/tournament/' . $pagina . '#id:' . $temporada);
}

function tsp_sofa_html($chave, $titulo = 'Classificação')
{
    $w = tsp_sofa_widget($chave);
    if (!$w) {
        return '';
    }
    return '<div class="tsp-sofa"><iframe src="' . esc_url($w[0]) . '" title="' . esc_attr($titulo) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" scrolling="no" frameborder="0" style="height:' . (int) $w[1] . 'px"></iframe>'
        . '<p class="tsp-sofa__credito">Classificação fornecida por <a href="' . esc_url($w[2]) . '" target="_blank" rel="noopener nofollow">Sofascore</a></p></div>';
}

// Caixa recolhível (o iframe só carrega quando o leitor abre)
function tsp_sofa_recolhivel($chave, $rotulo)
{
    $h = tsp_sofa_html($chave, $rotulo);
    return $h ? '<details class="tsp-sofa-caixa"><summary>' . esc_html($rotulo) . '</summary>' . $h . '</details>' : '';
}
