<?php
/**
 * Página de cada campeonato (/campeonato/<slug>/): guia completo para o torcedor e para o Google.
 * Resposta rápida (AEO) → índice → classificação → jogos → clubes paulistas → artilharia → regulamento →
 * onde assistir → perguntas frequentes (FAQPage) → últimas notícias.
 * Os números (líder, pontos, rodada) vêm da Base TSP e se atualizam sozinhos; o texto do guia fica aqui,
 * só com fatos conferidos (fontes no comentário de cada campeonato).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_campeonatos_guias()
{
    return array(
        // Fontes: O Imparcial (jan/2026, regulamento), Trivela (dez/2025, tabela básica da CBF), VAVEL (out/2026, vagas),
        // Meio & Mensagem (2026, transmissão). Conferido em 27/10/2026.
        'brasileiro-serie-a' => array(
            'dado' => 'serie_a', 'nome' => 'Brasileirão Série A', 'curto' => 'Brasileirão', 'temporada' => '2026', 'grupo' => array('a4', 'mb'),
            'resumo' => 'O Campeonato Brasileiro Série A 2026 reúne 20 clubes em pontos corridos, com turno e returno (38 rodadas), de 28 de janeiro a 2 de dezembro. É organizado pela CBF. Seis clubes paulistas disputam a edição: Corinthians, Palmeiras, Santos, São Paulo, Mirassol e Red Bull Bragantino.',
            'formato' => array(
                array('Clubes', '20'), array('Rodadas', '38 (turno e returno)'), array('Início', '28 de janeiro de 2026'), array('Fim', '2 de dezembro de 2026'),
                array('Campeão', 'Quem somar mais pontos'), array('Libertadores 2027', '1º ao 4º na fase de grupos; 5º na fase preliminar'),
                array('Sul-Americana 2027', 'Os 8 seguintes (6º ao 13º)'), array('Rebaixamento', '4 últimos (17º ao 20º) caem para a Série B'),
            ),
            'regras' => array(
                'Se um clube já classificado para a Libertadores também conquistar vaga por outro caminho (Copa do Brasil, Libertadores ou Sul-Americana), a vaga passa para o próximo da tabela: o G-4/G-5 pode virar G-6 ou mais.',
                'Critérios de desempate, nesta ordem: 1) mais vitórias; 2) maior saldo de gols; 3) mais gols marcados; 4) confronto direto; 5) menos cartões vermelhos; 6) menos cartões amarelos; 7) sorteio.',
                'Transferências: o jogador pode atuar por até 12 partidas por um clube e ainda se transferir para outro da Série A na mesma edição (antes eram 6).',
                'A edição de 2026 adota o impedimento semiautomático, com câmeras e sensor na bola.',
            ),
            'transmissao' => 'Os jogos são divididos, conforme a rodada, entre Globo (TV aberta), sportv e Premiere (TV fechada e pay-per-view), CazéTV (YouTube), Record e Prime Video. A transmissão de cada partida aparece na página do jogo.',
            'faq_extra' => array(
                array('Quantos times caem no Brasileirão 2026?', 'Quatro. Os clubes que terminarem do 17º ao 20º lugar são rebaixados para a Série B de 2027.'),
                array('Quantas vagas o Brasileirão 2026 dá para a Libertadores?', 'Cinco, na base: do 1º ao 4º lugar vão direto à fase de grupos da Libertadores 2027 e o 5º vai para a fase preliminar. O número pode crescer se clubes já classificados ganharem vaga por outro torneio.'),
                array('Quando termina o Brasileirão 2026?', 'A 38ª e última rodada está marcada para 2 de dezembro de 2026.'),
                array('Quais são os critérios de desempate do Brasileirão?', 'Vitórias, saldo de gols, gols marcados, confronto direto, cartões vermelhos, cartões amarelos e sorteio, nesta ordem.'),
            ),
        ),
        // Fontes: CBF (classificação e tabela, out/2026). Datas do período: tabela da competição.
        'brasileiro-serie-b' => array(
            'dado' => 'serie_b', 'nome' => 'Brasileirão Série B', 'curto' => 'Série B', 'temporada' => '2026', 'grupo' => array('sb'),
            'resumo' => 'A Série B do Campeonato Brasileiro 2026 tem 20 clubes em pontos corridos, com turno e returno (38 rodadas), organizada pela CBF. Quatro clubes paulistas disputam: Novorizontino, São Bernardo, Botafogo-SP e Ponte Preta.',
            'formato' => array(array('Clubes', '20'), array('Rodadas', '38 (turno e returno)'), array('Acesso à Série A', '1º e 2º direto; 3º ao 6º disputam os playoffs de acesso'), array('Rebaixamento', '4 últimos (17º ao 20º) caem para a Série C')),
            'regras' => array(),
            'transmissao' => '',
            'faq_extra' => array(),
        ),
    );
}

function tsp_campeonato_guia($slug)
{
    $g = tsp_campeonatos_guias();
    return $g[$slug] ?? null;
}

// Clubes paulistas do campeonato (slugs) a partir dos grupos do tema
function tsp_campeonato_clubes($guia)
{
    $s = array();
    foreach ((array) ($guia['grupo'] ?? array()) as $k) {
        $s = array_merge($s, tsp_grupo_slugs($k));
    }
    return $s;
}

// Resposta rápida montada com os números do dia (líder, vice, rodada, paulistas)
function tsp_campeonato_resposta($guia)
{
    $tabs = tsp_dado('tabelas');
    $t = $tabs[$guia['dado']]['linhas'] ?? array();
    if (count($t) < 2) {
        return '';
    }
    $l = $t[0];
    $v = $t[1];
    $dif = (int) $l[2] - (int) $v[2];
    $txt = $l[1] . ' lidera o ' . $guia['curto'] . ' ' . $guia['temporada'] . ' com ' . (int) $l[2] . ' pontos em ' . (int) $l[3] . ' jogos, ' . ($dif === 0 ? 'empatado em pontos com o ' . $v[1] : $dif . ' ' . ($dif === 1 ? 'ponto' : 'pontos') . ' à frente do ' . $v[1]) . '.';
    $sp = tsp_paulistas_tabela($guia['dado']);
    $pos = array();
    foreach ($t as $r) {
        if (in_array($r[1], $sp, true)) {
            $pos[] = $r[1] . ' (' . (int) $r[0] . 'º)';
        }
    }
    if ($pos) {
        $txt .= ' Paulistas: ' . implode(', ', $pos) . '.';
    }
    return $txt;
}

function tsp_campeonato_faq($guia)
{
    $faq = array();
    $r = tsp_campeonato_resposta($guia);
    if ($r) {
        $faq[] = array('Quem lidera o ' . $guia['curto'] . ' ' . $guia['temporada'] . '?', $r);
    }
    $clubes = array();
    foreach (tsp_campeonato_clubes($guia) as $s) {
        $t = get_term_by('slug', $s, 'times');
        if ($t) {
            $clubes[] = $t->name;
        }
    }
    if ($clubes) {
        $faq[] = array('Quais times paulistas disputam o ' . $guia['curto'] . ' ' . $guia['temporada'] . '?', implode(', ', $clubes) . '.');
    }
    if (!empty($guia['transmissao'])) {
        $faq[] = array('Onde assistir aos jogos do ' . $guia['curto'] . '?', $guia['transmissao']);
    }
    return array_merge($faq, (array) $guia['faq_extra']);
}

// Artilharia (Base TSP): só aparece quando a base traz a lista completa da temporada
function tsp_campeonato_artilharia($dado)
{
    $a = get_option('tsp_jogos_artilharia', array());
    $l = is_array($a) && !empty($a[$dado]) ? $a[$dado] : array();
    if (!$l || empty(get_option('tsp_jogos_artilharia_completa', array())[$dado])) {
        return array();
    }
    return array_slice($l, 0, 10);
}

add_action('wp_head', function () {
    if (!is_tax('campeonato')) {
        return;
    }
    $g = tsp_campeonato_guia(get_queried_object()->slug ?? '');
    if (!$g || is_paged()) {
        return;
    }
    $itens = array();
    foreach (tsp_campeonato_faq($g) as $f) {
        $itens[] = array('@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $f[1]));
    }
    if ($itens) {
        echo '<script type="application/ld+json">' . wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $itens), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }
}, 30);
