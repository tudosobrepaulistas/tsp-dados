<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0B0B0B">
<?php if (!has_site_icon()) : ?>
<link rel="icon" href="<?php echo esc_url(get_template_directory_uri() . '/assets/img/icone-192.png'); ?>" sizes="192x192">
<link rel="apple-touch-icon" href="<?php echo esc_url(get_template_directory_uri() . '/assets/img/icone-192.png'); ?>">
<?php endif; ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="tsp-pular" href="#conteudo">Pular para o conteúdo</a>

<div class="tsp-faixa">
	<div class="tsp-container tsp-faixa__in">
		<p class="tsp-faixa__txt"><span class="tsp-ponto" aria-hidden="true"></span>
			<?php
			$tsp_faixa = tsp_dado('faixa_topo', '');
			if (is_array($tsp_faixa) && !empty($tsp_faixa['texto'])) {
				echo '<strong>' . esc_html($tsp_faixa['rotulo'] ?? '') . '</strong> ' . esc_html($tsp_faixa['texto']);
			} else {
				echo 'Notícias de todos os times do estado de São Paulo';
			}
			?>
		</p>
		<a class="tsp-faixa__wpp" href="<?php echo esc_url(tsp_whatsapp_link()); ?>" target="_blank" rel="noopener">Receba notícias pelo WhatsApp</a>
	</div>
</div>

<header class="tsp-cab">
	<div class="tsp-container tsp-cab__in">
		<a class="tsp-marca" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
				<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/logo-tsp.webp?v=' . TSP_VERSAO); ?>" alt="<?php bloginfo('name'); ?>" width="154" height="94" fetchpriority="high">
			
		</a>
		<button class="tsp-menu-btn" type="button" aria-controls="tsp-menu" aria-expanded="false" aria-label="Abrir menu"><span></span><span></span><span></span></button>
		<nav id="tsp-menu" class="tsp-nav" aria-label="Menu principal">
			<?php
			if (has_nav_menu('principal')) {
				wp_nav_menu(array('theme_location' => 'principal', 'container' => false, 'menu_class' => 'tsp-nav__lista', 'depth' => 2));
			} else {
				tsp_menu_padrao();
			}
			?>
			<form class="tsp-busca" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
				<label class="tsp-sr" for="tsp-busca-campo">Buscar notícias</label>
				<input id="tsp-busca-campo" type="search" name="s" placeholder="Buscar notícias" value="<?php echo esc_attr(get_search_query()); ?>">
				<button type="submit" aria-label="Buscar"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M10 2a8 8 0 0 1 6.32 12.9l5.39 5.4-1.41 1.4-5.4-5.38A8 8 0 1 1 10 2zm0 2a6 6 0 1 0 0 12 6 6 0 0 0 0-12z"/></svg></button>
			</form>
		</nav>
	</div>
</header>

<div class="tsp-clubes">
	<div class="tsp-container tsp-clubes__in">
		<?php
		foreach (array('Série A' => array_merge(tsp_grupos()['a4']['clubes'], tsp_grupos()['mb']['clubes']), 'Série B' => tsp_grupos()['sb']['clubes']) as $tsp_rot => $tsp_lista) {
			echo '<span class="tsp-clubes__rot">' . esc_html($tsp_rot) . '</span>';
			foreach ($tsp_lista as $tsp_slug => $tsp_nome) {
				$tsp_t = get_term_by('slug', $tsp_slug, 'times');
				if ($tsp_t) {
					echo '<a href="' . esc_url(get_term_link($tsp_t)) . '">' . esc_html($tsp_nome) . '</a>';
				}
			}
			if ($tsp_rot === 'Série A') {
				echo '<span class="tsp-clubes__sep" aria-hidden="true"></span>';
			}
		}
		?>
		<a class="tsp-clubes__todos" href="<?php echo esc_url(home_url('/todos-os-times/')); ?>">Todos os times →</a>
	</div>
</div>

<div id="conteudo" class="tsp-conteudo">
