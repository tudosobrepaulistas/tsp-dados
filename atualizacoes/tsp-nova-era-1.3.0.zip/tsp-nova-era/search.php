<?php
get_header();
?>
<main class="tsp-container tsp-arquivo">
	<header class="tsp-arquivo__cab">
		<h1>Busca: <?php echo esc_html(get_search_query()); ?></h1>
		<?php get_search_form(); ?>
	</header>
	<?php if (have_posts()) : ?>
		<div class="tsp-grade tsp-grade--4">
			<?php while (have_posts()) : the_post(); tsp_card(get_the_ID(), 'grade'); endwhile; ?>
		</div>
		<?php tsp_paginacao(); ?>
	<?php else : ?>
		<p class="tsp-vazio">Não encontramos notícias com esse termo. Tente outra palavra ou o nome do time.</p>
	<?php endif; ?>
</main>
<?php
get_footer();
