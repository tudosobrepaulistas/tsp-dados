<?php
/**
 * Página de jogo (criada e atualizada sozinha pelo plugin TSP Jogos).
 */
get_header();
while (have_posts()) :
	the_post();
	?>
<main class="tsp-container tsp-com-lateral">
	<article class="tsp-materia">
		<?php tsp_breadcrumbs(); ?>
		<h1 class="tsp-materia__titulo tsp-materia__titulo--jogo"><?php the_title(); ?></h1>
		<div class="tsp-corpo tsp-corpo--jogo"><?php the_content(); ?></div>
		<?php tsp_cta_whatsapp(); ?>
	</article>
	<aside class="tsp-lateral" aria-label="Mais do TSP">
		<?php tsp_banner('tsp-banner-materia'); ?>
		<?php tsp_lista_ultimas(6, array(get_the_ID())); ?>
	</aside>
</main>
	<?php
endwhile;
get_footer();
