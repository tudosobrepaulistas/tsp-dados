<?php
// Qualquer listagem sem modelo próprio usa o mesmo desenho dos arquivos.
require __DIR__ . '/archive.php';
