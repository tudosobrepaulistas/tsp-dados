<form class="tsp-busca tsp-busca--pagina" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
	<label class="tsp-sr" for="tsp-busca-pagina">Buscar notícias</label>
	<input id="tsp-busca-pagina" type="search" name="s" placeholder="Buscar notícias" value="<?php echo esc_attr(get_search_query()); ?>">
	<button type="submit">Buscar</button>
</form>
