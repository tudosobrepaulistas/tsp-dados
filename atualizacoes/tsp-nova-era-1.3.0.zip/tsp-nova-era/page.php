<?php
get_header();
while (have_posts()) :
	the_post();
	?>
<main class="tsp-container tsp-pagina">
	<article>
		<?php tsp_breadcrumbs(); ?>
		<h1 class="tsp-materia__titulo"><?php the_title(); ?></h1>
		<div class="tsp-corpo"><?php the_content(); ?></div>
	</article>
</main>
	<?php
endwhile;
get_footer();
