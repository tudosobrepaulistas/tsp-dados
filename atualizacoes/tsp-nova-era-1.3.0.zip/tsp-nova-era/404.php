<?php
get_header();
?>
<main class="tsp-container tsp-arquivo">
	<header class="tsp-arquivo__cab">
		<h1>Página não encontrada</h1>
		<p>O endereço pode ter mudado. Busque a notícia ou volte para a <a href="<?php echo esc_url(home_url('/')); ?>">página inicial</a>.</p>
		<?php get_search_form(); ?>
	</header>
	<?php tsp_lista_ultimas(8, array(), 'Últimas notícias'); ?>
</main>
<?php
get_footer();
