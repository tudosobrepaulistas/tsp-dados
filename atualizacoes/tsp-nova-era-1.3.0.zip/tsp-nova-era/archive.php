<?php
/**
 * Arquivos: times (/times/...), campeonatos (/campeonato/...), séries, categorias, tags, autor e datas.
 * Mesmos endereços e mesma paginação de antes (/page/2/), para não perder nada no Google.
 */
get_header();
$tsp_desc = get_the_archive_description();
?>
<main class="tsp-container tsp-arquivo">
	<header class="tsp-arquivo__cab">
		<?php tsp_breadcrumbs(); ?>
		<h1><?php echo esc_html(wp_strip_all_tags(get_the_archive_title())); ?></h1>
		<?php if ($tsp_desc) : ?><div class="tsp-arquivo__desc"><?php echo wp_kses_post($tsp_desc); ?></div><?php endif; ?>
	</header>
	<?php if (have_posts()) : ?>
		<?php
		$tsp_ids = wp_list_pluck($GLOBALS['wp_query']->posts, 'ID');
		if (!is_paged()) {
			echo '<div class="tsp-topo">';
			tsp_card($tsp_ids[0], 'grande', true);
			echo '<div class="tsp-topo__lado tsp-topo__lado--lista">';
			foreach (array_slice($tsp_ids, 1, 3) as $tsp_i) {
				tsp_card($tsp_i, 'lista');
			}
			echo '</div></div>';
			$tsp_ids = array_slice($tsp_ids, 4);
		}
		if ($tsp_ids) {
			echo '<div class="tsp-grade tsp-grade--4">';
			foreach ($tsp_ids as $tsp_i) {
				tsp_card($tsp_i, 'grade');
			}
			echo '</div>';
		}
		tsp_paginacao();
		?>
	<?php else : ?>
		<p class="tsp-vazio">Nenhuma notícia por aqui ainda.</p>
	<?php endif; ?>
</main>
<?php
get_footer();
