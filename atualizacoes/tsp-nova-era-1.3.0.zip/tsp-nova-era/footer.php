</div><!-- #conteudo -->

<footer class="tsp-rodape">
	<div class="tsp-container tsp-rodape__in">
		<div class="tsp-rodape__marca">
			<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/logo-tsp.webp?v=' . TSP_VERSAO); ?>" alt="<?php bloginfo('name'); ?>" width="154" height="94" loading="lazy">
			<p>Notícias de todos os times do estado de São Paulo, da Série A à segunda divisão.</p>
			<a href="mailto:contato@tudosobrepaulista.com.br">contato@tudosobrepaulista.com.br</a>
		</div>
		<div class="tsp-rodape__col">
			<strong>Futebol</strong>
			<a href="<?php echo esc_url(home_url('/campeonato/brasileiro-serie-a/')); ?>">Série A</a>
			<a href="<?php echo esc_url(home_url('/campeonato/brasileiro-serie-b/')); ?>">Série B</a>
			<a href="<?php echo esc_url(home_url('/campeonato/brasileirao-feminino/')); ?>">Feminino</a>
			<a href="<?php echo esc_url(home_url('/campeonato/paulistao-a1/')); ?>">Paulistão A1</a>
			<a href="<?php echo esc_url(home_url('/campeonato/paulistao-a2/')); ?>">Paulistão A2</a>
			<a href="<?php echo esc_url(home_url('/campeonato/paulistao-a3/')); ?>">Paulistão A3</a>
			<a href="<?php echo esc_url(home_url('/campeonato/paulistao-a4/')); ?>">Paulistão A4</a>
		</div>
		<div class="tsp-rodape__col">
			<strong>TSP</strong>
			<?php
			if (has_nav_menu('rodape')) {
				wp_nav_menu(array('theme_location' => 'rodape', 'container' => false, 'depth' => 1, 'items_wrap' => '%3$s'));
			} else {
				foreach (array('sobre-nos' => 'Sobre nós', 'politica-de-privacidade' => 'Política de privacidade') as $tsp_slug => $tsp_nome) {
					$tsp_p = get_page_by_path($tsp_slug);
					if ($tsp_p) {
						echo '<a href="' . esc_url(get_permalink($tsp_p)) . '">' . esc_html($tsp_nome) . '</a>';
					}
				}
			}
			?>
			<a href="<?php echo esc_url(get_theme_mod('tsp_instagram', 'https://www.instagram.com/tudosobrepaulistas/')); ?>" rel="noopener" target="_blank">Instagram</a>
			<a href="<?php echo esc_url(get_theme_mod('tsp_youtube', 'https://www.youtube.com/@TudoSobrePaulista')); ?>" rel="noopener" target="_blank">YouTube</a>
			<a href="<?php echo esc_url(get_theme_mod('tsp_tiktok', 'https://vm.tiktok.com/ZMSPTNxc3/')); ?>" rel="noopener" target="_blank">TikTok</a>
		</div>
	</div>
	<div class="tsp-container tsp-rodape__base">© <?php echo esc_html(wp_date('Y')); ?> Tudo Sobre Paulista. Todos os direitos reservados.</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
