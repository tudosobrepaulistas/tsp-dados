<?php
/**
 * Página "Todos os times": os clubes paulistas da A1 à A4 em ordem alfabética, com escudo e divisão.
 */
get_header();
$tsp_lista = tsp_clubes_paulistas();
?>
<main class="tsp-container tsp-arquivo">
	<header class="tsp-arquivo__cab">
		<?php tsp_breadcrumbs(); ?>
		<h1>Todos os times paulistas</h1>
		<p class="tsp-arquivo__desc"><?php echo (int) count($tsp_lista); ?> clubes do estado de São Paulo, da Série A do Brasileirão à Série A4 do Paulistão, em ordem alfabética.</p>
	</header>
	<?php
	$tsp_letra = '';
	foreach ($tsp_lista as $tsp_c) {
		$tsp_l = strtoupper(substr(remove_accents($tsp_c['termo']->name), 0, 1));
		if ($tsp_l !== $tsp_letra) {
			if ($tsp_letra !== '') {
				echo '</div>';
			}
			$tsp_letra = $tsp_l;
			echo '<h2 class="tsp-letra">' . esc_html($tsp_l) . '</h2><div class="tsp-times">';
		}
		echo '<a href="' . esc_url(get_term_link($tsp_c['termo'])) . '">' . tsp_escudo($tsp_c['termo']) . esc_html($tsp_c['termo']->name) . '<small>' . esc_html($tsp_c['div']) . '</small></a>';
	}
	if ($tsp_letra !== '') {
		echo '</div>';
	}
	?>
</main>
<?php
get_footer();
