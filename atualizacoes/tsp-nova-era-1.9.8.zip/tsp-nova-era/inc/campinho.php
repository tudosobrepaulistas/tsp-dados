<?php
/**
 * Campinho do Elenco 2027 na página do clube (25/11/2026, pedido do Thiago).
 *  - Antes dos jogos: "time base" do TSP com o elenco anunciado, em 4-4-2: em cada posição, primeiro quem já é da casa
 *    (renovou ou seguiu do elenco anterior), depois os mais experientes (idade). Deixa claro que não é escalação oficial.
 *  - Com 3 ou mais jogos da temporada com escalação confirmada: esquema mais usado nos últimos jogos e, em cada setor,
 *    os jogadores com mais minutos (TSP Jogos 1.9.3, tsp_campinho_temporada), sempre como recorte (regra 16).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_CP_TEMPORADA_INICIO = '2027-01-01 00:00:00';

function tsp_cp_idade($x)
{
    if (!empty($x['nascimento'])) {
        return (int) floor((time() - strtotime($x['nascimento'])) / (365.25 * DAY_IN_SECONDS));
    }
    return (int) ($x['ficha']['idade'] ?? 0);
}

function tsp_cp_jogador_html($nome, $foto, $url, $extra = '', $vazio = false)
{
    if ($vazio) {
        return '<div class="tsp-cp__jog tsp-cp__jog--vazio"><span class="tsp-cp__foto">?</span><span class="tsp-cp__nome">' . esc_html($nome) . '</span></div>';
    }
    $partes = preg_split('~\s+~', trim($nome));
    $ini = mb_strtoupper(mb_substr($partes[0], 0, 1) . (count($partes) > 1 ? mb_substr(end($partes), 0, 1) : ''));
    $img = $foto ? '<img src="' . esc_url($foto) . '" alt="' . esc_attr($nome) . '" width="48" height="48" loading="lazy" referrerpolicy="no-referrer">' : esc_html($ini);
    $in = '<span class="tsp-cp__foto">' . $img . '</span><span class="tsp-cp__nome">' . esc_html($nome) . '</span>' . ($extra ? '<span class="tsp-cp__extra">' . esc_html($extra) . '</span>' : '');
    return $url ? '<a class="tsp-cp__jog" href="' . esc_url($url) . '">' . $in . '</a>' : '<div class="tsp-cp__jog">' . $in . '</div>';
}

function tsp_cp_campo_html($titulo, $linhas_html, $nota_html)
{
    $h = '<figure class="tsp-cp"><figcaption class="tsp-cp__tit">' . esc_html($titulo) . '</figcaption>' . $nota_html . '<div class="tsp-cp__campo">';
    foreach (array_reverse($linhas_html) as $l) { // ataque em cima, goleiro embaixo
        $h .= '<div class="tsp-cp__linha">' . implode('', $l) . '</div>';
    }
    return $h . '</div></figure>';
}

function tsp_el_campinho($termo, $slug, $el)
{
    $jog = array_values(array_filter((array) ($el['jogadores'] ?? array()), function ($x) {
        return !tsp_mc_e_comissao_pos($x['posicao'] ?? '');
    }));
    $por_nome = array();
    foreach ($jog as $x) {
        $por_nome[sanitize_title(remove_accents($x['nome']))] = $x;
    }
    // 1) Temporada em andamento: mais minutos por setor, esquema mais usado
    $tid = function_exists('tsp_jogos_api_do_slug') ? tsp_jogos_api_do_slug($slug) : 0;
    $cp = ($tid && function_exists('tsp_campinho_temporada')) ? tsp_campinho_temporada($tid, strtotime(TSP_CP_TEMPORADA_INICIO)) : null;
    if ($cp) {
        $linhas = array();
        foreach ($cp['linhas'] as $li => $l) {
            $linhas[$li] = array();
            foreach ($l as $u) {
                $x = $por_nome[sanitize_title(remove_accents($u['nome']))] ?? null;
                $linhas[$li][] = tsp_cp_jogador_html($u['nome'], $x['foto']['url'] ?? '', $x ? tsp_mc_jog_url($x['nome'], $slug) : '', (int) $u['min'] . " min");
            }
        }
        $nota = function_exists('tsp_recorte_aviso') ? tsp_recorte_aviso($cp['n'], $cp['de'], $cp['ate'], 'Esquema mais usado e, em cada setor, quem tem mais minutos (escalações confirmadas).')
            : '<p class="tsp-nota">Recorte dos últimos ' . (int) $cp['n'] . ' jogos com escalação confirmada.</p>';
        return tsp_cp_campo_html('Time base ' . tsp_de($termo) . ': ' . $cp['formacao'] . ($cp['tecnico'] ? ' · técnico ' . $cp['tecnico'] : ''), $linhas, $nota);
    }
    // 2) Antes dos jogos: time base com o elenco anunciado (4-4-2), os mais antigos de casa primeiro
    if (count($jog) < 6) {
        return '';
    }
    $ordenar = function ($pos) use ($jog) {
        $l = array_values(array_filter($jog, function ($x) use ($pos) {
            return ($x['posicao'] ?? '') === $pos;
        }));
        usort($l, function ($a, $b) {
            $ca = empty($a['novo']) ? 0 : 1; // quem já é da casa (renovou ou seguiu) vem antes do reforço
            $cb = empty($b['novo']) ? 0 : 1;
            return $ca <=> $cb ?: tsp_cp_idade($b) <=> tsp_cp_idade($a);
        });
        return $l;
    };
    $esquema = array(array('Goleiro' => 1), array('Lateral' => 2, 'Zagueiro' => 2), array('Volante' => 2, 'Meia' => 2), array('Atacante' => 2));
    $linhas = array();
    foreach ($esquema as $li => $grupo) {
        $linhas[$li] = array();
        $cel = array();
        foreach ($grupo as $pos => $q) {
            $l = $ordenar($pos);
            for ($i = 0; $i < $q; $i++) {
                $x = $l[$i] ?? null;
                $cel[$pos][] = $x ? tsp_cp_jogador_html($x['nome'], $x['foto']['url'] ?? '', tsp_mc_jog_url($x['nome'], $slug), $pos) : tsp_cp_jogador_html($pos . ' a definir', '', '', '', true);
            }
        }
        // ordem no campo: lateral, zagueiros, lateral / volantes no meio, meias nas pontas
        if (isset($cel['Lateral'])) {
            $linhas[$li] = array($cel['Lateral'][0], $cel['Zagueiro'][0], $cel['Zagueiro'][1], $cel['Lateral'][1]);
        } elseif (isset($cel['Volante'])) {
            $linhas[$li] = array($cel['Meia'][0], $cel['Volante'][0], $cel['Volante'][1], $cel['Meia'][1]);
        } else {
            $linhas[$li] = reset($cel);
        }
    }
    $nota = '<p class="tsp-cp__nota">' . esc_html('Montagem do TSP com o elenco anunciado: em cada posição, primeiro quem já é da casa, depois os mais experientes. Não é escalação oficial. Com a bola rolando, o campinho passa a mostrar o esquema mais usado e quem tem mais minutos.') . '</p>';
    return tsp_cp_campo_html('Time base ' . tsp_de($termo) . ' 2027 (antes dos jogos): 4-4-2', $linhas, $nota);
}
