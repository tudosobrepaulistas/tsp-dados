<?php
/**
 * Página do treinador e da comissão técnica (21/11/2026)
 *   /treinador/<clube>/<nome>/          (treinador)
 *   /comissao-tecnica/<clube>/<nome>/   (auxiliar, preparador físico, treinador de goleiros)
 * O antigo /jogador/<nome>/ de quem é da comissão leva para cá com redirecionamento 301.
 * Dados: api/mercado.json (movimento, ficha, carreira temporada a temporada com J, V, E, D quando a fonte traz).
 * Nada é estimado: aproveitamento só onde há vitórias, empates e derrotas; nos outros anos, % de vitórias.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_tec_e_comissao($p)
{
    return function_exists('tsp_mc_e_comissao_pos') && tsp_mc_e_comissao_pos($p['posicao'] ?? '');
}

function tsp_tec_url($p)
{
    $base = ($p['posicao'] ?? '') === 'Treinador' ? 'treinador' : 'comissao-tecnica';
    // 26/11/2026 (páginas pilares): treinador tem endereço fixo /treinador/<nome>/, que não muda quando ele troca de clube
    if ($base === 'treinador' && !empty($p['url_slug'])) {
        return home_url('/treinador/' . $p['url_slug'] . '/');
    }
    $clube = $p['clube'] ?: 'sem-clube';
    return home_url('/' . $base . '/' . $clube . '/' . sanitize_title(remove_accents($p['nome'])) . '/');
}

function tsp_tec_url_nome($nome)
{
    $n = sanitize_title(remove_accents((string) $nome));
    if ($n === '' || !function_exists('tsp_mc_jogadores')) {
        return '';
    }
    $idx = tsp_mc_jogadores();
    return isset($idx[$n]) && tsp_tec_e_comissao($idx[$n]) ? tsp_tec_url($idx[$n]) : '';
}

add_action('init', function () {
    add_rewrite_rule('^treinador/([a-z0-9-]+)/?$', 'index.php?tsp_tec_tipo=treinador&tsp_tec_nome=$matches[1]', 'top');
    add_rewrite_rule('^pessoas-sitemap\.xml$', 'index.php?tsp_tec_mapa=1', 'top');
    add_rewrite_rule('^(treinador|comissao-tecnica)/([a-z0-9-]+)/([a-z0-9-]+)/?$', 'index.php?tsp_tec_tipo=$matches[1]&tsp_tec_clube=$matches[2]&tsp_tec_nome=$matches[3]', 'top');
    if (get_option('tsp_tec_regras') !== '3') {
        flush_rewrite_rules(false);
        update_option('tsp_tec_regras', '3', true);
    }
});
add_filter('query_vars', function ($v) {
    return array_merge($v, array('tsp_tec_tipo', 'tsp_tec_clube', 'tsp_tec_nome', 'tsp_tec_mapa'));
});

// Conta da carreira como técnico principal
function tsp_tec_totais($carreira)
{
    $t = array('jogos' => 0, 'vitorias' => 0, 'clubes' => array(), 'temporadas' => array(), 'vde' => array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0));
    foreach ((array) $carreira as $c) {
        if (($c['funcao'] ?? 'Treinador') !== 'Treinador') {
            continue;
        }
        $t['jogos'] += (int) ($c['jogos'] ?? 0);
        $t['vitorias'] += (int) ($c['vitorias'] ?? 0);
        $t['clubes'][$c['clube']] = ($t['clubes'][$c['clube']] ?? 0) + (int) ($c['jogos'] ?? 0);
        if (preg_match_all('~(19|20)\d{2}~', (string) $c['temporada'], $mm)) {
            $ys = array_map('intval', $mm[0]);
            for ($y = min($ys); $y <= max($ys); $y++) {
                $t['temporadas'][$y] = 1;
            }
        }
        if (isset($c['empates'], $c['derrotas'])) {
            $t['vde']['j'] += (int) $c['jogos'];
            $t['vde']['v'] += (int) $c['vitorias'];
            $t['vde']['e'] += (int) $c['empates'];
            $t['vde']['d'] += (int) $c['derrotas'];
        }
    }
    return $t;
}

function tsp_tec_pct($a, $b)
{
    return $b ? number_format_i18n(100 * $a / $b, 1) . '%' : '–';
}

// Por temporada (só técnico principal), para o resumo de 2026 e o aproveitamento
function tsp_tec_por_ano($carreira)
{
    $a = array();
    foreach ((array) $carreira as $c) {
        if (($c['funcao'] ?? 'Treinador') !== 'Treinador') {
            continue;
        }
        $y = $c['temporada'];
        $a[$y] = $a[$y] ?? array('j' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'vde' => true, 'clubes' => array());
        $a[$y]['j'] += (int) ($c['jogos'] ?? 0);
        $a[$y]['v'] += (int) ($c['vitorias'] ?? 0);
        $a[$y]['clubes'][] = $c['clube'];
        if (isset($c['empates'], $c['derrotas'])) {
            $a[$y]['e'] += (int) $c['empates'];
            $a[$y]['d'] += (int) $c['derrotas'];
        } else {
            $a[$y]['vde'] = false;
        }
    }
    return $a;
}

// Matérias do TSP: primeiro as que citam o nome; completa com as últimas do clube atual
function tsp_tec_materias($nome, $t)
{
    $ids = array();
    $q = get_posts(array('post_type' => 'post', 's' => $nome, 'sentence' => true, 'posts_per_page' => 6, 'no_found_rows' => true));
    $posts = $q;
    foreach ($q as $x) {
        $ids[] = $x->ID;
    }
    if (count($posts) < 6 && $t) {
        $mais = get_posts(array('post_type' => 'post', 'posts_per_page' => 6 - count($posts), 'post__not_in' => $ids, 'no_found_rows' => true,
            'tax_query' => array(array('taxonomy' => 'times', 'field' => 'term_id', 'terms' => $t->term_id))));
        $posts = array_merge($posts, $mais);
    }
    return $posts;
}

add_action('template_redirect', function () {
    $nome_slug = get_query_var('tsp_tec_nome');
    if (!$nome_slug) {
        return;
    }
    $clube_slug = get_query_var('tsp_tec_clube');
    $p = null;
    if ($clube_slug === '' || $clube_slug === null) {
        $idx = tsp_mc_jogadores();
        if (isset($idx[$nome_slug]) && tsp_tec_e_comissao($idx[$nome_slug])) {
            $p = $idx[$nome_slug];
        }
    }
    foreach (($p ? array() : tsp_mc_jogadores()) as $x) {
        if (tsp_tec_e_comissao($x) && sanitize_title(remove_accents($x['nome'])) === $nome_slug && (($x['clube'] ?: 'sem-clube') === $clube_slug)) {
            $p = $x;
            break;
        }
    }
    if (!$p) {
        if (function_exists('tsp_404_real')) {
            tsp_404_real();
        }
        return;
    }
    $canon = tsp_tec_url($p);
    if (untrailingslashit($canon) !== untrailingslashit(home_url(strtok($_SERVER['REQUEST_URI'] ?? '', '?')))) {
        wp_safe_redirect($canon, 301);
        exit;
    }
    tsp_tec_pagina($p, $canon);
    exit;
});


// 22/11/2026: jogos do técnico na base do TSP (api/tecnicos.json, fichas técnicas com fonte)
function tsp_tec_base($nome)
{
    if (!function_exists('tsp_mc_arquivo')) {
        return null;
    }
    $d = tsp_mc_arquivo('tecnicos.json');
    $k = sanitize_title(remove_accents($nome));
    return $d['tecnicos'][$k] ?? null;
}

function tsp_tec_base_html($b)
{
    if (!$b || empty($b['jogos'])) {
        return '';
    }
    // 25/11/2026: é recorte, não total (regra do Thiago): diz quantos jogos e de quando a quando
    $ds = array();
    foreach ((array) ($b['lista'] ?? array()) as $g) {
        if (!empty($g['data'])) {
            $ds[] = strtotime($g['data'] . ' 12:00');
        }
    }
    $per = $ds ? ', de ' . wp_date('d/m/Y', min($ds)) . ' a ' . wp_date('d/m/Y', max($ds)) : '';
    $h = '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Recorte: últimos ' . (int) $b['jogos'] . ' jogos na base do TSP</h2><span class="tsp-secao__sub">' . esc_html('Só partidas com ficha técnica registrada' . $per . '. Não é o total da carreira nem da temporada.') . '</span></div></div>';
    $h .= '<div class="tsp-jog__nums">';
    foreach (array(array($b['jogos'], 'jogos'), array($b['V'], 'vitórias'), array($b['E'], 'empates'), array($b['D'], 'derrotas'), array(number_format_i18n($b['aproveitamento'], 1) . '%', 'aproveitamento'), array($b['gp'] . ':' . $b['gc'], 'gols pró/contra')) as $c) {
        $h .= '<div><b>' . esc_html($c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
    }
    $h .= '</div>';
    if (!empty($b['competicoes'])) {
        $h .= '<div class="tsp-tabela-rolagem"><table class="tsp-tabela"><thead><tr><th>Competição</th><th>J</th><th>V</th><th>E</th><th>D</th></tr></thead><tbody>';
        foreach ($b['competicoes'] as $c) {
            $h .= '<tr><td>' . esc_html($c['nome']) . '</td><td>' . (int) $c['jogos'] . '</td><td>' . (int) $c['V'] . '</td><td>' . (int) $c['E'] . '</td><td>' . (int) $c['D'] . '</td></tr>';
        }
        $h .= '</tbody></table></div>';
    }
    $ult = array_slice((array) $b['lista'], 0, 10);
    if ($ult) {
        $h .= '<h3>Últimos jogos</h3><div class="tsp-tabela-rolagem"><table class="tsp-tabela"><thead><tr><th>Data</th><th>Jogo</th><th>Placar</th><th>Técnico adversário</th></tr></thead><tbody>';
        foreach ($ult as $g) {
            $adv = $g['adversario_nome'] ?? $g['adversario'];
            $h .= '<tr><td>' . esc_html(wp_date('d/m/Y', strtotime($g['data'] . ' 12:00'))) . '</td><td>' . ($g['mando'] === 'casa' ? 'x ' : '@ ') . esc_html($adv) . '</td><td><b class="tsp-res tsp-res--' . esc_attr(strtolower($g['res'])) . '">' . esc_html($g['placar']) . '</b></td><td>' . esc_html($g['tecnico_adversario'] ?: '–') . '</td></tr>';
        }
        $h .= '</tbody></table></div>';
    }
    $contra = (array) ($b['contra'] ?? array());
    uasort($contra, function ($a, $c) {
        return $c['jogos'] <=> $a['jogos'];
    });
    $contra = array_slice($contra, 0, 8);
    if ($contra) {
        $h .= '<h3>Confrontos contra outros técnicos (no recorte)</h3><ul class="tsp-tecp__contra">';
        foreach ($contra as $c) {
            $h .= '<li><b>' . esc_html($c['nome']) . '</b>: ' . (int) $c['jogos'] . ' jogo' . ($c['jogos'] > 1 ? 's' : '') . ' (' . (int) $c['V'] . 'V ' . (int) $c['E'] . 'E ' . (int) $c['D'] . 'D)</li>';
        }
        $h .= '</ul>';
    }
    $h .= '<p class="tsp-nota">Recorte dos ' . (int) $b['jogos'] . ' jogos com ficha técnica registrada na base do TSP (2026 em diante): a base ainda está recebendo as rodadas anteriores e cresce todo dia.</p></section>';
    return $h;
}

function tsp_tec_pagina($p, $canon)
{
    $t = $p['clube'] ? get_term_by('slug', $p['clube'], 'times') : null;
    $clube_nome = $t ? $t->name : '';
    $f = (array) ($p['ficha'] ?? array());
    $func = $p['posicao'] ?: 'Treinador';
    $principal = $func === 'Treinador';
    $idade = tsp_mc_idade($p['nascimento'] ?? '') ?: (int) ($f['idade'] ?? 0);
    $car = (array) ($p['carreira'] ?? array());
    $tot = tsp_tec_totais($car);
    $ano = tsp_tec_por_ano($car);
    $a26 = $ano['2026'] ?? null;
    // 23/11/2026 (Thiago): número de técnico só sai completo e conferido. Enquanto a carreira inteira não estiver
    // levantada (ficha.carreira_completa), não aparece total, aproveitamento nem número por temporada.
    $completa = !empty($f['carreira_completa']);
    if (!$completa) {
        $tot['jogos'] = 0;
        $tot['vitorias'] = 0;
        $a26 = null;
    }
    $acessos = array_values(array_filter((array) ($f['acessos'] ?? array())));
    $titulos = array_values(array_filter((array) ($f['titulos'] ?? array())));
    $clubes = array_keys($tot['clubes']);
    $antes = array();
    foreach ($car as $c) {
        if (($c['funcao'] ?? 'Treinador') !== 'Treinador') {
            $antes[$c['clube']] = 1;
        }
    }
    $de = mb_strtolower($func);
    $artigo = $t && function_exists('tsp_de') ? tsp_de($t) : ($clube_nome ? 'do ' . $clube_nome : '');

    // Resposta rápida
    $apel = trim(preg_replace('~\s*\([^)]*\)~', '', (string) ($f['conhecido_como'] ?? '')));
    $anos_car = array();
    foreach ($car as $c) {
        if (preg_match_all('~(19|20)\d{2}~', (string) ($c['temporada'] ?? ''), $mm)) {
            $anos_car = array_merge($anos_car, array_map('intval', $mm[0]));
        }
    }
    $desde = $anos_car ? min($anos_car) : 0;
    $resumo = $p['nome'] . ($apel ? ', conhecido como ' . $apel . ',' : '') . ' é ' . $de . ($artigo ? ' ' . $artigo : '') . ' para 2027' . ($idade ? ', tem ' . $idade . ' anos' : '') . '.'
        . (!empty($f['natural']) ? ' Natural de ' . $f['natural'] . '.' : '')
        . (($acessos || $titulos) ? ' Soma ' . ($acessos ? count($acessos) . ' acesso' . (count($acessos) > 1 ? 's' : '') : '') . ($acessos && $titulos ? ' e ' : '') . ($titulos ? count($titulos) . ' título' . (count($titulos) > 1 ? 's' : '') : '') . ' conferidos pelo TSP' . ($desde ? ' em uma carreira iniciada em ' . $desde : '') . '.' : '');
    if ($tot['jogos']) {
        $resumo .= ' Como técnico principal, soma ' . $tot['jogos'] . ' jogos e ' . $tot['vitorias'] . ' vitórias (' . tsp_tec_pct($tot['vitorias'], $tot['jogos']) . ') em ' . count($clubes) . ' clubes, de ' . min(array_keys($tot['temporadas'])) . ' a ' . max(array_keys($tot['temporadas'])) . '.';
    }
    if ($a26 && $a26['vde'] && $a26['j']) {
        $resumo .= ' Em 2026: ' . $a26['j'] . ' jogos, ' . $a26['v'] . 'V ' . $a26['e'] . 'E ' . $a26['d'] . 'D, aproveitamento de ' . tsp_tec_pct($a26['v'] * 3 + $a26['e'], $a26['j'] * 3) . '.';
    }
    $titulo = $p['nome'] . (!empty($f['nome_completo']) && $f['nome_completo'] !== $p['nome'] ? ' (' . $f['nome_completo'] . ')' : '') . ': trajetória, números e carreira' . ($clube_nome ? ' no ' . $clube_nome : '');

    // 26/11/2026: página pilar (api/pessoas.json) traz título, resposta rápida e descrição escritos à mão
    $pil = (array) ($p['pilar'] ?? array());
    if (!empty($pil['resposta_rapida'])) {
        $resumo = $pil['resposta_rapida'];
    }
    if (!empty($pil['titulo'])) {
        $titulo = $pil['titulo'];
    }
    $desc = !empty($pil['descricao']) ? $pil['descricao'] : mb_substr($resumo, 0, 155);
    $pil_h2 = array();
    foreach ((array) ($pil['secoes'] ?? array()) as $s) {
        $pil_h2[] = mb_strtolower(trim($s['h2'] ?? ''));
    }
    foreach (array('pre_get_document_title', 'wpseo_title', 'wpseo_opengraph_title') as $fl) {
        add_filter($fl, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    foreach (array('wpseo_metadesc', 'wpseo_opengraph_desc') as $fl) {
        add_filter($fl, function () use ($desc) {
            return $desc;
        }, 99);
    }
    foreach (array('wpseo_canonical', 'wpseo_opengraph_url') as $fl) {
        add_filter($fl, function () use ($canon) {
            return $canon;
        }, 99);
    }
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
    $foto = (array) ($p['foto'] ?? array());
    echo '<main class="tsp-container tsp-jog tsp-tecp">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › '
        . ($t ? '<a href="' . esc_url(get_term_link($t)) . '">' . esc_html($clube_nome) . '</a> › ' : '')
        . '<a href="' . esc_url(home_url('/mercado-da-bola/treinadores/')) . '">Treinadores</a> › <span>' . esc_html($p['nome']) . '</span></nav>';

    // Cabeçalho
    echo '<header class="tsp-jog__cab"><div class="tsp-jog__foto">' . tsp_mc_foto($p['nome'], $foto, 220, false) . '</div><div class="tsp-jog__id">';
    echo '<p class="tsp-tecp__func">' . esc_html($func . ($clube_nome ? ' · ' . $clube_nome : '')) . '</p><h1>' . esc_html($titulo) . '</h1>';
    if ($t) {
        echo '<a class="tsp-jog__clube" href="' . esc_url(get_term_link($t)) . '">' . tsp_escudo($t, 28) . '<span>' . esc_html($clube_nome) . (!empty($p['saiu']) ? ' (saiu)' : ' · 2027') . '</span></a>';
    }
    echo '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resumo) . '</p></div>';
    echo '</div></header>';

    ob_start();
    // Ficha técnica e resumo profissional (modelo pedido pelo Thiago, 21/11/2026)
    $conq = array_merge($titulos, $acessos);
    // 22/11/2026 (Thiago): mostrar todos os campos; o que ainda não foi levantado aparece como "Em atualização"
    $linhas = array(
        'Nome completo' => $f['nome_completo'] ?? '',
        'Apelido' => $f['apelido'] ?? '',
        'Naturalidade' => $f['natural'] ?? '',
        'Nascimento' => !empty($p['nascimento']) ? wp_date('d/m/Y', strtotime($p['nascimento'] . ' 12:00')) . ($idade ? ' (' . $idade . ' anos)' : '') : ($idade ? $idade . ' anos' : ''),
        'Cargo atual' => (!$p['clube'] && !empty($p['situacao'])) ? $p['situacao'] : $func . ($artigo ? ' ' . $artigo : ''),
        'Contrato' => $f['contrato'] ?? '',
        'Posição como jogador' => $f['posicao_jogador'] ?? '',
        'Formação acadêmica' => $f['formacao'] ?? '',
        'Esquema tático preferido' => $f['esquema'] ?? '',
        'Início na comissão técnica' => $f['inicio_comissao'] ?? '',
    );
    if ($apel) {
        $linhas = array_slice($linhas, 0, 1, true) + array('Conhecido como' => $apel) + array_slice($linhas, 1, null, true);
    }
    if (empty($linhas['Apelido'])) {
        unset($linhas['Apelido']);
    }
    unset($linhas[$principal ? 'Início na comissão técnica' : 'Posição como jogador']);
    if (!$principal) {
        unset($linhas['Esquema tático preferido']);
    }
    echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Ficha técnica e resumo profissional</h2></div></div><dl class="tsp-tecp__ficha">';
    foreach ($linhas as $k => $v) {
        echo '<div' . ($v === '' ? ' class="tsp-tecp__vazio"' : '') . '><dt>' . esc_html($k) . '</dt><dd>' . ($v === '' ? 'Em atualização' : esc_html($v)) . '</dd></div>';
    }
    $rh = function_exists('tsp_mc_redes_html') ? tsp_mc_redes_html($f) : '';
    echo '<div' . ($rh === '' ? ' class="tsp-tecp__vazio"' : '') . '><dt>Redes sociais</dt><dd>' . ($rh === '' ? 'Em atualização' : $rh) . '</dd></div>'; // phpcs:ignore
    echo '</dl>';
    // Raio-X em números grandes (só o que está conferido)
    $rx = array_filter(array(
        $acessos ? array(count($acessos), count($acessos) > 1 ? 'acessos' : 'acesso') : null,
        $titulos ? array(count($titulos), count($titulos) > 1 ? 'títulos' : 'título') : null,
        ($nclub = count(array_unique(array_map(function ($c) { return $c['clube'] ?? ''; }, $car)))) ? array($nclub, $nclub > 1 ? 'clubes' : 'clube') : null,
        $desde ? array($desde, 'início da carreira') : null,
    ));
    if (count($rx) >= 2) {
        echo '<div class="tsp-jog__nums tsp-tecp__rx">';
        foreach ($rx as $c) {
            echo '<div><b>' . esc_html($c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
        }
        echo '</div>';
    }
    $hist = array_filter(array($f['inicio'] ?? '', $f['no_clube'] ?? ''));
    foreach ($hist as $h) {
        echo '<p class="tsp-tecp__inicio">' . esc_html(rtrim($h, '.')) . '.</p>';
    }
    echo '</section>';

    $h_ficha = ob_get_clean();
    ob_start();
    // Página pilar (26/11/2026): pergunta em H2, resposta direta de até 55 palavras e o aprofundamento
    foreach ((array) ($pil['secoes'] ?? array()) as $s) {
        if (empty($s['h2']) || empty($s['resposta'])) {
            continue;
        }
        echo '<section class="tsp-secao tsp-secao--caixa tsp-pilar"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($s['h2']) . '</h2></div></div>';
        echo '<p class="tsp-pilar__resp">' . esc_html($s['resposta']) . '</p>';
        foreach ((array) ($s['texto'] ?? array()) as $par) {
            echo '<p class="tsp-pilar__txt">' . esc_html($par) . '</p>';
        }
        // Tabela da seção (marcos, números por clube): dado em tabela é o que as IAs e o Google mais citam
        if (!empty($s['tabela']['linhas'])) {
            echo '<details class="tsp-pilar__mais"><summary>' . esc_html($s['tabela']['titulo'] ?? 'Ver a tabela completa') . ' <small>(' . count($s['tabela']['linhas']) . ' linhas)</small></summary><div class="tsp-tabela-rolagem"><table class="tsp-tabela tsp-pilar__tab"><thead><tr>';
            foreach ((array) ($s['tabela']['cab'] ?? array()) as $c) {
                echo '<th>' . esc_html($c) . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ($s['tabela']['linhas'] as $l) {
                echo '<tr' . (preg_match('~^(Total|Próxim)~u', (string) ($l[0] ?? '')) ? ' class="tsp-pilar__dest"' : '') . '>';
                foreach ((array) $l as $c) {
                    echo '<td>' . esc_html($c) . '</td>';
                }
                echo '</tr>';
            }
            echo '</tbody></table></div></details>';
        }
        echo '</section>';
    }

    $h_pilar = ob_get_clean();
    ob_start();
    // Entrevista ao TSP Exclusiva (conteúdo próprio do TSP: vídeo, cortes e perguntas)
    $ep = (!empty($p['exclusiva']) && function_exists('tsp_exclusiva_por_n')) ? tsp_exclusiva_por_n($p['exclusiva']) : null;
    if ($ep) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-tecp__excl"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Entrevista de ' . esc_html($p['nome']) . ' ao TSP Exclusiva</h2><span class="tsp-secao__sub">' . esc_html('Episódio #' . (int) $ep['n'] . ' · ' . tsp_exclusiva_data_longa($ep['data'])) . '</span></div></div>';
        $pl = str_replace('<span class="tsp-excl__novo">Novo episódio</span>', '', tsp_exclusiva_player($ep, true));
        echo '<div class="tsp-excl" style="--excl-cor:' . esc_attr(tsp_exclusiva_cor($ep)) . '">' . $pl . '</div></section>'; // phpcs:ignore
    }

    $h_excl = ob_get_clean();
    ob_start();
    // Estilo de jogo (citação com fonte); na página pilar a pergunta já está acima
    $tem_estilo = (bool) array_filter($pil_h2, function ($h) {
        return strpos($h, 'estilo') !== false;
    });
    if ($principal && !empty($f['estilo']) && !$tem_estilo) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-tecp__estilo"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Qual é o estilo de jogo de ' . esc_html($p['nome']) . '?</h2></div></div><blockquote>' . esc_html(rtrim($f['estilo'], '.')) . '.</blockquote></section>';
    }

    $h_estilo = ob_get_clean();
    ob_start();
    // Números da carreira
    if ($tot['jogos']) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Números da carreira</h2><span class="tsp-secao__sub">Como técnico principal</span></div></div><div class="tsp-jog__nums">';
        $cx = array(
            array($tot['jogos'], 'jogos'), array($tot['vitorias'], 'vitórias'), array(tsp_tec_pct($tot['vitorias'], $tot['jogos']), 'de vitórias'),
            array(count($clubes), count($clubes) === 1 ? 'clube' : 'clubes'), array(count($tot['temporadas']), 'temporadas'),
            array(count($acessos), count($acessos) === 1 ? 'acesso' : 'acessos'), array(count($titulos), count($titulos) === 1 ? 'título' : 'títulos'),
        );
        foreach ($cx as $c) {
            echo '<div><b>' . esc_html(is_int($c[0]) ? number_format_i18n($c[0]) : $c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
        }
        echo '</div>';
        if ($a26 && $a26['j']) {
            echo '<div class="tsp-tecp__ano"><b>2026</b> ' . esc_html(implode(', ', array_unique($a26['clubes']))) . ': ' . (int) $a26['j'] . ' jogos · '
                . ($a26['vde'] ? (int) $a26['v'] . ' vitória' . ($a26['v'] == 1 ? '' : 's') . ', ' . (int) $a26['e'] . ' empate' . ($a26['e'] == 1 ? '' : 's') . ', ' . (int) $a26['d'] . ' derrota' . ($a26['d'] == 1 ? '' : 's') . ' · <b>aproveitamento ' . esc_html(tsp_tec_pct($a26['v'] * 3 + $a26['e'], $a26['j'] * 3)) . '</b>' : (int) $a26['v'] . ' vitórias') . '</div>';
        }
        echo '</section>';
    }

    // "Jogos na base do TSP" saiu (23/11/2026): é parcial por natureza. Volta só como complemento de carreira completa.
    if ($completa) {
        echo tsp_tec_base_html(tsp_tec_base($p['nome'])); // phpcs:ignore
    } elseif ($principal) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Números da carreira</h2></div></div><p class="tsp-tecp__inicio"><b>Em atualização.</b> O TSP só publica jogos, vitórias e aproveitamento de ' . esc_html($p['nome']) . ' quando todos os trabalhos da carreira estiverem conferidos em fonte. Número parcial não entra.</p></section>';
    }

    $h_num = ob_get_clean();
    ob_start();
    // Títulos, acessos e destaques em linha do tempo (ano em destaque, mais recente primeiro)
    $destaques = array_values(array_filter((array) ($f['destaques'] ?? array())));
    $limpa = function ($t) {
        return trim(preg_replace('~\s*\((?=[^)]*(\d{2}/\d{2}|Futebol Interior|Correio|Trivela|Ag[êe]ncia|Lance|Gazeta|ge\b|UOL|Jovem Pan))[^)]*\)~u', '', (string) $t));
    };
    $linha = array();
    foreach ($titulos as $t) {
        $linha[] = array('tipo' => 'titulo', 'txt' => $limpa($t));
    }
    foreach ($acessos as $t) {
        $linha[] = array('tipo' => 'acesso', 'txt' => $limpa($t));
    }
    foreach ($linha as &$l) {
        $l['ano'] = preg_match('~(19|20)\d{2}~', $l['txt'], $m) ? (int) $m[0] : 0;
    }
    unset($l);
    usort($linha, function ($a, $b) {
        return $b['ano'] <=> $a['ano'];
    });
    if ($linha || $destaques) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Títulos e acessos de ' . esc_html($p['nome']) . '</h2>' . ($linha ? '<span class="tsp-secao__sub">' . count($titulos) . ' título' . (count($titulos) == 1 ? '' : 's') . ' · ' . count($acessos) . ' acesso' . (count($acessos) == 1 ? '' : 's') . '</span>' : '') . '</div></div>';
        if ($linha) {
            echo '<ol class="tsp-tl">';
            foreach ($linha as $l) {
                $txt = preg_replace('~^(Campe[aã]o|Acesso)\s~u', '$1 ', $l['txt']);
                echo '<li class="tsp-tl__i tsp-tl__i--' . $l['tipo'] . '"><span class="tsp-tl__ano">' . ($l['ano'] ?: '–') . '</span><span class="tsp-tl__ico" aria-hidden="true">' . ($l['tipo'] === 'titulo' ? '🏆' : '⬆') . '</span><span class="tsp-tl__txt">' . esc_html($txt) . '</span></li>';
            }
            echo '</ol>';
        }
        if ($destaques) {
            echo '<h3>Feitos marcantes</h3><ul class="tsp-tecp__feitos">';
            foreach (array_slice($destaques, 0, 6) as $d) {
                echo '<li>' . esc_html($limpa($d)) . '</li>';
            }
            echo '</ul>';
        }
        echo '</section>';
    }

    $h_tit = ob_get_clean();
    // 26/11/2026 (Thiago): página pilar mais harmônica. Começa resumida (números grandes + ficha + conquistas),
    // depois a entrevista em vídeo e só então as perguntas com o aprofundamento e as tabelas.
    if ($pil) {
        $cards = array();
        if ($tot['jogos']) {
            $cards[] = array(number_format_i18n($tot['jogos']), 'jogos');
            $cards[] = array(number_format_i18n($tot['vitorias']), 'vitórias');
            if ($tot['vde']['j']) {
                $cards[] = array(tsp_tec_pct($tot['vde']['v'] * 3 + $tot['vde']['e'], $tot['vde']['j'] * 3), 'aproveitamento');
            }
        }
        if ($titulos) {
            $cards[] = array(count($titulos), count($titulos) > 1 ? 'títulos' : 'título');
        }
        if ($acessos) {
            $cards[] = array(count($acessos), count($acessos) > 1 ? 'acessos' : 'acesso');
        }
        $nc = count(array_unique(array_map(function ($c) { return $c['clube'] ?? ''; }, $car)));
        if ($nc) {
            $cards[] = array($nc, $nc > 1 ? 'clubes' : 'clube');
        }
        if (count($cards) < 6 && $desde) {
            $cards[] = array($desde, 'início da carreira');
        }
        if ($cards) {
            echo '<section class="tsp-pilar__resumo" aria-label="' . esc_attr($p['nome'] . ' em números') . '">';
            foreach ($cards as $c) {
                echo '<div><b>' . esc_html($c[0]) . '</b><span>' . esc_html($c[1]) . '</span></div>';
            }
            echo '</section>';
            $h_ficha = preg_replace('~<div class="tsp-jog__nums tsp-tecp__rx">.*?</div></div>~s', '', $h_ficha);
            $h_ficha = preg_replace('~<div class="tsp-jog__nums tsp-tecp__rx">(?:<div><b>.*?</b><span>.*?</span></div>)+</div>~s', '', $h_ficha);
        }
        echo $h_ficha . $h_tit . $h_excl . $h_pilar . $h_estilo; // phpcs:ignore
        if (!$tot['jogos']) {
            echo $h_num; // phpcs:ignore
        }
    } else {
        echo $h_ficha . $h_pilar . $h_excl . $h_estilo . $h_num . $h_tit; // phpcs:ignore
    }

    // Trajetória: passagens seguidas no mesmo clube viram uma linha; colunas de números só se houver números
    if ($car) {
        $grupos = array();
        foreach ($car as $c) {
            $k = ($c['clube'] ?? '') . '|' . ($c['funcao'] ?? 'Treinador');
            $ult = end($grupos);
            if ($ult && $ult['k'] === $k && empty($c['jogos']) && empty($ult['jogos']) && empty($c['obs']) && empty($ult['obs'])) {
                $grupos[key($grupos)]['anos'][] = $c['temporada'] ?? '';
                continue;
            }
            $grupos[] = array_merge($c, array('k' => $k, 'anos' => array($c['temporada'] ?? '')));
        }
        $com_num = $completa && (bool) array_filter($car, function ($c) {
            return !empty($c['jogos']);
        });
        // Observação da trajetória: sem notas internas de apuração (fontes, "1 fonte", "números em atualização")
        $obs_limpa = function ($o) use ($limpa) {
            $partes = array_filter(array_map('trim', explode(';', (string) $o)), function ($x) {
                return $x !== '' && !preg_match('~fonte|confer|ano s[óo]|atualiza|n[úu]meros|\b(CB|DGABC|DOL|FI|ge)\b~iu', $x);
            });
            $o = preg_replace('~\s*\((?=[^)]*(Band|Vale|Itatiaia|DGABC|DOL|ABC do ABC|Correio|Jovem Pan|Trivela|Futebol Interior|\d{2}/\d{2}/\d{4}))[^)]*\)~u', '', implode('; ', $partes));
            return $limpa(preg_replace('~^ABC do ABC[^;]*;?\s*~u', '', $o));
        };
        foreach ($grupos as &$g) {
            $g['obs'] = $obs_limpa($g['obs'] ?? '');
        }
        unset($g);
        $com_obs = (bool) array_filter($grupos, function ($c) {
            return $c['obs'] !== '';
        });
        $h2_traj = 'Por quais clubes ' . $p['nome'] . ' passou?';
        if (in_array(mb_strtolower($h2_traj), $pil_h2, true)) {
            $h2_traj = 'Trajetória de ' . $p['nome'] . ' temporada a temporada';
        }
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__carreira"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($h2_traj) . '</h2><span class="tsp-secao__sub">' . esc_html(count($grupos) . ' passagens' . (!empty($p['carreira_fonte']) ? ' · Fontes: ' . $p['carreira_fonte'] : '')) . '</span></div></div>';
        echo '<div class="tsp-tabela-rolagem"><table class="tsp-tabela tsp-tecp__traj"><thead><tr><th>Ano</th><th>Clube</th><th>Função</th>' . ($com_num ? '<th>J</th><th>V</th><th>E</th><th>D</th><th>Aprov.</th>' : '') . ($com_obs ? '<th>Destaque</th>' : '') . '</tr></thead><tbody>';
        foreach ($grupos as $c) {
            $anos = array();
            foreach ($c['anos'] as $a) {
                if (preg_match_all('~(19|20)\d{2}~', (string) $a, $mm)) {
                    $anos = array_merge($anos, array_map('intval', $mm[0]));
                }
            }
            $per = $anos ? (min($anos) === max($anos) ? min($anos) : min($anos) . '–' . max($anos)) : implode(', ', $c['anos']);
            $term = get_term_by('name', $c['clube'] ?? '', 'times');
            $logo = $term ? tsp_escudo($term, 22) : tsp_mc_escudo(array('nome' => $c['clube'] ?? '', 'escudo' => $c['escudo'] ?? ''), 22);
            if (!empty($c['escudo']) && !$term) {
                $logo = '<span class="tsp-ge__esc"><img src="' . esc_url($c['escudo']) . '" alt="Escudo do ' . esc_attr($c['clube']) . '" width="22" height="22" loading="lazy" style="object-fit:contain"></span>';
            }
            $u_c = function_exists('tsp_clube_url') ? tsp_clube_url($c['clube'] ?? '') : ($term ? get_term_link($term) : '');
            $nome_c = $u_c ? '<a href="' . esc_url($u_c) . '">' . esc_html($c['clube']) . '</a>' : esc_html($c['clube'] ?? '');
            echo '<tr' . (($c['funcao'] ?? 'Treinador') !== 'Treinador' ? ' class="tsp-tecp__outra"' : '') . '><td>' . esc_html($per) . '</td><td><span class="tsp-fig__clube">' . (strpos($logo, '<img') !== false ? $logo : '') . $nome_c . '</span></td><td>' . esc_html($c['funcao'] ?? 'Treinador') . '</td>';
            if ($com_num) {
                $j = $c['jogos'] ?? null;
                $vde = isset($c['vitorias'], $c['empates'], $c['derrotas']) && $j;
                $aprov = $vde ? tsp_tec_pct($c['vitorias'] * 3 + $c['empates'], $j * 3) : ($j && isset($c['vitorias']) ? tsp_tec_pct($c['vitorias'], $j) . '<small> vit.</small>' : '–');
                echo '<td>' . esc_html($j ?? '–') . '</td><td>' . esc_html($c['vitorias'] ?? '–') . '</td><td>' . esc_html($c['empates'] ?? '–') . '</td><td>' . esc_html($c['derrotas'] ?? '–') . '</td><td>' . $aprov . '</td>';
            }
            if ($com_obs) {
                echo '<td class="tsp-tecp__obs">' . esc_html($c['obs'] ?? '') . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table></div>' . ($com_num ? '<p class="tsp-nota">Aproveitamento = pontos ganhos ÷ pontos disputados, só nas temporadas em que vitórias, empates e derrotas foram conferidos.</p>' : '') . '</section>';
    } else {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__carreira"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Trajetória temporada a temporada</h2></div></div><p class="tsp-atualiza">Em atualização</p></section>';
    }

    // Clubes
    if (!$car && ($clubes || $antes)) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Clubes em que trabalhou</h2></div></div><div class="tsp-tecp__clubes">';
        arsort($tot['clubes']);
        foreach ($tot['clubes'] as $cl => $j) {
            $logo = tsp_mc_escudo(array('nome' => $cl), 28);
            echo '<a class="tsp-tecp__clube" href="' . esc_url(function_exists('tsp_clube_url') ? tsp_clube_url($cl) : '#') . '">' . (strpos($logo, '<img') !== false ? $logo : '') . '<b>' . esc_html($cl) . '</b><small>' . (($j && $completa) ? (int) $j . ' jogos como técnico' : 'técnico') . '</small></a>';
        }
        foreach (array_keys($antes) as $cl) {
            if (isset($tot['clubes'][$cl])) {
                continue;
            }
            $logo = tsp_mc_escudo(array('nome' => $cl), 28);
            echo '<a class="tsp-tecp__clube" href="' . esc_url(function_exists('tsp_clube_url') ? tsp_clube_url($cl) : '#') . '">' . (strpos($logo, '<img') !== false ? $logo : '') . '<b>' . esc_html($cl) . '</b><small>comissão técnica</small></a>';
        }
        echo '</div></section>';
    }

    // Mercado
    if (!empty($p['movimentos'])) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-jog__mercado"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Mercado da Bola</h2></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url(home_url('/mercado-da-bola/treinadores/')) . '">Todos os treinadores →</a></span></div><ul class="tsp-jog__movs">';
        foreach ($p['movimentos'] as $m) {
            $rota = ($m['tipo'] ?? '') === 'renovacao' ? 'segue no ' . ($m['para']['nome'] ?? '') : trim(($m['de']['nome'] ?? '') . (!empty($m['para']['nome']) ? ' → ' . $m['para']['nome'] : ''), ' →');
            echo '<li><time datetime="' . esc_attr($m['data']) . '">' . esc_html(wp_date('d/m/Y', strtotime($m['data'] . ' 12:00'))) . '</time> <b>' . esc_html($m['tipo_nome'] ?? '') . '</b> ' . esc_html($rota)
                . (!empty($m['obs']) ? ' <small>' . esc_html($m['obs']) . '</small>' : '') . '</li>';
        }
        echo '</ul></section>';
    }

    // Matérias do TSP
    $mats = tsp_tec_materias($p['nome'], $t);
    if ($mats) {
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Matérias do TSP</h2></div></div><ul class="tsp-tecp__mats">';
        foreach ($mats as $x) {
            echo '<li><a href="' . esc_url(get_permalink($x)) . '">' . esc_html(get_the_title($x)) . '</a> <time datetime="' . esc_attr(get_the_date('c', $x)) . '">' . esc_html(get_the_date('d/m/Y', $x)) . '</time></li>';
        }
        echo '</ul></section>';
    }

    // Na imprensa: matérias de outros portais usadas na apuração (links de saída, só fontes aceitas)
    $links = array();
    foreach (array_merge((array) ($f['fontes'] ?? array()), array($f['fonte'] ?? ''), (array) ($p['movimentos'][0]['fontes'] ?? array())) as $u) {
        if (!is_string($u) || strpos($u, 'http') !== 0 || strpos($u, 'tudosobrepaulista') !== false || preg_match('~instagram|facebook|twitter|x\.com|wikipedia|transfermarkt|sofascore|ogol~i', $u)) {
            continue;
        }
        $links[$u] = 1;
    }
    if ($links) {
        $mapa = array('ge.globo' => 'ge', 'globo.com' => 'ge', 'uol' => 'UOL', 'lance' => 'Lance!', 'gazetaesportiva' => 'Gazeta Esportiva', 'futebolinterior' => 'Futebol Interior', 'correiobraziliense' => 'Correio Braziliense', 'trivela' => 'Trivela', 'agenciabrasil' => 'Agência Brasil', 'jovempan' => 'Jovem Pan', 'opovo' => 'O Povo', 'terra' => 'Terra', 'estadao' => 'Estadão', 'folha' => 'Folha', 'cnnbrasil' => 'CNN Brasil', 'espn' => 'ESPN');
        echo '<section class="tsp-secao tsp-secao--caixa"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($p['nome']) . ' na imprensa</h2><span class="tsp-secao__sub">Reportagens usadas na apuração do TSP</span></div></div><ul class="tsp-tecp__imprensa">';
        foreach (array_slice(array_keys($links), 0, 10) as $u) {
            $host = preg_replace('~^www\.~', '', (string) wp_parse_url($u, PHP_URL_HOST));
            $nome_v = $host;
            foreach ($mapa as $k => $v) {
                if (strpos($host, $k) !== false) {
                    $nome_v = $v;
                    break;
                }
            }
            $slug = trim((string) wp_parse_url($u, PHP_URL_PATH), '/');
            $slug = ucfirst(str_replace(array('-', '_'), ' ', preg_replace('~\.(html?|php)$~', '', basename($slug))));
            echo '<li><a href="' . esc_url($u) . '" target="_blank" rel="noopener"><b>' . esc_html($nome_v) . '</b><span>' . esc_html(mb_strimwidth($slug, 0, 90, '…')) . '</span></a></li>';
        }
        echo '</ul></section>';
    }

    // Perguntas frequentes (respondidas com os dados da página)
    $faq = array();
    $faq[] = array('Quem é ' . $p['nome'] . '?', !empty($pil['resposta_rapida']) ? $pil['resposta_rapida'] : $p['nome'] . (!empty($f['nome_completo']) ? ' (' . $f['nome_completo'] . ')' : '') . ' é ' . $de . ($artigo ? ' ' . $artigo : '') . ($idade ? ', tem ' . $idade . ' anos' : '') . '.' . (!empty($f['inicio']) ? ' ' . $f['inicio'] . '.' : ''));
    if ($clube_nome) {
        $faq[] = array('Qual é o clube de ' . $p['nome'] . ' em 2027?', $p['nome'] . (!empty($p['saiu']) ? ' deixou o ' . $clube_nome . '.' : ' é ' . $de . ' ' . $artigo . ' para a temporada 2027.' . (!empty($f['no_clube']) ? ' ' . $f['no_clube'] . '.' : '')));
    }
    if (!empty($f['natural'])) {
        $faq[] = array('De onde é ' . $p['nome'] . '?', $p['nome'] . ' é natural de ' . $f['natural'] . '.');
    }
    // 22/11/2026: intenções de busca (estilo, esquema, formação, idade, acessos) — só com dado conferido
    if ($idade) {
        $faq[] = array('Quantos anos tem ' . $p['nome'] . '?', $p['nome'] . ' tem ' . $idade . ' anos' . (!empty($p['nascimento']) ? ' (nasceu em ' . wp_date('d/m/Y', strtotime($p['nascimento'] . ' 12:00')) . ')' : '') . '.');
    }
    if (!empty($f['estilo'])) {
        $faq[] = array('Qual é o estilo de jogo de ' . $p['nome'] . '?', rtrim($f['estilo'], '.') . '.');
    }
    if (!empty($f['esquema'])) {
        $faq[] = array('Qual é o esquema tático preferido de ' . $p['nome'] . '?', rtrim($f['esquema'], '.') . '.');
    }
    if (!empty($f['formacao'])) {
        $faq[] = array('Qual é a formação de ' . $p['nome'] . '?', rtrim($f['formacao'], '.') . '.');
    }
    if ($acessos) {
        $faq[] = array('Quantos acessos ' . $p['nome'] . ' tem na carreira?', count($acessos) . ' acesso' . (count($acessos) > 1 ? 's' : '') . ' conferido' . (count($acessos) > 1 ? 's' : '') . ' pelo TSP: ' . implode('; ', $acessos) . '.');
    }
    if (!empty($f['posicao_jogador'])) {
        $faq[] = array('Qual era a posição de ' . $p['nome'] . ' quando jogava futebol?', 'Como jogador, ' . $p['nome'] . ' atuava como ' . mb_strtolower($f['posicao_jogador']) . '.');
    }
    if (!empty($f['inicio_comissao'])) {
        $faq[] = array('Desde quando ' . $p['nome'] . ' trabalha na comissão técnica?', $f['inicio_comissao'] . '.');
    }
    if ($clubes) {
        $faq[] = array(($principal ? 'Quais clubes ' . $p['nome'] . ' já treinou?' : 'Em quais clubes ' . $p['nome'] . ' já trabalhou?'), 'Como técnico principal: ' . implode(', ', $clubes) . '.' . ($antes ? ' Antes, na comissão técnica: ' . implode(', ', array_keys($antes)) . '.' : ''));
    }
    if ($tot['jogos']) {
        $faq[] = array('Quantos jogos ' . $p['nome'] . ' tem como treinador?', $tot['jogos'] . ' jogos como técnico principal, com ' . $tot['vitorias'] . ' vitórias (' . tsp_tec_pct($tot['vitorias'], $tot['jogos']) . ' de vitórias), segundo os registros conferidos pelo TSP.');
    }
    if ($a26 && $a26['vde'] && $a26['j']) {
        $faq[] = array('Qual foi o aproveitamento de ' . $p['nome'] . ' em 2026?', tsp_tec_pct($a26['v'] * 3 + $a26['e'], $a26['j'] * 3) . ': ' . $a26['j'] . ' jogos, ' . $a26['v'] . ' vitórias, ' . $a26['e'] . ' empates e ' . $a26['d'] . ' derrotas por ' . implode(', ', array_unique($a26['clubes'])) . '.');
    }
    if ($titulos || $acessos) {
        if (function_exists('tsp_mc_redes') && ($rs = tsp_mc_redes($f))) {
            $faq[] = array('Qual é o Instagram de ' . $p['nome'] . '?', implode('; ', array_map(function ($x) {
                return $x['nome'] . ': @' . $x['user'];
            }, $rs)) . '.');
        }
        $faq[] = array($p['nome'] . ' tem títulos ou acessos?', trim(($titulos ? 'Títulos: ' . implode('; ', $titulos) . '. ' : '') . ($acessos ? 'Acessos e campanhas: ' . implode('; ', $acessos) . '.' : '') . ($destaques ? ' Destaque: ' . $destaques[0] . '.' : '')));
    }
    // Perguntas extras da página pilar (intenções de busca: clube atual, recordes, números por clube...)
    foreach ((array) ($pil['faq'] ?? array()) as $qa) {
        if (!empty($qa[0]) && !empty($qa[1])) {
            $faq[] = array($qa[0], $qa[1]);
        }
    }
    if ($ep && !empty($ep['perguntas'])) {
        foreach ($ep['perguntas'] as $qa) {
            $faq[] = array($qa[0], $qa[1]);
        }
    }
    // Página pilar: as perguntas das seções entram nos dados estruturados; a lista visível não repete nada
    $todas = array();
    foreach ((array) ($pil['secoes'] ?? array()) as $s) {
        if (!empty($s['h2']) && !empty($s['resposta'])) {
            $todas[mb_strtolower($s['h2'])] = array($s['h2'], $s['resposta']);
        }
    }
    $visiveis = array();
    foreach ($faq as $q) {
        $k = mb_strtolower($q[0]);
        if (!isset($todas[$k])) {
            $todas[$k] = $q;
            $visiveis[] = $q;
        }
    }
    $faq = array_values($todas);
    if ($visiveis) {
        echo '<section class="tsp-secao tsp-secao--caixa tsp-faq"><div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>Perguntas frequentes sobre ' . esc_html($p['nome']) . '</h2></div></div>';
        foreach ($visiveis as $q) {
            echo '<div class="tsp-tecp__faq"><h3>' . esc_html($q[0]) . '</h3><p>' . esc_html($q[1]) . '</p></div>';
        }
        echo '</section>';
    }

    $notas = array('Dados conferidos pelo TSP em anúncios oficiais, matérias e registros de jogos.');
    if (!empty($foto['ia'])) {
        $notas[] = 'Figurinha: montagem com IA, ilustrativa, feita a partir da foto oficial de anúncio.';
    }
    echo '<p class="tsp-nota">' . esc_html(implode(' ', $notas)) . '</p>';

    // Dados estruturados: pessoa, FAQ e migalhas
    $ld = array('@context' => 'https://schema.org', '@type' => 'Person', 'name' => $p['nome'], 'url' => $canon, 'jobTitle' => $func . ' de futebol');
    if (!empty($f['nome_completo'])) {
        $ld['alternateName'] = $f['nome_completo'];
    }
    if (!empty($p['nascimento'])) {
        $ld['birthDate'] = $p['nascimento'];
    }
    if (function_exists('tsp_mc_redes') && ($rs = tsp_mc_redes($f))) {
        $ld['sameAs'] = array_column($rs, 'url');
    }
    if (!empty($foto['url'])) {
        $ld['image'] = $foto['url'];
    }
    if ($clube_nome && empty($p['saiu'])) {
        $ld['worksFor'] = array('@type' => 'SportsTeam', 'name' => $clube_nome, 'url' => $t ? get_term_link($t) : '');
    }
    $ldf = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($q) {
        return array('@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $q[1]));
    }, $faq));
    $mig = array(array('Início', home_url('/')));
    if ($t) {
        $mig[] = array($clube_nome, get_term_link($t));
    }
    $mig[] = array($p['nome'], $canon);
    $ldb = array('@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array_map(function ($x, $i) {
        return array('@type' => 'ListItem', 'position' => $i + 1, 'name' => $x[0], 'item' => $x[1]);
    }, $mig, array_keys($mig)));
    $lds = array($ld, $ldf, $ldb);
    if ($ep) {
        $ldv = array('@context' => 'https://schema.org', '@type' => 'VideoObject', 'name' => 'TSP Exclusiva #' . $ep['n'] . ': ' . $ep['titulo'], 'description' => !empty($ep['resumo']) ? $ep['resumo'] : $ep['titulo'], 'thumbnailUrl' => array(tsp_exclusiva_thumb($ep['id'], 'maxresdefault'), tsp_exclusiva_thumb($ep['id'])), 'uploadDate' => $ep['data'] . 'T12:00:00-03:00', 'embedUrl' => 'https://www.youtube.com/embed/' . $ep['id'], 'url' => tsp_exclusiva_ep_url($ep), 'publisher' => array('@type' => 'Organization', 'name' => 'Tudo Sobre Paulista'), 'about' => array('@type' => 'Person', 'name' => $p['nome'], 'url' => $canon));
        $lds[0]['subjectOf'] = array('@type' => 'VideoObject', 'name' => $ldv['name'], 'url' => $ldv['url']);
        $lds[] = $ldv;
    }
    foreach ($lds as $j) {
        echo '<script type="application/ld+json">' . wp_json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
    }
    echo '</main>';
    get_footer();
}


/* ---------- Mapa do site das páginas de treinadores e comissões (26/11/2026) ---------- */
add_action('template_redirect', function () {
    if (!get_query_var('tsp_tec_mapa')) {
        return;
    }
    status_header(200);
    header('Content-Type: application/xml; charset=UTF-8');
    header('X-Robots-Tag: noindex, follow', true);
    echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    $vistos = array();
    foreach (tsp_mc_jogadores() as $p) {
        if (!tsp_tec_e_comissao($p)) {
            continue;
        }
        $u = tsp_tec_url($p);
        if (isset($vistos[$u])) {
            continue;
        }
        $vistos[$u] = 1;
        $lm = '';
        foreach ((array) ($p['movimentos'] ?? array()) as $m) {
            $lm = max($lm, (string) ($m['atualizado'] ?? $m['data'] ?? ''));
        }
        echo '<url><loc>' . esc_url($u) . '</loc>' . ($lm ? '<lastmod>' . esc_html(gmdate('c', strtotime($lm))) . '</lastmod>' : '') . (!empty($p['pilar']) ? '<priority>0.8</priority>' : '') . '</url>';
    }
    echo '</urlset>';
    exit;
}, 1);
add_filter('wpseo_sitemap_index', function ($x) {
    return $x . '<sitemap><loc>' . esc_url(home_url('/pessoas-sitemap.xml')) . '</loc><lastmod>' . esc_html(gmdate('c')) . '</lastmod></sitemap>';
});

/* ---------- Link automático para a página pilar na primeira menção dentro das matérias (26/11/2026) ---------- */
function tsp_tec_alvos_link()
{
    static $a = null;
    if ($a !== null) {
        return $a;
    }
    $a = array();
    if (!function_exists('tsp_mc_jogadores')) {
        return $a;
    }
    foreach (tsp_mc_jogadores() as $p) {
        if (!empty($p['pilar']) && tsp_tec_e_comissao($p) && mb_strlen($p['nome']) >= 8) {
            $a[$p['nome']] = tsp_tec_url($p);
        }
    }
    return $a;
}
add_filter('the_content', function ($c) {
    if (is_admin() || !is_singular('post') || !in_the_loop()) {
        return $c;
    }
    $alvos = tsp_tec_alvos_link();
    if (!$alvos) {
        return $c;
    }
    $partes = preg_split('~(<[^>]+>)~', $c, -1, PREG_SPLIT_DELIM_CAPTURE);
    $fora = 0;
    $feito = array();
    foreach ($partes as $i => $pt) {
        if ($pt === '') {
            continue;
        }
        if ($pt[0] === '<') {
            if (preg_match('~^<(a|h[1-6]|script|style|figcaption|button)[\s>]~i', $pt)) {
                $fora++;
            } elseif (preg_match('~^</(a|h[1-6]|script|style|figcaption|button)>~i', $pt)) {
                $fora = max(0, $fora - 1);
            }
            continue;
        }
        if ($fora) {
            continue;
        }
        foreach ($alvos as $nome => $url) {
            if (isset($feito[$nome])) {
                continue;
            }
            $re = '~(?<![\p{L}\p{N}])' . preg_quote($nome, '~') . '(?![\p{L}\p{N}])~u';
            if (preg_match($re, $pt)) {
                $pt = preg_replace($re, '<a href="' . esc_url($url) . '" class="tsp-link-pessoa">$0</a>', $pt, 1);
                $partes[$i] = $pt;
                $feito[$nome] = 1;
            }
        }
    }
    return implode('', $partes);
}, 20);
