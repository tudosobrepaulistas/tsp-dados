<?php
/**
 * Canal do Telegram de cada clube (10/11/2026, pedido do Thiago).
 * Toda matéria do clube ganha uma chamada "Entre no nosso canal ... no Telegram" depois do 2º parágrafo,
 * e a página do clube ganha o botão ao lado do WhatsApp.
 * Começou com o Corinthians. Os outros clubes entram pela tela Ferramentas → 📣 Telegram dos clubes:
 * colou o link (https://t.me/...), salvou, já aparece em todas as matérias daquele clube.
 * A mesma tela é o checklist: ✅ clube com canal, ⬜ clube que ainda falta.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Já configurados de saída (o resto vem da tela)
function tsp_tg_padrao()
{
    return array(
        'corinthians' => array('url' => 'https://t.me/corinthians_noticias', 'apelido' => 'Timão'),
    );
}

function tsp_tg_todos()
{
    $o = get_option('tsp_telegram', null);
    if (!is_array($o)) {
        $o = tsp_tg_padrao();
        update_option('tsp_telegram', $o, false);
    }
    return $o;
}

function tsp_tg_do_clube($slug)
{
    $t = tsp_tg_todos();
    return !empty($t[$slug]['url']) ? $t[$slug] : null;
}

// Clube da matéria que tem canal (o primeiro clube marcado que tiver)
function tsp_tg_do_post($post_id)
{
    $termos = taxonomy_exists('times') ? wp_get_post_terms($post_id, 'times') : array();
    if (is_wp_error($termos)) {
        return null;
    }
    foreach ($termos as $t) {
        $c = tsp_tg_do_clube($t->slug);
        if ($c) {
            return array($t, $c);
        }
    }
    return null;
}

function tsp_tg_cta_html($termo, $c, $lugar = 'materia')
{
    $nome = !empty($c['apelido']) ? $c['apelido'] : $termo->name;
    $de = (strpos(tsp_de($termo), 'da ') === 0 && empty($c['apelido'])) ? 'da' : 'do';
    $h = '<aside class="tsp-tg tsp-tg--' . esc_attr($lugar) . '" aria-label="Canal no Telegram">';
    $h .= '<span class="tsp-tg__ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="26" height="26"><path fill="currentColor" d="M21.9 4.3 18.6 20c-.2 1.1-.9 1.4-1.8.9l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.1 9.2-8.3c.4-.4-.1-.6-.6-.2L6 13.5l-4.9-1.5c-1.1-.3-1.1-1.1.2-1.6L20.5 3c.9-.3 1.7.2 1.4 1.3z"/></svg></span>';
    $h .= '<div class="tsp-tg__txt"><strong>Entre no nosso canal ' . $de . ' ' . esc_html($nome) . ' no Telegram</strong><span>e receba todas as notícias na palma da sua mão.</span></div>';
    $h .= '<a class="tsp-tg__bt" href="' . esc_url($c['url']) . '" target="_blank" rel="noopener" data-tsp-tg="' . esc_attr($termo->slug) . '">Entrar no canal</a></aside>';
    return $h;
}

// Na matéria: depois do 2º parágrafo (matéria curta: no fim)
add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $html;
    }
    $x = tsp_tg_do_post(get_the_ID());
    if (!$x) {
        return $html;
    }
    $cta = tsp_tg_cta_html($x[0], $x[1]);
    $n = 0;
    $pos = 0;
    while (($p = stripos($html, '</p>', $pos)) !== false) {
        $n++;
        $pos = $p + 4;
        if ($n === 2) {
            return substr($html, 0, $pos) . $cta . substr($html, $pos);
        }
    }
    return $html . $cta;
}, 25);

// Tela de configuração + checklist
add_action('admin_menu', function () {
    add_management_page('Telegram dos clubes', '📣 Telegram dos clubes', 'manage_options', 'tsp-telegram', 'tsp_tg_tela');
});

add_action('admin_post_tsp_tg_salvar', function () {
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão.');
    }
    check_admin_referer('tsp_tg');
    $novo = array();
    foreach ((array) ($_POST['tg'] ?? array()) as $slug => $v) {
        $url = esc_url_raw(trim(wp_unslash($v['url'] ?? '')));
        if ($url && preg_match('~^https://(t\.me|telegram\.me)/~i', $url)) {
            $novo[sanitize_title($slug)] = array('url' => $url, 'apelido' => sanitize_text_field(wp_unslash($v['apelido'] ?? '')));
        }
    }
    update_option('tsp_telegram', $novo, false);
    do_action('litespeed_purge_all');
    wp_safe_redirect(admin_url('tools.php?page=tsp-telegram&ok=1'));
    exit;
});

function tsp_tg_tela()
{
    $tg = tsp_tg_todos();
    $termos = get_terms(array('taxonomy' => 'times', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC'));
    $termos = is_wp_error($termos) ? array() : $termos;
    $feitos = count(array_filter($termos, function ($t) use ($tg) {
        return !empty($tg[$t->slug]['url']);
    }));
    echo '<div class="wrap"><h1>📣 Telegram dos clubes</h1>';
    if (!empty($_GET['ok'])) {
        echo '<div class="notice notice-success is-dismissible"><p>Salvo. A chamada já aparece nas matérias dos clubes com ✅.</p></div>';
    }
    echo '<p>Cole o link do canal (começa com <code>https://t.me/</code>) e clique em <strong>Salvar</strong>. A chamada "Entre no nosso canal ... no Telegram" entra sozinha em <strong>todas</strong> as matérias do clube, depois do 2º parágrafo, e o botão aparece na página do clube.</p>';
    echo '<p><strong>Checklist: ' . $feitos . ' de ' . count($termos) . ' clubes com canal.</strong> Ordem: clubes com mais matérias primeiro. Apelido é opcional (ex.: Timão, Verdão, Peixe, Tricolor); sem apelido, usa o nome do clube.</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="tsp_tg_salvar">';
    wp_nonce_field('tsp_tg');
    echo '<p><button class="button button-primary">Salvar</button></p><table class="widefat striped" style="max-width:980px"><thead><tr><th style="width:30px"></th><th>Clube</th><th>Matérias</th><th>Link do canal no Telegram</th><th>Apelido</th></tr></thead><tbody>';
    foreach ($termos as $t) {
        $c = $tg[$t->slug] ?? array();
        $ok = !empty($c['url']);
        echo '<tr><td>' . ($ok ? '✅' : '⬜') . '</td><td><strong>' . esc_html($t->name) . '</strong></td><td>' . (int) $t->count . '</td><td><input type="url" class="regular-text" placeholder="https://t.me/..." name="tg[' . esc_attr($t->slug) . '][url]" value="' . esc_attr($c['url'] ?? '') . '"></td><td><input type="text" style="width:120px" name="tg[' . esc_attr($t->slug) . '][apelido]" value="' . esc_attr($c['apelido'] ?? '') . '"></td></tr>';
    }
    echo '</tbody></table><p><button class="button button-primary">Salvar</button></p></form></div>';
}
