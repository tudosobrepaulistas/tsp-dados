<?php
/**
 * Conferência das matérias:
 *  - Possíveis erros detectados sozinhos (sem foto, sem crédito, sem time, texto curto, título fora do padrão...).
 *  - Avaliação do administrador: Pendente, OK, Devolutiva (corrigir; conta no pagamento) ou Recusada (não conta no pagamento),
 *    com observação. A devolutiva aparece no painel do redator; quando ele salva a matéria, vira "Corrigida (rever)".
 * Rascunho nunca conta: o relatório só lê matérias publicadas.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_REL_MIN_CHARS = 1000;

function tsp_rel_avaliacoes()
{
    return array('' => 'Pendente', 'ok' => 'OK', 'devolutiva' => 'Devolutiva', 'corrigida' => 'Corrigida (rever)', 'recusada' => 'Recusada (não conta)');
}

function tsp_rel_problemas($p, $chars)
{
    $e = array();
    $thumb = get_post_thumbnail_id($p);
    if (!$thumb) {
        $e[] = 'Sem foto de destaque';
    } else {
        $cred = function_exists('tsp_credito_foto') ? tsp_credito_foto($p->ID) : trim((string) wp_get_attachment_caption($thumb));
        if ($cred === '') {
            $e[] = 'Foto sem crédito';
        }
    }
    $t = get_the_terms($p, 'times');
    if (!$t || is_wp_error($t)) {
        $e[] = 'Sem time marcado';
    }
    if ($chars < TSP_REL_MIN_CHARS) {
        $e[] = 'Texto curto (' . number_format_i18n($chars) . ' caracteres)';
    }
    $tit = html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8');
    $len = mb_strlen($tit);
    if ($len < 30) {
        $e[] = 'Título curto';
    } elseif ($len > 110) {
        $e[] = 'Título longo';
    }
    $letras = preg_replace('~[^\p{L}]~u', '', $tit);
    if (mb_strlen($letras) > 10 && mb_strlen(preg_replace('~[^\p{Lu}]~u', '', $letras)) / mb_strlen($letras) > 0.6) {
        $e[] = 'Título em caixa alta';
    }
    if (function_exists('tsp_subtitulo') && tsp_subtitulo($p->ID) === '') {
        $e[] = 'Sem subtítulo';
    }
    return $e;
}

function tsp_rel_aval($id)
{
    return array((string) get_post_meta($id, 'tsp_avaliacao', true), (string) get_post_meta($id, 'tsp_avaliacao_obs', true));
}

// Salva a avaliação (só administrador)
add_action('wp_ajax_tsp_rel_avaliar', function () {
    check_ajax_referer('tsp_rel_avaliar', 'nonce');
    if (!tsp_rel_coord()) {
        wp_send_json_error('Sem permissão.');
    }
    $id = (int) ($_POST['id'] ?? 0);
    $a = sanitize_key($_POST['aval'] ?? '');
    if (!$id || !array_key_exists($a, tsp_rel_avaliacoes()) || !in_array(get_post_type($id), tsp_rel_tipos(), true)) {
        wp_send_json_error('Dados inválidos.');
    }
    $obs = sanitize_textarea_field(wp_unslash($_POST['obs'] ?? ''));
    if ($a === '') {
        delete_post_meta($id, 'tsp_avaliacao');
    } else {
        update_post_meta($id, 'tsp_avaliacao', $a);
    }
    update_post_meta($id, 'tsp_avaliacao_obs', $obs);
    update_post_meta($id, 'tsp_avaliacao_por', get_current_user_id());
    update_post_meta($id, 'tsp_avaliacao_em', current_time('mysql'));
    wp_send_json_success('Salvo');
});

// Redator salvou uma matéria com devolutiva → "Corrigida (rever)"
add_action('save_post', function ($id, $post) {
    if (wp_is_post_revision($id) || !in_array($post->post_type, tsp_rel_tipos(), true)) {
        return;
    }
    if (get_post_meta($id, 'tsp_avaliacao', true) === 'devolutiva' && get_current_user_id() === (int) $post->post_author && !tsp_rel_coord()) {
        update_post_meta($id, 'tsp_avaliacao', 'corrigida');
    }
}, 30, 2);

// Matérias recusadas não contam
function tsp_rel_meta_valida()
{
    return array('relation' => 'OR', array('key' => 'tsp_avaliacao', 'compare' => 'NOT EXISTS'), array('key' => 'tsp_avaliacao', 'value' => 'recusada', 'compare' => '!='));
}

// Devolutivas e recusadas do redator (para o painel dele)
function tsp_rel_devolutivas($autor)
{
    return get_posts(array('post_type' => tsp_rel_tipos(), 'post_status' => 'publish', 'author' => (int) $autor, 'posts_per_page' => 15, 'no_found_rows' => true,
        'meta_query' => array(array('key' => 'tsp_avaliacao', 'value' => array('devolutiva', 'recusada'), 'compare' => 'IN'))));
}

function tsp_rel_aval_js()
{
    $n = wp_create_nonce('tsp_rel_avaliar');
    $u = admin_url('admin-ajax.php');
    return "<script>document.addEventListener('click',function(e){var b=e.target.closest('[data-aval-salvar]');if(!b)return;var tr=b.closest('tr'),fd=new FormData();fd.append('action','tsp_rel_avaliar');fd.append('nonce'," . wp_json_encode($n) . ");fd.append('id',b.getAttribute('data-aval-salvar'));fd.append('aval',tr.querySelector('[data-aval]').value);fd.append('obs',tr.querySelector('[data-obs]').value);b.disabled=true;b.textContent='...';fetch(" . wp_json_encode($u) . ",{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){b.textContent=j.success?'Salvo ✓':'Erro';b.disabled=false;}).catch(function(){b.textContent='Erro';b.disabled=false;});});</script>";
}
