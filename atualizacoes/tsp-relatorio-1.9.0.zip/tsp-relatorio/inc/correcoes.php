<?php
/**
 * Central de correções.
 *  - Possíveis erros encontrados sozinhos viram um pedido de correção para o redator (um aviso por redator, com todas as matérias).
 *  - Erros de informação (fato errado: placar, autor do gol, pé, data, nome...) são apontados pela coordenação
 *    ou pelo editor-chefe automático (arquivo api/correcoes.json da base do TSP), com a sugestão de correção.
 *  - Gravidade: grave (informação errada) · média (foto, crédito) · leve (forma: título, subtítulo, tamanho, time).
 *  - O redator recebe a mensagem (painel + e-mail) e a coordenação (Vinicios Cotrim) recebe na mesma hora para acompanhar.
 *  - Corrigiu no prazo: vale normalmente. Não corrigiu: a matéria vira "Recusada" e a comissão dela não entra no fechamento.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Prazo para corrigir, em horas, pela gravidade mais alta do pedido
const TSP_CORR_PRAZO = array('grave' => 6, 'media' => 24, 'leve' => 48);
const TSP_CORR_BASE = 'https://raw.githubusercontent.com/tudosobrepaulistas/tsp-dados/main/api/correcoes.json';

function tsp_corr_gravidades()
{
    return array(
        'grave' => array('🔴 Grave', 'Informação errada'),
        'media' => array('🟠 Média', 'Foto ou crédito'),
        'leve' => array('🟡 Leve', 'Forma do texto'),
    );
}

// Possível erro automático → gravidade e sugestão de correção
function tsp_corr_classificar($problema)
{
    $mapa = array(
        'Sem foto de destaque' => array('media', 'Coloque uma foto de destaque real, com crédito (ex.: "Foto: Fulano/Clube").'),
        'Foto sem crédito' => array('media', 'Preencha o crédito da foto (ex.: "Foto: Fulano/Clube" ou "Foto: Reprodução/Instagram do Clube").'),
        'Sem time marcado' => array('leve', 'Marque o time da matéria no campo "Times" (assim ela aparece na página do clube).'),
        'Título curto' => array('leve', 'Use um título de 30 a 110 caracteres, com o nome do clube e a informação principal.'),
        'Título longo' => array('leve', 'Encurte o título para até 110 caracteres, mantendo o clube e a informação principal.'),
        'Título em caixa alta' => array('leve', 'Escreva o título só com a primeira letra e os nomes próprios em maiúscula.'),
        'Sem subtítulo' => array('leve', 'Preencha o subtítulo completando a informação do título com um dado novo.'),
    );
    foreach ($mapa as $k => $v) {
        if (strpos($problema, $k) === 0) {
            return $v;
        }
    }
    if (strpos($problema, 'Texto curto') === 0) {
        return array('leve', 'Amplie o texto para pelo menos ' . number_format_i18n(TSP_REL_MIN_CHARS) . ' caracteres, com contexto, fontes e o próximo compromisso do clube.');
    }
    return array('leve', 'Revise este ponto.');
}

function tsp_corr($id)
{
    $c = get_post_meta($id, 'tsp_corr', true);
    return is_array($c) ? $c : array();
}

function tsp_corr_coordenadores()
{
    return array_values(array_filter(get_users(array('role' => 'tsp_coordenador')), function ($u) {
        return !user_can($u, 'manage_options');
    }));
}

// Só matérias de redator contam (o administrador e a conta da redação/Máquina ficam de fora)
function tsp_corr_autor_redator($autor)
{
    $u = get_userdata($autor);
    return $u && !user_can($u, 'manage_options') && $u->user_login !== 'tsp';
}

function tsp_corr_fmt($ts)
{
    return wp_date('d/m \à\s H\hi', $ts);
}

/* ---------- Avisos (painel + e-mail) ---------- */

function tsp_corr_avisar($user_id, $assunto, $linhas, $link = '')
{
    $av = get_user_meta($user_id, 'tsp_avisos', true);
    $av = is_array($av) ? $av : array();
    array_unshift($av, array('t' => time(), 'assunto' => $assunto, 'texto' => implode("\n", $linhas), 'link' => $link, 'lido' => 0));
    update_user_meta($user_id, 'tsp_avisos', array_slice($av, 0, 40));
    $u = get_userdata($user_id);
    if ($u && is_email($u->user_email)) {
        $html = '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.55;color:#222;max-width:620px">';
        foreach ($linhas as $l) {
            $html .= $l === '' ? '<br>' : '<p style="margin:0 0 8px">' . nl2br(esc_html($l)) . '</p>';
        }
        if ($link) {
            $html .= '<p><a href="' . esc_url($link) . '" style="display:inline-block;background:#E8862A;color:#111;padding:10px 16px;border-radius:8px;font-weight:bold;text-decoration:none">Abrir no painel</a></p>';
        }
        $html .= '<p style="color:#777;font-size:12px">Tudo Sobre Paulista · Redação</p></div>';
        @wp_mail($u->user_email, 'TSP | ' . $assunto, $html, array('Content-Type: text/html; charset=UTF-8'));
    }
}

function tsp_corr_avisos_nao_lidos($user_id)
{
    $av = get_user_meta($user_id, 'tsp_avisos', true);
    return is_array($av) ? count(array_filter($av, function ($a) {
        return empty($a['lido']);
    })) : 0;
}

/* ---------- Abrir pedido de correção ---------- */

// $itens: [['g' => grave|media|leve, 'motivo' => '...', 'sugestao' => '...', 'auto' => 0|1, 'fontes' => [...]]]
function tsp_corr_abrir($id, $itens, $por = 0)
{
    $c = tsp_corr($id);
    $antes = ($c && ($c['status'] ?? '') === 'aberta') ? (array) $c['itens'] : array();
    $chaves = array();
    foreach ($antes as $i) {
        $chaves[$i['motivo']] = 1;
    }
    $novos = array();
    foreach ($itens as $i) {
        if (empty($chaves[$i['motivo']])) {
            $novos[] = $i;
            $chaves[$i['motivo']] = 1;
        }
    }
    if (!$novos) {
        return array();
    }
    $todos = array_merge($antes, $novos);
    $ordem = array('grave' => 3, 'media' => 2, 'leve' => 1);
    $max = 'leve';
    foreach ($todos as $i) {
        if ($ordem[$i['g']] > $ordem[$max]) {
            $max = $i['g'];
        }
    }
    $gn = 'leve';
    foreach ($novos as $i) {
        if ($ordem[$i['g']] > $ordem[$gn]) {
            $gn = $i['g'];
        }
    }
    $prazo = time() + TSP_CORR_PRAZO[$gn] * HOUR_IN_SECONDS;
    if (!empty($c['prazo']) && ($c['status'] ?? '') === 'aberta') {
        $prazo = min($prazo, (int) $c['prazo']);
    }
    update_post_meta($id, 'tsp_corr', array('itens' => $todos, 'status' => 'aberta', 'enviado' => time(), 'prazo' => $prazo, 'gravidade' => $max, 'por' => (int) $por));
    update_post_meta($id, 'tsp_avaliacao', 'devolutiva');
    update_post_meta($id, 'tsp_avaliacao_obs', 'Corrigir até ' . tsp_corr_fmt($prazo) . ': ' . implode(' · ', wp_list_pluck($todos, 'motivo')));
    update_post_meta($id, 'tsp_avaliacao_em', current_time('mysql'));
    return $novos;
}

// Texto da mensagem ao redator (cordial, motivacional e com o compromisso)
function tsp_corr_msg_redator($nome, $materias)
{
    $l = array('Oi, ' . $nome . '! Tudo bem?', '');
    $l[] = count($materias) > 1
        ? 'Obrigado pelas matérias que você vem publicando: elas fazem o TSP crescer todos os dias. Na conferência, encontramos alguns pontos para ajustar em ' . count($materias) . ' delas.'
        : 'Obrigado pela matéria: ela já está no ar ajudando o TSP a crescer. Na conferência, encontramos alguns pontos para ajustar.';
    $l[] = '';
    $g = tsp_corr_gravidades();
    foreach ($materias as $m) {
        $l[] = '📰 "' . $m['titulo'] . '" · corrigir até ' . tsp_corr_fmt($m['prazo']);
        foreach ($m['itens'] as $i) {
            $l[] = '   ' . $g[$i['g']][0] . ' (' . $g[$i['g']][1] . '): ' . $i['motivo'];
            if (!empty($i['sugestao'])) {
                $l[] = '   ✏️ Sugestão: ' . $i['sugestao'];
            }
        }
        $l[] = '   Corrigir: ' . $m['editar'];
        $l[] = '';
    }
    $l[] = 'Sabemos da sua dedicação e contamos com o seu compromisso: a credibilidade do TSP é construída matéria por matéria, e a sua assinatura está em cada uma delas.';
    $l[] = 'Lembrando a regra combinada: se a correção (texto, foto, crédito e afins) não for feita no prazo, a comissão desta matéria é cancelada e ela não entra no fechamento. Assim que você salvar a matéria corrigida, a gente confere.';
    $l[] = 'Qualquer dúvida, fale com o Vinicios Cotrim, nosso editor-chefe. Bom trabalho!';
    $l[] = '— Redação Tudo Sobre Paulista';
    return $l;
}

function tsp_corr_enviar_lote($autor, $materias, $origem)
{
    if (!$materias) {
        return;
    }
    $u = get_userdata($autor);
    if (!$u) {
        return;
    }
    $n = count($materias);
    $tem_grave = (bool) array_filter($materias, function ($m) {
        return $m['gravidade'] === 'grave';
    });
    tsp_corr_avisar($autor, ($tem_grave ? '🔴 Correção urgente' : 'Ajuste') . ($n > 1 ? ' em ' . $n . ' matérias' : ': ' . $materias[0]['titulo']), tsp_corr_msg_redator($u->display_name, $materias), admin_url('index.php'));
    // Coordenação recebe na mesma hora para acompanhar
    $l = array('Para acompanhamento: pedido de correção enviado agora para ' . $u->display_name . ' (' . $origem . ').', '');
    $g = tsp_corr_gravidades();
    foreach ($materias as $m) {
        $l[] = '📰 "' . $m['titulo'] . '" · prazo ' . tsp_corr_fmt($m['prazo']);
        foreach ($m['itens'] as $i) {
            $l[] = '   ' . $g[$i['g']][0] . ': ' . $i['motivo'];
        }
        $l[] = '   Ver: ' . $m['link'];
        $l[] = '';
    }
    $l[] = 'Se não for corrigida no prazo, a matéria vira "Recusada" sozinha e não entra no pagamento.';
    foreach (tsp_corr_coordenadores() as $c) {
        tsp_corr_avisar($c->ID, 'Acompanhar: ' . $u->display_name . ' · ' . $n . ' matéria(s)' . ($tem_grave ? ' · 🔴 grave' : ''), $l, admin_url('admin.php?page=tsp-relatorio&aval=devolutiva'));
    }
}

function tsp_corr_item_materia($p)
{
    $c = tsp_corr($p->ID);
    return array('titulo' => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'), 'prazo' => (int) $c['prazo'], 'gravidade' => $c['gravidade'],
        'editar' => admin_url('post.php?post=' . $p->ID . '&action=edit'), 'link' => get_permalink($p), 'itens' => array());
}

/* ---------- Rotina de hora em hora: novos possíveis erros, prazos vencidos e erros do editor-chefe ---------- */

add_action('init', function () {
    if (!wp_next_scheduled('tsp_corr_rotina')) {
        wp_schedule_event(time() + 300, 'hourly', 'tsp_corr_rotina');
    }
});
add_action('tsp_corr_rotina', 'tsp_corr_rotina');

function tsp_corr_rotina()
{
    if (get_transient('tsp_corr_trava')) {
        return;
    }
    set_transient('tsp_corr_trava', 1, 5 * MINUTE_IN_SECONDS);
    tsp_corr_importar();
    tsp_corr_auto();
    tsp_corr_vencer();
    delete_transient('tsp_corr_trava');
}

// Possíveis erros automáticos das matérias publicadas no fechamento atual (publicadas há mais de 30 min)
function tsp_corr_auto()
{
    list($ini) = tsp_rel_fechamento(0);
    $q = get_posts(array('post_type' => tsp_rel_tipos(), 'post_status' => 'publish', 'posts_per_page' => 600, 'no_found_rows' => true,
        'date_query' => array(array('after' => $ini->format('Y-m-d H:i:s'), 'inclusive' => true), array('before' => wp_date('Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS))),
        'meta_query' => array('relation' => 'AND', array('key' => 'tsp_corr_auto_visto', 'compare' => 'NOT EXISTS'))));
    $lotes = array();
    foreach ($q as $p) {
        update_post_meta($p->ID, 'tsp_corr_auto_visto', 1);
        if (!tsp_corr_autor_redator($p->post_author) || in_array(get_post_meta($p->ID, 'tsp_avaliacao', true), array('ok', 'recusada'), true)) {
            continue;
        }
        $pr = tsp_rel_problemas($p, tsp_rel_caracteres($p));
        if (!$pr) {
            continue;
        }
        $itens = array();
        foreach ($pr as $x) {
            list($g, $s) = tsp_corr_classificar($x);
            $itens[] = array('g' => $g, 'motivo' => $x, 'sugestao' => $s, 'auto' => 1);
        }
        $novos = tsp_corr_abrir($p->ID, $itens);
        if ($novos) {
            $m = tsp_corr_item_materia($p);
            $m['itens'] = $novos;
            $lotes[$p->post_author][] = $m;
        }
    }
    foreach ($lotes as $autor => $mats) {
        tsp_corr_enviar_lote($autor, $mats, 'conferência automática');
    }
    return array_sum(array_map('count', $lotes));
}

// Prazo vencido sem correção → Recusada (comissão cancelada)
function tsp_corr_vencer()
{
    $q = get_posts(array('post_type' => tsp_rel_tipos(), 'post_status' => 'any', 'posts_per_page' => 300, 'no_found_rows' => true,
        'meta_query' => array(array('key' => 'tsp_avaliacao', 'value' => 'devolutiva'))));
    foreach ($q as $p) {
        $c = tsp_corr($p->ID);
        if (($c['status'] ?? '') !== 'aberta' || (int) $c['prazo'] > time()) {
            continue;
        }
        $c['status'] = 'vencida';
        $c['vencida'] = time();
        update_post_meta($p->ID, 'tsp_corr', $c);
        update_post_meta($p->ID, 'tsp_avaliacao', 'recusada');
        update_post_meta($p->ID, 'tsp_avaliacao_obs', 'Prazo de correção encerrado em ' . tsp_corr_fmt((int) $c['prazo']) . ' sem ajuste: comissão cancelada. Pendências: ' . implode(' · ', wp_list_pluck($c['itens'], 'motivo')));
        $u = get_userdata($p->post_author);
        $tit = html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8');
        if ($u) {
            tsp_corr_avisar($u->ID, 'Prazo encerrado: ' . $tit, array('Oi, ' . $u->display_name . '.', '', 'O prazo para corrigir "' . $tit . '" terminou sem o ajuste. Como combinado, a comissão desta matéria foi cancelada e ela não entra no fechamento.', 'A matéria segue no ar e ainda pode ser corrigida: o leitor merece a informação certa. Contamos com você nas próximas!', '— Redação Tudo Sobre Paulista'), admin_url('post.php?post=' . $p->ID . '&action=edit'));
        }
        foreach (tsp_corr_coordenadores() as $co) {
            tsp_corr_avisar($co->ID, 'Vencida: ' . ($u ? $u->display_name : '') . ' · ' . $tit, array('A correção de "' . $tit . '" não foi feita no prazo. A matéria virou "Recusada" (não conta no pagamento).', 'Pendências: ' . implode(' · ', wp_list_pluck($c['itens'], 'motivo')), 'Se o erro for de informação, corrija você ou peça ao administrador.'), get_permalink($p));
        }
    }
}

// Redator salvou a matéria: confere de novo o que é automático; o que é de informação vai para a coordenação rever
add_action('save_post', function ($id, $post) {
    if (wp_is_post_revision($id) || !in_array($post->post_type, tsp_rel_tipos(), true) || $post->post_status !== 'publish') {
        return;
    }
    $c = tsp_corr($id);
    if (($c['status'] ?? '') !== 'aberta') {
        return;
    }
    $agora = tsp_rel_problemas($post, tsp_rel_contar($post));
    $pend = array_values(array_filter($c['itens'], function ($i) use ($agora) {
        if (empty($i['auto'])) {
            return true; // erro de informação: só a coordenação confirma
        }
        $base = function ($x) {
            return trim(preg_replace('~\s*\(.*$~', '', $x));
        };
        foreach ($agora as $a) {
            if ($base($a) === $base($i['motivo'])) {
                return true;
            }
        }
        return false;
    }));
    $manuais = array_filter($pend, function ($i) {
        return empty($i['auto']);
    });
    $auto_pend = count($pend) - count($manuais);
    if ($auto_pend === 0 && !$manuais) {
        $c['status'] = 'corrigida';
        $c['corrigida'] = time();
        update_post_meta($id, 'tsp_corr', $c);
        update_post_meta($id, 'tsp_avaliacao', 'ok');
        update_post_meta($id, 'tsp_avaliacao_obs', 'Corrigida em ' . tsp_corr_fmt(time()) . ' (conferência automática).');
        return;
    }
    if ($auto_pend === 0 && $manuais && (int) get_current_user_id() === (int) $post->post_author) {
        $c['status'] = 'rever';
        $c['corrigida'] = time();
        update_post_meta($id, 'tsp_corr', $c);
        update_post_meta($id, 'tsp_avaliacao', 'corrigida');
        $u = get_userdata($post->post_author);
        foreach (tsp_corr_coordenadores() as $co) {
            tsp_corr_avisar($co->ID, 'Rever correção: ' . html_entity_decode(get_the_title($post), ENT_QUOTES, 'UTF-8'), array(($u ? $u->display_name : 'O redator') . ' salvou a matéria com o erro de informação apontado. Confira se ficou certo e marque "OK" no relatório.', 'Erro apontado: ' . implode(' · ', wp_list_pluck($manuais, 'motivo'))), admin_url('post.php?post=' . $id . '&action=edit'));
        }
        return;
    }
    // Ainda falta corrigir: continua aguardando (desfaz o "corrigida" automático do salvamento)
    update_post_meta($id, 'tsp_avaliacao', 'devolutiva');
}, 40, 2);

// Coordenação marcou OK ou Recusada no relatório: fecha o pedido de correção
add_action('updated_post_meta', function ($mid, $id, $chave, $valor) {
    if ($chave !== 'tsp_avaliacao' || !in_array($valor, array('ok', 'recusada'), true)) {
        return;
    }
    $c = tsp_corr($id);
    if ($c && in_array($c['status'] ?? '', array('aberta', 'rever'), true)) {
        $c['status'] = $valor === 'ok' ? 'corrigida' : 'vencida';
        update_post_meta($id, 'tsp_corr', $c);
    }
}, 10, 4);

/* ---------- Erros do editor-chefe automático (api/correcoes.json na base do TSP) ---------- */

function tsp_corr_importar()
{
    $r = wp_remote_get(TSP_CORR_BASE . '?t=' . time(), array('timeout' => 15));
    if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) {
        return 0;
    }
    $d = json_decode(wp_remote_retrieve_body($r), true);
    $feitos = get_option('tsp_corr_importadas', array());
    $feitos = is_array($feitos) ? $feitos : array();
    $lotes = array();
    foreach ((array) ($d['itens'] ?? array()) as $x) {
        $chave = sanitize_key($x['chave'] ?? '');
        $id = (int) ($x['id'] ?? 0);
        $g = in_array($x['gravidade'] ?? '', array('grave', 'media', 'leve'), true) ? $x['gravidade'] : 'grave';
        if (!$chave || isset($feitos[$chave]) || !$id || get_post_status($id) !== 'publish') {
            continue;
        }
        $feitos[$chave] = time();
        $p = get_post($id);
        if (!$p || !tsp_corr_autor_redator($p->post_author) || get_post_meta($id, 'tsp_avaliacao', true) === 'recusada') {
            continue;
        }
        $fontes = array();
        foreach ((array) ($x['fontes'] ?? array()) as $f) {
            if (!empty($f['url']) && wp_http_validate_url($f['url'])) {
                $fontes[] = sanitize_text_field($f['nome'] ?? '') . ': ' . esc_url_raw($f['url']);
            }
        }
        $item = array('g' => $g, 'motivo' => sanitize_text_field($x['motivo'] ?? 'Informação a conferir'), 'sugestao' => sanitize_text_field($x['sugestao'] ?? '') . ($fontes ? ' (Fontes: ' . implode(' | ', $fontes) . ')' : ''), 'auto' => 0);
        $novos = tsp_corr_abrir($id, array($item));
        if ($novos) {
            $m = tsp_corr_item_materia($p);
            $m['itens'] = $novos;
            $lotes[$p->post_author][] = $m;
        }
    }
    update_option('tsp_corr_importadas', array_slice($feitos, -2000, null, true), false);
    foreach ($lotes as $autor => $mats) {
        tsp_corr_enviar_lote($autor, $mats, 'editor-chefe: checagem com outras fontes');
    }
    return array_sum(array_map('count', $lotes));
}

// O robô avisa que publicou novos apontamentos (sem dados sensíveis; no máximo 1 vez por minuto)
add_action('rest_api_init', function () {
    register_rest_route('tsp/v1', '/correcoes-ler', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function () {
        if (get_transient('tsp_corr_ler')) {
            return array('ok' => true, 'espera' => true);
        }
        set_transient('tsp_corr_ler', 1, MINUTE_IN_SECONDS);
        return array('ok' => true, 'novos' => tsp_corr_importar());
    }));
});

/* ---------- Apontar erro de informação (coordenação e administrador) ---------- */

add_action('wp_ajax_tsp_corr_apontar', function () {
    check_ajax_referer('tsp_corr_apontar', 'nonce');
    if (!tsp_rel_coord()) {
        wp_send_json_error('Sem permissão.');
    }
    $id = (int) ($_POST['id'] ?? 0);
    $g = sanitize_key($_POST['g'] ?? 'grave');
    $motivo = sanitize_text_field(wp_unslash($_POST['motivo'] ?? ''));
    $sug = sanitize_text_field(wp_unslash($_POST['sugestao'] ?? ''));
    if (!$id || !in_array(get_post_type($id), tsp_rel_tipos(), true) || !isset(TSP_CORR_PRAZO[$g]) || mb_strlen($motivo) < 5) {
        wp_send_json_error('Escreva o que está errado (pelo menos 5 letras).');
    }
    $p = get_post($id);
    $novos = tsp_corr_abrir($id, array(array('g' => $g, 'motivo' => $motivo, 'sugestao' => $sug, 'auto' => 0)), get_current_user_id());
    if (!$novos) {
        wp_send_json_error('Este apontamento já foi enviado.');
    }
    $m = tsp_corr_item_materia($p);
    $m['itens'] = $novos;
    $eu = wp_get_current_user();
    tsp_corr_enviar_lote($p->post_author, array($m), 'apontado por ' . $eu->display_name);
    wp_send_json_success('Enviado ao redator e à coordenação. Prazo: ' . tsp_corr_fmt((int) tsp_corr($id)['prazo']));
});

// Formulário que aparece na linha da matéria no relatório
function tsp_corr_html_linha($id)
{
    $c = tsp_corr($id);
    $h = '';
    if ($c) {
        $st = array('aberta' => '⏳ Aguardando correção até ' . tsp_corr_fmt((int) $c['prazo']), 'rever' => '👀 Redator corrigiu: rever', 'corrigida' => '✅ Corrigida', 'vencida' => '❌ Prazo vencido: comissão cancelada');
        $h .= '<div class="tsp-corr-st">' . esc_html($st[$c['status']] ?? $c['status']) . '</div>';
    }
    if (tsp_rel_coord()) {
        $h .= '<details class="tsp-corr-f"><summary>⚠️ Apontar erro</summary><select data-corr-g>';
        foreach (tsp_corr_gravidades() as $k => $g) {
            $h .= '<option value="' . esc_attr($k) . '">' . esc_html($g[0] . ' · ' . $g[1]) . '</option>';
        }
        $h .= '</select><input type="text" data-corr-motivo placeholder="O que está errado? Ex.: o gol foi de pé direito, não esquerdo"><input type="text" data-corr-sug placeholder="Sugestão de correção (opcional)"><button type="button" class="button button-primary button-small" data-corr-enviar="' . (int) $id . '">Enviar ao redator</button><span data-corr-res></span></details>';
    }
    return $h;
}

function tsp_corr_js()
{
    return '<style>.tsp-corr-st{font-size:12px;margin-top:4px}.tsp-corr-f{margin-top:6px}.tsp-corr-f summary{cursor:pointer;color:#b3261e;font-weight:600}.tsp-corr-f select,.tsp-corr-f input{display:block;width:100%;margin:4px 0}</style>'
        . "<script>document.addEventListener('click',function(e){var b=e.target.closest('[data-corr-enviar]');if(!b)return;var f=b.closest('details'),r=f.querySelector('[data-corr-res]'),fd=new FormData();fd.append('action','tsp_corr_apontar');fd.append('nonce'," . wp_json_encode(wp_create_nonce('tsp_corr_apontar')) . ");fd.append('id',b.getAttribute('data-corr-enviar'));fd.append('g',f.querySelector('[data-corr-g]').value);fd.append('motivo',f.querySelector('[data-corr-motivo]').value);fd.append('sugestao',f.querySelector('[data-corr-sug]').value);b.disabled=true;r.textContent=' enviando...';fetch(" . wp_json_encode(admin_url('admin-ajax.php')) . ",{method:'POST',body:fd,credentials:'same-origin'}).then(function(x){return x.json()}).then(function(j){r.textContent=' '+(j.data||'');b.disabled=!!j.success}).catch(function(){r.textContent=' Erro';b.disabled=false})});</script>";
}

/* ---------- Avisos no painel e na tela da matéria ---------- */

function tsp_corr_avisos_html($user_id)
{
    $av = get_user_meta($user_id, 'tsp_avisos', true);
    if (!is_array($av) || !$av) {
        return '';
    }
    $n = tsp_corr_avisos_nao_lidos($user_id);
    $h = '<h3>📬 Mensagens da redação' . ($n ? ' <span style="background:#c0392b;color:#fff;border-radius:999px;padding:1px 8px;font-size:12px">' . (int) $n . ' nova(s)</span>' : '') . '</h3>';
    foreach (array_slice($av, 0, 6) as $a) {
        $h .= '<details class="tsp-p-msg ' . (empty($a['lido']) ? 'aviso' : '') . '"' . (empty($a['lido']) ? ' open' : '') . '><summary><strong>' . esc_html($a['assunto']) . '</strong> <small>' . esc_html(wp_date('d/m H\hi', $a['t'])) . '</small></summary><div style="white-space:pre-line;margin-top:6px">' . make_clickable(esc_html($a['texto'])) . '</div></details>';
    }
    foreach ($av as &$a) {
        $a['lido'] = 1;
    }
    update_user_meta($user_id, 'tsp_avisos', $av);
    return $h;
}

// Ao abrir a matéria para editar: o que corrigir e até quando
add_action('admin_notices', function () {
    $s = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$s || $s->base !== 'post' || empty($_GET['post'])) {
        return;
    }
    $c = tsp_corr((int) $_GET['post']);
    if (($c['status'] ?? '') !== 'aberta') {
        return;
    }
    $g = tsp_corr_gravidades();
    echo '<div class="notice notice-error"><p><strong>Esta matéria precisa de correção até ' . esc_html(tsp_corr_fmt((int) $c['prazo'])) . '.</strong> Sem o ajuste no prazo, a comissão dela é cancelada.</p><ul style="list-style:disc;margin-left:20px">';
    foreach ($c['itens'] as $i) {
        echo '<li>' . esc_html($g[$i['g']][0] . ': ' . $i['motivo']) . (!empty($i['sugestao']) ? '<br><em>Sugestão: ' . make_clickable(esc_html($i['sugestao'])) . '</em>' : '') . '</li>';
    }
    echo '</ul><p>Corrija e clique em <strong>Atualizar</strong>. A conferência é feita na hora.</p></div>';
});

// Botão para o administrador rodar a conferência agora (Relatório da redação)
add_action('admin_post_tsp_corr_agora', function () {
    if (!current_user_can('manage_options')) {
        wp_die('Sem permissão');
    }
    check_admin_referer('tsp_corr_agora');
    delete_transient('tsp_corr_trava');
    tsp_corr_rotina();
    wp_safe_redirect(admin_url('admin.php?page=tsp-relatorio&corr=1'));
    exit;
});
