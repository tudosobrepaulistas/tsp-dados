<?php
/**
 * Função "Coordenador(a) de redação": edita, agenda e publica matérias de todos os redatores,
 * vê o relatório da equipe inteira (sem valores em R$), avalia matérias (devolutivas) e vê pautas.
 * NÃO mexe no site: sem plugins, tema, configurações, usuários, páginas, menus, banners,
 * blocos da home, categorias/times nem código HTML livre.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_rel_coord($user_id = 0)
{
    $user_id = $user_id ?: get_current_user_id();
    return $user_id && (user_can($user_id, 'manage_options') || user_can($user_id, 'tsp_coordenar'));
}

function tsp_rel_caps_coordenador()
{
    return array(
        'read' => true, 'upload_files' => true, 'moderate_comments' => true, 'tsp_coordenar' => true,
        'edit_posts' => true, 'edit_others_posts' => true, 'edit_published_posts' => true, 'edit_private_posts' => true,
        'publish_posts' => true, 'read_private_posts' => true,
        'delete_posts' => true, 'delete_others_posts' => true, 'delete_published_posts' => true, 'delete_private_posts' => true,
        'unfiltered_html' => false, 'manage_categories' => false, 'edit_pages' => false, 'edit_theme_options' => false,
    );
}

// Cria/atualiza a função quando a versão do plugin muda
add_action('init', function () {
    if (get_option('tsp_rel_coord_v') === '1') {
        return;
    }
    remove_role('tsp_coordenador');
    add_role('tsp_coordenador', 'Coordenador(a) de redação', tsp_rel_caps_coordenador());
    update_option('tsp_rel_coord_v', '1', false);
});

// Coordenação conta como redator no pagamento (escreve também), mas sem acesso a valores dos outros.
