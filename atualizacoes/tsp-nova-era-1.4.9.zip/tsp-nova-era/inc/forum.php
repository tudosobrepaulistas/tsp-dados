<?php
/**
 * Fórum da torcida por clube + cadastro de leads (25/11/2026, pedido do Thiago).
 *
 * /forum/                 todos os grupos de WhatsApp e fóruns (A1 e A2 do Paulistão 2027)
 * /forum/<clube>/         grupo de WhatsApp do clube, pautas do TSP, tópicos da torcida e perguntas frequentes
 * /forum/topico/<nome>/   um tópico com as respostas
 *
 * Para publicar, o torcedor entra no grupo de WhatsApp do clube e se cadastra (nome, time, WhatsApp) com
 * consentimento (LGPD, art. 7º, I). No site só aparece o primeiro nome. O WhatsApp fica só no painel
 * "Fórum e leads" (administrador). O próprio torcedor apaga os dados dele com um botão.
 * Publicação: entra no ar na hora, menos quando tem link, telefone ou palavra proibida (vai para moderação).
 */

if (!defined('ABSPATH')) {
    exit;
}

const TSP_FR_TERMOS = 'forum-v1-2026-11-25';

/* ---------- Dados ---------- */

function tsp_fr_tabela()
{
    global $wpdb;
    return $wpdb->prefix . 'tsp_leads';
}

function tsp_fr_divisoes()
{
    return array(
        'Paulistão A1 2027' => array('palmeiras', 'corinthians', 'saopaulo', 'santos', 'botafogosp', 'capivariano', 'ferroviaria', 'guarani', 'juventus', 'mirassol', 'noroeste', 'novorizontino', 'portuguesa', 'primavera', 'bragantino', 'saobernardo'),
        'Paulistão A2 2027' => array('aguasanta', 'interdelimeira', 'ituano', 'linense', 'marilia', 'monteazul', 'osasco-sporting', 'pontepreta', 'portuguesasantista', 'santoandre', 'saojose', 'sertaozinho', 'taubate', 'veloclube', 'votuporanguense', 'xvdepiracicaba'),
    );
}

function tsp_fr_div_do($slug)
{
    foreach (tsp_fr_divisoes() as $d => $l) {
        if (in_array($slug, $l, true)) {
            return $d;
        }
    }
    return '';
}

// Grupo do clube (inc/whatsapp-grupos.php) com o slug
function tsp_fr_grupo($slug)
{
    $g = function_exists('tsp_wg_grupos') ? tsp_wg_grupos() : array();
    return isset($g[$slug]) ? array_merge($g[$slug], array('slug' => $slug)) : null;
}

function tsp_fr_nome_grupo($g)
{
    return !empty($g['grupo']) ? $g['grupo'] : 'TSP ' . $g['nome'] . (!empty($g['tipo']) ? ' - Resenha' : '');
}

function tsp_fr_quem($g)
{
    return $g['de'] . ' ' . $g['nome'];
}

function tsp_fr_url($slug = '')
{
    return home_url('/forum/' . ($slug ? $slug . '/' : ''));
}

add_action('init', function () {
    register_post_type('tsp_topico', array(
        'labels' => array('name' => 'Fórum: tópicos', 'singular_name' => 'Tópico', 'menu_name' => 'Fórum: tópicos'),
        'public' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-format-chat',
        'has_archive' => false,
        'exclude_from_search' => true,
        'show_in_rest' => false,
        'supports' => array('title', 'editor', 'comments', 'custom-fields'),
        'rewrite' => array('slug' => 'forum/topico', 'with_front' => false),
    ));
    add_rewrite_rule('^forum/?$', 'index.php?tsp_forum=1', 'top');
    add_rewrite_rule('^forum/([a-z0-9-]+)/?$', 'index.php?tsp_forum=$matches[1]', 'top');
    add_rewrite_rule('^tsp-mapa-forum\.xml$', 'index.php?tsp_forum=sitemap', 'top');
    if (get_option('tsp_fr_regras') !== '2') {
        flush_rewrite_rules(false);
        update_option('tsp_fr_regras', '2', true);
    }
    if (get_option('tsp_fr_db') !== '1') {
        tsp_fr_criar_tabela();
    }
    if (get_option('tsp_fr_pautas') !== '1' && did_action('wp_loaded') === 0) {
        add_action('wp_loaded', 'tsp_fr_criar_pautas');
    }
}, 20);

add_filter('query_vars', function ($v) {
    $v[] = 'tsp_forum';
    return $v;
});

function tsp_fr_criar_tabela()
{
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    dbDelta('CREATE TABLE ' . tsp_fr_tabela() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  criado datetime NOT NULL,
  nome varchar(80) NOT NULL DEFAULT '',
  whatsapp varchar(20) NOT NULL DEFAULT '',
  time_slug varchar(60) NOT NULL DEFAULT '',
  forum_slug varchar(60) NOT NULL DEFAULT '',
  confirmou_grupo tinyint(1) NOT NULL DEFAULT 0,
  aceite_termos varchar(40) NOT NULL DEFAULT '',
  aceite_ofertas tinyint(1) NOT NULL DEFAULT 0,
  ip_hash char(16) NOT NULL DEFAULT '',
  origem varchar(255) NOT NULL DEFAULT '',
  status varchar(12) NOT NULL DEFAULT 'ativo',
  ultimo_uso datetime NULL,
  PRIMARY KEY  (id),
  KEY whatsapp (whatsapp),
  KEY forum_slug (forum_slug)
) $c;");
    update_option('tsp_fr_db', '1', true);
}

// Pautas iniciais do TSP em cada fórum (só opinião, nenhum fato novo)
function tsp_fr_criar_pautas()
{
    if (get_option('tsp_fr_pautas') === '1' || !function_exists('tsp_wg_grupos')) {
        return;
    }
    update_option('tsp_fr_pautas', '1', true);
    $admins = get_users(array('role' => 'administrator', 'number' => 1, 'fields' => 'ID'));
    $autor = $admins ? (int) $admins[0] : 0;
    foreach (tsp_wg_grupos() as $slug => $g) {
        $quem = tsp_fr_quem($g);
        $div = tsp_fr_div_do($slug);
        $comp = $div ? 'no ' . $div : 'na temporada 2027';
        $pautas = array(
            array('Qual a sua expectativa para o ' . $g['nome'] . ' ' . $comp . '?', 'Briga lá em cima, campanha tranquila ou sufoco? Diga o que você espera ' . $quem . ' ' . $comp . ' e por quê.'),
            array('Mercado da bola: de que posição o ' . $g['nome'] . ' mais precisa?', 'Goleiro, zaga, laterais, meio ou ataque? Diga a posição e, se quiser, o perfil de jogador que você traria. Aqui é opinião da torcida: contratação confirmada sai no Mercado da Bola do TSP.'),
            array('Escalação ideal: qual é o seu time titular ' . $quem . '?', 'Monte o seu onze ' . $quem . ' para 2027. Quem é indispensável e quem você deixaria no banco?'),
        );
        foreach ($pautas as $p) {
            $id = wp_insert_post(array(
                'post_type' => 'tsp_topico',
                'post_status' => 'publish',
                'post_title' => str_replace('o ' . $g['nome'], ($g['de'] === 'da' ? 'a ' : 'o ') . $g['nome'], $p[0]),
                'post_content' => $p[1],
                'post_author' => $autor,
                'comment_status' => 'open',
            ));
            if ($id && !is_wp_error($id)) {
                update_post_meta($id, '_tsp_clube', $slug);
                update_post_meta($id, '_tsp_pauta', 1);
                update_post_meta($id, '_tsp_autor', 'Redação TSP');
            }
        }
    }
}

/* ---------- Lead: cookie assinado ---------- */

function tsp_fr_assinar($id)
{
    return $id . '.' . substr(hash_hmac('sha256', 'lead' . $id, wp_salt('auth')), 0, 20);
}

function tsp_fr_lead_atual()
{
    static $lead = false;
    if ($lead !== false) {
        return $lead;
    }
    $lead = null;
    $c = isset($_COOKIE['tsp_lead']) ? sanitize_text_field(wp_unslash($_COOKIE['tsp_lead'])) : '';
    if ($c && preg_match('/^(\d+)\./', $c, $m) && hash_equals(tsp_fr_assinar((int) $m[1]), $c)) {
        global $wpdb;
        $l = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . tsp_fr_tabela() . ' WHERE id = %d AND status = %s', (int) $m[1], 'ativo'), ARRAY_A);
        $lead = $l ?: null;
    }
    return $lead;
}

function tsp_fr_cookie($valor, $dias)
{
    $exp = $dias > 0 ? time() + $dias * DAY_IN_SECONDS : time() - 3600;
    setcookie('tsp_lead', $valor, array('expires' => $exp, 'path' => '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax'));
    // Só o primeiro nome, para a página (que pode vir do cache) mostrar o formulário certo
    setcookie('tsp_lead_nome', $valor ? tsp_fr_primeiro_nome($GLOBALS['tsp_fr_nome'] ?? '') : '', array('expires' => $exp, 'path' => '/', 'secure' => is_ssl(), 'httponly' => false, 'samesite' => 'Lax'));
}

function tsp_fr_primeiro_nome($n)
{
    $n = trim(preg_replace('/\s+/', ' ', (string) $n));
    $p = explode(' ', $n);
    return mb_substr($p[0], 0, 30);
}

function tsp_fr_ip_hash()
{
    $ip = isset($_SERVER['HTTP_CF_CONNECTING_IP']) ? $_SERVER['HTTP_CF_CONNECTING_IP'] : ($_SERVER['REMOTE_ADDR'] ?? ''); // phpcs:ignore
    return substr(hash_hmac('sha256', (string) $ip, wp_salt('nonce')), 0, 16);
}

// Ficha anti-robô que funciona mesmo com a página em cache (vale 7 dias, mínimo 3 segundos)
function tsp_fr_ficha()
{
    $t = time();
    return $t . '.' . substr(hash_hmac('sha256', 'fr' . $t, wp_salt('nonce')), 0, 16);
}

function tsp_fr_ficha_ok($f)
{
    if (!preg_match('/^(\d+)\.([a-f0-9]{16})$/', (string) $f, $m)) {
        return false;
    }
    $idade = time() - (int) $m[1];
    return $idade >= 3 && $idade <= 7 * DAY_IN_SECONDS && hash_equals(substr(hash_hmac('sha256', 'fr' . $m[1], wp_salt('nonce')), 0, 16), $m[2]);
}

/* ---------- Recebimento dos formulários ---------- */

function tsp_fr_volta($url, $msg)
{
    wp_safe_redirect(add_query_arg('fr', $msg, $url) . '#participar');
    exit;
}

// Texto suspeito vai para moderação
function tsp_fr_suspeito($t)
{
    $t = mb_strtolower($t);
    if (preg_match('~https?://|www\.|chat\.whatsapp|wa\.me|\.com\b|\.br\b|@~u', $t)) {
        return true;
    }
    if (preg_match('/\d[\d\s().-]{8,}\d/', $t)) {
        return true;
    }
    foreach (array('aposta', 'bet', 'pix', 'cassino', 'tigrinho', 'porra', 'caralho', 'puta', 'viado', 'macaco', 'arrombado', 'fdp', 'buceta', 'cuzão', 'piranha') as $p) {
        if (preg_match('/(^|[^\p{L}])' . preg_quote($p, '/') . '([^\p{L}]|$)/u', $t)) {
            return true;
        }
    }
    return false;
}

function tsp_fr_limite_ok($lead_id)
{
    $k = 'tsp_fr_lim_' . (int) $lead_id;
    $n = (int) get_transient($k);
    if ($n >= 8) {
        return false;
    }
    set_transient($k, $n + 1, HOUR_IN_SECONDS);
    return true;
}

add_action('template_redirect', function () {
    if (empty($_POST['tsp_fr_acao'])) { // phpcs:ignore
        return;
    }
    $acao = sanitize_key(wp_unslash($_POST['tsp_fr_acao'])); // phpcs:ignore
    $volta = esc_url_raw(wp_unslash($_POST['tsp_fr_volta'] ?? '')); // phpcs:ignore
    $volta = $volta && wp_validate_redirect($volta) ? strtok($volta, '?#') : tsp_fr_url();
    if (!empty($_POST['tsp_fr_site']) || !tsp_fr_ficha_ok(wp_unslash($_POST['tsp_fr_ficha'] ?? ''))) { // phpcs:ignore
        tsp_fr_volta($volta, 'erro');
    }
    global $wpdb;

    if ($acao === 'cadastro') {
        $nome = sanitize_text_field(wp_unslash($_POST['nome'] ?? '')); // phpcs:ignore
        $zap = preg_replace('/\D/', '', wp_unslash($_POST['whatsapp'] ?? '')); // phpcs:ignore
        $time = sanitize_key(wp_unslash($_POST['time'] ?? '')); // phpcs:ignore
        $forum = sanitize_key(wp_unslash($_POST['forum'] ?? '')); // phpcs:ignore
        if (strlen($zap) === 13 && strpos($zap, '55') === 0) {
            $zap = substr($zap, 2);
        }
        if (mb_strlen($nome) < 2 || mb_strlen($nome) > 80 || !preg_match('/^\d{10,11}$/', $zap) || empty($_POST['termos']) || empty($_POST['grupo'])) { // phpcs:ignore
            tsp_fr_volta($volta, 'faltou');
        }
        $agora = current_time('mysql');
        $ja = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . tsp_fr_tabela() . ' WHERE whatsapp = %s AND status = %s', $zap, 'ativo'));
        $dados = array(
            'nome' => mb_substr($nome, 0, 80),
            'time_slug' => mb_substr($time, 0, 60),
            'forum_slug' => mb_substr($forum, 0, 60),
            'confirmou_grupo' => 1,
            'aceite_termos' => TSP_FR_TERMOS . ' ' . $agora,
            'aceite_ofertas' => empty($_POST['ofertas']) ? 0 : 1, // phpcs:ignore
            'ip_hash' => tsp_fr_ip_hash(),
            'origem' => mb_substr($volta, 0, 255),
            'ultimo_uso' => $agora,
        );
        if ($ja) {
            $wpdb->update(tsp_fr_tabela(), $dados, array('id' => (int) $ja));
            $id = (int) $ja;
        } else {
            $wpdb->insert(tsp_fr_tabela(), array_merge($dados, array('criado' => $agora, 'whatsapp' => $zap, 'status' => 'ativo')));
            $id = (int) $wpdb->insert_id;
        }
        $GLOBALS['tsp_fr_nome'] = $nome;
        tsp_fr_cookie(tsp_fr_assinar($id), 365);
        tsp_fr_volta($volta, 'bemvindo');
    }

    $lead = tsp_fr_lead_atual();
    if (!$lead) {
        tsp_fr_volta($volta, 'cadastre');
    }

    if ($acao === 'apagar') {
        $ids = get_posts(array('post_type' => 'tsp_topico', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => '_tsp_lead', 'meta_value' => (int) $lead['id'])); // phpcs:ignore
        foreach ($ids as $p) {
            wp_delete_post($p, true);
        }
        foreach (get_comments(array('meta_key' => '_tsp_lead', 'meta_value' => (int) $lead['id'], 'status' => 'all')) as $c) { // phpcs:ignore
            wp_delete_comment($c->comment_ID, true);
        }
        $wpdb->delete(tsp_fr_tabela(), array('id' => (int) $lead['id']));
        tsp_fr_cookie('', -1);
        tsp_fr_volta($volta, 'apagado');
    }

    if (!tsp_fr_limite_ok($lead['id'])) {
        tsp_fr_volta($volta, 'calma');
    }
    $wpdb->update(tsp_fr_tabela(), array('ultimo_uso' => current_time('mysql')), array('id' => (int) $lead['id']));
    $autor = tsp_fr_primeiro_nome($lead['nome']);

    if ($acao === 'topico') {
        $clube = sanitize_key(wp_unslash($_POST['forum'] ?? '')); // phpcs:ignore
        $tit = sanitize_text_field(wp_unslash($_POST['titulo'] ?? '')); // phpcs:ignore
        $txt = sanitize_textarea_field(wp_unslash($_POST['texto'] ?? '')); // phpcs:ignore
        if (!tsp_fr_grupo($clube) || mb_strlen($tit) < 8 || mb_strlen($tit) > 120 || mb_strlen($txt) < 10 || mb_strlen($txt) > 2000) {
            tsp_fr_volta($volta, 'faltou');
        }
        $mod = tsp_fr_suspeito($tit . ' ' . $txt);
        $id = wp_insert_post(array(
            'post_type' => 'tsp_topico',
            'post_status' => $mod ? 'pending' : 'publish',
            'post_title' => $tit,
            'post_content' => $txt,
            'post_author' => 0,
            'comment_status' => 'open',
        ));
        if ($id && !is_wp_error($id)) {
            update_post_meta($id, '_tsp_clube', $clube);
            update_post_meta($id, '_tsp_lead', (int) $lead['id']);
            update_post_meta($id, '_tsp_autor', $autor);
        }
        tsp_fr_volta($volta, $mod ? 'moderacao' : 'publicado');
    }

    if ($acao === 'resposta') {
        $post = (int) ($_POST['topico'] ?? 0); // phpcs:ignore
        $txt = sanitize_textarea_field(wp_unslash($_POST['texto'] ?? '')); // phpcs:ignore
        if (get_post_type($post) !== 'tsp_topico' || get_post_status($post) !== 'publish' || mb_strlen($txt) < 2 || mb_strlen($txt) > 1500) {
            tsp_fr_volta($volta, 'faltou');
        }
        $mod = tsp_fr_suspeito($txt);
        $cid = wp_insert_comment(array(
            'comment_post_ID' => $post,
            'comment_author' => $autor,
            'comment_author_email' => '',
            'comment_content' => $txt,
            'comment_approved' => $mod ? 0 : 1,
            'comment_type' => 'comment',
        ));
        if ($cid) {
            add_comment_meta($cid, '_tsp_lead', (int) $lead['id']);
        }
        tsp_fr_volta($volta, $mod ? 'moderacao' : 'publicado');
    }
    tsp_fr_volta($volta, 'erro');
}, 1);

/* ---------- Pedaços de página ---------- */

function tsp_fr_aviso()
{
    $m = array(
        'bemvindo' => array('ok', 'Cadastro feito! Agora você já pode abrir tópicos e responder.'),
        'publicado' => array('ok', 'Publicado! Obrigado por participar.'),
        'moderacao' => array('alerta', 'Recebido. Como o texto tem link, telefone ou palavra da lista de bloqueio, ele passa pela moderação antes de aparecer.'),
        'faltou' => array('erro', 'Faltou alguma coisa. Confira os campos (WhatsApp com DDD) e as caixas de confirmação.'),
        'cadastre' => array('erro', 'Para publicar, faça o cadastro abaixo.'),
        'calma' => array('alerta', 'Muitas publicações em pouco tempo. Tente de novo daqui a pouco.'),
        'apagado' => array('ok', 'Pronto: seus dados e suas publicações foram apagados.'),
        'erro' => array('erro', 'Não deu certo. Recarregue a página e tente de novo.'),
    );
    $k = isset($_GET['fr']) ? sanitize_key(wp_unslash($_GET['fr'])) : ''; // phpcs:ignore
    return isset($m[$k]) ? '<p class="tsp-fr__aviso tsp-fr__aviso--' . $m[$k][0] . '" role="status">' . esc_html($m[$k][1]) . '</p>' : '';
}

function tsp_fr_campos_comuns($volta)
{
    return '<input type="hidden" name="tsp_fr_volta" value="' . esc_attr($volta) . '">'
        . '<input type="hidden" name="tsp_fr_ficha" value="' . esc_attr(tsp_fr_ficha()) . '">'
        . '<div class="tsp-fr__mel" aria-hidden="true"><label>Site <input type="text" name="tsp_fr_site" tabindex="-1" autocomplete="off"></label></div>';
}

function tsp_fr_texto_lgpd()
{
    return '<details class="tsp-fr__lgpd"><summary>Como o TSP usa os seus dados (LGPD)</summary>'
        . '<p><strong>Quem cuida dos dados:</strong> Tudo Sobre Paulista (TSP), tudosobrepaulista.com.br.</p>'
        . '<p><strong>O que pedimos:</strong> nome, WhatsApp e time do coração.</p>'
        . '<p><strong>Para quê:</strong> identificar quem publica no fórum, moderar as conversas e confirmar a participação no grupo de WhatsApp do clube. Só se você marcar a caixa de novidades, também para mandar notícias e ofertas do TSP e de parceiros pelo WhatsApp.</p>'
        . '<p><strong>Base legal:</strong> o seu consentimento (Lei 13.709/2018, art. 7º, I). Você pode retirar quando quiser.</p>'
        . '<p><strong>O que aparece no site:</strong> só o seu primeiro nome. O WhatsApp nunca é publicado nem vendido.</p>'
        . '<p><strong>Por quanto tempo:</strong> enquanto você participar. Cadastro sem uso por 24 meses é apagado.</p>'
        . '<p><strong>Seus direitos:</strong> ver, corrigir e apagar seus dados. Neste aparelho, use o botão "Apagar meus dados" do fórum. Em outro aparelho, escreva para contato@tudosobrepaulista.com.br ou fale com um administrador do grupo de WhatsApp do clube.</p>'
        . '<p><small>Versão dos termos: ' . esc_html(TSP_FR_TERMOS) . '</small></p></details>';
}

function tsp_fr_form_cadastro($g, $volta)
{
    $times = function_exists('tsp_clubes_paulistas') ? tsp_clubes_paulistas() : array();
    $opts = '<option value="">Escolha</option>';
    $tem = false;
    foreach ($times as $s => $info) {
        $t = get_term_by('slug', $s, 'times');
        $n = $t ? $t->name : $s;
        $sel = $g && $s === $g['slug'];
        $tem = $tem || $sel;
        $opts .= '<option value="' . esc_attr($s) . '"' . ($sel ? ' selected' : '') . '>' . esc_html($n) . '</option>';
    }
    if ($g && !$tem) {
        $opts .= '<option value="' . esc_attr($g['slug']) . '" selected>' . esc_html($g['nome']) . '</option>';
    }
    $opts .= '<option value="outro">Outro time</option>';
    $h = '<form class="tsp-fr__form tsp-fr__cad" method="post" action="' . esc_url($volta) . '">' . tsp_fr_campos_comuns($volta)
        . '<input type="hidden" name="tsp_fr_acao" value="cadastro"><input type="hidden" name="forum" value="' . esc_attr($g ? $g['slug'] : '') . '">'
        . '<h3>Cadastre-se para publicar</h3>';
    if ($g) {
        $h .= '<p class="tsp-fr__passo"><b>1.</b> Entre no grupo ' . esc_html(tsp_fr_quem($g)) . ': <a class="tsp-fr__bt tsp-fr__bt--zap" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug']) . '-forum">Entrar no grupo</a></p><p class="tsp-fr__passo"><b>2.</b> Preencha:</p>';
    }
    $h .= '<label>Nome <input type="text" name="nome" required maxlength="80" autocomplete="name"></label>'
        . '<label>WhatsApp com DDD <input type="tel" name="whatsapp" required inputmode="numeric" placeholder="(19) 99999-9999" autocomplete="tel-national"></label>'
        . '<label>Time do coração <select name="time" required>' . $opts . '</select></label>'
        . '<label class="tsp-fr__caixa"><input type="checkbox" name="grupo" value="1" required> Entrei no grupo de WhatsApp do clube.</label>'
        . '<label class="tsp-fr__caixa"><input type="checkbox" name="termos" value="1" required> Li e aceito que o TSP use meu nome, WhatsApp e time para o fórum, como explicado abaixo.</label>'
        . '<label class="tsp-fr__caixa"><input type="checkbox" name="ofertas" value="1"> Quero receber novidades e ofertas do TSP e de parceiros pelo WhatsApp (opcional).</label>'
        . tsp_fr_texto_lgpd()
        . '<button type="submit" class="tsp-fr__bt">Cadastrar e participar</button></form>';
    return $h;
}

function tsp_fr_bloco_participar($g, $volta, $form_lead)
{
    // As duas versões vão na página; o script mostra a certa pelo cookie (a página pode vir do cache)
    $sair = '<form class="tsp-fr__apagar" method="post" action="' . esc_url($volta) . '" onsubmit="return confirm(\'Apagar seu cadastro e tudo o que você publicou no fórum?\')">' . tsp_fr_campos_comuns($volta)
        . '<input type="hidden" name="tsp_fr_acao" value="apagar"><button type="submit">Apagar meus dados</button></form>';
    return '<section class="tsp-fr__participar" id="participar">' . tsp_fr_aviso()
        . '<div class="tsp-fr__com" hidden><p class="tsp-fr__ola">Olá, <b data-fr-nome></b>!</p>' . $form_lead . $sair . '</div>'
        . '<div class="tsp-fr__sem">' . tsp_fr_form_cadastro($g, $volta) . '</div></section>';
}

function tsp_fr_form_topico($g, $volta)
{
    return '<form class="tsp-fr__form" method="post" action="' . esc_url($volta) . '">' . tsp_fr_campos_comuns($volta)
        . '<input type="hidden" name="tsp_fr_acao" value="topico"><input type="hidden" name="forum" value="' . esc_attr($g['slug']) . '">'
        . '<h3>Abrir um tópico</h3>'
        . '<label>Título <input type="text" name="titulo" required minlength="8" maxlength="120" placeholder="Ex.: Quem deve ser o camisa 10 em 2027?"></label>'
        . '<label>Sua opinião <textarea name="texto" required minlength="10" maxlength="2000" rows="5"></textarea></label>'
        . '<p class="tsp-fr__regra">Respeito sempre. Sem links, telefones, apostas ou ofensas (esses vão para moderação).</p>'
        . '<button type="submit" class="tsp-fr__bt">Publicar</button></form>';
}

function tsp_fr_form_resposta($post_id, $volta)
{
    return '<form class="tsp-fr__form" method="post" action="' . esc_url($volta) . '">' . tsp_fr_campos_comuns($volta)
        . '<input type="hidden" name="tsp_fr_acao" value="resposta"><input type="hidden" name="topico" value="' . (int) $post_id . '">'
        . '<h3>Responder</h3><label>Sua resposta <textarea name="texto" required minlength="2" maxlength="1500" rows="4"></textarea></label>'
        . '<p class="tsp-fr__regra">Respeito sempre. Sem links, telefones, apostas ou ofensas (esses vão para moderação).</p>'
        . '<button type="submit" class="tsp-fr__bt">Responder</button></form>';
}

function tsp_fr_autor($post_id)
{
    $a = get_post_meta($post_id, '_tsp_autor', true);
    return $a ? $a : 'Torcedor';
}

function tsp_fr_topicos($slug, $n = 30)
{
    $q = get_posts(array('post_type' => 'tsp_topico', 'post_status' => 'publish', 'numberposts' => $n, 'meta_key' => '_tsp_clube', 'meta_value' => $slug, 'orderby' => 'modified', 'order' => 'DESC')); // phpcs:ignore
    usort($q, function ($a, $b) {
        $pa = (int) get_post_meta($a->ID, '_tsp_pauta', true);
        $pb = (int) get_post_meta($b->ID, '_tsp_pauta', true);
        if ($pa !== $pb) {
            return $pb - $pa;
        }
        return strcmp($b->post_modified, $a->post_modified);
    });
    return $q;
}

function tsp_fr_item($p)
{
    $n = (int) get_comments_number($p->ID);
    $pauta = (int) get_post_meta($p->ID, '_tsp_pauta', true);
    return '<li class="tsp-fr__item' . ($pauta ? ' tsp-fr__item--pauta' : '') . '"><a href="' . esc_url(get_permalink($p)) . '">' . ($pauta ? '<span class="tsp-fr__selo">Pauta TSP</span>' : '')
        . '<strong>' . esc_html(get_the_title($p)) . '</strong><small>' . esc_html(tsp_fr_autor($p->ID)) . ' · ' . ($n === 1 ? '1 resposta' : $n . ' respostas') . '</small></a></li>';
}

function tsp_fr_seo($titulo, $desc, $url, $robots = '')
{
    foreach (array('pre_get_document_title', 'wpseo_title') as $f) {
        add_filter($f, function () use ($titulo) {
            return $titulo . ' | TSP';
        }, 99);
    }
    add_filter('wpseo_metadesc', function () use ($desc) {
        return mb_substr($desc, 0, 155);
    }, 99);
    foreach (array('wpseo_canonical', 'wpseo_opengraph_url') as $f) {
        add_filter($f, function () use ($url) {
            return $url;
        }, 99);
    }
    if ($robots) {
        add_filter('wpseo_robots', function () use ($robots) {
            return $robots;
        }, 99);
        add_filter('wp_robots', function ($r) {
            return array('noindex' => true, 'follow' => true);
        }, 99);
    }
}

function tsp_fr_faq($g)
{
    $quem = tsp_fr_quem($g);
    $resenha = !empty($g['tipo']);
    return array(
        array('Como entrar no grupo de WhatsApp ' . $quem . '?', 'Toque em "Entrar no grupo" nesta página e confirme no WhatsApp. A entrada é imediata e grátis. O grupo se chama ' . tsp_fr_nome_grupo($g) . ' e é organizado pelo Tudo Sobre Paulista.'),
        array('O grupo de WhatsApp ' . $quem . ' é oficial?', 'Não. É um grupo ' . ($resenha ? 'aberto de torcedores' : 'de notícias') . ' organizado pelo Tudo Sobre Paulista (TSP). Não tem ligação com o clube. Os canais oficiais ' . $quem . ' são os do próprio clube.'),
        array('Quanto custa participar?', 'Nada. O grupo de WhatsApp e o fórum da torcida são gratuitos.'),
        array('Quais são as regras do grupo?', 'Respeito a todos, sem racismo, homofobia ou ofensas; assunto é futebol; proibido apostas, jogos piratas, golpes e propaganda sem autorização. Quem descumpre é removido pelos administradores.'),
        array('Como publicar no fórum ' . $quem . '?', 'Entre no grupo de WhatsApp do clube e faça o cadastro com nome, WhatsApp e time do coração. Depois disso você abre tópicos e responde às pautas. No site aparece só o seu primeiro nome.'),
    );
}

/* ---------- Páginas ---------- */

add_action('template_redirect', function () {
    $f = get_query_var('tsp_forum');
    if (!$f) {
        return;
    }
    if ($f === 'sitemap') {
        tsp_fr_sitemap();
        exit;
    }
    if ($f === '1') {
        tsp_fr_pagina_hub();
        exit;
    }
    $g = tsp_fr_grupo(sanitize_key($f));
    if (!$g) {
        wp_safe_redirect(tsp_fr_url(), 301);
        exit;
    }
    tsp_fr_pagina_clube($g);
    exit;
}, 5);

function tsp_fr_cabeca()
{
    status_header(200);
    $GLOBALS['wp_query']->is_404 = false;
    get_header();
}

function tsp_fr_pagina_hub()
{
    $tit = 'Grupos de WhatsApp dos clubes paulistas: link para entrar e fórum da torcida';
    $resp = 'O Tudo Sobre Paulista tem grupos de WhatsApp abertos e gratuitos para a torcida dos clubes do Paulistão A1 e A2 2027. Escolha o seu time, toque em "Entrar no grupo" e participe também do fórum do clube. Os grupos não são oficiais dos clubes.';
    tsp_fr_seo($tit, $resp, tsp_fr_url());
    tsp_fr_cabeca();
    echo '<main class="tsp-container tsp-fr">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <span>Grupos de WhatsApp e fórum</span></nav>';
    echo '<header class="tsp-fr__cab"><h1>' . esc_html($tit) . '</h1><div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div></header>';
    foreach (tsp_fr_divisoes() as $div => $lista) {
        echo '<section class="tsp-fr__div"><h2>' . esc_html($div) . '</h2><div class="tsp-fr__grade">';
        foreach ($lista as $s) {
            $g = tsp_fr_grupo($s);
            if (!$g) {
                continue;
            }
            $t = get_term_by('slug', $s, 'times');
            echo '<article class="tsp-fr__card">' . ($t ? tsp_escudo($t, 44) : '') . '<h3><a href="' . esc_url(tsp_fr_url($s)) . '">' . esc_html($g['nome']) . '</a></h3>'
                . '<small>' . (!empty($g['tipo']) ? 'Grupo aberto de resenha' : 'Grupo de notícias') . '</small>'
                . '<div class="tsp-fr__acoes"><a class="tsp-fr__bt tsp-fr__bt--zap" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($s) . '-hub">Entrar no grupo</a><a class="tsp-fr__bt tsp-fr__bt--claro" href="' . esc_url(tsp_fr_url($s)) . '">Fórum</a></div></article>';
        }
        echo '</div></section>';
    }
    echo '<p class="tsp-nota">Os grupos são organizados pelo Tudo Sobre Paulista (TSP) e não têm ligação com os clubes. Regras: respeito, futebol como assunto, nada de apostas, pirataria, golpes ou propaganda sem autorização.</p>';
    echo '</main>';
    get_footer();
}

function tsp_fr_pagina_clube($g)
{
    $quem = tsp_fr_quem($g);
    $url = tsp_fr_url($g['slug']);
    $resenha = !empty($g['tipo']);
    $tit = 'Grupo de WhatsApp ' . $quem . ': link para entrar e fórum da torcida';
    $resp = 'O grupo ' . ($resenha ? 'aberto de WhatsApp' : 'de WhatsApp') . ' ' . $quem . ' é o "' . tsp_fr_nome_grupo($g) . '", organizado pelo Tudo Sobre Paulista. A entrada é grátis pelo botão abaixo. Não é o grupo oficial do clube. No fórum, quem entra no grupo e se cadastra abre tópicos e responde às pautas.';
    tsp_fr_seo($tit, $resp, $url);
    $faq = tsp_fr_faq($g);
    add_action('wp_head', function () use ($faq) {
        $itens = array();
        foreach ($faq as $q) {
            $itens[] = array('@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $q[1]));
        }
        echo '<script type="application/ld+json">' . wp_json_encode(array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $itens), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }, 30);
    tsp_fr_cabeca();
    $t = get_term_by('slug', $g['slug'], 'times');
    echo '<main class="tsp-container tsp-fr">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <a href="' . esc_url(tsp_fr_url()) . '">Grupos de WhatsApp e fórum</a> › <span>' . esc_html($g['nome']) . '</span></nav>';
    echo '<header class="tsp-fr__cab tsp-fr__cab--clube">' . ($t ? tsp_escudo($t, 64) : '') . '<div><h1>' . esc_html($tit) . '</h1>'
        . '<div class="tsp-camp__resposta"><strong>Resposta rápida</strong><p>' . esc_html($resp) . '</p></div></div></header>';
    echo '<div class="tsp-fr__entrar"><a class="tsp-fr__bt tsp-fr__bt--zap tsp-fr__bt--grande" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($g['slug']) . '-forum">' . tsp_wg_ico(22) . ' Entrar no grupo ' . esc_html($quem) . '</a>'
        . ($t ? '<a class="tsp-fr__bt tsp-fr__bt--claro" href="' . esc_url(get_term_link($t)) . '">Notícias ' . esc_html($quem) . '</a>' : '') . '</div>';
    // Últimas notícias do clube (página também recebe os anúncios de "notícias do <clube>")
    if ($t) {
        $nots = get_posts(array('post_type' => tsp_tipos(), 'post_status' => 'publish', 'numberposts' => 6, 'no_found_rows' => true, 'tax_query' => array(array('taxonomy' => 'times', 'field' => 'slug', 'terms' => $g['slug'])))); // phpcs:ignore
        if ($nots) {
            echo '<section class="tsp-fr__nots"><h2>Últimas notícias ' . esc_html($quem) . '</h2><ul>';
            foreach ($nots as $n) {
                echo '<li><a href="' . esc_url(get_permalink($n)) . '">' . esc_html(get_the_title($n)) . '</a><small>' . esc_html(get_the_date('d/m H\\hi', $n)) . '</small></li>';
            }
            echo '</ul><a class="tsp-fr__mais" href="' . esc_url(get_term_link($t)) . '">Todas as notícias ' . esc_html($quem) . ' →</a></section>';
        }
    }
    echo '<div class="tsp-fr__corpo"><section class="tsp-fr__lista"><h2>Fórum da torcida ' . esc_html($quem) . '</h2>';
    $tops = tsp_fr_topicos($g['slug']);
    echo $tops ? '<ul>' . implode('', array_map('tsp_fr_item', $tops)) . '</ul>' : '<p class="tsp-vazio">Ainda não há tópicos. Abra o primeiro!</p>'; // phpcs:ignore
    echo '</section><aside class="tsp-fr__lado">' . tsp_fr_bloco_participar($g, $url, tsp_fr_form_topico($g, $url)) . '</aside></div>'; // phpcs:ignore
    echo '<section class="tsp-fr__faq"><h2>Perguntas frequentes</h2>';
    foreach ($faq as $q) {
        echo '<h3>' . esc_html($q[0]) . '</h3><p>' . esc_html($q[1]) . '</p>';
    }
    echo '</section><p class="tsp-nota">Opiniões publicadas no fórum são de quem escreveu, não do TSP. Grupo e fórum organizados pelo Tudo Sobre Paulista, sem ligação com o clube.</p></main>';
    get_footer();
}

// Tópico: página própria (noindex até ter 3 respostas, para não indexar página rala)
add_action('template_redirect', function () {
    if (!is_singular('tsp_topico')) {
        return;
    }
    $p = get_queried_object();
    $slug = get_post_meta($p->ID, '_tsp_clube', true);
    $g = tsp_fr_grupo($slug);
    if (!$g) {
        return;
    }
    $url = get_permalink($p);
    $n = (int) get_comments_number($p->ID);
    $desc = wp_trim_words(wp_strip_all_tags($p->post_content), 25, '…');
    tsp_fr_seo(get_the_title($p) . ' - Fórum ' . tsp_fr_quem($g), $desc, $url, $n >= 3 ? '' : 'noindex, follow');
    tsp_fr_cabeca();
    $t = get_term_by('slug', $slug, 'times');
    echo '<main class="tsp-container tsp-fr tsp-fr--topico">';
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a> › <a href="' . esc_url(tsp_fr_url()) . '">Fórum</a> › <a href="' . esc_url(tsp_fr_url($slug)) . '">' . esc_html($g['nome']) . '</a></nav>';
    echo '<article class="tsp-fr__topico"><header>' . ($t ? tsp_escudo($t, 40) : '') . '<h1>' . esc_html(get_the_title($p)) . '</h1></header>'
        . '<p class="tsp-fr__meta">' . esc_html(tsp_fr_autor($p->ID)) . ' · ' . esc_html(get_the_date('d/m/Y H:i', $p)) . '</p>'
        . '<div class="tsp-fr__texto">' . wpautop(esc_html($p->post_content)) . '</div></article>'; // phpcs:ignore
    $cs = get_comments(array('post_id' => $p->ID, 'status' => 'approve', 'order' => 'ASC'));
    echo '<section class="tsp-fr__respostas"><h2>' . ($n === 1 ? '1 resposta' : $n . ' respostas') . '</h2>';
    foreach ($cs as $c) {
        echo '<div class="tsp-fr__resp"><p class="tsp-fr__meta"><b>' . esc_html($c->comment_author ?: 'Torcedor') . '</b> · ' . esc_html(mysql2date('d/m/Y H:i', $c->comment_date)) . '</p>' . wpautop(esc_html($c->comment_content)) . '</div>'; // phpcs:ignore
    }
    echo '</section>';
    echo tsp_fr_bloco_participar($g, $url, tsp_fr_form_resposta($p->ID, $url)); // phpcs:ignore
    echo '<p class="tsp-fr__volta"><a href="' . esc_url(tsp_fr_url($slug)) . '">← Todos os tópicos ' . esc_html(tsp_fr_quem($g)) . '</a> · <a class="tsp-fr__bt tsp-fr__bt--zap" href="' . esc_url($g['url']) . '" target="_blank" rel="noopener nofollow" data-tsp-wg="' . esc_attr($slug) . '-topico">Entrar no grupo</a></p>';
    echo '</main>';
    get_footer();
    exit;
}, 6);

// Script: mostra o formulário certo (com ou sem cadastro) e formata o WhatsApp
add_action('wp_footer', function () {
    if (!get_query_var('tsp_forum') && !is_singular('tsp_topico')) {
        return;
    }
    echo "<script>(function(){var m=document.cookie.match(/(?:^|; )tsp_lead_nome=([^;]*)/),n=m?decodeURIComponent(m[1]):'';"
        . "document.querySelectorAll('.tsp-fr__participar').forEach(function(s){var com=s.querySelector('.tsp-fr__com'),sem=s.querySelector('.tsp-fr__sem');if(n){com.hidden=false;sem.hidden=true;var b=com.querySelector('[data-fr-nome]');if(b)b.textContent=n}});"
        . "document.querySelectorAll('input[name=whatsapp]').forEach(function(i){i.addEventListener('input',function(){var d=i.value.replace(/\\D/g,'').slice(0,11),r=d;if(d.length>2)r='('+d.slice(0,2)+') '+d.slice(2);if(d.length>7)r='('+d.slice(0,2)+') '+d.slice(2,d.length-4)+'-'+d.slice(-4);i.value=r})});})();</script>";
}, 30);

/* ---------- Matérias e página do clube: convite para o fórum ---------- */

function tsp_fr_cta($g)
{
    return '<p class="tsp-fr-cta"><a href="' . esc_url(tsp_fr_url($g['slug'])) . '">💬 Debata no fórum da torcida ' . esc_html(tsp_fr_quem($g)) . ' →</a></p>';
}

add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query() || !function_exists('tsp_wg_do_post')) {
        return $html;
    }
    $gs = tsp_wg_do_post(get_the_ID());
    return $gs ? $html . tsp_fr_cta($gs[0]) : $html;
}, 13);

/* ---------- Sitemap próprio (Yoast não enxerga páginas virtuais) ---------- */

add_filter('wpseo_sitemap_index', function ($x) {
    return $x . '<sitemap><loc>' . esc_url(home_url('/tsp-mapa-forum.xml')) . '</loc><lastmod>' . esc_html(gmdate('c')) . '</lastmod></sitemap>';
});

function tsp_fr_sitemap()
{
    status_header(200);
    header('Content-Type: application/xml; charset=UTF-8');
    header('X-Robots-Tag: noindex, follow');
    echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>' . esc_url(tsp_fr_url()) . '</loc></url>';
    foreach (tsp_fr_divisoes() as $l) {
        foreach ($l as $s) {
            if (tsp_fr_grupo($s)) {
                echo '<url><loc>' . esc_url(tsp_fr_url($s)) . '</loc></url>';
            }
        }
    }
    echo '</urlset>';
}

/* ---------- Painel do administrador: Fórum e leads ---------- */

add_action('admin_menu', function () {
    add_menu_page('Fórum e leads', 'Fórum e leads', 'manage_options', 'tsp-leads', 'tsp_fr_admin', 'dashicons-groups', 26);
});

add_action('admin_init', function () {
    if (!current_user_can('manage_options') || empty($_GET['page']) || $_GET['page'] !== 'tsp-leads') { // phpcs:ignore
        return;
    }
    global $wpdb;
    if (!empty($_GET['apagar']) && check_admin_referer('tsp_lead_apagar')) {
        $wpdb->delete(tsp_fr_tabela(), array('id' => (int) $_GET['apagar']));
        wp_safe_redirect(admin_url('admin.php?page=tsp-leads&feito=1'));
        exit;
    }
    if (!empty($_GET['csv']) && check_admin_referer('tsp_lead_csv')) {
        $rows = $wpdb->get_results('SELECT criado,nome,whatsapp,time_slug,forum_slug,aceite_ofertas,aceite_termos FROM ' . tsp_fr_tabela() . " WHERE status='ativo' ORDER BY id DESC", ARRAY_A);
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename=leads-forum-' . gmdate('Y-m-d') . '.csv');
        $o = fopen('php://output', 'w');
        fwrite($o, "\xEF\xBB\xBF");
        fputcsv($o, array('Cadastro', 'Nome', 'WhatsApp', 'Time do coração', 'Fórum', 'Aceitou ofertas', 'Termos aceitos'), ';');
        foreach ($rows as $r) {
            $r['aceite_ofertas'] = $r['aceite_ofertas'] ? 'sim' : 'não';
            fputcsv($o, $r, ';');
        }
        exit;
    }
});

// Cadastro sem uso por 24 meses é apagado (prometido no texto da LGPD)
add_action('init', function () {
    if (!wp_next_scheduled('tsp_fr_limpeza')) {
        wp_schedule_event(time() + 600, 'daily', 'tsp_fr_limpeza');
    }
});
add_action('tsp_fr_limpeza', function () {
    global $wpdb;
    $wpdb->query($wpdb->prepare('DELETE FROM ' . tsp_fr_tabela() . ' WHERE COALESCE(ultimo_uso, criado) < %s', gmdate('Y-m-d H:i:s', time() - 730 * DAY_IN_SECONDS)));
});

function tsp_fr_admin()
{
    global $wpdb;
    $tab = tsp_fr_tabela();
    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $tab WHERE status='ativo'");
    $ofertas = (int) $wpdb->get_var("SELECT COUNT(*) FROM $tab WHERE status='ativo' AND aceite_ofertas=1");
    $semana = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tab WHERE status='ativo' AND criado >= %s", wp_date('Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS)));
    $por = $wpdb->get_results("SELECT forum_slug, COUNT(*) n, SUM(aceite_ofertas) o FROM $tab WHERE status='ativo' GROUP BY forum_slug ORDER BY n DESC", ARRAY_A);
    $filtro = isset($_GET['forum']) ? sanitize_key(wp_unslash($_GET['forum'])) : ''; // phpcs:ignore
    $lista = $filtro
        ? $wpdb->get_results($wpdb->prepare("SELECT * FROM $tab WHERE status='ativo' AND forum_slug=%s ORDER BY id DESC LIMIT 300", $filtro), ARRAY_A)
        : $wpdb->get_results("SELECT * FROM $tab WHERE status='ativo' ORDER BY id DESC LIMIT 300", ARRAY_A);
    $pend_t = (int) wp_count_posts('tsp_topico')->pending;
    $pend_c = (int) get_comments(array('status' => 'hold', 'post_type' => 'tsp_topico', 'count' => true));
    echo '<div class="wrap"><h1>Fórum e leads</h1>';
    if (!empty($_GET['feito'])) { // phpcs:ignore
        echo '<div class="notice notice-success"><p>Cadastro apagado.</p></div>';
    }
    echo '<p style="font-size:15px"><b>' . $total . '</b> cadastros · <b>' . $semana . '</b> nos últimos 7 dias · <b>' . $ofertas . '</b> aceitaram receber ofertas.</p>';
    echo '<p>Na moderação: <a href="' . esc_url(admin_url('edit.php?post_type=tsp_topico&post_status=pending')) . '">' . $pend_t . ' tópicos</a> e <a href="' . esc_url(admin_url('edit-comments.php?comment_status=moderated')) . '">' . $pend_c . ' respostas</a>. · <a href="' . esc_url(tsp_fr_url()) . '" target="_blank">Ver o fórum</a></p>';
    echo '<p><a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=tsp-leads&csv=1'), 'tsp_lead_csv')) . '">Baixar planilha (CSV)</a></p>';
    echo '<p style="max-width:760px;color:#555">LGPD: só mande oferta para quem marcou "Aceitou ofertas = sim". Se alguém pedir para sair, apague o cadastro aqui. Não compartilhe a planilha fora da empresa.</p>';
    echo '<h2>Por fórum</h2><table class="widefat striped" style="max-width:520px"><thead><tr><th>Fórum</th><th>Cadastros</th><th>Aceitam ofertas</th></tr></thead><tbody>';
    foreach ($por as $r) {
        $g = tsp_fr_grupo($r['forum_slug']);
        echo '<tr><td><a href="' . esc_url(admin_url('admin.php?page=tsp-leads&forum=' . $r['forum_slug'])) . '">' . esc_html($g ? $g['nome'] : ($r['forum_slug'] ?: '—')) . '</a></td><td>' . (int) $r['n'] . '</td><td>' . (int) $r['o'] . '</td></tr>';
    }
    echo '</tbody></table><h2>' . ($filtro ? 'Cadastros do fórum: ' . esc_html($filtro) . ' · <a href="' . esc_url(admin_url('admin.php?page=tsp-leads')) . '">ver todos</a>' : 'Últimos cadastros') . '</h2>';
    echo '<table class="widefat striped"><thead><tr><th>Data</th><th>Nome</th><th>WhatsApp</th><th>Time</th><th>Fórum</th><th>Ofertas</th><th></th></tr></thead><tbody>';
    foreach ($lista as $l) {
        $z = $l['whatsapp'];
        $zf = strlen($z) >= 10 ? '(' . substr($z, 0, 2) . ') ' . substr($z, 2, -4) . '-' . substr($z, -4) : $z;
        echo '<tr><td>' . esc_html(mysql2date('d/m/Y H:i', $l['criado'])) . '</td><td>' . esc_html($l['nome']) . '</td><td><a href="https://wa.me/55' . esc_attr($z) . '" target="_blank" rel="noopener">' . esc_html($zf) . '</a></td><td>' . esc_html($l['time_slug']) . '</td><td>' . esc_html($l['forum_slug']) . '</td><td>' . ($l['aceite_ofertas'] ? 'sim' : 'não') . '</td>'
            . '<td><a href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=tsp-leads&apagar=' . (int) $l['id']), 'tsp_lead_apagar')) . '" onclick="return confirm(\'Apagar este cadastro?\')">Apagar</a></td></tr>';
    }
    echo $lista ? '' : '<tr><td colspan="7">Nenhum cadastro ainda.</td></tr>';
    echo '</tbody></table></div>';
}
