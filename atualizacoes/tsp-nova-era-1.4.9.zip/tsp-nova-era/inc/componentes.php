<?php
/**
 * Peças reutilizáveis do tema: consultas por clube, cartões de notícia, blocos de tabela e vídeos.
 * Tudo é automático: as matérias entram nos blocos pela classificação "Times" que o redator marca.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_tipos()
{
    return array('materia', 'post');
}

function tsp_dado($chave, $padrao = array())
{
    $v = function_exists('tsp_dados') ? tsp_dados($chave, $padrao) : $padrao;
    // O plugin TSP Jogos coloca aqui os dados automáticos (tabelas, rodadas, jogos dos clubes)
    return apply_filters('tsp_dado', $v, $chave);
}

/* ---------- Consultas ---------- */

function tsp_consulta($args, &$vistos)
{
    // Versões por clube (matéria reescrita na ótica de outro clube) não entram na home nem nos blocos: só na página do clube
    $sem_versao = array('key' => 'tsp_versao_de', 'compare' => 'NOT EXISTS');
    $args['meta_query'] = !empty($args['meta_query']) ? array('relation' => 'AND', $args['meta_query'], $sem_versao) : array($sem_versao);
    $q = new WP_Query(array_merge(array(
        'post_type'              => tsp_tipos(),
        'post_status'            => 'publish',
        'posts_per_page'         => 8,
        'post__not_in'           => $vistos,
        'ignore_sticky_posts'    => true,
        'no_found_rows'          => true,
        'update_post_term_cache' => true,
    ), $args));
    return $q->posts;
}

function tsp_tax_times($slugs)
{
    return array(array('taxonomy' => 'times', 'field' => 'slug', 'terms' => (array) $slugs, 'include_children' => false));
}

// N matérias de cada clube (ex.: 2 por clube), juntas e em ordem da mais nova para a mais antiga
// $exclusivo = true: só matérias marcadas apenas com clubes do grupo (ex.: Mirassol e Bragantino, sem Palmeiras junto)
function tsp_ids_por_clube($slugs, $por_clube, &$vistos, $exclusivo = false)
{
    $posts = array();
    foreach ($slugs as $s) {
        $n = 0;
        foreach (tsp_consulta(array('posts_per_page' => $exclusivo ? 20 : $por_clube, 'tax_query' => tsp_tax_times($s)), $vistos) as $p) {
            if ($n >= $por_clube) {
                break;
            }
            if ($exclusivo) {
                $do_post = wp_get_post_terms($p->ID, 'times', array('fields' => 'slugs'));
                if (is_wp_error($do_post) || array_diff($do_post, $slugs)) {
                    continue;
                }
            }
            $posts[$p->ID] = $p;
            $vistos[] = $p->ID;
            $n++;
        }
    }
    uasort($posts, function ($a, $b) {
        return strcmp($b->post_date, $a->post_date);
    });
    return array_keys($posts);
}

// Bloco de 9: 2 por clube (todos os clubes aparecem) e completa com as mais novas do grupo
function tsp_ids_bloco($slugs, &$vistos, $total = 9)
{
    $ids = tsp_ids_por_clube($slugs, 2, $vistos);
    if (count($ids) < $total) {
        $ids = array_merge($ids, tsp_ids_grupo($slugs, $total - count($ids), $vistos));
    }
    return array_slice($ids, 0, $total);
}

// As N mais novas de um grupo de clubes
function tsp_ids_grupo($slugs, $n, &$vistos)
{
    $ids = wp_list_pluck(tsp_consulta(array('posts_per_page' => $n, 'tax_query' => tsp_tax_times($slugs)), $vistos), 'ID');
    $vistos = array_merge($vistos, $ids);
    return $ids;
}

// Vídeos: matérias dos clubes que têm vídeo do YouTube ou são coletivas
// 27/11/2026 (Thiago: "coloque essa matéria como a primeira no site"): manchete da home.
// Abre a home (1º card grande), fora dos vídeos e dos outros blocos: a matéria de api/manchete.json (até "ate") ou,
// se não houver, a mais recente com a tag "manchete" publicada nas últimas 36 horas.
function tsp_manchete_ids(&$vistos, $n = 1)
{
    $ids = array();
    if (function_exists('tsp_mc_arquivo')) {
        $m = tsp_mc_arquivo('manchete.json');
        if (!empty($m['ids']) && (empty($m['ate']) || strtotime($m['ate']) > time())) {
            foreach ((array) $m['ids'] as $id) {
                $id = (int) $id;
                if ($id && get_post_status($id) === 'publish' && !in_array($id, $vistos, true)) {
                    $ids[] = $id;
                }
            }
        }
    }
    if (count($ids) < $n) {
        $q = tsp_consulta(array('posts_per_page' => $n - count($ids), 'tag' => 'manchete', 'date_query' => array(array('after' => '36 hours ago')), 'update_post_meta_cache' => false), $vistos);
        $ids = array_merge($ids, wp_list_pluck($q, 'ID'));
    }
    $ids = array_slice($ids, 0, max($n, 1));
    $vistos = array_merge($vistos, $ids);
    return $ids;
}

function tsp_ids_videos($slugs, $n, &$vistos)
{
    $achados = array();
    foreach (tsp_consulta(array('posts_per_page' => 200, 'tax_query' => tsp_tax_times($slugs)), $vistos) as $p) {
        if (tsp_video_id($p->ID) || stripos($p->post_title, 'coletiva') !== false) {
            $achados[] = $p->ID;
            if (count($achados) >= $n) {
                break;
            }
        }
    }
    $vistos = array_merge($vistos, $achados);
    return $achados;
}

function tsp_video_id($post_id)
{
    $c = get_post_field('post_content', $post_id);
    if ($c && preg_match('~(?:youtube(?:-nocookie)?\.com/(?:embed/|watch\?v=|shorts/|live/)|youtu\.be/)([A-Za-z0-9_-]{11})~', $c, $m)) {
        return $m[1];
    }
    return '';
}

/* ---------- Dados de um post ---------- */

function tsp_time_do_post($post_id)
{
    $termos = get_the_terms($post_id, 'times');
    if (!$termos || is_wp_error($termos)) {
        return null;
    }
    $conhecidos = array();
    foreach (tsp_grupos() as $g) {
        $conhecidos = array_merge($conhecidos, isset($g['clubes']) ? $g['clubes'] : array_fill_keys(array_keys($g['divisao']), ''));
    }
    foreach ($termos as $t) {
        if (isset($conhecidos[$t->slug])) {
            return $t;
        }
    }
    return $termos[0];
}

function tsp_chapeu($post_id)
{
    $t = tsp_time_do_post($post_id);
    // Matéria de Libertadores ou Copa do Brasil fora do bloco da copa: o chapéu mostra a competição (08/11/2026)
    if ($t) {
        $tit = html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8');
        if (preg_match('~libertadores~iu', $tit)) {
            return $t->name . ' · Libertadores';
        }
        if (preg_match('~copa do brasil~iu', $tit)) {
            return $t->name . ' · Copa do Brasil';
        }
        return $t->name;
    }
    $c = get_the_terms($post_id, 'campeonato');
    return ($c && !is_wp_error($c)) ? $c[0]->name : '';
}

function tsp_data_rel($post_id)
{
    $ts = get_post_timestamp($post_id);
    if (!$ts) {
        return '';
    }
    $dif = time() - $ts;
    if ($dif < DAY_IN_SECONDS * 2) {
        return 'há ' . human_time_diff($ts, time());
    }
    return wp_date('d/m/Y', $ts);
}

function tsp_img($post_id, $tamanho = 'home-765x570', $eager = false, $classe = '')
{
    if (!has_post_thumbnail($post_id)) {
        return '<span class="tsp-img tsp-img--vazia ' . esc_attr($classe) . '" aria-hidden="true"></span>';
    }
    $alt = trim((string) get_post_meta(get_post_thumbnail_id($post_id), '_wp_attachment_image_alt', true));
    $attr = array('class' => 'tsp-img ' . $classe, 'alt' => $alt !== '' ? $alt : get_the_title($post_id), 'decoding' => 'async');
    // Foto em pé (retrato): o recorte automático cortava a cabeça. Usa a foto inteira e enquadra pela parte de cima.
    $meta = wp_get_attachment_metadata(get_post_thumbnail_id($post_id));
    if (!empty($meta['width']) && !empty($meta['height']) && $meta['height'] > $meta['width'] * 1.05) {
        $tamanho = 'large';
        $attr['style'] = 'object-fit:cover;object-position:50% 15%';
    }
    if ($eager) {
        $attr['loading'] = 'eager';
        $attr['fetchpriority'] = 'high';
    } else {
        $attr['loading'] = 'lazy';
    }
    return get_the_post_thumbnail($post_id, $tamanho, $attr);
}

/* ---------- Cartões ---------- */

function tsp_card($post_id, $variante = 'grade', $eager = false)
{
    $link = get_permalink($post_id);
    $titulo = get_the_title($post_id);
    $chapeu = tsp_chapeu($post_id);
    $data = tsp_data_rel($post_id);
    $tempo = '<time datetime="' . esc_attr(get_the_date('c', $post_id)) . '">' . esc_html($data) . '</time>';

    if ($variante === 'grande' || $variante === 'sobre') {
        $tam = $variante === 'grande' ? 'home-765x570' : 'home-765x570';
        echo '<a class="tsp-card tsp-card--' . $variante . '" href="' . esc_url($link) . '">';
        echo tsp_img($post_id, $tam, $eager);
        echo '<span class="tsp-card__veu" aria-hidden="true"></span><span class="tsp-card__txt">';
        if ($chapeu) {
            echo '<span class="tsp-selo">' . esc_html($chapeu) . '</span>';
        }
        echo '<span class="tsp-card__titulo">' . esc_html($titulo) . '</span>' . '<span class="tsp-card__data">' . $tempo . '</span></span></a>';
        return;
    }
    if ($variante === 'lista') {
        echo '<a class="tsp-card tsp-card--lista" href="' . esc_url($link) . '">' . tsp_img($post_id, 'home-370x270');
        echo '<span class="tsp-card__txt">';
        if ($chapeu) {
            echo '<span class="tsp-chapeu">' . esc_html($chapeu) . '</span>';
        }
        echo '<span class="tsp-card__titulo">' . esc_html($titulo) . '</span><span class="tsp-card__data">' . $tempo . '</span></span></a>';
        return;
    }
    echo '<a class="tsp-card tsp-card--grade" href="' . esc_url($link) . '"><span class="tsp-card__foto">' . tsp_img($post_id, 'home-370x270') . '</span>';
    if ($chapeu) {
        echo '<span class="tsp-chapeu">' . esc_html($chapeu) . '</span>';
    }
    echo '<span class="tsp-card__titulo">' . esc_html($titulo) . '</span><span class="tsp-card__data">' . $tempo . '</span></a>';
}

function tsp_card_video($post_id, $grande = false)
{
    $link = get_permalink($post_id);
    $chapeu = tsp_chapeu($post_id);
    echo '<a class="tsp-video ' . ($grande ? 'tsp-video--grande' : 'tsp-video--lista') . '" href="' . esc_url($link) . '">';
    echo '<span class="tsp-video__foto">' . tsp_img($post_id, $grande ? 'home-765x570' : 'home-370x270') . '<span class="tsp-play" aria-hidden="true"></span></span>';
    echo '<span class="tsp-card__txt">';
    if ($chapeu) {
        echo '<span class="tsp-chapeu">' . esc_html($chapeu) . '</span>';
    }
    echo '<span class="tsp-card__titulo">' . esc_html(get_the_title($post_id)) . '</span></span></a>';
}

/* ---------- Seções ---------- */

function tsp_secao_cab($titulo, $link = '', $clubes = array(), $sub = '', $id = '', $escudos = false)
{
    echo '<div class="tsp-secao__cab"><div class="tsp-secao__tit">';
    echo '<h2' . ($id ? ' id="' . esc_attr($id) . '"' : '') . '>' . esc_html($titulo) . '</h2>';
    if ($sub) {
        echo '<span class="tsp-secao__sub">' . esc_html($sub) . '</span>';
    }
    echo '</div><span class="tsp-secao__links' . ($escudos ? ' tsp-secao__links--escudos' : '') . '">';
    foreach ($clubes as $slug => $nome) {
        $t = get_term_by('slug', $slug, 'times');
        if ($t) {
            echo $escudos
                ? '<a href="' . esc_url(get_term_link($t)) . '" title="' . esc_attr($t->name) . '" aria-label="' . esc_attr('Notícias ' . tsp_de($t)) . '">' . tsp_escudo($t, 26) . '</a>'
                : '<a href="' . esc_url(get_term_link($t)) . '">' . esc_html($nome) . '</a>';
        }
    }
    if ($link) {
        echo '<a class="tsp-vertudo" href="' . esc_url(home_url($link)) . '">Ver tudo →</a>';
    }
    echo '</span></div>';
}

// Layout "A": 1 grande + 2 grandes ao lado + fileira de menores (Série A e Série B)
function tsp_layout_a($ids)
{
    if (!$ids) {
        echo '<p class="tsp-vazio">Ainda não há matérias publicadas para estes clubes.</p>';
        return;
    }
    echo '<div class="tsp-topo">';
    tsp_card($ids[0], 'grande', true);
    echo '<div class="tsp-topo__lado tsp-topo__lado--sobre">';
    foreach (array_slice($ids, 1, 2) as $id) {
        tsp_card($id, 'sobre');
    }
    echo '</div></div>';
    $resto = array_slice($ids, 3);
    if ($resto) {
        echo '<div class="tsp-grade tsp-grade--5">';
        foreach ($resto as $id) {
            tsp_card($id, 'grade');
        }
        echo '</div>';
    }
}

// Layout "B": 1 grande + 3 em lista ao lado + grade de menores
function tsp_layout_b($ids, $colunas = 4)
{
    if (!$ids) {
        echo '<p class="tsp-vazio">Ainda não há matérias publicadas para estes clubes.</p>';
        return;
    }
    echo '<div class="tsp-topo">';
    tsp_card($ids[0], 'grande');
    echo '<div class="tsp-topo__lado tsp-topo__lado--lista">';
    foreach (array_slice($ids, 1, 3) as $id) {
        tsp_card($id, 'lista');
    }
    echo '</div></div>';
    $resto = array_slice($ids, 4);
    if ($resto) {
        echo '<div class="tsp-grade tsp-grade--' . (int) $colunas . '">';
        foreach ($resto as $id) {
            tsp_card($id, 'grade');
        }
        echo '</div>';
    }
}

// Os 16 clubes da divisão em grade (8 por linha no computador, 4 no celular), em ordem alfabética
function tsp_chips_divisao($divisao, $mostrar = 0)
{
    $termos = array();
    foreach (array_keys($divisao) as $slug) {
        $t = get_term_by('slug', $slug, 'times');
        if ($t) {
            $termos[remove_accents($t->name) . $slug] = $t;
        }
    }
    ksort($termos, SORT_NATURAL | SORT_FLAG_CASE);
    $total = count($termos);
    $recolhe = $mostrar && $total > $mostrar;
    echo '<div class="tsp-chips' . ($recolhe ? ' tsp-chips--recolhido' : '') . '">';
    $i = 0;
    foreach ($termos as $t) {
        $extra = $recolhe && $i++ >= $mostrar;
        echo '<a href="' . esc_url(get_term_link($t)) . '"' . ($extra ? ' class="tsp-chips__extra"' : '') . '>' . tsp_escudo($t, 30) . '<span>' . esc_html($t->name) . '</span></a>';
    }
    echo '</div>';
    if ($recolhe) {
        echo '<button type="button" class="tsp-chips__mais" data-chips aria-expanded="false">Ver todos os ' . (int) $total . ' clubes ↓</button>';
    }
}

/* ---------- Vídeos ---------- */

function tsp_bloco_videos($ids, $titulo, $ancora = '')
{
    if (!$ids) {
        return;
    }
    $yt = get_theme_mod('tsp_youtube', 'https://www.youtube.com/@TudoSobrePaulista');
    echo '<section class="tsp-secao tsp-secao--escura"' . ($ancora ? ' id="' . esc_attr($ancora) . '"' : '') . '>';
    echo '<div class="tsp-secao__cab"><div class="tsp-secao__tit"><h2>' . esc_html($titulo) . '</h2></div><span class="tsp-secao__links"><a class="tsp-vertudo" href="' . esc_url($yt) . '" target="_blank" rel="noopener">Canal no YouTube →</a></span></div>';
    if (count($ids) === 1) {
        echo '<div class="tsp-topo tsp-topo--so">';
        tsp_card_video($ids[0], true);
        echo '</div></section>';
        return;
    }
    echo '<div class="tsp-topo">';
    tsp_card_video($ids[0], true);
    echo '<div class="tsp-topo__lado tsp-topo__lado--lista">';
    foreach (array_slice($ids, 1, 4) as $id) {
        tsp_card_video($id);
    }
    echo '</div></div></section>';
}

/* ---------- Tabelas e jogos (vêm de Ferramentas → TSP · Dados do tema) ---------- */

function tsp_zona_cor($serie, $p)
{
    if ($serie === 'fem_paulista') {
        return $p <= 2 ? '#1F6B3F' : ($p <= 6 ? '#8CC79A' : '#B8B2A7');
    }
    if ($serie === 'serie_b') {
        return $p <= 2 ? '#1F6B3F' : ($p <= 6 ? '#8CC79A' : ($p >= 17 ? '#C0392B' : 'transparent'));
    }
    return $p <= 4 ? '#1F4E9A' : ($p === 5 ? '#7FA3DE' : ($p <= 13 ? '#2D7A4F' : ($p >= 17 ? '#C0392B' : 'transparent')));
}

function tsp_tabela_html($serie, $limite = 20, $destaque = '', $inicio = 0, $legenda = true)
{
    $tabs = tsp_dado('tabelas');
    if (empty($tabs[$serie]['linhas'])) {
        return '';
    }
    $t = $tabs[$serie];
    $sp = tsp_paulistas_tabela($serie);
    $com_forma = false;
    foreach ($t['linhas'] as $r) {
        $com_forma = $com_forma || (is_array($r) && !empty($r[8]));
    }
    $h = '<div class="tsp-rolagem"><table class="tsp-tabela">' . ($legenda ? '<caption>' . esc_html(is_string($legenda) ? $legenda : ($t['titulo'] ?? 'Classificação')) . '</caption>' : '');
    $h .= '<thead><tr><th scope="col">#</th><th scope="col" class="tsp-tabela__time">Time</th><th scope="col" title="Pontos">P</th><th scope="col" title="Jogos">J</th><th scope="col" class="tsp-col-x" title="Vitórias">V</th><th scope="col" class="tsp-col-x" title="Empates">E</th><th scope="col" class="tsp-col-x" title="Derrotas">D</th><th scope="col" title="Saldo de gols">SG</th>' . ($com_forma ? '<th scope="col" class="tsp-tabela__forma" title="Últimos 5 jogos">Últimos 5</th>' : '') . '</tr></thead><tbody>';
    foreach (array_slice($t['linhas'], $inicio, $limite) as $r) {
        if (!is_array($r) || count($r) < 8) {
            continue;
        }
        $p = (int) $r[0];
        $e_sp = in_array($r[1], $sp, true);
        $sg = (int) $r[7];
        $classe = trim(($e_sp ? 'tsp-sp' : '') . ($destaque && in_array($r[1], (array) $destaque, true) ? ' tsp-clube-atual' : ''));
        $h .= '<tr' . ($classe ? ' class="' . $classe . '"' : '') . '><td style="border-left-color:' . esc_attr(tsp_zona_cor($serie, $p)) . '">' . $p . '</td><td class="tsp-tabela__time">' . (tsp_link_time($r[1]) ? '<a href="' . esc_url(tsp_link_time($r[1])) . '">' . esc_html($r[1]) . '</a>' : esc_html($r[1])) . ($e_sp ? ' <span class="tsp-selo-sp">SP</span>' : '') . '</td><td><strong>' . (int) $r[2] . '</strong></td><td>' . (int) $r[3] . '</td><td class="tsp-col-x">' . (int) $r[4] . '</td><td class="tsp-col-x">' . (int) $r[5] . '</td><td class="tsp-col-x">' . (int) $r[6] . '</td><td>' . ($sg > 0 ? '+' . $sg : $sg) . '</td>' . ($com_forma ? '<td class="tsp-tabela__forma">' . tsp_forma_html($r[8] ?? '') . '</td>' : '') . '</tr>';
    }
    $h .= '</tbody></table></div>';
    return $h;
}

// Bolinhas dos últimos 5 jogos: V verde, E amarelo, D vermelho (do mais antigo para o mais recente)
function tsp_forma_html($forma, $completar = true)
{
    $nomes = array('V' => 'Vitória', 'E' => 'Empate', 'D' => 'Derrota');
    $letras = str_split(substr(preg_replace('~[^VED]~', '', strtoupper((string) $forma)), -5));
    $h = '<span class="tsp-cinco" aria-label="Últimos jogos: ' . esc_attr(implode(', ', array_map(function ($l) use ($nomes) {
        return $nomes[$l];
    }, array_filter($letras)))) . '">';
    for ($i = count(array_filter($letras)); $completar && $i < 5; $i++) {
        $h .= '<i class="tsp-cinco__vazio" aria-hidden="true">–</i>';
    }
    foreach (array_filter($letras) as $l) {
        $h .= '<i class="tsp-cinco__' . strtolower($l) . '" title="' . esc_attr($nomes[$l]) . '" aria-hidden="true">' . $l . '</i>';
    }
    return $h . '</span>';
}

function tsp_legenda($serie)
{
    if ($serie === 'fem_paulista') {
        $h = '<div class="tsp-legenda">';
        foreach (array('#1F6B3F' => 'Semifinal direto (1º e 2º)', '#8CC79A' => 'Play-in (3º ao 6º)', '#B8B2A7' => 'Copa Paulista Feminina (7º e 8º)') as $cor => $txt) {
            $h .= '<span><i style="background:' . esc_attr($cor) . '"></i>' . esc_html($txt) . '</span>';
        }
        return $h . '</div>';
    }
    $itens = $serie === 'serie_b'
        ? array('#1F6B3F' => 'Acesso direto (1º e 2º)', '#8CC79A' => 'Playoffs de acesso (3º ao 6º)', '#C0392B' => 'Z4 · Rebaixamento (17º ao 20º)')
        : array('#1F4E9A' => 'Libertadores (1º ao 4º)', '#7FA3DE' => 'Pré-Libertadores (5º)', '#2D7A4F' => 'Sul-Americana (6º ao 13º)', '#C0392B' => 'Rebaixamento (17º ao 20º)');
    $h = '<div class="tsp-legenda">';
    foreach ($itens as $cor => $txt) {
        $h .= '<span><i style="background:' . esc_attr($cor) . '"></i>' . esc_html($txt) . '</span>';
    }
    return $h . '<span><span class="tsp-selo-sp">SP</span> Time paulista</span><span>' . tsp_forma_html('VED', false) . ' Últimos 5: vitória, empate, derrota</span></div>';
}

function tsp_jogos_html($serie, $tipo)
{
    $jogos = tsp_dado('jogos');
    if (empty($jogos[$serie][$tipo]['lista'])) {
        return '';
    }
    $b = $jogos[$serie][$tipo];
    $sp = tsp_paulistas_tabela($serie);
    $escuro = $tipo === 'proximos';
    $h = '<div class="tsp-jogos' . ($escuro ? ' tsp-jogos--escuro' : '') . '"><h3>' . esc_html($b['titulo'] ?? ($escuro ? 'Próximos jogos' : 'Resultados')) . '</h3><ul>';
    foreach ($b['lista'] as $g) {
        if (!is_array($g)) {
            continue;
        }
        $casa = $g[1] ?? '';
        $fora = $escuro ? ($g[2] ?? '') : ($g[3] ?? '');
        $meio = $escuro ? 'x' : ($g[2] ?? '');
        $tem = in_array($casa, $sp, true) || in_array($fora, $sp, true);
        $h .= '<li' . ($tem ? ' class="tsp-sp"' : '') . '><span class="tsp-jogos__dia">' . esc_html($g[0] ?? '') . '</span><span class="tsp-jogos__casa' . (in_array($casa, $sp, true) ? ' tsp-forte' : '') . '">' . esc_html($casa) . '</span><span class="tsp-jogos__placar">' . esc_html($meio) . '</span><span class="tsp-jogos__fora' . (in_array($fora, $sp, true) ? ' tsp-forte' : '') . '">' . esc_html($fora) . '</span></li>';
    }
    $h .= '</ul>';
    if (!empty($b['nota'])) {
        $h .= '<p class="tsp-nota">' . esc_html($b['nota']) . '</p>';
    }
    return $h . '</div>';
}

function tsp_bloco_tabela($serie, $titulo, $link, $ancora, $resultados_primeiro = true)
{
    $tabs = tsp_dado('tabelas');
    $tem = !empty($tabs[$serie]['linhas']);
    $sofa = $tem ? '' : tsp_sofa_html($serie, $titulo);
    $res = tsp_rodadas_html($serie, 'resultados');
    $prx = tsp_rodadas_html($serie, 'proximos');
    if (!$res && !$prx) {
        $res = tsp_jogos_html($serie, 'resultados');
        $prx = tsp_jogos_html($serie, 'proximos');
    }
    if (!$tem && !$sofa && !$res && !$prx) {
        return;
    }
    $nota = $tabs[$serie]['nota'] ?? '';
    echo '<section class="tsp-secao tsp-secao--solta" id="' . esc_attr($ancora) . '">';
    tsp_secao_cab($titulo, $link);
    $ge = tsp_tabela_ge($serie);
    if ($ge) {
        echo $ge . '</section>'; // phpcs:ignore -- montado com escape
        return;
    }
    if ($tem) {
        // Classificação em duas colunas: 1º ao 10º e 11º ao 20º
        $meio = (int) ceil(count($tabs[$serie]['linhas']) / 2);
        echo '<div class="tsp-classif">';
        echo '<div class="tsp-caixa tsp-classif__a">' . tsp_tabela_html($serie, $meio, '', 0, false) . '</div>';
        echo '<div class="tsp-caixa tsp-classif__b">' . tsp_tabela_html($serie, $meio, '', $meio, false) . '</div>';
        echo '</div><div class="tsp-classif__rodape">' . tsp_legenda($serie) . ($nota ? '<p class="tsp-nota">' . esc_html($nota) . '</p>' : '') . '</div>';
    } elseif ($sofa) {
        echo '<div class="tsp-caixa">' . $sofa . '</div>';
    }
    if ($res || $prx) {
        // Resultados à esquerda, próximos jogos à direita (cada lado navega pelas rodadas)
        echo '<div class="tsp-rodadas-2">' . ($res ? '<div>' . $res . '</div>' : '') . ($prx ? '<div>' . $prx . '</div>' : '') . '</div>';
    }
    echo '</section>';
}

function tsp_bloco_feminino_comp()
{
    // Campeonatos femininos em disputa: chaveamento da Copa do Brasil Feminina e painel do Paulistão Feminino (base do TSP)
    if (function_exists('tsp_jogos_chave_html')) {
        // Copa do Brasil Feminina só aparece em andamento e com clube paulista ainda na disputa (10/11/2026)
        $h = (!function_exists('tsp_jogos_chave_tem_paulista_vivo') || tsp_jogos_chave_tem_paulista_vivo('fem_copa_do_brasil')) ? tsp_jogos_chave_html('fem_copa_do_brasil') : '';
        $p = function_exists('tsp_jogos_painel_fem_html') ? tsp_jogos_painel_fem_html() : '';
        if ($h || $p) {
            echo '<div class="tsp-caixa tsp-fem-comp">';
            if ($h) {
                echo '<h3 class="tsp-chave-tit">Copa do Brasil Feminina · Tabela</h3>' . $h; // phpcs:ignore
            }
            echo $p ? '<div' . ($h ? ' style="margin-top:22px"' : '') . '>' . $p . '</div>' : ''; // phpcs:ignore
            echo '</div>';
            return;
        }
    }
    $comps = tsp_dado('feminino');
    if (empty($comps['competicoes'])) {
        $h = tsp_sofa_recolhivel('fem_brasileiro_a1', 'Classificação · Brasileirão Feminino A1') . tsp_sofa_recolhivel('fem_paulistao', 'Classificação · Paulistão Feminino');
        if ($h) {
            echo '<div class="tsp-sofa-grade">' . $h . '</div>';
        }
        return;
    }
    echo '<div class="tsp-caixa tsp-fem-comp"><div class="tsp-fem-comp__cab"><h3>' . esc_html($comps['titulo'] ?? 'Tabelas e jogos · Feminino profissional') . '</h3>';
    if (!empty($comps['nota'])) {
        echo '<span>' . esc_html($comps['nota']) . '</span>';
    }
    echo '</div><div class="tsp-fem-comp__grade">';
    foreach ($comps['competicoes'] as $c) {
        echo '<div class="tsp-fem-comp__item"><strong>' . esc_html($c['nome'] ?? '') . '</strong><span class="tsp-nota">' . esc_html($c['fase'] ?? '') . '</span>';
        foreach (array(array('t1', 'l1'), array('t2', 'l2')) as $par) {
            if (empty($c[$par[1]])) {
                continue;
            }
            echo '<span class="tsp-rotulo">' . esc_html($c[$par[0]] ?? '') . '</span><ul>';
            foreach ($c[$par[1]] as $g) {
                echo '<li><strong>' . esc_html($g[0] ?? '') . '</strong><span>' . esc_html($g[1] ?? '') . '</span></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }
    echo '</div></div>';
}

/* ---------- Outros ---------- */

function tsp_whatsapp_link()
{
    return get_theme_mod('tsp_whatsapp', 'https://chat.whatsapp.com/LsgWJv02mM8D7pBMVnnc60');
}

function tsp_cta_whatsapp()
{
    echo '<section class="tsp-wpp"><div><h2>O futebol paulista no seu WhatsApp</h2><p>Resultados, bastidores e coletivas de todos os times, direto no celular.</p></div>';
    echo '<a class="tsp-botao tsp-botao--wpp" href="' . esc_url(tsp_whatsapp_link()) . '" target="_blank" rel="noopener">Entrar no grupo</a></section>';
}

function tsp_banner($area)
{
    if (is_active_sidebar($area)) {
        echo '<div class="tsp-banner">';
        dynamic_sidebar($area);
        echo '</div>';
    }
}

function tsp_tempo_leitura($post_id)
{
    $palavras = str_word_count(wp_strip_all_tags(get_post_field('post_content', $post_id)));
    return max(1, (int) ceil($palavras / 220));
}

function tsp_lista_ultimas($n = 6, $excluir = array(), $titulo = 'Últimas notícias', $slug_time = '', $ids_prontos = null)
{
    if (is_array($ids_prontos)) {
        $ps = array_filter(array_map('get_post', $ids_prontos));
    } else {
        $vistos = $excluir;
        $args = array('posts_per_page' => $n);
        if ($slug_time) {
            $args['tax_query'] = tsp_tax_times($slug_time);
        }
        $ps = tsp_consulta($args, $vistos);
    }
    if (!$ps) {
        return;
    }
    echo '<div class="tsp-caixa tsp-ultimas"><h2 class="tsp-caixa__tit">' . esc_html($titulo) . '</h2><ol>';
    foreach ($ps as $p) {
        echo '<li><a href="' . esc_url(get_permalink($p)) . '"><span class="tsp-chapeu">' . esc_html(tsp_chapeu($p->ID)) . '</span>' . esc_html(get_the_title($p)) . '</a></li>';
    }
    echo '</ol></div>';
}

function tsp_relacionadas($post_id, $n = 4, $excluir = array())
{
    $t = tsp_time_do_post($post_id);
    $vistos = array_merge(array($post_id), $excluir);
    $args = array('posts_per_page' => $n);
    if ($t) {
        $args['tax_query'] = tsp_tax_times($t->slug);
    }
    $ps = tsp_consulta($args, $vistos);
    // Clube com poucas matérias: completa com as do mesmo clube que já estão na lateral
    if ($t && count($ps) < $n && $excluir) {
        $ja = array_merge(array($post_id), wp_list_pluck($ps, 'ID'));
        $ps = array_merge($ps, tsp_consulta(array('posts_per_page' => $n - count($ps), 'tax_query' => tsp_tax_times($t->slug)), $ja));
    }
    if (!$ps) {
        return;
    }
    echo '<section class="tsp-relacionadas"><h2>' . esc_html($t ? 'Mais ' . tsp_de($t) : 'Leia também') . '</h2><div class="tsp-grade tsp-grade--4">';
    foreach ($ps as $p) {
        tsp_card($p->ID, 'grade');
    }
    echo '</div></section>';
}

function tsp_serie_do_post($post_id)
{
    $t = tsp_time_do_post($post_id);
    if (!$t) {
        return '';
    }
    if (in_array($t->slug, array_merge(tsp_grupo_slugs('a4'), tsp_grupo_slugs('mb')), true)) {
        return 'serie_a';
    }
    if (in_array($t->slug, tsp_grupo_slugs('sb'), true)) {
        return 'serie_b';
    }
    return '';
}

function tsp_breadcrumbs()
{
    if (function_exists('yoast_breadcrumb')) {
        yoast_breadcrumb('<nav class="tsp-migalhas" aria-label="Você está em">', '</nav>');
        return;
    }
    echo '<nav class="tsp-migalhas" aria-label="Você está em"><a href="' . esc_url(home_url('/')) . '">Início</a>';
    if (is_singular()) {
        $t = tsp_time_do_post(get_the_ID());
        if ($t) {
            echo ' › <a href="' . esc_url(get_term_link($t)) . '">' . esc_html($t->name) . '</a>';
        }
    }
    echo '</nav>';
}

function tsp_paginacao()
{
    the_posts_pagination(array('mid_size' => 1, 'prev_text' => '← Anteriores', 'next_text' => 'Próximas →'));
}

/* ---------- Escudos e lista de clubes ---------- */

// Escudo: usa o campo "Imagem" (100 x 100) que já existe no cadastro de cada time.
// O fundo branco/liso do arquivo é removido uma vez (cópia em uploads/tsp-escudos) para o escudo ficar transparente.
function tsp_escudo_url($termo)
{
    $id = $termo ? (int) get_term_meta($termo->term_id, 'imagem', true) : 0;
    if (!$id) {
        return '';
    }
    $cache = get_term_meta($termo->term_id, 'tsp_escudo_png', true);
    if (is_array($cache) && (int) ($cache['anexo'] ?? 0) === $id && !empty($cache['url'])) {
        return $cache['url'];
    }
    $url = tsp_escudo_gerar_transparente($id);
    if (!$url) {
        $url = wp_get_attachment_image_url($id, 'thumbnail');
    }
    if ($url) {
        update_term_meta($termo->term_id, 'tsp_escudo_png', array('anexo' => $id, 'url' => $url));
    }
    return (string) $url;
}

function tsp_escudo_gerar_transparente($anexo_id)
{
    if (!function_exists('imagecreatefromstring')) {
        return '';
    }
    $arq = get_attached_file($anexo_id);
    if (!$arq || !file_exists($arq) || filesize($arq) > 3 * MB_IN_BYTES) {
        return '';
    }
    $src = @imagecreatefromstring(file_get_contents($arq));
    if (!$src) {
        return '';
    }
    $w = imagesx($src);
    $h = imagesy($src);
    $lado = 128;
    $esc = min($lado / $w, $lado / $h);
    $nw = max(1, (int) round($w * $esc));
    $nh = max(1, (int) round($h * $esc));
    $img = imagecreatetruecolor($nw, $nh);
    imagealphablending($img, false);
    imagesavealpha($img, true);
    imagefill($img, 0, 0, imagecolorallocatealpha($img, 0, 0, 0, 127));
    imagecopyresampled($img, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($src);
    // Se os cantos já são transparentes, o arquivo já está certo
    $cantos = array(array(0, 0), array($nw - 1, 0), array(0, $nh - 1), array($nw - 1, $nh - 1));
    $transp = 0;
    foreach ($cantos as $c) {
        if (((imagecolorat($img, $c[0], $c[1]) >> 24) & 0x7F) > 100) {
            $transp++;
        }
    }
    if ($transp < 3) {
        // Apaga o fundo: pinta de transparente tudo que for parecido com a cor dos cantos e estiver ligado à borda
        $base = imagecolorat($img, 0, 0);
        $br = ($base >> 16) & 0xFF;
        $bg = ($base >> 8) & 0xFF;
        $bb = $base & 0xFF;
        $vistos = array();
        $fila = array();
        for ($x = 0; $x < $nw; $x++) {
            $fila[] = array($x, 0);
            $fila[] = array($x, $nh - 1);
        }
        for ($y = 0; $y < $nh; $y++) {
            $fila[] = array(0, $y);
            $fila[] = array($nw - 1, $y);
        }
        $vazio = imagecolorallocatealpha($img, 255, 255, 255, 127);
        while ($fila) {
            list($x, $y) = array_pop($fila);
            $k = $y * $nw + $x;
            if (isset($vistos[$k])) {
                continue;
            }
            $vistos[$k] = 1;
            $c = imagecolorat($img, $x, $y);
            $d = abs((($c >> 16) & 0xFF) - $br) + abs((($c >> 8) & 0xFF) - $bg) + abs(($c & 0xFF) - $bb);
            if ($d > 60) {
                continue;
            }
            imagesetpixel($img, $x, $y, $vazio);
            foreach (array(array(1, 0), array(-1, 0), array(0, 1), array(0, -1)) as $m) {
                $nx = $x + $m[0];
                $ny = $y + $m[1];
                if ($nx >= 0 && $ny >= 0 && $nx < $nw && $ny < $nh && !isset($vistos[$ny * $nw + $nx])) {
                    $fila[] = array($nx, $ny);
                }
            }
        }
    }
    $up = wp_upload_dir();
    $pasta = trailingslashit($up['basedir']) . 'tsp-escudos';
    wp_mkdir_p($pasta);
    $nome = 'escudo-' . (int) $anexo_id . '-' . filemtime($arq) . '.png';
    $ok = imagepng($img, $pasta . '/' . $nome, 9);
    imagedestroy($img);
    return $ok ? trailingslashit($up['baseurl']) . 'tsp-escudos/' . $nome : '';
}

function tsp_escudo($termo, $tam = 28)
{
    $src = $termo ? tsp_escudo_url($termo) : '';
    if ($src) {
        return '<img class="tsp-escudo" src="' . esc_url($src) . '" alt="' . esc_attr('Escudo ' . tsp_de($termo)) . '" width="' . (int) $tam . '" height="' . (int) $tam . '" loading="lazy" decoding="async">';
    }
    return '<span class="tsp-escudo tsp-escudo--vazio" style="width:' . (int) $tam . 'px;height:' . (int) $tam . 'px" aria-hidden="true"></span>';
}

// Os 64 clubes paulistas da A1 à A4, com a divisão de cada um, em ordem alfabética
function tsp_clubes_paulistas()
{
    $g = tsp_grupos();
    $div = array();
    foreach (array('a4', 'mb') as $k) {
        foreach ($g[$k]['clubes'] as $s => $n) {
            $div[$s] = 'Série A';
        }
    }
    foreach ($g['sb']['clubes'] as $s => $n) {
        $div[$s] = 'Série B';
    }
    $div += $g['d1']['divisao'] + $g['d2']['divisao'] + $g['d3']['divisao'] + $g['d4']['divisao'];
    $termos = get_terms(array('taxonomy' => 'times', 'slug' => array_keys($div), 'hide_empty' => false));
    $lista = array();
    if (!is_wp_error($termos)) {
        foreach ($termos as $t) {
            $lista[] = array('termo' => $t, 'div' => $div[$t->slug]);
        }
    }
    usort($lista, function ($a, $b) {
        return strcoll(remove_accents($a['termo']->name), remove_accents($b['termo']->name));
    });
    return $lista;
}

/* ---------- Dias de Copa do Brasil e Libertadores ---------- */
/*
 * Em Ferramentas → TSP · Dados do tema, chave "copas" (lista). Exemplo:
 * "copas": [{ "nome": "Libertadores · Final", "de": "2026-11-26", "ate": "2026-11-29",
 *             "clubes": ["palmeiras"],
 *             "resultados": { "titulo": "Semifinal", "lista": [["22/10", "Palmeiras", "2 x 0", "Racing"]] },
 *             "proximos":   { "titulo": "Final", "lista": [["Sáb 28/11 17h", "Palmeiras", "Flamengo"]] } }]
 * Entre "de" e "ate" a home abre com os clubes da competição e troca a tabela do Brasileirão pelos jogos dela.
 */
function tsp_copa_ativa()
{
    $copas = tsp_dado('copas');
    if (!is_array($copas)) {
        return null;
    }
    $hoje = wp_date('Y-m-d');
    foreach ($copas as $c) {
        if (is_array($c) && !empty($c['de']) && !empty($c['ate']) && !empty($c['clubes']) && $hoje >= $c['de'] && $hoje <= $c['ate']) {
            return $c;
        }
    }
    return null;
}

function tsp_bloco_copa_destaque($copa, &$vistos)
{
    $clubes = array_values(array_filter((array) $copa['clubes'], 'is_string'));
    $nomes = array();
    foreach ($clubes as $s) {
        $t = get_term_by('slug', $s, 'times');
        if ($t) {
            $nomes[$s] = $t->name;
        }
    }
    if (!$nomes) {
        return;
    }
    // Dia de copa: 4 notícias dos clubes que jogam (1 grande + 3 ao lado)
    $por = max(2, (int) ceil(4 / count($nomes)));
    echo '<section class="tsp-secao tsp-secao--caixa tsp-secao--copa" id="copa" aria-labelledby="h-copa">';
    tsp_secao_cab($copa['nome'] ?? 'Copa', '', $nomes, '', 'h-copa');
    // Só matérias do clube que joga (título com o nome dele ou clube principal), sem notícia de outro clube marcada junto
    $vistos_antes = $vistos;
    $cand = tsp_ids_por_clube(array_keys($nomes), 25, $vistos);
    $ok = array();
    // Só o que fala DESTA competição (08/11/2026): matéria de Libertadores não entra no bloco da Copa do Brasil e vice-versa
    $liga = (string) ($copa['liga'] ?? '');
    $re = $liga === 'libertadores' ? '~libertadores~iu' : '~copa do brasil~iu';
    $re_outra = $liga === 'libertadores' ? '~copa do brasil~iu' : '~libertadores~iu';
    $termo = $liga === 'libertadores' ? 'libertadores' : 'copadobrasil';
    foreach ($cand as $pid) {
        $tit0 = html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8');
        $txt0 = $tit0 . ' ' . wp_strip_all_tags(get_the_excerpt($pid)) . ' ' . (function_exists('tsp_subtitulo') ? tsp_subtitulo($pid) : '');
        $da_copa = preg_match($re, $txt0);
        if (!$da_copa || preg_match($re_outra, $tit0)) {
            continue;
        }
        $t = tsp_time_do_post($pid);
        $tit = $tit0;
        $no_titulo = false;
        foreach ($nomes as $n) {
            $no_titulo = $no_titulo || mb_stripos($tit, $n) !== false;
        }
        if ($no_titulo || ($t && isset($nomes[$t->slug]))) {
            $ok[] = $pid;
        }
    }
    $ok = array_slice($ok, 0, 4);
    $vistos = array_merge($vistos_antes, $ok); // as que não entraram continuam livres para os outros blocos
    tsp_layout_b($ok);
    echo '</section>';
}

function tsp_bloco_copa_jogos($copa)
{
    // Chaveamento completo da competição (base de jogos do TSP); sem ele, a lista simples de jogos
    if (!empty($copa['liga']) && function_exists('tsp_jogos_chave_html')) {
        $ch = tsp_jogos_chave_html($copa['liga']);
        if ($ch) {
            echo '<section class="tsp-secao tsp-secao--solta" id="jogos-copa">';
            tsp_secao_cab('Tabela · ' . preg_replace('~\s*·.*$~', '', (string) ($copa['nome'] ?? 'Copa')));
            echo $ch . '</section>'; // phpcs:ignore -- HTML montado com escape no plugin
            return;
        }
    }
    $h = '';
    foreach (array('resultados' => false, 'proximos' => true) as $tipo => $escuro) {
        if (empty($copa[$tipo]['lista'])) {
            continue;
        }
        $h .= '<div class="tsp-jogos' . ($escuro ? ' tsp-jogos--escuro' : '') . '"><h3>' . esc_html($copa[$tipo]['titulo'] ?? ($escuro ? 'Próximos jogos' : 'Resultados')) . '</h3><ul>';
        foreach ($copa[$tipo]['lista'] as $g) {
            $h .= '<li><span class="tsp-jogos__dia">' . esc_html($g[0] ?? '') . '</span><span class="tsp-jogos__casa">' . esc_html($g[1] ?? '') . '</span><span class="tsp-jogos__placar">' . esc_html($escuro ? 'x' : ($g[2] ?? '')) . '</span><span class="tsp-jogos__fora">' . esc_html($escuro ? ($g[2] ?? '') : ($g[3] ?? '')) . '</span></li>';
        }
        $h .= '</ul></div>';
    }
    if (!$h) {
        return;
    }
    echo '<section class="tsp-secao tsp-secao--solta" id="jogos-copa">';
    tsp_secao_cab($copa['nome'] ?? 'Copa');
    echo '<div class="tsp-copa-jogos">' . $h . '</div></section>';
}

/* ---------- Rodadas navegáveis (Base TSP): resultados com ficha e matéria; próximos com onde assistir e confronto ---------- */

function tsp_link_time($nome)
{
    $l = tsp_dado('links_times');
    return is_array($l) && !empty($l[$nome]) ? $l[$nome] : '';
}

// $modo: 'resultados' começa na última rodada com jogo encerrado; 'proximos' na primeira com jogo a disputar
function tsp_rodadas_html($liga, $modo)
{
    $todas = tsp_dado('rodadas');
    if (empty($todas[$liga]['rodadas'])) {
        return '';
    }
    $rods = $todas[$liga]['rodadas'];
    // Rodada "fechada" = metade ou mais dos jogos já terminou (um jogo atrasado não prende a rodada inteira)
    $fechada = array();
    foreach ($rods as $i => $r) {
        $n_fim = 0;
        foreach ($r['jogos'] as $g) {
            $n_fim += $g['status'] === 'fim' ? 1 : 0;
        }
        $fechada[$i] = $r['jogos'] && $n_fim * 2 >= count($r['jogos']);
    }
    $ini = -1;
    if ($modo === 'resultados') {
        foreach ($fechada as $i => $f) {
            if ($f) {
                $ini = $i; // a última rodada fechada
            }
        }
    } else {
        foreach ($fechada as $i => $f) {
            if (!$f) {
                $ini = $i; // a primeira rodada ainda por jogar
                break;
            }
        }
    }
    if ($ini < 0) {
        return '';
    }
    $de = max(0, $ini - 3);
    $ate = min(count($rods) - 1, $ini + 3);
    $escuro = $modo === 'proximos';
    $h = '<div class="tsp-jogos tsp-rodadas' . ($escuro ? ' tsp-jogos--escuro' : '') . '" data-rodadas>';
    $h .= '<div class="tsp-rodadas__cab"><button type="button" class="tsp-rodadas__seta" data-dir="-1" aria-label="Rodada anterior">‹</button><h3 data-titulo>' . esc_html($rods[$ini]['titulo'] . ' · ' . ($escuro ? 'Próximos jogos' : 'Resultados')) . '</h3><button type="button" class="tsp-rodadas__seta" data-dir="1" aria-label="Próxima rodada">›</button></div>';
    for ($i = $de; $i <= $ate; $i++) {
        $r = $rods[$i];
        $tit = $r['titulo'] . ' · ' . ($fechada[$i] ? 'Resultados' : 'Próximos jogos');
        $h .= '<ul class="tsp-rodadas__lista" data-titulo="' . esc_attr($tit) . '"' . ($i === $ini ? '' : ' hidden') . '>';
        foreach ($r['jogos'] as $g) {
            $nome = function ($lado) use ($g) {
                $n = esc_html($g[$lado]);
                $cls = 'tsp-jogos__' . $lado . ($g[$lado . '_sp'] ? ' tsp-forte' : '');
                return $g[$lado . '_link'] ? '<a class="' . $cls . '" href="' . esc_url($g[$lado . '_link']) . '">' . $n . '</a>' : '<span class="' . $cls . '">' . $n . '</span>';
            };
            $fim = $g['status'] === 'fim';
            $meio = $g['placar'] !== '' ? $g['placar'] : 'x';
            $links = array();
            if ($fim) {
                if ($g['jogo']) {
                    $links[] = '<a href="' . esc_url($g['jogo']) . '">Ficha técnica</a>';
                }
                if ($g['materia']) {
                    $links[] = '<a href="' . esc_url($g['materia']) . '">Como foi o jogo</a>';
                }
            } elseif ($g['status'] === 'vai') {
                if ($g['materia']) {
                    $links[] = '<a href="' . esc_url($g['materia']) . '">Onde assistir</a>';
                }
                if ($g['jogo']) {
                    $links[] = '<a href="' . esc_url($g['jogo']) . '">Confronto e escalações</a>';
                }
            } else {
                $links[] = '<span class="tsp-rodadas__aviso">' . esc_html($g['status']) . '</span>';
            }
            $sp = $g['casa_sp'] || $g['fora_sp'];
            $h .= '<li class="tsp-jogos__item' . ($sp ? ' tsp-sp' : '') . '"><span class="tsp-jogos__dia">' . esc_html($g['dia']) . '</span>' . $nome('casa') . '<span class="tsp-jogos__placar">' . esc_html($meio) . '</span>' . $nome('fora');
            if ($links) {
                $h .= '<span class="tsp-jogos__extra">' . implode('', $links) . '</span>';
            }
            $h .= '</li>';
        }
        $h .= '</ul>';
    }
    return $h . '</div>';
}

// Simulador dentro das matérias dos clubes da Série A: depois do 2º parágrafo (antes da vitrine de ofertas).
add_filter('the_content', function ($html) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query() || !function_exists('tsp_sim_botao_html')) {
        return $html;
    }
    if (tsp_serie_do_post(get_the_ID()) !== 'serie_a') {
        return $html;
    }
    $cta = tsp_sim_botao_html('Simule o Brasileirão');
    if ($cta === '') {
        return $html;
    }
    $n = 0;
    $pos = 0;
    while ($n < 2 && ($x = stripos($html, '</p>', $pos)) !== false) {
        $pos = $x + 4;
        $n++;
    }
    return $n === 2 ? substr($html, 0, $pos) . $cta . substr($html, $pos) : $html . $cta;
}, 25);

/* ---------- Páginas especiais montadas no "Módulo de Código" do Divi (perfis de treinadores etc.) ----------
 * Sem o Divi, as quebras de linha viravam marcas soltas, as aspas viravam aspas tipográficas e as anotações
 * de quem montou a página (URL recomendada, título SEO, "cole no módulo...") apareciam no texto.
 * Aqui o código é remontado como estava no Divi, sem as anotações. */
function tsp_pagina_pilar($post_id)
{
    $c = (string) get_post_field('post_content', $post_id);
    return strpos($c, 'et_pb_line_break_holder') !== false || strpos($c, '[et_pb_code') !== false;
}

function tsp_pilar_html($c)
{
    if (preg_match_all('~\[et_pb_code[^\]]*\](.*?)\[/et_pb_code\]~s', $c, $m)) {
        $c = implode("\n", $m[1]);
    }
    $c = preg_replace('~<!--\s*\[et_pb_line_break_holder\]\s*-->~', "\n", $c);
    $c = preg_replace('~\[/?et_pb_[^\]]*\]~', '', $c);
    $c = str_replace(array('&#91;', '&#93;'), array('[', ']'), $c);
    // Anotações antes do código (comentários com instruções de montagem): começa no primeiro bloco de verdade
    if (preg_match('~<(style|main|article|section|header|div)\b~i', $c, $x, PREG_OFFSET_CAPTURE) && $x[0][1] > 0) {
        $antes = substr($c, 0, $x[0][1]);
        if (strpos($antes, '<!--') !== false || trim(wp_strip_all_tags($antes)) === '') {
            $c = substr($c, $x[0][1]);
        }
    }
    $c = preg_replace('~<!--.*?-->~s', '', $c); // demais anotações
    // Aspas tipográficas dentro das tags voltam a ser aspas normais (senão imagens e links quebram)
    $c = preg_replace_callback('~<[^>]+>~', function ($t) {
        $t = str_replace(array('&#8221;', '&#8220;', '&#8243;', '&#8217;', '”', '“', '″'), array('"', '"', '"', "'", '"', '"', '"'), $t[0]);
        return preg_replace('~(\d)(?:&#215;|×)(\d)~u', '$1x$2', $t); // 300×208 → 300x208 nos endereços das imagens
    }, $c);
    $c = str_replace(array('Nesta página pilar', 'nesta página pilar', 'página pilar', 'Página pilar'), array('Nesta página', 'nesta página', 'página', 'Página'), $c);
    return trim($c);
}

add_filter('the_content', function ($c) {
    if (!is_singular() || !in_the_loop() || !is_main_query() || !tsp_pagina_pilar(get_the_ID())) {
        return $c;
    }
    $GLOBALS['tsp_pilar'] = tsp_pilar_html((string) get_post_field('post_content', get_the_ID()));
    return '<!--tsp-pilar-->';
}, 4);
add_filter('the_content', function ($c) {
    if (empty($GLOBALS['tsp_pilar']) || strpos($c, 'tsp-pilar') === false) {
        return $c;
    }
    $h = $GLOBALS['tsp_pilar'];
    unset($GLOBALS['tsp_pilar']);
    return preg_replace('~(?:<p>)?\s*<!--tsp-pilar-->\s*(?:</p>)?~', str_replace(array('\\', '$'), array('\\\\', '\\$'), $h), $c, 1);
}, 999);


/* ---------- Versão por clube: aviso no topo, com link para a matéria original ---------- */
add_filter('the_content', function ($c) {
    if (!is_singular(tsp_tipos()) || !in_the_loop() || !is_main_query()) {
        return $c;
    }
    $orig = (int) get_post_meta(get_the_ID(), 'tsp_versao_de', true);
    if (!$orig || get_post_status($orig) !== 'publish') {
        return $c;
    }
    $t = tsp_time_do_post(get_the_ID());
    $aviso = '<p class="tsp-versao"><strong>Versão ' . esc_html($t ? tsp_de($t) : 'do clube') . '.</strong> Esta é a mesma notícia contada pelo lado ' . esc_html($t ? tsp_de($t) : 'do clube') . '. Leia a matéria original: <a href="' . esc_url(get_permalink($orig)) . '">' . esc_html(get_the_title($orig)) . '</a>.</p>';
    return $aviso . $c;
}, 20);

// Notícias de campeonato sem clube marcado (CBF, FPF, tabela, regulamento) entram no bloco do campeonato (08/11/2026)
function tsp_campeonatos_do_bloco($chave)
{
    $m = array(
        'serie_a' => array('brasileiro-serie-a'),
        'serie_b' => array('brasileiro-serie-b'),
        'fem'     => array('paulistao-feminino', 'brasileirao-feminino', 'copadobrasil-feminina', 'libertadores-feminina', 'copapaulista-feminina', 'copinha-feminina', 'ladies-cup'),
        'd1'      => array('paulistao-a1', 'paulistao', 'paulistao-a'),
        'd2'      => array('paulistao-a2'),
        'd3'      => array('paulistao-a3'),
        'd4'      => array('paulistao-a4'),
        'outros'  => array('paulistao-b1', 'copapaulista'),
    );
    return $m[$chave] ?? array();
}

function tsp_com_federacao($ids, $chave, &$vistos, $total = 9, $max = 2)
{
    $camps = tsp_campeonatos_do_bloco($chave);
    if (!$camps) {
        return $ids;
    }
    $fed = tsp_consulta(array(
        'posts_per_page' => $max,
        'date_query'     => array(array('after' => '7 days ago')),
        'tax_query'      => array('relation' => 'AND',
            array('taxonomy' => 'campeonato', 'field' => 'slug', 'terms' => $camps),
            array('taxonomy' => 'times', 'operator' => 'NOT EXISTS'),
        ),
    ), $vistos);
    if (!$fed) {
        return $ids;
    }
    $todos = array();
    foreach (array_merge($ids, wp_list_pluck($fed, 'ID')) as $i) {
        $todos[(int) $i] = get_post_field('post_date', $i);
    }
    arsort($todos);
    $vistos = array_merge($vistos, wp_list_pluck($fed, 'ID'));
    $fids = wp_list_pluck($fed, 'ID');
    // garante que a notícia do campeonato entra mesmo com o bloco cheio
    $saida = array_slice(array_keys($todos), 0, $total);
    foreach ($fids as $f) {
        if (!in_array($f, $saida, true)) {
            array_pop($saida);
            $saida[] = $f;
        }
    }
    usort($saida, function ($a, $b) use ($todos) {
        return strcmp($todos[$b], $todos[$a]);
    });
    return $saida;
}

/* ---------- Categorias de base (08/11/2026) ----------
 * Matéria de base = título com "Sub-20", "Sub-17" etc., Copinha, ou campeonato de base marcado.
 * Masculina: bloco "Categorias de base" (destaque Sub-20 + destaques Sub-17, Sub-15, Sub-13 e Sub-11).
 * Feminina: bloco "Futebol feminino de base" (1 destaque + 3), o último da home.
 * As matérias de base saem dos outros blocos (não se repetem). */
function tsp_base_categoria($post_id)
{
    $tit = html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8');
    $cat = 0;
    if (preg_match('~\bsub[\s-]?(\d{2})\b~iu', $tit, $m)) {
        $cat = (int) $m[1];
    } elseif (preg_match('~\bcopinha\b|copa s[ãa]o paulo de futebol j[úu]nior~iu', $tit)) {
        $cat = 20;
    }
    if (!$cat) {
        $c = get_the_terms($post_id, 'campeonato');
        foreach ((is_array($c) ? $c : array()) as $t) {
            if (preg_match('~sub-?(\d{2})~', $t->slug, $m)) {
                $cat = (int) $m[1];
            } elseif (in_array($t->slug, array('copinha', 'copinha-feminina', 'brasileirao-aspirantes'), true)) {
                $cat = 20;
            }
        }
    }
    if (!$cat || $cat > 23 || $cat < 9) {
        return null;
    }
    $fem = (bool) preg_match('~feminin|\bmeninas\b~iu', $tit);
    if (!$fem) {
        $tm = get_the_terms($post_id, 'times');
        foreach ((is_array($tm) ? $tm : array()) as $t) {
            if (preg_match('~feminin~', $t->slug)) {
                $fem = true;
            }
        }
    }
    return array('cat' => $cat >= 18 ? 20 : $cat, 'fem' => $fem);
}

// 24/11/2026 (Thiago): seção da Copinha na home, entre o Brasileirão e o feminino.
// Matéria da Copinha masculina (título ou campeonato "copinha"); a Copinha Feminina fica no bloco do feminino.
// Roda antes dos blocos de base, para a Copinha não sumir no bloco "Categorias de base". Sem foto repetida.
function tsp_copinha_ids(&$vistos, $n = 9)
{
    $q = tsp_consulta(array('posts_per_page' => 250, 'date_query' => array(array('after' => '45 days ago')), 'update_post_meta_cache' => false), $vistos);
    $ids = array();
    $fotos = array();
    foreach ($q as $p) {
        $tit = html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8');
        if (preg_match('~feminin|\bmeninas\b~iu', $tit)) {
            continue;
        }
        $ok = (bool) preg_match('~\bcopinha\b|copa s[ãa]o paulo de futebol j[úu]nior~iu', $tit);
        $cs = (array) wp_get_post_terms($p->ID, 'campeonato', array('fields' => 'slugs'));
        if (in_array('copinha-feminina', $cs, true)) {
            continue;
        }
        if (!$ok && !in_array('copinha', $cs, true)) {
            continue;
        }
        $f = tsp_foto_chave($p->ID);
        if ($f && isset($fotos[$f])) {
            continue;
        }
        if ($f) {
            $fotos[$f] = true;
        }
        $ids[] = $p->ID;
        if (count($ids) >= $n) {
            break;
        }
    }
    // 25/11/2026 (Thiago: "não podemos ter espaços em branco"): bloco sempre cheio (1 + 2 + 5). Faltando matéria recente,
    // completa com as mais recentes do campeonato Copinha (guia, história, curiosidades), sem feminina e sem foto repetida.
    if (count($ids) < $n) {
        $mais = tsp_consulta(array('posts_per_page' => 40, 'tax_query' => array(array('taxonomy' => 'campeonato', 'field' => 'slug', 'terms' => 'copinha')), 'update_post_meta_cache' => false), $vistos);
        foreach ($mais as $p) {
            if (count($ids) >= $n) {
                break;
            }
            if (in_array($p->ID, $ids, true) || preg_match('~feminin|\bmeninas\b~iu', html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'))) {
                continue;
            }
            $f = tsp_foto_chave($p->ID);
            if ($f && isset($fotos[$f])) {
                continue;
            }
            if ($f) {
                $fotos[$f] = true;
            }
            $ids[] = $p->ID;
        }
    }
    $vistos = array_merge($vistos, $ids);
    return $ids;
}

// Matéria de futebol feminino (pelo time marcado ou pelo título) fica fora dos blocos masculinos
function tsp_reservar_femininas(&$vistos)
{
    $q = tsp_consulta(array('posts_per_page' => 200, 'date_query' => array(array('after' => '10 days ago')), 'update_post_meta_cache' => false), $vistos);
    foreach ($q as $p) {
        $fem = (bool) preg_match('~feminin|\bsereias\b|\bbrabas\b|\bbragantinas\b|\bmeninas\b|\bguerreiras\b~iu', get_the_title($p));
        if (!$fem) {
            foreach ((array) wp_get_post_terms($p->ID, 'times', array('fields' => 'slugs')) as $s) {
                if (is_string($s) && strpos($s, 'feminin') !== false) {
                    $fem = true;
                    break;
                }
            }
        }
        if ($fem) {
            $vistos[] = $p->ID;
        }
    }
}

// Mesma foto enviada duas vezes (outro anexo, mesmo arquivo): compara o nome do arquivo sem tamanho/sufixo
function tsp_foto_chave($post_id)
{
    $f = (int) get_post_thumbnail_id($post_id);
    if (!$f) {
        return '';
    }
    // 25/11/2026: a mesma imagem enviada para matérias diferentes ganha nomes diferentes (nome da matéria);
    // então a chave é o tamanho do arquivo + largura x altura, que são iguais quando a foto é a mesma
    $md = wp_get_attachment_metadata($f);
    if (is_array($md) && !empty($md['filesize']) && !empty($md['width'])) {
        return 'f' . (int) $md['filesize'] . 'x' . (int) $md['width'] . 'x' . (int) ($md['height'] ?? 0);
    }
    $u = (string) wp_get_attachment_url($f);
    $b = strtolower(pathinfo(wp_parse_url($u, PHP_URL_PATH), PATHINFO_FILENAME));
    return preg_replace('~(-\d+x\d+|-scaled|-e\d{10,}|-\d{1,2})+$~', '', $b);
}

function tsp_base_ids(&$vistos)
{
    $q = tsp_consulta(array('posts_per_page' => 300, 'date_query' => array(array('after' => '21 days ago')), 'update_post_meta_cache' => false), $vistos);
    $r = array('sub20' => array(), 'menores' => array(), 'fem' => array());
    $por_cat = array();
    $fotos = array(); // 20/11/2026: a mesma foto não aparece duas vezes no bloco (matérias do mesmo jogo)
    foreach ($q as $p) {
        $b = tsp_base_categoria($p->ID);
        if (!$b) {
            continue;
        }
        $f = tsp_foto_chave($p->ID);
        if ($f && isset($fotos[$f])) {
            continue;
        }
        if ($f) {
            $fotos[$f] = true;
        }
        if ($b['fem']) {
            $r['fem'][] = $p->ID;
        } elseif ($b['cat'] === 20) {
            $r['sub20'][] = $p->ID;
        } else {
            $por_cat[$b['cat'] >= 16 ? 17 : ($b['cat'] >= 14 ? 15 : ($b['cat'] >= 12 ? 13 : 11))][] = $p->ID;
        }
    }
    // Sub-bloco: a mais nova de cada categoria (Sub-17, Sub-15, Sub-13, Sub-11) e depois completa com as seguintes
    $r['menores'] = array();
    foreach (array(17, 15, 13, 11) as $c) {
        if (!empty($por_cat[$c])) {
            $r['menores'][] = array_shift($por_cat[$c]);
        }
    }
    $sobra = array();
    foreach ($por_cat as $ids) {
        $sobra = array_merge($sobra, $ids);
    }
    rsort($sobra);
    $r['menores'] = array_slice(array_merge($r['menores'], $sobra), 0, 4);
    // Grade de baixo sempre com 4: se faltar matéria das categorias menores, completa com as Sub-20 seguintes
    $sub20_extra = array_slice($r['sub20'], 4);
    $r['sub20'] = array_slice($r['sub20'], 0, 4);
    while (count($r['menores']) < 4 && $sub20_extra) {
        $r['menores'][] = array_shift($sub20_extra);
    }
    $r['fem'] = array_slice($r['fem'], 0, 4);
    // Todas as de base ficam fora dos outros blocos (não só as que aparecem)
    foreach ($q as $p) {
        if (tsp_base_categoria($p->ID)) {
            $vistos[] = $p->ID;
        }
    }
    return $r;
}

function tsp_bloco_base($base)
{
    if (!$base['sub20'] && !$base['menores']) {
        return;
    }
    echo '<section class="tsp-secao" id="categorias-de-base" aria-labelledby="h-base">';
    tsp_secao_cab('Categorias de base', '', array(), 'Futebol paulista Sub-20, Sub-17, Sub-15, Sub-13 e Sub-11', 'h-base');
    if ($base['sub20']) {
        echo '<h3 class="tsp-sub-bloco">Sub-20</h3>';
        tsp_layout_b($base['sub20']);
    }
    if ($base['menores']) {
        echo '<h3 class="tsp-sub-bloco">Sub-17, Sub-15, Sub-13 e Sub-11</h3><div class="tsp-grade tsp-grade--' . max(2, min(4, count($base['menores']))) . '">';
        foreach ($base['menores'] as $id) {
            tsp_card($id, 'grade');
        }
        echo '</div>';
    }
    echo '</section>';
}

function tsp_bloco_base_fem($ids)
{
    if (!$ids) {
        return;
    }
    echo '<section class="tsp-secao" id="feminino-base" aria-labelledby="h-fem-base">';
    tsp_secao_cab('Futebol feminino de base', '', array(), 'Sub-20, Sub-17 e categorias menores', 'h-fem-base');
    tsp_layout_b($ids);
    echo '</section>';
}

/* ---------- Tabela + jogos no estilo do ge (09-10/11/2026) ----------
 * Esquerda: classificação com escudo, P J V E D GP GC SG % e últimos jogos, setinha de subiu/caiu e cor das zonas.
 * Direita: "Jogos" com escudos, estádio, dia e hora, navegando por TODAS as rodadas; abre na rodada atual. */
function tsp_ge_escudo($id, $nome, $tam = 24)
{
    if ($id && function_exists('tsp_jogos_escudo_html')) {
        $h = tsp_jogos_escudo_html((int) $id, $nome);
        if ($h && strpos($h, '<img') !== false) {
            return '<span class="tsp-ge__esc">' . $h . '</span>';
        }
    }
    // Sem id (tabela feminina, por exemplo): procura o clube pelo nome
    $t = get_term_by('name', $nome, 'times');
    if (!$t) {
        $t = get_term_by('slug', sanitize_title($nome), 'times');
    }
    if ($t && function_exists('tsp_escudo_url') && tsp_escudo_url($t)) {
        return '<span class="tsp-ge__esc">' . tsp_escudo($t, $tam) . '</span>';
    }
    return '<span class="tsp-ge__esc tsp-ge__esc--vazio" aria-hidden="true"></span>';
}

function tsp_tabela_ge_tabela($serie, $titulo = 'Tabela')
{
    $tabs = tsp_dado('tabelas');
    $t = $tabs[$serie] ?? array();
    if (empty($t['linhas'])) {
        return '';
    }
    $tem_gols = false;
    $tem_forma = false;
    foreach ($t['linhas'] as $r) {
        $tem_gols = $tem_gols || (isset($r[9]) && is_numeric($r[9]) && ((int) $r[9] || (int) ($r[10] ?? 0)));
        $tem_forma = $tem_forma || !empty($r[8]) && preg_match('~^[VED]+$~', (string) $r[8]);
    }
    $sp = tsp_paulistas_tabela($serie);
    $h = '<div class="tsp-ge__tabela">' . ($titulo ? '<h3 class="tsp-ge__tit">' . esc_html($titulo) . '</h3>' : '') . '<div class="tsp-rolagem"><table class="tsp-ge__tab"><thead><tr><th class="tsp-ge__pos" colspan="2">Classificação</th><th title="Pontos">P</th><th title="Jogos">J</th><th title="Vitórias">V</th><th title="Empates">E</th><th title="Derrotas">D</th>' . ($tem_gols ? '<th title="Gols pró">GP</th><th title="Gols contra">GC</th>' : '') . '<th title="Saldo de gols">SG</th><th title="Aproveitamento">%</th>' . ($tem_forma ? '<th class="tsp-ge__ult">Últ. jogos</th>' : '') . '</tr></thead><tbody>';
    foreach ($t['linhas'] as $r) {
        if (!is_array($r) || count($r) < 8) {
            continue;
        }
        $p = (int) $r[0];
        $var = (int) ($r[12] ?? 0);
        $seta = $var > 0 ? '<span class="tsp-ge__var tsp-ge__var--sobe" title="Subiu ' . $var . '">▲' . $var . '</span>' : ($var < 0 ? '<span class="tsp-ge__var tsp-ge__var--cai" title="Caiu ' . abs($var) . '">▼' . abs($var) . '</span>' : '');
        $link = strpos((string) $serie, 'fem') === 0 ? tsp_link_time_fem($r[1]) : tsp_link_time($r[1]); // 24/11/2026: tabela feminina leva à página do time feminino
        $nome = '<span class="tsp-ge__nome">' . ($link ? '<a href="' . esc_url($link) . '">' . esc_html($r[1]) . '</a>' : esc_html($r[1])) . '</span>';
        $pct = (int) $r[3] ? round((int) $r[2] / ((int) $r[3] * 3) * 100) : 0;
        $cor = tsp_zona_cor($serie, $p);
        $sg = (int) $r[7];
        $h .= '<tr' . (in_array($r[1], $sp, true) ? ' class="tsp-sp"' : '') . '><td class="tsp-ge__n"' . ($cor !== 'transparent' ? ' style="box-shadow:inset 4px 0 0 ' . esc_attr($cor) . '"' : '') . '><span class="tsp-ge__pos-n"' . ($cor !== 'transparent' ? ' style="background:' . esc_attr($cor) . ';color:#fff"' : '') . '>' . $p . '</span></td><td class="tsp-ge__time"><span class="tsp-ge__timein">' . tsp_ge_escudo($r[11] ?? 0, $r[1]) . $nome . $seta . '</span></td><td class="tsp-ge__p">' . (int) $r[2] . '</td><td>' . (int) $r[3] . '</td><td>' . (int) $r[4] . '</td><td>' . (int) $r[5] . '</td><td>' . (int) $r[6] . '</td>' . ($tem_gols ? '<td>' . (int) $r[9] . '</td><td>' . (int) ($r[10] ?? 0) . '</td>' : '') . '<td>' . ($sg > 0 ? '+' . $sg : $sg) . '</td><td>' . $pct . '</td>' . ($tem_forma ? '<td class="tsp-ge__ult">' . tsp_forma_html($r[8] ?? '') . '</td>' : '') . '</tr>';
    }
    return $h . '</tbody></table></div>' . tsp_legenda($serie) . (!empty($t['nota']) ? '<p class="tsp-nota">' . esc_html($t['nota']) . '</p>' : '') . '</div>';
}

function tsp_tabela_ge($serie)
{
    $todas = tsp_dado('rodadas');
    $rd = $todas[$serie] ?? array();
    $tab = tsp_tabela_ge_tabela($serie);
    if (!$tab && empty($rd['rodadas'])) {
        return '';
    }
    $h = '<div class="tsp-ge">' . $tab;
    if (!empty($rd['rodadas'])) {
        $rods = $rd['rodadas'];
        $atual = min(count($rods) - 1, max(0, (int) ($rd['atual'] ?? 0)));
        $h .= '<div class="tsp-ge__jogos" data-rodadas><h3 class="tsp-ge__tit">Jogos</h3><div class="tsp-ge__nav"><button type="button" class="tsp-rodadas__seta" data-dir="-1" aria-label="Rodada anterior">‹</button><strong data-titulo>' . esc_html($rods[$atual]['titulo']) . '</strong><button type="button" class="tsp-rodadas__seta" data-dir="1" aria-label="Próxima rodada">›</button></div>';
        foreach ($rods as $i => $r) {
            $h .= '<ul class="tsp-rodadas__lista tsp-ge__lista" data-titulo="' . esc_attr($r['titulo']) . '"' . ($i === $atual ? '' : ' hidden') . '>';
            foreach ($r['jogos'] as $g) {
                $fim = $g['status'] === 'fim';
                $pl = $g['placar'] !== '' ? str_replace(' x ', '<i>×</i>', esc_html($g['placar'])) : '<i>×</i>';
                $link = $g['materia'] ?: $g['jogo'];
                $rot = $fim ? 'Saiba como foi' : ($g['status'] === 'vai' ? 'Fique por dentro' : $g['status']);
                $info = !empty($g['quando']) ? $g['quando'] : $g['dia'];
                $h .= '<li class="tsp-ge__jogo"><div class="tsp-ge__info">' . (!empty($g['estadio']) ? '<span>' . esc_html($g['estadio']) . '</span>' : '') . '<span>' . esc_html($info) . '</span></div>';
                $h .= '<div class="tsp-ge__linha"><span class="tsp-ge__c"><span class="tsp-ge__tn">' . esc_html($g['casa']) . '</span>' . tsp_ge_escudo($g['casa_id'] ?? 0, $g['casa'], 30) . '</span><span class="tsp-ge__pl' . ($fim ? ' tsp-ge__pl--fim' : '') . '">' . $pl . '</span><span class="tsp-ge__f">' . tsp_ge_escudo($g['fora_id'] ?? 0, $g['fora'], 30) . '<span class="tsp-ge__tn">' . esc_html($g['fora']) . '</span></span></div>';
                $h .= $link ? '<a class="tsp-ge__mais" href="' . esc_url($link) . '">' . esc_html($rot) . '</a>' : '';
                $h .= '</li>';
            }
            $h .= '</ul>';
        }
        $h .= '</div>';
    }
    return $h . '</div>';
}

// Página do time feminino pelo nome do clube ("Corinthians" → Corinthians Feminino); sem página feminina, nada de link para o masculino
function tsp_link_time_fem($nome)
{
    $t = get_term_by('name', $nome . ' Feminino', 'times');
    if (!$t) {
        $t = get_term_by('slug', sanitize_title(remove_accents($nome)) . '-feminino', 'times');
    }
    if (!$t) {
        $m = get_term_by('name', $nome, 'times');
        if ($m) {
            $t = get_term_by('slug', $m->slug . '-feminino', 'times');
        }
    }
    return ($t && !is_wp_error($t)) ? get_term_link($t) : '';
}
