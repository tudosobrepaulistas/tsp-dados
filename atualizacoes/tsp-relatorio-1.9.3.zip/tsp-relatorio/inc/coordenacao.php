<?php
/**
 * Função "Coordenador(a) de redação": edita, agenda e publica matérias de todos os redatores,
 * edita o perfil dos redatores (nome, bio, foto, redes, times que cobre — sem senha, e-mail ou função),
 * vê o relatório da equipe inteira (sem valores em R$), avalia matérias (devolutivas) e vê pautas.
 * NÃO mexe no site: sem plugins, tema, configurações, usuários, páginas, menus, banners,
 * blocos da home, categorias/times nem código HTML livre.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_rel_coord($user_id = 0)
{
    $user_id = $user_id ?: get_current_user_id();
    return $user_id && (user_can($user_id, 'manage_options') || user_can($user_id, 'tsp_coordenar'));
}

function tsp_rel_caps_coordenador()
{
    return array(
        'read' => true, 'upload_files' => true, 'moderate_comments' => true, 'tsp_coordenar' => true,
        'list_users' => true, 'edit_users' => true, 'promote_users' => false, 'create_users' => false, 'delete_users' => false, 'remove_users' => false,
        'edit_posts' => true, 'edit_others_posts' => true, 'edit_published_posts' => true, 'edit_private_posts' => true,
        'publish_posts' => true, 'read_private_posts' => true,
        'delete_posts' => true, 'delete_others_posts' => true, 'delete_published_posts' => true, 'delete_private_posts' => true,
        'unfiltered_html' => false, 'manage_categories' => false, 'edit_pages' => false, 'edit_theme_options' => false,
    );
}

// Cria/atualiza a função quando a versão do plugin muda
add_action('init', function () {
    if (get_option('tsp_rel_coord_v') === '2') {
        return;
    }
    remove_role('tsp_coordenador');
    add_role('tsp_coordenador', 'Coordenador(a) de redação', tsp_rel_caps_coordenador());
    update_option('tsp_rel_coord_v', '2', false);
});

// Coordenação conta como redator no pagamento (escreve também), mas sem acesso a valores dos outros.

// Coordenação só edita perfis de redatores (nunca de administradores ou de outra coordenação) e não apaga nem muda função
add_filter('map_meta_cap', function ($caps, $cap, $user_id, $args) {
    if (!in_array($cap, array('edit_user', 'delete_user', 'promote_user', 'remove_user'), true) || user_can($user_id, 'manage_options') || !user_can($user_id, 'tsp_coordenar')) {
        return $caps;
    }
    $alvo = (int) ($args[0] ?? 0);
    if ($cap !== 'edit_user') {
        return array('do_not_allow');
    }
    if ($alvo && $alvo !== (int) $user_id && (user_can($alvo, 'manage_options') || user_can($alvo, 'tsp_coordenar'))) {
        return array('do_not_allow');
    }
    return $caps;
}, 10, 4);

function tsp_rel_coord_editando_outro($alvo)
{
    $eu = get_current_user_id();
    return $eu && (int) $alvo !== $eu && !current_user_can('manage_options') && current_user_can('tsp_coordenar');
}

// Sem senha e sem e-mail de outra pessoa (evita que a conta do redator troque de dono)
add_filter('show_password_fields', function ($mostrar, $perfil = null) {
    return ($perfil && tsp_rel_coord_editando_outro($perfil->ID)) ? false : $mostrar;
}, 10, 2);
add_filter('wp_pre_insert_user_data', function ($dados, $atualizando, $user_id) {
    if ($atualizando && $user_id && tsp_rel_coord_editando_outro($user_id)) {
        $antes = get_userdata($user_id);
        if ($antes) {
            $dados['user_email'] = $antes->user_email;
            $dados['user_pass'] = $antes->user_pass;
            $dados['user_login'] = $antes->user_login;
        }
    }
    return $dados;
}, 10, 3);
add_action('admin_head-user-edit.php', function () {
    if (!empty($_GET['user_id']) && tsp_rel_coord_editando_outro((int) $_GET['user_id'])) {
        echo '<style>.user-email-wrap input,#email{pointer-events:none;background:#f0f0f1}.user-role-wrap{display:none}</style>';
    }
});
