<?php
/**
 * Audiência interna (08/11/2026): cliques por matéria contados pelo próprio site, sem custo e sem serviço de fora.
 *  - Cada leitura real conta 1 vez por pessoa e por sessão (robôs e o tráfego automático estrangeiro ficam de fora,
 *    pelo mesmo filtro do Analytics; só conta quem fica 3 segundos na página).
 *  - Relatório → Audiência: Top do dia, Top do mês e ranking dos redatores (quem traz mais leitores).
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_aud_tabela()
{
    global $wpdb;
    return $wpdb->prefix . 'tsp_views';
}

add_action('init', function () {
    if (get_option('tsp_aud_db') === '1') {
        return;
    }
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta('CREATE TABLE ' . tsp_aud_tabela() . " (
        post_id bigint(20) unsigned NOT NULL,
        dia date NOT NULL,
        n int(10) unsigned NOT NULL DEFAULT 0,
        PRIMARY KEY  (post_id,dia),
        KEY dia (dia)
    ) " . $wpdb->get_charset_collate() . ';');
    update_option('tsp_aud_db', '1', true);
});

add_action('rest_api_init', function () {
    register_rest_route('tsp/v1', '/v', array('methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function ($r) {
        $id = (int) $r->get_param('p');
        $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (!$id || preg_match('~bot|crawl|spider|headless|python|curl|wget|scrap|preview~i', $ua) || get_post_status($id) !== 'publish' || !in_array(get_post_type($id), tsp_rel_tipos(), true)) {
            return new WP_REST_Response(null, 204);
        }
        global $wpdb;
        $wpdb->query($wpdb->prepare('INSERT INTO ' . tsp_aud_tabela() . ' (post_id, dia, n) VALUES (%d, %s, 1) ON DUPLICATE KEY UPDATE n = n + 1', $id, wp_date('Y-m-d')));
        return new WP_REST_Response(null, 204);
    }));
});

// Marcador leve no fim da matéria (funciona mesmo com cache de página)
add_action('wp_footer', function () {
    if (!is_singular(tsp_rel_tipos()) || is_user_logged_in()) {
        return;
    }
    $id = get_queried_object_id();
    $url = esc_url_raw(rest_url('tsp/v1/v?p=' . $id));
    echo "<script>(function(){try{if(window.tspRobo||navigator.webdriver)return;var k='tspv" . (int) $id . "';if(sessionStorage.getItem(k))return;setTimeout(function(){if(document.visibilityState==='hidden')return;sessionStorage.setItem(k,1);navigator.sendBeacon?navigator.sendBeacon(" . wp_json_encode($url) . "):fetch(" . wp_json_encode($url) . ",{method:'POST',keepalive:true})},3000)}catch(e){}})();</script>\n";
}, 99);

function tsp_aud_top($de, $ate, $lim = 20)
{
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare('SELECT post_id, SUM(n) AS v FROM ' . tsp_aud_tabela() . ' WHERE dia BETWEEN %s AND %s GROUP BY post_id ORDER BY v DESC LIMIT %d', $de, $ate, $lim));
}

function tsp_aud_redatores($de, $ate)
{
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare('SELECT p.post_author AS autor, SUM(v.n) AS v, COUNT(DISTINCT v.post_id) AS mats FROM ' . tsp_aud_tabela() . " v JOIN {$wpdb->posts} p ON p.ID = v.post_id WHERE v.dia BETWEEN %s AND %s GROUP BY p.post_author ORDER BY v DESC", $de, $ate));
    // matérias publicadas no período (para a média por matéria nova)
    foreach ($rows as $r) {
        $r->novas = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_author = %d AND post_status = 'publish' AND post_type IN ('materia','post') AND post_date BETWEEN %s AND %s", $r->autor, $de . ' 00:00:00', $ate . ' 23:59:59'));
    }
    return $rows;
}

add_action('admin_menu', function () {
    add_submenu_page('tsp-relatorio', 'Audiência', '📈 Audiência', 'edit_posts', 'tsp-audiencia', 'tsp_aud_tela');
}, 20);

function tsp_aud_tela()
{
    if (!current_user_can('manage_options') && !(function_exists('tsp_rel_coord') && tsp_rel_coord())) {
        wp_die('Só a coordenação e o administrador veem a audiência.');
    }
    $hoje = wp_date('Y-m-d');
    $ontem = wp_date('Y-m-d', time() - DAY_IN_SECONDS);
    $mes = wp_date('Y-m-01');
    $mes_ant_ini = wp_date('Y-m-01', strtotime('first day of last month', current_time('timestamp')));
    $mes_ant_fim = wp_date('Y-m-t', strtotime('first day of last month', current_time('timestamp')));
    $lista = function ($rows, $titulo) {
        echo '<div class="tsp-aud-caixa"><h2>' . esc_html($titulo) . '</h2>';
        if (!$rows) {
            echo '<p>Ainda sem leituras contadas.</p></div>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr><th>#</th><th>Matéria</th><th>Autor</th><th style="text-align:right">Cliques</th></tr></thead><tbody>';
        foreach ($rows as $i => $r) {
            $p = get_post($r->post_id);
            if (!$p) {
                continue;
            }
            echo '<tr><td>' . ($i + 1) . '</td><td><a href="' . esc_url(get_permalink($p)) . '" target="_blank">' . esc_html(get_the_title($p)) . '</a><br><small>' . esc_html(get_the_date('d/m H\hi', $p)) . '</small></td><td>' . esc_html(get_the_author_meta('display_name', $p->post_author)) . '</td><td style="text-align:right"><strong>' . number_format_i18n((int) $r->v) . '</strong></td></tr>';
        }
        echo '</tbody></table></div>';
    };
    echo '<div class="wrap"><h1>📈 Audiência das matérias</h1><p>Cliques contados pelo próprio site (pessoas reais, 1 por sessão; robôs fora). Começou a contar em ' . esc_html(get_option('tsp_aud_inicio', $hoje)) . '. Para números oficiais de visitas, o Google Analytics continua valendo.</p>';
    echo '<style>.tsp-aud{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:18px}.tsp-aud-caixa{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:12px 14px}.tsp-aud-caixa h2{margin-top:4px}</style><div class="tsp-aud">';
    $lista(tsp_aud_top($hoje, $hoje), '🔥 Top do dia (hoje)');
    $lista(tsp_aud_top($ontem, $ontem, 10), 'Top de ontem');
    $lista(tsp_aud_top($mes, $hoje), '🏆 Top do mês');
    echo '<div class="tsp-aud-caixa"><h2>✍️ Redatores que mais trazem leitores (mês)</h2>';
    $red = tsp_aud_redatores($mes, $hoje);
    if (!$red) {
        echo '<p>Ainda sem leituras contadas.</p>';
    } else {
        echo '<table class="widefat striped"><thead><tr><th>#</th><th>Autor</th><th style="text-align:right">Cliques no mês</th><th style="text-align:right">Matérias lidas</th><th style="text-align:right">Publicadas no mês</th><th style="text-align:right">Média por matéria</th></tr></thead><tbody>';
        foreach ($red as $i => $r) {
            $u = get_userdata($r->autor);
            $nome = $u ? $u->display_name : '—';
            $robo = $u && (user_can($u, 'manage_options') || $u->user_login === 'tsp');
            echo '<tr><td>' . ($i + 1) . '</td><td>' . esc_html($nome) . ($robo ? ' <small>(Máquina/Redação)</small>' : '') . '</td><td style="text-align:right"><strong>' . number_format_i18n((int) $r->v) . '</strong></td><td style="text-align:right">' . (int) $r->mats . '</td><td style="text-align:right">' . (int) $r->novas . '</td><td style="text-align:right">' . number_format_i18n($r->mats ? $r->v / $r->mats : 0, 1) . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';
    $lista(tsp_aud_top($mes_ant_ini, $mes_ant_fim, 10), 'Top do mês passado');
    echo '</div></div>';
}

add_action('init', function () {
    if (!get_option('tsp_aud_inicio')) {
        update_option('tsp_aud_inicio', wp_date('d/m/Y'), false);
    }
});
