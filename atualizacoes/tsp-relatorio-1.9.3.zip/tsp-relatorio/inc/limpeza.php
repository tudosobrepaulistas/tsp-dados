<?php
/**
 * Limpeza de restos de IA/prompt (08/11/2026, pedido do Thiago).
 * Toda matéria (redator, Máquina, Redação) passa por aqui ao salvar. Sai do texto, sem mexer no resto:
 *  - frases de assistente ("Claro! Aqui está...", "Espero que ajude", "Se quiser, posso...", "Como IA...");
 *  - rótulos de prompt ("Título:", "Meta descrição:", "Palavra-chave:", "Slug:", "Tags:", "Prompt:");
 *  - lembretes para preencher ("[inserir link]", "[nome do jogador]");
 *  - marcas do ChatGPT (data-start, oaicite, contentReference, turn0search) e markdown solto (**negrito**, ## título, ---).
 * O que foi limpo fica anotado na matéria (campo tsp_limpeza) para a coordenação ver.
 */

if (!defined('ABSPATH')) {
    exit;
}

function tsp_limpeza_frase_lixo($t)
{
    $t = trim(html_entity_decode(wp_strip_all_tags($t), ENT_QUOTES, 'UTF-8'));
    if ($t === '') {
        return false;
    }
    $p = array(
        '~^(claro|certo|perfeito|[óo]timo|com certeza|beleza|entendido)\s*[!,.:]\s*(aqui|segue|abaixo|vou|posso|preparei|fiz|reescrevi)~iu',
        '~^(aqui est[áa]|segue(m)?(,)? (abaixo|o texto|a mat[ée]ria|uma|um)|abaixo,? (segue|est[áa])|preparei (uma|um|o|a) )~iu',
        '~^(como (um )?(modelo de linguagem|assistente|intelig[êe]ncia artificial|ia\b))~iu',
        '~^(espero que (isso|este texto|a mat[ée]ria)? ?(te )?ajude)~iu',
        '~^(se (voc[êe] )?(quiser|desejar|preferir|precisar)[, ]+(eu )?(posso|fa[çc]o|consigo))~iu',
        '~^(posso (tamb[ée]m )?(ajustar|adaptar|fazer|criar|reescrever|gerar|incluir|sugerir)|quer que eu|deseja que eu|gostaria que eu)~iu',
        '~^(observa[çc][ãa]o|nota|obs)\s*:\s*(este|esse|o) (texto|conte[úu]do|artigo)~iu',
        '~^\**\s*(meta[ -]?descri[çc][ãa]o|palavra[- ]chave( principal| foco)?|slug( sugerido)?|tags?( sugeridas)?|sugest[ãa]o de t[íi]tulo|t[íi]tulo (seo|sugerido|alternativo)|linha fina sugerida|prompt|instru[çc][õo]es?|resumo para redes|legenda para instagram)\s*\**\s*:~iu',
        '~^(vers[ãa]o (reescrita|otimizada|revisada)( para seo)?\s*:?)$~iu',
        '~^(-{3,}|\*{3,}|_{3,})$~u',
    );
    foreach ($p as $re) {
        if (preg_match($re, $t)) {
            return true;
        }
    }
    return false;
}

function tsp_limpeza_texto($html, &$n)
{
    $antes = $html;
    // Marcas do ChatGPT
    $html = preg_replace('~\s(data-(start|end|pm-slice|is-last-node|is-only-node|path-to-node|index-in-node))="[^"]*"~i', '', $html);
    $html = preg_replace('~:?contentReference\[oaicite:\d+\]\{index=\d+\}|\[?oaicite:\d+\]?|【[^】]*†[^】]*】|\bturn\d+(search|news|view)\d+\b~u', '', $html);
    // Lembretes para preencher
    $html = preg_replace('~\[\s*(inserir|insira|adicionar|adicione|colocar|coloque|link|nome d[oa]|data d[oa]|fonte|citar)\b[^\]]{0,60}\]~iu', '', $html);
    $html = preg_replace('~ +([.,;])~u', '$1', $html);
    $html = preg_replace('~\(\s*(inserir|insira|adicionar|adicione|colocar|coloque)\b[^)]{0,60}\)~iu', '', $html);
    // Parágrafos/linhas que são conversa de assistente ou rótulo de prompt
    $html = preg_replace_callback('~<(p|h[1-6]|li|div)\b[^>]*>(.*?)</\1>~isu', function ($m) {
        return tsp_limpeza_frase_lixo($m[2]) ? '' : $m[0];
    }, $html);
    if (strpos($html, '<') === false || !preg_match('~<(p|h\d|li|div)\b~i', $html)) {
        $linhas = preg_split("~\r?\n~", $html);
        $linhas = array_filter($linhas, function ($l) {
            return !tsp_limpeza_frase_lixo($l);
        });
        $html = implode("\n", $linhas);
    }
    // Markdown solto: **negrito** → <strong>, "## Título" no começo do parágrafo → só o texto
    $html = preg_replace('~\*\*([^*\n<]{1,200})\*\*~u', '<strong>$1</strong>', $html);
    $html = preg_replace('~(<(p|h[1-6]|li)\b[^>]*>|^|\n)\s*#{1,6}\s+~u', '$1', $html);
    // Blocos do editor que ficaram vazios
    $html = preg_replace('~<!-- wp:(paragraph|heading|list-item)[^>]*-->\s*<!-- /wp:\1 -->\s*~', '', $html);
    $html = preg_replace('~<(p|li)\b[^>]*>\s*(&nbsp;|\s)*</\1>~i', '', $html);
    if ($html !== $antes) {
        $n++;
    }
    return $html;
}

function tsp_limpeza_titulo($t, &$n)
{
    $novo = trim(preg_replace('~^\s*\**\s*(t[íi]tulo( seo| sugerido| da mat[ée]ria)?|headline|manchete)\s*\**\s*:\s*~iu', '', $t));
    $novo = trim(preg_replace('~^\*\*(.+)\*\*$~u', '$1', $novo));
    $novo = preg_replace('~^["“](.+)["”]$~u', '$1', $novo);
    if ($novo !== $t) {
        $n++;
    }
    return $novo;
}

add_filter('wp_insert_post_data', function ($data, $postarr) {
    if (!in_array($data['post_type'], tsp_rel_tipos(), true) || in_array($data['post_status'], array('auto-draft', 'trash', 'inherit'), true)) {
        return $data;
    }
    $n = 0;
    $c = tsp_limpeza_texto(wp_unslash($data['post_content']), $n);
    $t = tsp_limpeza_titulo(wp_unslash($data['post_title']), $n);
    $e = $data['post_excerpt'] !== '' ? tsp_limpeza_titulo(tsp_limpeza_texto(wp_unslash($data['post_excerpt']), $n), $n) : '';
    if ($n) {
        $data['post_content'] = wp_slash($c);
        $data['post_title'] = wp_slash($t);
        $data['post_excerpt'] = wp_slash($e);
        if (!empty($postarr['ID'])) {
            update_post_meta((int) $postarr['ID'], 'tsp_limpeza', array('em' => time(), 'por' => get_current_user_id()));
        }
    }
    return $data;
}, 5, 2);
